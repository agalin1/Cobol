000100******************************************************************00010003
000200*                                                                *00020003
000300* NOMBRE DEL OBJETO:  UGTCGAR                                    *00030003
000400*                                                                *00040003
000500* DESCRIPCION:      TABLA DE GARANTIAS A NIVEL ENTIDAD           *00050003
000600* --------------------------------------------------------       *00060003
000700*                                                                *00070003
000800* TABLA DE CODIGOS DE TODAS LAS GARANTIAS EXISTENTES EN          *00080003
000900* LA ENTIDAD.                                                    *00090003
001000*                                                                *00100003
001100*                                                                *00110003
001200*                                                                *00120003
001300*                   **----------------------------------------** *00130003
001400*                   **---     CLAVE CODIGO DE GARANTIA     ---** *00140003
001500*                   **----------------------------------------** *00150003
001600* CLAVE                                                          100160003
001700* CODIGAR           CODIGO DE GARANTIA                           100170003
001800*                   **----------------------------------------** *00180003
001900*                   **---          DESCRIPCION             ---** *00190003
002000*                   **----------------------------------------** *00200003
002100* DESCRIPCION                                                    400210003
002200* TEXTOLAR          DESCRIPCION DE LA GARANTIA                   400220003
002300* TEXTORED          DESCRIPCION REDUCIDA DE LA GARANTIA         5400230003
002400*                   **----- STAMP DE ULTIMA MODIFICACION -----** *00240003
002500* STAMP-UMO                                                     6900250003
002600* ENTIDAD-UMO       ENTIDAD QUE REALIZO LA ULTIMA MODIFICACION  6900260003
002700* CENTRO-UMO        CENTRO QUE REALIZO LA ULTIMA MODIFICACION   7300270003
002800* USERID-UMO        USUARIO QUE REALIZO LA ULTIMA MODIFICACION  7700280003
002900* NETNAME-UMO       TERMINAL QUE REALIZO LA ULTIMA MODIFICACION 8500290003
003000* TIMESTAMP         FECHA Y HORA DE LA ULTIMA MODIFICACION      9300300003
003100***-----------------------------------------------------------** *00310003
003200**MOD.JFM.08/05/98  **SE AGREGAN ATRIBUTOS DE GARANTIA.BGAN01-** *00320003
003300***-----------------------------------------------------------** *00330003
003400*                                                                400340003
003500* PORGAR            PORCENTAJE DE GARANTIA                       400350006
003800* GRADGAR           GRADOS DE GARANTIA. SE REDEFINEN POR:        400380008
003810* COBGAR            COBERTURA DE LA GARANTIA                     400381008
003900*                   <L> LIMITADA                                 400390003
004000*                   <I> ILIMITADA                                400400003
004100* CLAGAR            CLASE DE LA GARANTIA                         400410003
004100* GRUP0             GRUPO DE LA GARANTIA                         400411011
003900*                   <A> ADMISIBLE                                400412010
004000*                   <N> NO ADMISIBLE                             400413010
004200******************************************************************00420003
004300                                                                  00430003
004400 01 UGTCGAR.                                                      00440003
004500*          **----------------------------------------**           00450003
004600*          **---     CLAVE CODIGO DE GARANTIA     ---**           00460003
004700*          **----------------------------------------**           00470003
004800    05 GAR-CLAVE.                                                 00480003
004900       10 GAR-CODIGAR                 PIC X(03).                  00490003
005000*          **----------------------------------------**           00500003
005100*          **---          DESCRIPCION             ---**           00510003
005200*          **----------------------------------------**           00520003
005300    05 GAR-DESCRIPCION.                                           00530003
005400       10 GAR-TEXTOLAR                PIC X(50).                  00540003
005500       10 GAR-TEXTORED                PIC X(15).                  00550003
005600*          **----- STAMP DE ULTIMA MODIFICACION -----**           00560003
005700    05 GAR-STAMP-UMO.                                             00570003
005800       10 GAR-ENTIDAD-UMO             PIC X(04).                  00580003
005900       10 GAR-CENTRO-UMO              PIC X(04).                  00590003
006000       10 GAR-USERID-UMO              PIC X(08).                  00600003
006100       10 GAR-NETNAME-UMO             PIC X(08).                  00610003
006200       10 GAR-TIMESTAMP               PIC X(26).                  00620003
006300    05 GAR-ATRIBUTOS.                                             00630003
006310       10 GAR-GRADGAR                 PIC X(01).                  00631008
006320       10 GAR-COBGAR REDEFINES GAR-GRADGAR PIC X(01).             00632008
006400       10 GAR-PORGAR       PIC S9(3)V9(4) USAGE COMP-3.           00640007
006600       10 GAR-CLAGAR                  PIC X(01).                  00660003
006600       10 GAR-GRUPO                   PIC X(01).                  00661009
006700                                                                  00670003
006800******************************************************************00680003
006900*                                                                *00690003
007000*         LONGITUD TOTAL DEL REGISTRO EN BYTES :    121          *00700003
007100*                                                                *00710003
007200******************************************************************00720003