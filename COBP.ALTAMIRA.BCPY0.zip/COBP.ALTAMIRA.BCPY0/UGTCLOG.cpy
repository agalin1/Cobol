      ******************************************************************
      *                                                                *
      * NOMBRE DEL OBJETO:  UGTCLOG                                    *
      *                                                                *
      * DESCRIPCION:     TABLA  LOG DE PRESTAMOS                       *
      * ---------------------------------------------------------------*
      *   BBVA               --- PRESTAMOS ALTAMIRA ---
      *                                                                *
      ******************************************************************
      * DESCRIPCION DE CAMPOS                                          *
      ******************************************************************
      *    LOG_ENTIOFI                ENTIDAD DE ALTA DE LA CUENTA
      *    LOG_CUENTA                 NUMERO DE CUENTA
      *    LOG_TIMESTAMP              FECHA Y HORA DEL EVENTO
      *    LOG_CODIGO                 CODIGO DEL EVENTO
      *    LOG_FECMOV                 FECHA DE MOVIMIENTO
      *    LOG_CONSOPE                CONSECUTIVO DE LA OPERACION
      *    LOG_FECANT                 FECHA ANTERIOR
      *    LOG_IMPANT                 IMPORTE ANTERIOR
      *    LOG_CARANT                 CAMPO CARACTERES ANTERIOR
      *    LOG_TASA_ANT               VALOR TASA ANTERIOR
      *    LOG_FECNUE                 FECHA NUEVA
      *    LOG_IMPNUE                 IMPORTE NUEVO
      *    LOG_CARNUE                 CAMPO CARACTERES NUEVO
      *    LOG_TASA_NUE               VALOR TASA NUEVO
      *    LOG_TABLA                  TABLA MODIFICADA
      *    LOG_COLUMNA                COLUMNA MODIFICADA
      *    LOG_DESCRIPCION            DESCRIPCION EVENTO
      *    LOG_ENTIDAD_UMO            ENTIDAD QUE MODIFICA
      *    LOG_CENTRO_UMO             CENTRO QUE MODIFICA
      *    LOG_USERID_UMO             USUARIO QUE MODIFICA
      *    LOG_NETNAME_UMO            TERMINAL O PROGRAMA QUE MODIF
      ******************************************************************
       01 UGTCLOG.
             03 LOG-ENTIOFI         PIC X(8).
             03 LOG-CUENTA          PIC X(10).
             03 LOG-TIMESTAMP       PIC X(26).
             03 LOG-CODIGO          PIC X(4).
             03 LOG-FECMOV          PIC X(10).
             03 LOG-CONSOPE         PIC S9(5)V USAGE COMP-3.
             03 LOG-FECANT          PIC X(10).
             03 LOG-IMPANT          PIC S9(13)V9(2) USAGE COMP-3.
             03 LOG-CARANT          PIC X(30).
             03 LOG-TASA-ANT        PIC S9(3)V9(5) USAGE COMP-3.
             03 LOG-FECNUE          PIC X(10).
             03 LOG-IMPNUE          PIC S9(13)V9(2) USAGE COMP-3.
             03 LOG-CARNUE          PIC X(30).
             03 LOG-TASA-NUE        PIC S9(3)V9(5) USAGE COMP-3.
             03 LOG-TABLA           PIC X(7).
             03 LOG-COLUMNA         PIC X(15).
             03 LOG-DESCRIPCION     PIC X(80).
             03 LOG-ENTIDAD-UMO     PIC X(4).
             03 LOG-CENTRO-UMO      PIC X(4).
             03 LOG-USERID-UMO      PIC X(8).
             03 LOG-NETNAME-UMO     PIC X(8).
      *
      ******************************************************************
      *                                                                *
      *         LONGITUD TOTAL DEL REGISTRO EN BYTES :                 *
      *                                                                *
      ******************************************************************