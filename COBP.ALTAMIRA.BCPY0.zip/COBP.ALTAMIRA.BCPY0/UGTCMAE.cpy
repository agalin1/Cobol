000100******************************************************************00010000
000200*                                                                *00020000
000300* NOMBRE DEL OBJETO:  UGTCMAE                                    *00030000
000400*                                                                *00040000
000500* DESCRIPCION:     TABLA DE CONTRATOS DE PRESTAMOS               *00050000
000600* --------------------------------------------------------       *00060000
000700*                                                                *00070000
000800* CONTRATOS DE PRESTAMOS. CONTIENE UNA FILA POR                  *00080000
000900* CADA PROPUESTA DE CONTRATO DE PRESTAMO O CONTRATO DE           *00090000
001000* PRESTAMO FORMALIZADO, CON SUS DATOS BASICOS.                   *00100000
001100*                                                                *00110000
001200*                                                                *00120000
001300*                   **----------------------------------------** *00130000
001400*                   **---    CODIGO DE CUENTA CLIENTE      ---** *00140000
001500*                   **----------------------------------------** *00150000
001600* CLAVE                                                          *00160000
001700* CCC                                                            *00170000
001800* ENTIOFI           CLAVE DE ENTIDAD Y NUMERO DE OFICINA         *00180000
001900* CUENTA            NUMERO DE CUENTA                             *00190000
002000* DIGICCC1          DIGITO 1 DEL CODIGO CUENTA CLIENTE           *00200000
002100* DIGICCC2          DIGITO 2 DEL CODIGO CUENTA CLIENTE           *00210000
002200*                   **----------------------------------------** *00220000
002300*                   **---    DATOS BASICOS DE LA CUENTA    ---** *00230000
002400*                   **----------------------------------------** *00240000
002500* DATOS-BAS                                                      *00250000
002600* ENOTIT            ENTIDAD/OFICINA TITULAR DE LA CUENTA         *00260000
002700* ENOTITAN          ENTIDAD/OFICINA TITULAR ANTERIOR DE LA CUEN  *00270000
002800* UGNOFRES          ENTIDAD/OFICINA ELEVADA                      *00280000
002900* UGNOFFOR          ENTIDAD/OFICINA FORMALIZADORA                *00290000
003000* PRODUCTO          PRODUCTO                                     *00300000
003100* SUBPRO            SUBPRODUCTO                                  *00310000
003200* CODIGAR           CODIGO DE GARANTIA                           *00320000
003300* CODIDES           CODIGO DE DESTINO                            *00330000
003400* PLAZO             CODIGO DE PLAZO                              *00340000
003500* MONEDA            CODIGO DE DIVISA                             *00350000
003600* TAE               TASA ANUAL EQUIVALENTE                       *00360000
003700*                   ***--------------------------------------*** *00370000
003800*                   ***-      DATOS GENERALES DE LA CTA.    -*** *00380000
003900*                   ***--------------------------------------*** *00390000
004000* DATOS-GENER                                                    *00400000
004100* CAPSOLI           CAPITAL SOLICITADO                           *00410000
004200* IMPCONCE          CAPITAL CONCEDIDO                            *00420000
004300* IMPDISPU          CAPITAL DISPUESTO                            *00430000
004400* FESOLIC           FECHA DE SOLICITUD                           *00440000
004500* FEFORMA           FECHA DE FORMALIZACION                       *00450000
004600* FECAPROBA         FECHA DE APROBACION DE LA PROPUESTA          *00460000
004700* FECPRIAMO         FECHA DE PRIMERA AMORTIZACION                *00470000
004800* FECPRILIQ         FECHA DE PRIMERA LIQUIDACION                 *00480000
004900* FEVENCIN          FECHA DE VENCIMIENTO                         *00490000
005000* SITPRES           CODIGO DE SITUACION DEL PRESTAMO             *00500000
005100* SITPRES-0         <'0'> - EN VIGOR O ACTIVO                    *00510000
005200* SITPRES-1         <'1'> - CANCELADO                            *00520000
005300* SITPRES-2         <'2'> - BLOQUEO JUDICIAL                     *00530000
005400* SITPRES-3         <'3'> - BLOQUEO ADMINISTRATIVO               *00540000
005500* SITPRES-4         <'4'> - MIBOR MARCO ACTIVO                   *00550000
005600* SITPRES-5         <'5'> - MIBOR RETROCEDIDO                    *00560000
005700* SITPRES-7         <'7'> - PROPUESTA EN TRAMITE                 *00570000
005800* SITPRES-8         <'8'> - PROPUESTA APROBADA SIN FORMALIZAR    *00580000
005900* SITPRES-9         <'9'> - PROPUESTA DENEGADA                   *00590000
006000* SITPRES-A         <'A'> - PROPUESTA ANULADA                    *00600000
006100* SITPRES-P         <'P'> - CANC. POR RESOLUCION PROCEDIM.NOTAR. *00610000
006110* SITPRES-R         <'R'> - CANC. POR REESTRUCTURA               *00611021
006200* FECSIT            FECHA DE ULTIMA SITUACION                    *00620000
006300* SALTEOR           SALDO TEORICO                                *00630000
006400* SALREAL           SALDO REAL                                   *00640000
006500* FECSAL            FECHA DE ULTIMO SALDO                        *00650000
006600* FEULIQ            FECHA DE ULTIMA LIQUIDACION                  *00660000
006700* FEPROLIQ          FECHA DE PROXIMA LIQUIDACION                 *00670000
006710* BGPAS                                                           00671022
006800* FECPCAIN          FECHA DE PROXIMO CAMBIO DE TIPO DE INTERES   *00680000
006810* FECPCAIN          CON DIEZ DIAS DE ANTERIORIDAD PARA PRESTAMOS *00681023
006820* FECPCAIN          CON TASA VARIABLE.                           *00682022
006830* FECPCAIN          PARA TASA FIJA UNICAMENTE EL REPORTE DE LIQUI*00683022
006840* FECPCAIN          DACION DE UN NUEVO PERIODO                   *00684022
006850* BGPAS                                                           00685022
006900* FEULIES           FECHA DE ULTIMA LIQUIDACION ESPECIAL         *00690000
007000* FEULAMES          FECHA DE ULTIMA AMORTIZACION ESPECIAL        *00700000
007100* FEFINCAR          FECHA DE FIN DEL PERIODO DE CARENCIA         *00710000
007200* FEULAMO           FECHA DE ULTIMA AMORTIZACION                 *00720000
007300* FEPROAMO          FECHA DE PROXIMA AMORTIZACION                *00730000
007400*                   ***--------------------------------------*** *00740000
007500*                   ***-      DATOS SITUACION DEUDA         -*** *00750000
007600*                   ***--------------------------------------*** *00760000
007700* DATOS-SITUAC                                                   *00770000
007800* SITDEUOB          CODIGO SITUACION DEUDA OBJETIVA              *00780000
007900* SITDEUOB-00       <'00'> - NORMAL                              *00790000
008000*@IBBV-PR                                                        *00800000
008100**SITDEUOB-10       <'10'> - VENCIDO ( MENOS DE 3 MESES )        *00810000
008200**SITDEUOB-20       <'20'> - DUDOSO  ( POR MOROSIDAD    )        *00820000
008300**SITDEUOB-21       <'21'> - DUDOSO  ( POR DEUDA > 25% DEL TOTAL *00830000
008400**SITDEUOB-22       <'22'> - DUDOSO  ( POR >1 A#O ANTIGUED.CUOTA *00840000
008500**SITDEUOB-40       <'40'> - PROPUESTO MUY DUDOSO (DUDOSO>3 A#OS *00850000
008600* SITDEUOB-30       <'30'> - DELINCUENCIA                        *00860000
008700* SITDEUOB-90       <'90'> - MORA NO PRODUCTIVA                  *00870000
008800* SITDEUOB-95       <'95'> - MORA NO PRODUCTIVA                  *00880000
008900* SITDEUOB-98       <'98'> - PROPUESTO FALLIDO                   *00890000
009000*@FBBV-PR                                                        *00900000
009100* SITDEUSU          CODIGO SITUACION DEUDA SUBJETIVA             *00910000
009200* SITDEUSU-00       <'00'> - NO REALIZADA                        *00920000
009300*@IBBV-PR                                                        *00930000
009400* SITDEUSU-99       <'99'> - FALLIDO                             *00940000
009500*@-FASE-2-BBV-PR-I                                                00950000
009600* SITDEUSU-23       <'23'> - DACO                                *00960000
009700* SITDEUSU-24       <'24'> - QUIEBRA                             *00970000
009800* SITDEUSU-25       <'25'> - ACCION LEGAL                        *00980000
009900* SITDEUSU-26       <'26'> - REPOSEIDO                           *00990000
010000* SITDEUSU-27       <'27'> - ACUERDO CONSUMER CREDIT             *01000000
010100* SITDEUSU-28       <'28'> - PLAN DE PAGOS                       *01010000
010200*@-FASE-2-BBV-PR-F                                                01020000
010300**SITDEUSU-31       <'31'> - DUDOSO                              *01030000
010400**SITDEUSU-32       <'32'> - DUDOSO ( NO DOCUMENTADO )           *01040000
010500**SITDEUSU-33       <'33'> - DUDOSO ( DEUDA TITULAR > 25 % )     *01050000
010600**SITDEUSU-34       <'34'> - DUDOSO ( REQUERIMIENTO )            *01060000
010700**SITDEUSU-35       <'35'> - DUDOSO ( PROCEDIMIENTO )            *01070000
010800**SITDEUSU-41       <'41'> - MUY DUDOSO ( DUDOSO > 3 A#OS )      *01080000
010900**SITDEUSU-42       <'42'> - MUY DUDOSO ( SUBJETIVO )            *01090000
011000*@FBBV-PR                                                        *01100000
011100* FESITOB           FECHA DE SITUACION DEUDA OBJETIVA            *01110000
011200* FESITSU           FECHA DE SITUACION DEUDA SUBJETIVA           *01120000
011300* ACUIMPA           IMPORTE ACUMULADO POR IMPAGOS                *01130000
011400* FEAPLARE          FECHA DE APLAZAMIENTO DEL PAGO               *01140000
011500* INTDEVEN          INTERESES DEVENGADOS POR ENTREGAS            *01150000
011600*                   ***--------------------------------------*** *01160000
011700*                   ***-            INDICADORES             -*** *01170000
011800*                   ***--------------------------------------*** *01180000
011900* INDICADORES                                                    *01190000
012000* INDIMAT           INDICADOR DE CUENTAS RELACIONADAS            *01200000
012100* INDIMAT-0         <'0'> - SIN CUENTAS RELACIONADAS             *01210000
012200* INDIMAT-1         <'1'> - MATRIZ DE MIBOR  ( MARCO )           *01220000
012300* INDIMAT-2         <'2'> - MIEMBRO DE MIBOR/REVOLVING           *01230000
012400* INDIMAT-3         <'3'> - PROMOTOR TIPO 1  ( MARCO )           *01240000
012500* INDIMAT-4         <'4'> - PROMOTOR TIPO 2  ( MARCO )           *01250000
012600* INDIMAT-5         <'5'> - MIEMBRO SUBROGADO TIPO 1             *01260000
012700* INDIMAT-6         <'6'> - MIEMBRO SUBROGADO TIPO 2             *01270000
012800* INDIMAT-7         <'7'> - CUENTA MODELO PROMOTORES             *01280000
012900* INDIMAT-8         <'8'> - MATRIU DE REVOLVING                  *01290000
013000* INDLIQES                                                       *01300000
013100* INDLIQES-SI       <'S'> SI TIENE CONDIC. DE LIQUID. ESPECIFICA *01310000
013200* INDLIQES-NO       <'N'> NO TIENE CONDIC. DE LIQUID. ESPECIFICA *01320000
013300* INDADMES                                                       *01330000
013400* INDADMES-SI       <'S'> SI TIENE CONDIC. DE ADMINI. ESPECIFICA *01340000
013500* INDADMES-NO       <'N'> NO TIENE CONDIC. DE ADMINI. ESPECIFICA *01350000
013600* INDCAMBIO         INDICADOR DE CAMBIO CONDICIONES ADM. LIQ.    *01360000
013700* INDCAMBIO-0       <'0'> - SITUACION NORMAL                     *01370000
013800* INDCAMBIO-1       <'1'> - CAMBIO PENDIENTE                     *01380000
013900* INDCAMBIO-2       <'2'> - AVISO EMITIDO ( INTERES VARIABLE )   *01390000
014000* INDCAMBIO-3       <'3'> - CAMBIO PDTE. Y AVISO EMITIDO ( " )   *01400000
014100* INDCAMBIO-4       <'4'> - CAMBIO PDTE. PARA INTERES POR TRAMOS *01410000
014200* INDCUAMA          INDICADOR DE CUADRO MANUAL                   *01420000
014300* INDCUAMA-0        <'0'> SIN CUADRO MANUAL                      *01430000
014400* INDCUAMA-1        <'1'> CON CUADRO MANUAL                      *01440000
014500* INDCUAMA-2        <'2'> PENDIENTE DE ACTUALIZAR CUADRO         *01450000
014600* INDACPRO          INDICADOR DE ACTUALIZACION DE PROVISIONES    *01460000
014700* INDACPRO-SI       <'S'> PENDIENTE ACTUALIZAR PROVISIONES       *01470000
014800* INDACPRO-NO       <'N'> PROVISIONES ACTUALIZADAS               *01480000
014900* INDFISCA          INDICADOR DE ENVIAR DECLARACION FISCAL       *01490000
015000* INDFISCA-SI       <'S'> ENVIAR DECLARACION FISCAL              *01500000
015100* INDFISCA-NO       <'N'> NO ENVIAR DECLARACION FISCAL           *01510000
015200* INDDEUPE          INDICADOR DE DEUDA PENDIENTE                 *01520000
015300* INDDEUPE-SI       <'S'> SI TIENE DEUDA PENDIENTE DE PAGO       *01530000
015400* INDDEUPE-NO       <'N'> NO TIENE DEUDA PENDIENTE DE PAGO       *01540000
015500* INDAVEMI          INDICADOR DE AVISO VENCIMIENTO EMITIDO       *01550000
015600* INDAVEMI-SI       <'S'> SI SE ENVIO AVISO DE VENCIMIENTO       *01560000
015700* INDAVEMI-NO       <'N'> NO SE ENVIO AVISO DE VENCIMIENTO       *01570000
015800* INDSINI           INDICADOR DE SINIESTRO                       *01580000
015900* INDSINI-SI        <'S'> PASADO / MARCADO PARA PASAR (SUBJETIVO *01590000
016000* INDSINI-NO        <'N'> NO EN SINIESTRO                        *01600000
016100* INDFACTU          INDICADOR DE FACTURABLE                      *01610000
016200* INDFACTU-SI       <'S'> SI FACTURABLE                          *01620000
016300* INDFACTU-NO       <'N'> NO FACTURABLE                          *01630000
016400* INDCARGA          INDICADOR DE CARGA BATCH                     *01640000
016500*                   CEC: INDICA CAMBIO TIPO INT. A MITAD PERIODO *01650000
016600* INDCARGA-1 CEC    <'1'> CAMBIA EL TIPO INTERES MITAD PERIODO   *01660000
016700* INDCARGA-0 CEC    <'0'> NO CAMBIA EL TIPO INTERES MITAD PERIODO*01670000
016800* INDCARGA-0 RONDA  <'0'> SIN CARGA BATCH                        *01680000
016900* INDCARGA-1 RONDA  <'1'> CARGA BATCH CON ENVIO DE RECIBOS       *01690000
017000* INDCARGA-2 RONDA  <'2'> CARGA BATCH SIN ENVIO DE RECIBOS       *01700000
017100* INDPOL            INDICADOR DE POLIZA EMITIDA                  *01710000
017200* INDPOL-SI         <'S'> POLIZA EMITIDA                         *01720000
017300* INDPOL-NO         <'N'> POLIZA NO EMITIDA                      *01730000
017400* @IBC IS*                                                        01740000
017500* INDPOL-P          <'P'> POLIZA PENDIENTE                       *01750000
017600* @FBC IS*                                                        01760000
017700* INDAYUDA          INDICADOR DE AYUDA ECONOMICA PERSONAL        *01770000
017800* INDAYUDA-0        <'0'> SIN AYUDA ECONOMICA                    *01780000
017900* INDAYUDA-1        <'1'> CON AYUDA ECONOMICA PDTE.              *01790000
018000* INDAYUDA-2        <'2'> CON AYUDA ECONOMICA CONSUMIDA.         *01800000
018100* IND-MARCA1        * INDICADOR DE TIPO DE CLIENTE               *01810000
018200* * TIPOCLI         REDEFINICION DE MARCA1                       *01820000
018300*                   TIPOCLI-E  EMPLEADOS                          01830000
018400*                   TIPOCLI-D  DIRECTORES                         01840000
018500*                   TIPOCLI-C  CLIENTES EN GENERAL                01850000
018600* IND-MARCA2        * INDICADOR DE TIPO DE PRODUCTO              *01860000
018700* * TIPOPRO         REDEFINICION DE MARCA2                       *01870000
018800*                   TIPOPRO-A  DESCUBIERTOS CTA CTE               01880000
018900*                   TIPOPRO-C  CREDITO CONSUMO                    01890000
019000*                   TIPOPRO-D  COMERCIO                           01900000
019100*                   TIPOPRO-E  CREDIFAST                          01910000
019200*                   TIPOPRO-F  CREDITO HIPOTECARIO                01920000
019300*                   TIPOPRO-G  CREDITO HIP DIF.VIVIENDA           01930000
019400*                   TIPOPRO-H  GANACA#A                           01940000
019500*                   TIPOPRO-I  RESOLUCIONES                       01950000
019600*                   TIPOPRO-J  FACTORING SIN RECURSOS             01960000
019700*                   TIPOPRO-K  OTROS ORDINARIOS                   01970000
019800*                   TIPOPRO-R  REDESCUENTOS                       01980000
019900* IND-MARCA3        * IND. SOLICITUD CARTA DE PAGO               *01990000
020000*@IBBV-PR                                                        *02000000
020100**IND-MARCA4        INDICADOR DE SOLICITUD DE CUPONES            *02010000
020200**CUPON-YA          <'Y'> CUPON YA SOLICITADO                    *02020000
020300**CUPON-SI          <'S'> SOLICITUD DE CUPON                     *02030000
020400**CUPON-NO          <'N'> NO SOLICITUD DE CUPON                  *02040000
020500**FBBV-PR                                                        *02050000
020600* BBV-COLOMBIA-I                                                 *02060000
020700* IND-MARCA4        INDICADOR DE TIPO DE CARTERA                 *02070000
020800* TIPOCAR-N         <'N'> CONSUMO                                *02080000
020900* TIPOCAR-C         <'C'> COMERCIO                               *02090000
021000* TIPOCAR-H         <'H'> HIPOTECARIO                            *02100000
021100* BBV-COLOMBIA-F                                                 *02110000
021200*@-FASE-2-BBV-PR-I                                               *02120000
021300* IND-MARCA5        INDICADOR DE CAMBIO DE TITULAR               *02130000
021400* MODTIT-SI         <'S'> SE HA MODIFICADO EL TITULAR            *02140000
021500* MODTIT-NO         <'N'> NO SE HA MODIFICADO EL TITULAR         *02150000
021600*@-FASE-2-BBV-PR-F                                               *02160000
021700*                   ***----------- MARCAS LIBRES ------------*** *02170000
021800* BBV-COLOMBIA-I                                                 *02180000
021900* IND-MARCA6        INDICADOR DE SEGURO EN TRAMITE               *02190000
022000*    SEG-TRAMITE    <'T'> SEGURO EN TRAMITE                      *02200000
022100*    SEG-RESUELTO   <'R'> SEGURO RESUELTO                        *02210000
022200*    SEG-DENEGADO   <'D'> SEGURO DENEGADO                        *02220000
022300* IND-MARCA7        INDICADOR TIPO DE PRODUCTOR                  *02230000
022400*    PROD-PEQUE     <'P'> PEQUE#O PRODUCTOR                      *02240000
022500*    PROD-GRANDE    <'G'> GRANDE PRODUCTOR                       *02250000
022600* BBV-COLOMBIA-F                                                 *02260000
022700*@-FASE-2-BBV-PR-I                                               *02270000
022800* IND-MARCA8        INDICADOR DE COMISION PENDIENTE              *02280000
022900* COM-PENDT         <'S'> TIENE COMISION DE IMPAGO PENDIENTE     *02290000
023000* COM-NO-PENDT      <'N'> NO TIENE COMISION DE IMPAGO PENDIENTE  *02300000
023100*@-FASE-2-BBV-PR-F                                               *02310000
023200*                   ***--------------------------------------*** *02320000
023300*                   ***-           DATOS CLIENTE            -*** *02330000
023400*                   ***--------------------------------------*** *02340000
023500* DATOS-CLIENTE                                                  *02350000
023600* COMIMP                                                         *02360000
023700* INDIMPA           INDICADOR COMUNICACION IMPAGADOS             *02370000
023800* INDIMPA-SI        <'S'> PROCEDE COMUNICAR                      *02380000
023900* INDIMPA-NO        <'N'> NO PROCEDE COMUNICAR                   *02390000
024000* CODCICLO          CODIGO DE CICLO DE COMUNICACION IMPAGADOS    *02400000
024100* FEPROCOM          FECHA DE PROXIMA COMUNICACION IMPAGADOS      *02410000
024200* CCC-VIN                                                        *02420000
024300* ENTIDAD-VIN       CLAVE DE ENTIDAD SEGUN BANCO DE ESPA#A       *02430000
024400* CENTRO-VIN        CENTRO                                       *02440000
024500* CUENTA-VIN        NUMERO DE CUENTA                             *02450000
024600* DIGICCC1-VIN      DIGITO 1 DE CONTROL                          *02460000
024700* DIGICCC2-VIN      DIGITO 2 DE CONTROL                          *02470000
024800* CLIENTE           CODIGO DE CLIENTE                            *02480000
024900* PARTICIPES        NUMERO DE PARTICIPES                         *02490000
025000* IND-RESPON        RESPONSABILIDAD                              *02500000
025100* IND-RESPON-M      <'M'> MANCOMUNADO                            *02510000
025200* IND-RESPON-S      <'S'> SOLIDARIO                              *02520000
025300* IND-RESPON-U      <'U'> UNIPERSONAL                            *02530000
025400* IMPROOB           IMPORTE PROVISIONADO OBJETIVO                *02540000
025500* IMPROSU           IMPORTE PROVISIONADO SUBJETIVO               *02550000
025600* PORPROMA          PORCENTAJE DE PROVISION MANUAL               *02560000
025700* NUMRECIB          NUMERO DE RECIBOS EMITIDOS                   *02570000
025800* SUBSUJET          CODIGO RAZON DEL SUJETO                      *02580000
025900* IMPDESDI          IMPORTE DESGLOSADO DE DISPOSICIONES SUCESI   *02590000
026000* UGIIIANA          IMPORTE CAPITAL PENDIENTE INICIO A¦O         *02600000
026100* PORDISPO          PORCENTAJE POSIBLE DE DISPOSICIONES SUC.     *02610000
026200*@-FASE-2-BBV-PR-I                                               *02620000
026300* UGYAOASC          SIN USO ACTUAL EN TABLA MAESTRA              *02630000
026400*@-FASE-2-BBV-PR-I                                               *02640000
026500* UGYEMCED          INDICADOR DE EMISION DE CEDULAS              *02650000
026600* UGYPPAUT          INDICADOR DE PROPUESTA AUTOMATICA            *02660000
026700* UGYPPAUT-0        <'0'> PROPUESTA NO EMITIDA                   *02670000
026800* UGYPPAUT-1        <'1'> PROPUESTA SOLICITADA                   *02680000
026900* UGYPPAUT-2        <'2'> PROPUESTA EMITIDA                      *02690000
027000* UGYPPAUT-3        <'3'> PROPUESTA EN ESTUDIO                   *02700000
027100*@2FASE-BBV-PR-I                                                  02710000
027200* UGYPPAUT-4        <'4'> PROPUESTA FAVORABLE(SE HA DADO DECISION*02720000
027300*                         FINAL EN CREDIT SCORING).              *02730000
027400* UGYPPAUT-5        <'5'> PROPUESTA DESFAVORABLE(SE HA DADO DEC. *02740000
027500*                         FINAL EN CREDIT SCORING).              *02750000
027600*@2FASE-BBV-PR-F                                                  02760000
027700* UGYPAPRE          INDICADOR DE OPERACION CON PAGARE            *02770000
027800* UGYPAPRE-SI       <'S'> CON PAGARE                             *02780000
027900* UGYPAPRE-NO       <'N'> SIN PAGARE                             *02790000
028000* CLAINTER          CLASE INTERVENCION TITULAR CORREO            *02800000
028100* SECINTER          SECUENCIA INTERVENCION TITULAR CORREO        *02810000
028200* SECDOMI           SECUENCIA DOMICILIO TITULAR DEL CORREO       *02820000
028300* ENOMOROS          ENTIDAD/OFICINA RESPONSABLE GESTION MOROSI   *02830000
028400* LIBRE-IMP1        IMPORT PROVISIONAT EXERCICIS ANTERIORS       *02840000
028500* LIBRE-IMP2        TOTAL PROVISION CAPITAL    SUBJETIVA         *02850000
028600* LIBRE-IMP3        IMPORTE LIBRE 3                              *02860000
028700* UGIDISPO          REDEF. DE LIBRE-IMP3 AMB DISPONIBLE OPS. MARC*02870000
028800*                   **----------CAMPOS  LIBRES----------------** *02880000
028900* LIBRE-IMP4        IMPORTE LIBRE 4                              *02890000
029000* LIBRE-IMP5        IMPORTE LIBRE 5                              *02900000
029100* LIBRE-CAR1        COLECTIU                                     *02910000
029200* LIBRE-CAR2        CARACTER LIBRE                               *02920000
029300* CNAEOGES          REDEF. DE LIBRE-CAR2 AMD DESTINVE I OFIGES-VI*02930000
029400*@-FASE-2-BBV-PR-I                                               *02940000
029500* CNAEOGES1         REDEF. DE LIBRE-CAR2 ->PROPOSITO Y OFIGES-VIN*02950000
029600*@-FASE-2-BBV-PR-F                                               *02960000
029700* LIBRE-CAR3        CARACTER LIBRE                               *02970000
029800* CENSTRAC          REDEF. DE LIBRE-CAR3 CON CENSUS TRACT        *02980000
029900*                   **----- CAMPOS NUEVOS  -------------------** *02990000
030000* UGCIOPRE          CODIGO DE IDIOMA                             *03000000
030100* UGCDEAMB          CODIGO DE AMBITO                             *03010000
030200* UGPITTAE          TAE-ACTUAL                                   *03020000
030300* UGYASASS          INDICADOR DE SEGURO ASOCIADO                 *03030000
030400* UGYMVPRE          INDICADOR DE CARGA DE MOVIMIENTOS            *03040000
030500* UGFSOPRE          FECHA DE DEMANDA                             *03050000
030600* UGFPAMOR          FECHA DE PASE A MORA                         *03060000
030700* UGFCAREB          FECHA DE ULTIMO RECIBO CARGADO EN BD         *03070000
030800*                   **----------------------------------------** *03080000
030900*                   **--- REDEFINICIO PER MARC MIBOR/REVOLVING * *03090000
031000*                   **----------------------------------------** *03100000
031100* UGFRMANT REDEFINES UGFCAREB:DATA REBUT IMPAG.MES ANTIC(MARC)   *03110000
031200*                   **----------------------------------------** *03120000
031300* UGFCAMOV          FECHA DE ULTIMO MOVIMIENTO CARGADO EN BD     *03130000
031400* UGFMAFOR          FECHA DE FORMALIZACION PRESTAMO MATRIZ       *03140000
031500* UGYTIMOR          TIPO DE TRATAMIENTO DE LA MOROSIDAD          *03150000
031600* UGYTIINV          TIPO DE INVERSION                            *03160000
031700* UGYPAFDO          INDICADOR DE PASE A FALLIDO                  *03170000
031800*  UGYPAFDO-R       <'R'> REESTRUCTURA                           *03180000
031900*  UGYPAFDO-N       <'N'> RENOVACION                             *03190000
032000*  UGYPAFDO-J       <'J'> PASE A FALLIDO                         *03200000
032100* UGYDERBO          INDICADOR DE DEUDA NO EN RECIBO.             *03210000
032200* UGYAC025          INDICADOR DE ACUMULA RIESGOS > 25 %          *03220000
032300* UGCPRINV          PROVINCIA DE INVERSION                       *03230000
032400* UGCDIPAG          DIA DE PAGO                                  *03240000
032500* UGICOJUD          ACUMULADO COSTAS JUDICIALES                  *03250000
032600* UGIORINT          INTERESES EN CUENTAS DE ORDEN                *03260000
032700*@IBBV-PR                                                        *03270000
032800* UGYEMPRE          INDICADOR DE PRESTAMO DE EMPLEADOS           *03280000
032900*                   <0> NO ES EMPLEADO DE BANCA                  *03290000
033000*                   <1> EMPLEADO DEL BBV                         *03300000
033100*                   <2> EMPLEADO DE BANCA PERO NO DEL BBV        *03310000
033200*@FBBV-PR                                                        *03320000
033300* UGYCATAE          INDICADOR DE RECALCULO DE LA TAE             *03330000
033400*                   **----- STAMP DE ULTIMA MODIFICACION -----** *03340000
033500* STAMP-UMO                                                      *03350000
033600* ENTIDAD-UMO       ENTIDAD QUE REALIZO LA ULTIMA MODIFICACION   *03360000
033700* CENTRO-UMO        CENTRO QUE REALIZO LA ULTIMA MODIFICACION    *03370000
033800* USERID-UMO        USUARIO QUE REALIZO LA ULTIMA MODIFICACION   *03380000
033900* NETNAME-UMO       TERMINAL QUE REALIZO LA ULTIMA MODIFICACIO   *03390000
034000* TIMESTAMP         FECHA Y HORA DE LA ULTIMA MODIFICACION       *03400000
034100*       ***--------------------------------------------------*** *03410000
034200*       ***--  MODIFICACIO OPIRAT   10.02.93               --*** *03420000
034300*       ***--------------------------------------------------*** *03430000
034400* UGYVTOME          VENCIMENT MIG PONDERAT                       *03440000
034500* UGYTRI            TASA RENDIMENT INTERNA                       *03450000
034600* UGCNACRE          NACIO RESIDENCIA                             *03460000
034700* UGYCGOCU          INDICADOR CARGO EN CURSO                     *03470000
034800* UGNOFPRE          EMPLEADO O PROMOTOR AL QUE SE ASIGNA EL PREST*03480000
034900* UGIMPFDO          IMPORTE DE PASE A FALLIDO                    *03490000
035000* UGIPROIM          IMPORT PRODUCTES IMPUTATS A RESULTATS        *03500000
035100* UGCREFEM          REFERENCIA EMISSIO CEDULES                   *03510000
035200* UGYNVENC          INDICADOR PRESTEC VEN.UT (NO CANCELLAT)      *03520000
035300* UGCTIVEN          INDINANT ACTUAL (TIPUS VENCIMENT (A,V,P))    *03530000
035400*@-FASE-2-BBV-PR-I                                               *03540000
035500* DEALER            CODIGO DE DEALER DE LA CUENTA                *03550000
035600* CAMPANA           CODIGO DE CAMPANA                            *03560000
035700* PAGO-PREVIO       SALDO DE PAGO ADELANTADO                     *03570000
035800*@-FASE-2-BBV-PR-F                                               *03580000
035900*@-BC-I-LAP                                                      *03590000
036000* CUENTA_ANT        CUENTA ANTERIOR DEL PRESTAMO                 *03600000
036100* CUENTA_ABO        CUENTA DE ABONO DEL PRESTAMO                 *03610000
036200*@-BC-F-LAP                                                      *03620000
036300*                                                                *03630000
036400*@-BG-I- SE INCLUYE EL CAMPO DE CODIGO DE ACTIVIDAD              *03640000
036500* ACTIVIDAD                                                      *03650000
036600******************************************************************03660000
036700******************************************************************03670000
036800* MODIFICACION AL0047D  02/94                                    *03680000
036900* SE CAMBIAN LOS CNAE DE CUATRO DIGITOS POR LOS DE CINCO POR     *03690000
037000* IMPERATIVO LEGAL EN LA COPY DE LA TABLA MAESTRA, EL OBJETO     *03700000
037100* ES EL CAMPO CODIDES.                                           *03710000
037200******************************************************************03720000
037300*                                                                 03730000
037400                                                                  03740000
037500 01 UGTCMAE.                                                      03750000
037600*          **----------------------------------------**           03760000
037700*          **---    CODIGO DE CUENTA CLIENTE      ---**           03770000
037800*          **----------------------------------------**           03780000
037900    05 MAE-CLAVE.                                                 03790000
038000       10 MAE-CCC.                                                03800000
038100          15 MAE-ENTIOFI              PIC X(08).                  03810000
038200          15 MAE-CUENTA               PIC X(10).                  03820000
038300       10 MAE-DIGICCC1                PIC X(01).                  03830000
038400       10 MAE-DIGICCC2                PIC X(01).                  03840000
038500*          **----------------------------------------**           03850000
038600*          **---    DATOS BASICOS DE LA CUENTA    ---**           03860000
038700*          **----------------------------------------**           03870000
038800    05 MAE-DATOS-BAS.                                             03880000
038900       10 MAE-ENOTIT                  PIC X(08).                  03890000
039000       10 MAE-ENOTITAN                PIC X(08).                  03900000
039100       10 MAE-UGNOFRES                PIC X(08).                  03910000
039200       10 MAE-UGNOFFOR                PIC X(08).                  03920000
039300       10 MAE-PRODUCTO                PIC X(02).                  03930000
039400       10 MAE-SUBPRO                  PIC X(04).                  03940000
039500       10 MAE-CODIGAR                 PIC X(03).                  03950000
039600*                                                                 03960000
039700* @PAL0047D ******************************************************03970000
039800*                                                                 03980000
039900*      10 MAE-CODIDES                 PIC X(04).                  03990000
040000       10 MAE-CODIDES                 PIC X(05).                  04000000
040100*                                                                 04010000
040200* @FAL0047D ******************************************************04020000
040300*                                                                 04030000
040400       10 MAE-PLAZO                   PIC X(04).                  04040000
040500       10 MAE-MONEDA                  PIC X(04).                  04050000
040600*LAP   10 MAE-TAE                     PIC S9(02)V9(3) COMP-3.     04060000
040700       10 MAE-TAE                     PIC S9(03)V9(5) COMP-3.     04070000
040800*          ***--------------------------------------***           04080000
040900*          ***-      DATOS GENERALES DE LA CTA.    -***           04090000
041000    05 MAE-DATOS-GENER.                                           04100000
041100*@IBBV-PR                                                         04110000
041200*      10 MAE-CAPSOLI                 PIC S9(13)      COMP-3.     04120000
041300*      10 MAE-IMPCONCE                PIC S9(13)      COMP-3.     04130000
041400*      10 MAE-IMPDISPU                PIC S9(13)      COMP-3.     04140000
041500       10 MAE-CAPSOLI                 PIC S9(13)V99   COMP-3.     04150000
041600       10 MAE-IMPCONCE                PIC S9(13)V99   COMP-3.     04160000
041700       10 MAE-IMPDISPU                PIC S9(13)V99   COMP-3.     04170000
041800*@FBBV-PR                                                         04180000
041900       10 MAE-FESOLIC                 PIC X(10).                  04190000
042000       10 MAE-FEFORMA                 PIC X(10).                  04200000
042100       10 MAE-FECAPROBA               PIC X(10).                  04210000
042200       10 MAE-FECPRIAMO               PIC X(10).                  04220000
042300       10 MAE-FECPRILIQ               PIC X(10).                  04230000
042400       10 MAE-FEVENCIN                PIC X(10).                  04240000
042500       10 MAE-SITPRES                 PIC X(01).                  04250000
042600          88 MAE-88-SITPRES-0         VALUE '0'.                  04260000
042700          88 MAE-88-SITPRES-1         VALUE '1'.                  04270000
042800          88 MAE-88-SITPRES-2         VALUE '2'.                  04280000
042900          88 MAE-88-SITPRES-3         VALUE '3'.                  04290000
043000          88 MAE-88-SITPRES-4         VALUE '4'.                  04300000
043100          88 MAE-88-SITPRES-5         VALUE '5'.                  04310000
043200          88 MAE-88-SITPRES-7         VALUE '7'.                  04320000
043300          88 MAE-88-SITPRES-8         VALUE '8'.                  04330000
043400          88 MAE-88-SITPRES-9         VALUE '9'.                  04340000
043500          88 MAE-88-SITPRES-A         VALUE 'A'.                  04350000
043600          88 MAE-88-SITPRES-P         VALUE 'P'.                  04360000
043700       10 MAE-FECSIT                  PIC X(10).                  04370000
043800*@IBBV-PR                                                         04380000
043900*      10 MAE-SALTEOR                 PIC S9(13)      COMP-3.     04390000
044000*      10 MAE-SALREAL                 PIC S9(13)      COMP-3.     04400000
044100       10 MAE-SALTEOR                 PIC S9(13)V99   COMP-3.     04410000
044200       10 MAE-SALREAL                 PIC S9(13)V99   COMP-3.     04420000
044300*@FBBV-PR                                                         04430000
044400       10 MAE-FECSAL                  PIC X(10).                  04440000
044500       10 MAE-FEULIQ                  PIC X(10).                  04450000
044600       10 MAE-FEPROLIQ                PIC X(10).                  04460000
044700       10 MAE-FECPCAIN                PIC X(10).                  04470000
044800       10 MAE-FEULIES                 PIC X(10).                  04480000
044900       10 MAE-FEULAMES                PIC X(10).                  04490000
045000       10 MAE-FEFINCAR                PIC X(10).                  04500000
045100       10 MAE-FEULAMO                 PIC X(10).                  04510000
045200       10 MAE-FEPROAMO                PIC X(10).                  04520000
045300*          ***--------------------------------------***           04530000
045400*          ***-      DATOS SITUACION DEUDA         -***           04540000
045500*          ***--------------------------------------***           04550000
045600    05 MAE-DATOS-SITUAC.                                          04560000
045700       10 MAE-SITDEUOB                PIC X(02).                  04570000
045800          88 MAE-88-SITDEUOB-00       VALUE '00'.                 04580000
045900*@-BC-I MZ                                                        04590000
046000          88 MAE-88-SITDEUOB-10       VALUE '10'.                 04600000
046100          88 MAE-88-SITDEUOB-20       VALUE '20'.                 04610000
046200*@-BC-F MZ                                                        04620000
046300*@IBBV-PR                                                         04630000
046400          88 MAE-88-SITDEUOB-30       VALUE '30'.                 04640000
046500          88 MAE-88-SITDEUOB-90       VALUE '90'.                 04650000
046600          88 MAE-88-SITDEUOB-95       VALUE '95'.                 04660000
046700          88 MAE-88-SITDEUOB-98       VALUE '98'.                 04670000
046800*         88 MAE-88-SITDEUOB-10       VALUE '10'.                 04680000
046900*         88 MAE-88-SITDEUOB-20       VALUE '20'.                 04690000
047000*         88 MAE-88-SITDEUOB-21       VALUE '21'.                 04700000
047100*         88 MAE-88-SITDEUOB-22       VALUE '22'.                 04710000
047200*         88 MAE-88-SITDEUOB-40       VALUE '40'.                 04720000
047300*@FBBV-PR                                                         04730000
047400       10 MAE-SITDEUSU                PIC X(02).                  04740000
047500          88 MAE-88-SITDEUSU-00       VALUE '00'.                 04750000
047600*@-BC-I MZ                                                        04760000
047700          88 MAE-88-SITDEUSU-33       VALUE '33'.                 04770000
047800          88 MAE-88-SITDEUSU-34       VALUE '34'.                 04780000
047900          88 MAE-88-SITDEUSU-35       VALUE '35'.                 04790000
048000*@-BC-F MZ                                                        04800000
048100*@-FASE-2-BBV-PR-I                                                04810000
048200          88 MAE-88-SITDEUSU-23       VALUE '23'.                 04820000
048300          88 MAE-88-SITDEUSU-24       VALUE '24'.                 04830000
048400          88 MAE-88-SITDEUSU-25       VALUE '25'.                 04840000
048500          88 MAE-88-SITDEUSU-26       VALUE '26'.                 04850000
048600          88 MAE-88-SITDEUSU-27       VALUE '27'.                 04860000
048700          88 MAE-88-SITDEUSU-28       VALUE '28'.                 04870000
048800*@-FASE-2-BBV-PR-F                                                04880000
048900*@IBBV-PR                                                         04890000
049000          88 MAE-88-SITDEUSU-99       VALUE '99'.                 04900000
049100*         88 MAE-88-SITDEUSU-31       VALUE '31'.                 04910000
049200*         88 MAE-88-SITDEUSU-32       VALUE '32'.                 04920000
049300*         88 MAE-88-SITDEUSU-33       VALUE '33'.                 04930000
049400*         88 MAE-88-SITDEUSU-34       VALUE '34'.                 04940000
049500*         88 MAE-88-SITDEUSU-35       VALUE '35'.                 04950000
049600*         88 MAE-88-SITDEUSU-41       VALUE '41'.                 04960000
049700*         88 MAE-88-SITDEUSU-42       VALUE '42'.                 04970000
049800*@FBBV-PR                                                         04980000
049900       10 MAE-FESITOB                 PIC X(10).                  04990000
050000       10 MAE-FESITSU                 PIC X(10).                  05000000
050100*      10 MAE-ACUIMPA                 PIC S9(13)      COMP-3.     05010000
050200       10 MAE-ACUIMPA                 PIC S9(13)V99   COMP-3.     05020000
050300*@FBBV-PR                                                         05030000
050400       10 MAE-FEAPLARE                PIC X(10).                  05040000
050500*@IBBV-PR                                                         05050000
050600*      10 MAE-INTDEVEN                PIC S9(13)      COMP-3.     05060000
050700       10 MAE-INTDEVEN                PIC S9(13)V99   COMP-3.     05070000
050800*@FBBV-PR                                                         05080000
050900*          ***--------------------------------------***           05090000
051000*          ***-            INDICADORES             -***           05100000
051100*          ***--------------------------------------***           05110000
051200    05 MAE-INDICADORES.                                           05120000
051300       10 MAE-INDIMAT                 PIC X(01).                  05130000
051400          88 MAE-88-INDIMAT-0         VALUE '0'.                  05140000
051500          88 MAE-88-INDIMAT-1         VALUE '1'.                  05150000
051600          88 MAE-88-INDIMAT-2         VALUE '2'.                  05160000
051700          88 MAE-88-INDIMAT-3         VALUE '3'.                  05170000
051800          88 MAE-88-INDIMAT-4         VALUE '4'.                  05180000
051900          88 MAE-88-INDIMAT-5         VALUE '5'.                  05190000
052000          88 MAE-88-INDIMAT-6         VALUE '6'.                  05200000
052100          88 MAE-88-INDIMAT-7         VALUE '7'.                  05210000
052200          88 MAE-88-INDIMAT-8         VALUE '8'.                  05220000
052300*@-BG-YAO                                                         05230000
052400          88 MAE-88-INDIMAT-D         VALUE 'D'.                  05240000
052500       10 MAE-INDLIQES                PIC X(01).                  05250000
052600          88 MAE-88-INDLIQES-SI       VALUE 'S'.                  05260000
052700          88 MAE-88-INDLIQES-NO       VALUE 'N'.                  05270000
052800       10 MAE-INDADMES                PIC X(01).                  05280000
052900          88 MAE-88-INDADMES-SI       VALUE 'S'.                  05290000
053000          88 MAE-88-INDADMES-NO       VALUE 'N'.                  05300000
053100       10 MAE-INDCAMBIO               PIC X(01).                  05310000
053200          88 MAE-88-INDCAMBIO-0       VALUE '0'.                  05320000
053300          88 MAE-88-INDCAMBIO-1       VALUE '1'.                  05330000
053400          88 MAE-88-INDCAMBIO-2       VALUE '2'.                  05340000
053500          88 MAE-88-INDCAMBIO-3       VALUE '3'.                  05350000
053600          88 MAE-88-INDCAMBIO-4       VALUE '4'.                  05360000
053700       10 MAE-INDCUAMA                PIC X(01).                  05370000
053800          88 MAE-88-INDCUAMA-0        VALUE '0'.                  05380000
053900          88 MAE-88-INDCUAMA-1        VALUE '1'.                  05390000
054000          88 MAE-88-INDCUAMA-2        VALUE '2'.                  05400000
054100       10 MAE-INDACPRO                PIC X(01).                  05410000
054200          88 MAE-88-INDACPRO-SI       VALUE 'S'.                  05420000
054300          88 MAE-88-INDACPRO-NO       VALUE 'N'.                  05430000
054400       10 MAE-INDFISCA                PIC X(01).                  05440000
054500          88 MAE-88-INDFISCA-SI       VALUE 'S'.                  05450000
054600          88 MAE-88-INDFISCA-NO       VALUE 'N'.                  05460000
054700       10 MAE-INDDEUPE                PIC X(01).                  05470000
054800          88 MAE-88-INDDEUPE-SI       VALUE 'S'.                  05480000
054900          88 MAE-88-INDDEUPE-NO       VALUE 'N'.                  05490000
055000       10 MAE-INDAVEMI                PIC X(01).                  05500000
055100          88 MAE-88-INDAVEMI-SI       VALUE 'S'.                  05510000
055200          88 MAE-88-INDAVEMI-NO       VALUE 'N'.                  05520000
055300       10 MAE-INDSINI                 PIC X(01).                  05530000
055400          88 MAE-88-INDSINI-SI        VALUE 'S'.                  05540000
055500          88 MAE-88-INDSINI-NO        VALUE 'N'.                  05550000
055600       10 MAE-INDFACTU                PIC X(01).                  05560000
055700          88 MAE-88-INDFACTU-SI       VALUE 'S'.                  05570000
055800          88 MAE-88-INDFACTU-NO       VALUE 'N'.                  05580000
055900       10 MAE-INDCARGA                PIC X(01).                  05590000
056000          88 MAE-88-INDCARGA-0        VALUE '0'.                  05600000
056100          88 MAE-88-INDCARGA-1        VALUE '1'.                  05610000
056200          88 MAE-88-INDCARGA-2        VALUE '2'.                  05620000
056300       10 MAE-INDPOL                  PIC X(01).                  05630000
056400          88 MAE-88-INDPOL-SI         VALUE 'S'.                  05640000
056500          88 MAE-88-INDPOL-NO         VALUE 'N'.                  05650000
056600*@IBC IS                                                          05660000
056700          88 MAE-88-INDPOL-P          VALUE 'P'.                  05670000
056800*@FBC IS                                                          05680000
056900       10 MAE-INDAYUDA                PIC X(01).                  05690000
057000          88 MAE-88-INDAYUDA-0        VALUE '0'.                  05700000
057100          88 MAE-88-INDAYUDA-1        VALUE '1'.                  05710000
057200          88 MAE-88-INDAYUDA-2        VALUE '2'.                  05720000
057300*          ***----------- MARCAS LIBRES ------------***           05730000
057400       10 MAE-IND-MARCA1              PIC X(01).                  05740000
057500       10 MAE-TIPOCLI  REDEFINES MAE-IND-MARCA1                   05750000
057600                                      PIC X(01).                  05760000
057700          88 MAE-88-TIPOCLI-CLIENTES      VALUE 'C'.              05770000
057800          88 MAE-88-TIPOCLI-EMPLEADOS     VALUE 'E'.              05780000
057900          88 MAE-88-TIPOCLI-DIRECTORES    VALUE 'D'.              05790000
058000       10 MAE-IND-MARCA2              PIC X(01).                  05800000
058100       10 MAE-TIPOPRO  REDEFINES MAE-IND-MARCA2                   05810000
058200                                      PIC X(01).                  05820000
058300          88 MAE-88-TIPOPRO-DESCUB       VALUE 'A'.               05830000
058400          88 MAE-88-TIPOPRO-CONSUMO      VALUE 'C'.               05840000
058500          88 MAE-88-TIPOPRO-COMERCIAL    VALUE 'D'.               05850000
058600          88 MAE-88-TIPOPRO-CREDIFAST    VALUE 'E'.               05860000
058700          88 MAE-88-TIPOPRO-HIPOTECA     VALUE 'F'.               05870000
058800          88 MAE-88-TIPOPRO-HIPO-DIF     VALUE 'G'.               05880000
058900          88 MAE-88-TIPOPRO-GANACA       VALUE 'H'.               05890000
059000          88 MAE-88-TIPOPRO-RESOLUC      VALUE 'I'.               05900000
059100          88 MAE-88-TIPOPRO-FACTORING    VALUE 'J'.               05910000
059200          88 MAE-88-TIPOPRO-OTROS        VALUE 'K'.               05920000
059300          88 MAE-88-TIPOPRO-REDESC       VALUE 'R'.               05930000
059400       10 MAE-IND-MARCA3              PIC X(01).                  05940000
059500          88 MAE-88-CARTA-PAGO-SI     VALUE 'S'.                  05950000
059600       10 MAE-IND-MARCA4              PIC X(01).                  05960000
059700*@IBBV-PR                                                         05970000
059800*         88 MAE-88-CUPON-YA         VALUE 'Y'.                   05980000
059900*         88 MAE-88-CUPON-SI         VALUE 'S'.                   05990000
060000*         88 MAE-88-CUPON-NO         VALUE 'N'.                   06000000
060100*@FBBV-PR                                                         06010000
060200*BBV-COLOMBIA-I                                                   06020000
060300          88 MAE-88-TIPOCAR-CONS     VALUE 'N'.                   06030000
060400          88 MAE-88-TIPOCAR-COMER    VALUE 'C'.                   06040000
060500          88 MAE-88-TIPOCAR-HIPOT    VALUE 'H'.                   06050000
060600*BBV-COLOMBIA-F                                                   06060000
060700*@-FASE-2-BBV-PR-I                                                06070000
060800       10 MAE-IND-MARCA5              PIC X(01).                  06080000
060900          88 MAE-88-MODTIT-SI        VALUE 'S'.                   06090000
061000          88 MAE-88-MODTIT-NO        VALUE 'N'.                   06100000
061100*@-FASE-2-BBV-PR-F                                                06110000
061200       10 MAE-IND-MARCA6              PIC X(01).                  06120000
061300          88 MAE-88-SEG-TRAMITE      VALUE 'T'.                   06130000
061400          88 MAE-88-SEG-RESUELTO     VALUE 'R'.                   06140000
061500          88 MAE-88-SEG-DENEGADO     VALUE 'D'.                   06150000
061600       10 MAE-IND-MARCA7              PIC X(01).                  06160000
061700          88 MAE-88-PROD-PEQUE       VALUE 'P'.                   06170000
061800          88 MAE-88-PROD-GRANDE      VALUE 'G'.                   06180000
061900       10 MAE-IND-MARCA8              PIC X(01).                  06190000
062000          88 MAE-88-COM-PENDT        VALUE 'S'.                   06200000
062100          88 MAE-88-COM-NO-PENDT     VALUE 'N'.                   06210000
062200*          ***--------------------------------------***           06220000
062300*          ***-           DATOS CLIENTE            -***           06230000
062400*          ***--------------------------------------***           06240000
062500    05 MAE-DATOS-CLIENTE.                                         06250000
062600       10 MAE-COMIMP.                                             06260000
062700          15 MAE-INDIMPA              PIC X(01).                  06270000
062800             88 MAE-88-INDIMPA-SI     VALUE 'S'.                  06280000
062900             88 MAE-88-INDIMPA-NO     VALUE 'N'.                  06290000
063000          15 MAE-CODCICLO             PIC X(02).                  06300000
063100          15 MAE-FEPROCOM             PIC X(10).                  06310000
063200       10 MAE-CCC-VIN.                                            06320000
063300          15 MAE-ENTIDAD-VIN          PIC X(04).                  06330000
063400          15 MAE-CENTRO-VIN           PIC X(04).                  06340000
063500          15 MAE-CUENTA-VIN           PIC X(10).                  06350000
063600          15 MAE-DIGICCC1-VIN         PIC X(01).                  06360000
063700          15 MAE-DIGICCC2-VIN         PIC X(01).                  06370000
063800       10 MAE-CLIENTE                 PIC X(08).                  06380000
063900       10 MAE-CLIENTE-9               REDEFINES MAE-CLIENTE       06390000
064000                                      PIC 9(08).                  06400000
064100       10 MAE-PARTICIPES              PIC S9(03)      COMP-3.     06410000
064200       10 MAE-IND-RESPON              PIC X(01).                  06420000
064300          88 MAE-88-IND-RESPON-M      VALUE 'M'.                  06430000
064400          88 MAE-88-IND-RESPON-S      VALUE 'S'.                  06440000
064500          88 MAE-88-IND-RESPON-U      VALUE 'U'.                  06450000
064600*@IBBV-PR                                                         06460000
064700*      10 MAE-IMPROOB                 PIC S9(13)      COMP-3.     06470000
064800*      10 MAE-IMPROSU                 PIC S9(13)      COMP-3.     06480000
064900       10 MAE-IMPROOB                 PIC S9(13)V99   COMP-3.     06490000
065000       10 MAE-IMPROSU                 PIC S9(13)V99   COMP-3.     06500000
065100*@FBBV-PR                                                         06510000
065200       10 MAE-PORPROMA                PIC S9(03)V9(2) COMP-3.     06520000
065300       10 MAE-NUMRECIB                PIC S9(05)      COMP-3.     06530000
065400       10 MAE-SUBSUJET                PIC X(03).                  06540000
065500*@IBBV-PR                                                         06550000
065600*      10 MAE-IMPDESDI                PIC S9(13)      COMP-3.     06560000
065700*      10 MAE-UGIIIANA                PIC S9(13)      COMP-3.     06570000
065800       10 MAE-IMPDESDI                PIC S9(13)V99   COMP-3.     06580000
065900       10 MAE-UGIIIANA                PIC S9(13)V99   COMP-3.     06590000
066000*@FBBV-PR                                                         06600000
066100       10 MAE-PORDISPO                PIC S9(3)       COMP-3.     06610000
066200       10 MAE-UGYAOASC                PIC X.                      06620000
066300          88 MAE-88-UGYAOASC-0        VALUE '0'.                  06630000
066400          88 MAE-88-UGYAOASC-1        VALUE '1'.                  06640000
066500          88 MAE-88-UGYAOASC-2        VALUE '2'.                  06650000
066600       10 MAE-UGYEMCED                PIC X.                      06660000
066700       10 MAE-UGYPPAUT                PIC X.                      06670000
066800          88 MAE-88-UGYPPAUT-0        VALUE '0'.                  06680000
066900          88 MAE-88-UGYPPAUT-1        VALUE '1'.                  06690000
067000          88 MAE-88-UGYPPAUT-2        VALUE '2'.                  06700000
067100          88 MAE-88-UGYPPAUT-3        VALUE '3'.                  06710000
067200          88 MAE-88-UGYPPAUT-4        VALUE '4'.                  06720000
067300          88 MAE-88-UGYPPAUT-5        VALUE '5'.                  06730000
067400       10 MAE-UGYPAPRE                PIC X(01).                  06740000
067500          88 MAE-88-UGYPAPRE-SI       VALUE 'S'.                  06750000
067600          88 MAE-88-UGYPAPRE-NO       VALUE 'N'.                  06760000
067700       10 MAE-CLAINTER                PIC X.                      06770000
067800       10 MAE-SECINTER                PIC X(2).                   06780000
067900       10 MAE-SECDOMI                 PIC S9(3)     COMP-3.       06790000
068000       10 MAE-ENOMOROS                PIC X(08).                  06800000
068100*@IBBV-PR                                                         06810000
068200*      10 MAE-LIBRE-IMP1              PIC S9(13)      COMP-3.     06820000
068300*      10 MAE-LIBRE-IMP2              PIC S9(13)      COMP-3.     06830000
068400*      10 MAE-LIBRE-IMP3              PIC S9(13)      COMP-3.     06840000
068500*      10 MAE-UGIDISPO REDEFINES MAE-LIBRE-IMP3 PIC S9(13) COMP-3.06850000
068600*          **----------CAMPOS  LIBRES----------------**           06860000
068700*      10 MAE-LIBRE-IMP4              PIC S9(13)      COMP-3.     06870000
068800*      10 MAE-LIBRE-IMP5              PIC S9(13)      COMP-3.     06880000
068900       10 MAE-LIBRE-IMP1              PIC S9(13)V99   COMP-3.     06890000
069000       10 MAE-LIBRE-IMP2              PIC S9(13)V99   COMP-3.     06900000
069100       10 MAE-LIBRE-IMP3              PIC S9(13)V99   COMP-3.     06910000
069200       10 MAE-UGIDISPO REDEFINES MAE-LIBRE-IMP3                   06920000
069300                                      PIC S9(13)V99   COMP-3.     06930000
069400*          **----------CAMPOS  LIBRES----------------**           06940000
069500       10 MAE-LIBRE-IMP4              PIC S9(13)V99   COMP-3.     06950000
069600       10 MAE-LIBRE-IMP5              PIC S9(13)V99   COMP-3.     06960000
069700*@FBBV-PR                                                         06970000
069800       10 MAE-LIBRE-CAR1              PIC X(10).                  06980000
069900       10 MAE-LIBRE-CAR2              PIC X(10).                  06990000
070000       10 MAE-CNAEOGES REDEFINES MAE-LIBRE-CAR2.                  07000000
070100          15 MAE-DESTINVE             PIC X(05).                  07010000
070200          15 MAE-OFIGES-VIN           PIC X(04).                  07020000
070300          15 FILLER                   PIC X(01).                  07030000
070400*@-FASE-2-BBV-PR-I                                               *07040000
070500       10 MAE-CNAEOGES1 REDEFINES MAE-LIBRE-CAR2.                 07050000
070600          15 MAE-PROPOSITO            PIC X(02).                  07060000
070700          15 FILLER                   PIC X(03).                  07070000
070800          15 MAE-OFIGES-VIN1          PIC X(04).                  07080000
070900          15 FILLER                   PIC X(01).                  07090000
071000*@-FASE-2-BBV-PR-F                                               *07100000
071100       10 MAE-LIBRE-CAR3              PIC X(10).                  07110000
071200       10 MAE-CENSTRAC REDEFINES MAE-LIBRE-CAR3.                  07120000
071300          15 MAE-CENSTRCT             PIC X(07).                  07130000
071400          15 FILLER                   PIC X(03).                  07140000
071500*          **----- CAMPOS NUEVOS --------------------**           07150000
071600       10 MAE-UGCIOPRE                PIC X(1).                   07160000
071700       10 MAE-UGCDEAMB                PIC X(1).                   07170000
071800       10 MAE-UGYASASS                PIC X(1).                   07180000
071900          88 MAE-88-UGYASASS-SI       VALUE 'S'.                  07190000
072000          88 MAE-88-UGYASASS-NO       VALUE 'N'.                  07200000
072100       10 MAE-UGYMVPRE                PIC X(01).                  07210000
072200          88 MAE-88-UGYMVPRE-SI       VALUE 'S'.                  07220000
072300          88 MAE-88-UGYMVPRE-NO       VALUE 'N'.                  07230000
072400*LAP   10 MAE-UGPITTAE                PIC S9(02)V9(3) COMP-3.     07240000
072500       10 MAE-UGPITTAE                PIC S9(03)V9(5) COMP-3.     07250000
072600       10 MAE-UGFSOPRE                PIC X(10).                  07260000
072700       10 MAE-UGFPAMOR                PIC X(10).                  07270000
072800       10 MAE-UGFCAREB                PIC X(10).                  07280000
072900       10 MAE-UGFRMANT REDEFINES MAE-UGFCAREB   PIC X(10).        07290000
073000       10 MAE-UGFCAMOV                PIC X(10).                  07300000
073100       10 MAE-UGFMAFOR                PIC X(10).                  07310000
073200       10 MAE-UGYTIMOR                PIC X(01).                  07320000
073300       10 MAE-UGYTIINV                PIC X(01).                  07330000
073400       10 MAE-UGYPAFDO                PIC X(01).                  07340000
073500          88 MAE-88-UGYPAFDO-R        VALUE 'R'.                  07350000
073600          88 MAE-88-UGYPAFDO-N        VALUE 'N'.                  07360000
073700          88 MAE-88-UGYPAFDO-J        VALUE 'J'.                  07370000
073800       10 MAE-UGYDERBO                PIC X(01).                  07380000
073900       10 MAE-UGYAC025                PIC X(01).                  07390000
074000       10 MAE-UGCPRINV                PIC S9(03)      COMP-3.     07400000
074100       10 MAE-UGCDIPAG                PIC S9(03)      COMP-3.     07410000
074200*@IBBV-PR                                                         07420000
074300*      10 MAE-UGICOJUD                PIC S9(13)      COMP-3.     07430000
074400*      10 MAE-UGIORINT                PIC S9(13)      COMP-3.     07440000
074500       10 MAE-UGICOJUD                PIC S9(13)V99   COMP-3.     07450000
074600       10 MAE-UGIORINT                PIC S9(13)V99   COMP-3.     07460000
074700*@FBBV-PR                                                         07470000
074800       10 MAE-UGYEMPRE                PIC X(01).                  07480000
074900       10 MAE-UGYCATAE                PIC X(01).                  07490000
075000*          **----- STAMP DE ULTIMA MODIFICACION -----**           07500000
075100    05 MAE-STAMP-UMO.                                             07510000
075200       10 MAE-ENTIDAD-UMO             PIC X(04).                  07520000
075300       10 MAE-CENTRO-UMO              PIC X(04).                  07530000
075400       10 MAE-USERID-UMO              PIC X(08).                  07540000
075500       10 MAE-NETNAME-UMO             PIC X(08).                  07550000
075600       10 MAE-TIMESTAMP               PIC X(26).                  07560000
075700                                                                  07570000
075800*       ***--------------------------------------------------*** *07580000
075900*       ***--  MODIFICACIO OPIRAT   10.02.93               --*** *07590000
076000*       ***--------------------------------------------------*** *07600000
076100    05 MAE-MODIF-VAR.                                             07610000
076200       10 MAE-UGYVTOME                PIC S9(03)        COMP-3.   07620000
076300*LAP   10 MAE-UGYTRI                  PIC S9(03)V999    COMP-3.   07630000
076400       10 MAE-UGYTRI                  PIC S9(03)V9(5)   COMP-3.   07640000
076500       10 MAE-UGCNACRE                PIC  X(03).                 07650000
076600       10 MAE-UGYCGOCU                PIC  X.                     07660000
076700          88 MAE-88-UGYCGOCU-SI       VALUE 'S'.                  07670000
076800          88 MAE-88-UGYCGOCU-NO       VALUE 'N'.                  07680000
076900       10 MAE-UGNOFPRE                PIC  X(08).                 07690000
077000       10 MAE-UGIMPFDO                PIC S9(12)V999    COMP-3.   07700000
077100       10 MAE-UGIPROIM                PIC S9(12)V999    COMP-3.   07710000
077200       10 MAE-UGCREFEM                PIC  X(03).                 07720000
077300       10 MAE-UGYNVENC                PIC  X.                     07730000
077400       10 MAE-UGCTIVEN                PIC  X.                     07740000
077500*@-FASE-2-BBV-PR-I                                               *07750000
077600       10 MAE-DEALER                  PIC  X(10).                 07760000
077700       10 MAE-CAMPANA                 PIC  X(4).                  07770000
077800       10 MAE-PAGO-PREVIO             PIC S9(12)V999  COMP-3.     07780000
077900*@-FASE-2-BBV-PR-F                                               *07790000
078000*@-BC-I-LAP                                                      *07800000
078100       10 MAE-CUENTA-ANT              PIC  X(10).                 07810000
078200*@-BC-I MZ                                                        07820000
078300       10 MAE-CUENTA-ABO              PIC X(20).                  07830000
078400       10 MAE-CUENTA-ABOR  REDEFINES  MAE-CUENTA-ABO.             07840000
078500          15 MAE-ENTIDAD-ABO          PIC X(04).                  07850000
078600          15 MAE-CENTRO-ABO           PIC X(04).                  07860000
078700          15 MAE-CTACCC-ABO           PIC X(10).                  07870000
078800          15 MAE-DIGICCC1-ABO         PIC X(01).                  07880000
078900          15 MAE-DIGICCC2-ABO         PIC X(01).                  07890000
079000*@-BC-F MZ                                                        07900000
079100       10 MAE-GESTOR                  PIC  X(05).                 07910000
079200       10 MAE-LIBRE-IMP6              PIC S9(13)V99   COMP-3.     07920000
079300       10 MAE-LIBRE-IMP7              PIC S9(13)V99   COMP-3.     07930000
079400       10 MAE-LIBRE-IMP8              PIC S9(13)V99   COMP-3.     07940000
079500*@-BC-I MZ  EN ESTE CAMPO SE GUARDARA EL CODIGO DE CLIENTE        07950000
079600*                                     DEL GARANTE                 07960000
079700       10 MAE-LIBRE-CAR4              PIC X(10).                  07970000
079800*@-BC-F MZ                                                        07980000
079900       10 MAE-LIBRE-CAR5              PIC X(05).                  07990000
080000       10 MAE-LIBRE-CAR6              PIC X(05).                  08000000
080100       10 MAE-ERROR-CONVERSI REDEFINES MAE-LIBRE-CAR6             08010000
080200                                      PIC X(05).                  08020000
080300       10 MAE-IND-MARCA9              PIC X(01).                  08030000
080400       10 MAE-INDMASIV REDEFINES MAE-IND-MARCA9                   08040000
080500                                      PIC X(01).                  08050000
080600          88 MAE-88-INDMASIV-CENTRAL      VALUE 'C'.              08060000
080700          88 MAE-88-INDMASIV-DESCENT      VALUE 'D'.              08070000
080800          88 MAE-88-INDMASIV-NORMAL       VALUE 'N'.              08080000
080900       10 MAE-IND-MARCA10             PIC X(01).                  08090000
081000       10 MAE-TIPOCOR  REDEFINES MAE-IND-MARCA10                  08100000
081100                                      PIC X(01).                  08110000
081200          88 MAE-88-TIPOCOR-FISICA        VALUE 'F'.              08120000
081300          88 MAE-88-TIPOCOR-JUDICIAL      VALUE 'M'.              08130000
081400       10 MAE-IND-MARCA11             PIC X(01).                  08140000
081500*@-GB-YAO                                                         08150000
081600       10 MAE-IND-CONVERSI REDEFINES  MAE-IND-MARCA11             08160000
081700                                      PIC X(01).                  08170000
081800       10 MAE-EXPEDIENTE              PIC X(10).                  08180000
081900*@-BC-F-LAP                                                      *08190000
082000*@-BG-I                                                           08200000
082100       10 MAE-ACTIVIDAD               PIC X(11).                  08210000
082200******************************************************************08220000
082300*                                                                *08230000
082400*         LONGITUD TOTAL DEL REGISTRO EN BYTES :                 *08240000
082500*                                                                *08250000
082600******************************************************************08260000