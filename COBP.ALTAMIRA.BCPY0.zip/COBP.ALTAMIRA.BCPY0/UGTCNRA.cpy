      ******************************************************************00000100
      * COPY       : UGTCNRA                                           *00000200
      * DESCRIPCION: COPY DE LA TABLA UGDTNRA                          *00000300
      * GP17916-HUQA-CCSS-6856                                         *00000300
      *----------------------------------------------------------------*00003900
      *                     LOG DE MODIFICACIONES                      *00004000
      *----------------------------------------------------------------*00004100
      * AUTOR    FECHA       MODIFICACION                              *
      *----------------------------------------------------------------*
      * C810908  24-03-2022  SE REALIZA AJUSTE PARA INCLUIR NUEVOS     *
      * DCP                  CAMPOS A LA TABLA PARA VARIABLES DE       *
      * COL01                CARTERA COMERCIAL                         *
      *                      GP-35771 COLWSCANAL-1036                  *
      *----------------------------------------------------------------*
      * C810846  09-06-2023  SE REALIZA AJUSTE PARA AUMENTAR EL TAMA#O *
      * GLADIADORES TEAM     DEL CAMPO NRA-CONSECUTIVO A DECIMAL(9).   *
      * COL02                COLWSPREST-15688.                         *
      *----------------------------------------------------------------*
      ******************************************************************00000400
       01  UGTCNRA.                                                     00000500
           10  NRA-TIPO-PRODUCTO       PIC X(2).                        00000600
           10  NRA-VARIABLE            PIC X(2).                        00000700
      *COL02-I
      *    10  NRA-CONSECUTIVO         PIC S9(4) USAGE COMP-3.          00000710
           10  NRA-CONSECUTIVO         PIC S9(9)V USAGE COMP-3.
      *COL02-F
           10  NRA-FECHA-INI           PIC X(10).                       00000800
           10  NRA-FECHA-FIN           PIC X(10).                       00000900
           10  NRA-RANGO-INI           PIC S9(4) USAGE COMP-3.          00001100
           10  NRA-RANGO-FIN           PIC S9(4) USAGE COMP-3.          00001200
           10  NRA-IND-DOM-NOMINA      PIC X(1).                        00001300
           10  NRA-SITUA-LABORAL       PIC X(1).                        00001300
           10  NRA-MONTO-INICIAL       PIC S9(5)V9(4) USAGE COMP-3.     00001400
           10  NRA-MONTO-FINAL         PIC S9(5)V9(4) USAGE COMP-3.     00001500
           10  NRA-SEGMENTO            PIC S9(5)      USAGE COMP-3.
           10  NRA-IND-CLIENTE-VIP     PIC X(1).                        00001800
           10  NRA-RANGO-RIESGO-INI    PIC S9(5)V9(4) USAGE COMP-3.     00001600
           10  NRA-RANGO-RIESGO-FIN    PIC S9(5)V9(4) USAGE COMP-3.     00001700
           10  NRA-IND-ESTADO-VEH      PIC X(1).                        00001900
           10  NRA-IND-TIPO-VEH        PIC X(1).                        00001900
           10  NRA-CLAVE-ID            PIC X(25).                       00001900
           10  NRA-CLUSTER             PIC X(25).                       00001900
           10  NRA-ESTADO              PIC X(2).                        00001900
           10  NRA-TASA                PIC S9(3)V9(4) USAGE COMP-3.     00001900
           10  NRA-CENTRO-UMO          PIC X(4).                        00002100
           10  NRA-USERID-UMO          PIC X(8).                        00002200
           10  NRA-NETNAME-UMO         PIC X(4).                        00002300
           10  NRA-TIMESTAMP           PIC X(26).                       00002400
      *COL01-I
           10  NRA-RATING              PIC X(5).
           10  NRA-RANGO-RATING        PIC X(1).
           10  NRA-GARANTIA            PIC X(1).
           10  NRA-PORCENTA            PIC S9(2)V9(2) USAGE COMP-3.
      *COL01-F
      ******************************************************************00010001
      * COPY NUEVO                                                     *00020001
      ******************************************************************00030001