000100******************************************************************00010000
000200*                                                                *00020000
000300* NOMBRE DEL OBJETO:  UGTCPRO                                    *00030000
000400*                                                                *00040000
000500* DESCRIPCION:   TABLA DE CARACTERISTICAS DE SUBPRODUCTOS        *00050000
000600* --------------------------------------------------------       *00060000
000700*                                                                *00070000
000800* CARACTERISTICAS GENERALES DE SUBPRODUCTOS DE PRESTAMOS         *00080000
000900*                                                                *00090000
001000*                                                                *00100000
001100*                                                                *00110000
001200*                                                                *00120000
001300*                   **----------------------------------------** *00130000
001400*                   **---    CLAVE DE PRODUCTO/SERVICIO    ---** *00140000
001500*                   **----------------------------------------** *00150000
001600* CLAVE                                                          100160000
001700* PRODUCTO          CODIGO DE PRODUCTO                           100170000
001800* SUBPRO            CODIGO DE SUBPRODUCTO                        400180000
001900*                   **----------------------------------------** *00190000
002000*                   **---   DATOS BASICOS DEL SUBPRODUCTO  ---** *00200000
002100*                   **----------------------------------------** *00210000
002200* DATOS-BAS                                                      700220000
002300* TEXTORED          DESCRIPCION ABREVIADA DEL SUBPRODUCTO        700230000
002400* TEXTOLAR          DESCRIPCION DEL SUBPRODUCTO                 2200240000
002500* FECOVALI          FECHA DE COMIENZO DE VALIDEZ                7200250000
002600* FEFIVALI          FECHA DE FIN DE VALIDEZ                     7600260000
002700* IMPMAXGE          IMPORTE MAXIMO GENERAL                      8000270000
002800* CUPOTOPR          CUPO TOTAL POR PRODUCTO                     8700280000
002900* CUPODIPR          CUPO DISPUESTO POR PRODUCTO                 9400290000
003000* PLAZOMIN          PLAZO MINIMO DEL PRESTAMO                  10100300000
003100* PLAZOMAX          PLAZO MAXIMO DEL PRESTAMO                  10500310000
003200* PORINMIN          TIPO DE INTERES MINIMO DEL PRESTAMO        10900320000
003300* PORINMAX          TIPO DE INTERES MAXIMO DEL PRESTAMO        11200330000
003400* INDCUOFI          INDICADOR DE CUPOS POR OFICINA             11500340000
003500* INDCUOFI-0        <'0'> - NO SE DISTRIBUYE POR OFICINA         *00350000
003600* INDCUOFI-1        <'1'> - PDTE. DE DISTRIBUIR POR PROCESO BATC *00360000
003700* INDCUOFI-2        <'2'> - DISTRIBUIDO YA POR PROCESO BATCH     *00370000
003800* INDISSU           INDICADOR DE DISPOSICIONES SUCESIVAS       11600380000
003900* INDISSU-S         <'S'> - SE PERMITEN                          *00390000
004000* INDISSU-N         <'N'> - NO SE PERMITEN                       *00400000
004100* INDENTAN          INDICADOR DE ENTREGAS ANTICIPADAS          11800410000
004200* INDENTAN-S        <'S'> - SE PERMITEN                          *00420000
004300* INDENTAN-N        <'N'> - NO SE PERMITEN                       *00430000
004400* IMPMINEA          IMPORTE MINIMO DE ENTREGAS ANTICIPADAS     11900440000
004500* IMPMIPAR          IMPORTE MINIMO DE PAGO DE RECIBOS          12600450000
004600* NIVCONCE          NIVEL DE CONCESION                         13300460000
004700* NIVCONCE-P        <'P'> - SEGUN ESCALA DE PTMOS. PERSONALES    *00470000
004800* NIVCONCE-H        <'H'> - SEGUN ESCALA DE PTMOS. HIPOTECARIOS  *00480000
004900* PORDISPO          PORCENTAJE DISPOSICIONES SUCESIVAS         13400490000
005000* UGCDEINI          CODIGO DESTINO INICIAL                     13400500000
005100* UGCDEFIN          CODIGO DESTINO FINAL                       13400510000
005200* UGCCAMIN          CODIGO CARENCIA MINIMA                     13400520000
005300* UGCCAMAX          CODIGO CARENCIA MAXIMA                     13400530000
005400* UGQFIMIN          CANTIDAD MINIMA DE FIADORES                13400540000
005500* IND-CONDES        POSIBILIDAD DE CONDICIONES ESPECIFICAS     13600550000
005600* IND-CONDES-S      <'S'> - PERMITE MODIFICAR CUALQUIER CONDIC.  *00560000
005700* IND-CONDES-N      <'N'> - TODAS, MENOS PERCAP, PERINT, CODTIAM *00570000
005800* UGYPRASC         INDICADOR DE PRODUCTO ASCAT                 13400580000
005900* UGYPRASC-S       <'S'> -SI ES PRODUCTO DE ASCAT                *00590000
006000* UGYPRASC-N       <'N'> -NO ES PRODUCTO DE ASCAT                *00600000
006100* UGYSEASO         POSIBILIDAD DE ASOCIAR SEGURO A ASCAT       13400610000
006200*                  NUEVO DOMINIO DE SEGUROS PARA EL BC :         *00620000
006300* UGYSEASO-N       <'N'>  NO TIENE SEGURO ASOCIADO               *00630000
006400* UGYSEASO-S       <'S'>  TIENE SEGURO DE VIDA                   *00640011
006500* UGYSEASO-I       <'I'>  TIENE SEGURO DE VIDA     + INMUEBLE    *00650011
006600* UGYSEASO-V       <'V'>  TIENE SEGURO DE VIDA     + VEHICULO    *00660011
006700* -SE DEJA DE USAR <'S'> -PERMITE ASOCIAR SEGURO DE VIDA         *00670000
006800* -SE DEJA DE USAR <'N'> -NO PERMITE ASOCIAR SEGURO DE VIDA      *00680000
006900* UGYADPAG         POSIBILIDAD DE ADMITIR PAGARES              13400690000
007000* UGYADPAG-S       <'S'> -PERMITE ASOCIAR PAGARES                *00700000
007100* UGYADPAG-N       <'N'> -NO PERMITE ASOCIAR PAGARES             *00710000
007200* UGYPREMP         PRESTAMOS A EMPLEADOS                       13*00720000
007300* @IBC JLG  REDEFINIDO COMO TIPOCLI                              *00730000
007400*  TIPOCLI REDEFINES   UGYPREMP                                  *00740000
007500*  TIPO-CLI-E       <'E'> - EMPLEADOS                            *00750000
007600*  TIPO-CLI-C       <'C'> - CLIENTES                             *00760000
007700*  TIPO-CLI-D       <'D'> - DIRECTIVOS                           *00770000
007800* UGYPREMP-N---------------------------------                    *00780000
007900* PERINT           PERIODICIDAD DE INTERESES                     *00790000
008000* TIPOREDU         TIPO DE REDUCCION                             *00800000
008100* TIPOREDU-P       <'P'> - REDUCCION PERIODICA                   *00810000
008200* TIPOREDU-A       <'A'> - REDUCCION APERIODICA                  *00820000
008300* TIPOREDU-V       <'V'> - REDUCCION AL VENCIMIENTO              *00830000
008400* PERIODICI        PERIODICIDAD DE REDUCCION                     *00840000
008500* TIPODIAS         TIPO DIAS PARA CALCULO PERIODICIDAD COMISION  *00850000
008600* TIPODIAS-1       <'1'> - SOBRE DIA DE APERTURA                 *00860000
008700* TIPODIAS-2       <'2'> - PERIODOS NATURALES                    *00870000
008800* TIPODIAS-5       <'5'> - PERIODOS NATURALES SIN FRACCION       *00880000
008900* DIASCAL          DIAS A#O APLICAR                              *00890000
009000* DIASCAL-N        <'N'> - A#O NATURAL                           *00900000
009100* DIASCAL-C        <'C'> - A#O COMERCIAL                         *00910000
009200* INDINANT         INDICADOR TIPO VENCIMIENTO                    *00920000
009300* INDINANT-V       <'V'> - VENCIDOS                              *00930000
009400* INDINANT-A       <'A'> - ANTICIPADOS                           *00940000
009500* UGPCMAPN         COMISION AMORTIZACION PARCIAL MINIMA          *00950000
009600* UGPCMAPX         COMISION AMORTIZACION PARCIAL MAXIMA          *00960000
009700* UGPCMATN         COMISION AMORTIZACION TOTAL MINIMA            *00970000
009800* UGPCMATX         COMISION AMORTIZACION TOTAL MAXIMA            *00980000
009900* UGPCMAMN         COMISION APERTURA MINIMA                      *00990000
010000* UGPCMAMX         COMISION APERTURA MAXIMA                      *01000000
010100* UGPDFCAN         DIFERENCIAL CARENCIA MINIMO                   *01010000
010200* UGPDFCAX         DIFERENCIAL CARENCIA MAXIMO                   *01020000
010300* UGPDFAMN         DIFERENCIAL AMORTIZACION MINIMO               *01030000
010400* UGPDFAMX         DIFERENCIAL AMORTIZACION MAXIMO               *01040000
010500* UGPDPEMN         GASTOS ESTUDIO MINIMO                         *01050000
010600* UGPDPEMX         GASTOS ESTUDIO MAXIMO                         *01060000
010700*                   **-----------CAMPOS  LIBRES---------------** *01070000
010800* IND-MARCA1        MARCA 1                                    13701080000
010900*                   INDICADOR DE CLASE DE PRODUCTO             13701090000
011000*                   UGYTIPRO-0  NORMAL                         13701100000
011100*                   UGYTIPRO-1  MIBOR                          13701110000
011200*                   UGYTIPRO-8  REVOLVING                      13701120000
011300* IND-MARCA2        MARCA 2                                    13801130000
011400* TIPOPRO           REDEFINIDO DE IND-MARCA2                   13801140000
011500*                   INDICADOR DE TIPO DE PRODUCTO              13801150000
011600*                  TIPOPRO-A  DESCUBIERTOS CTA CTE             13801160010
011800*                  TIPOPRO-C  CREDITO CONSUMO                  13801180010
011900*                  TIPOPRO-D  COMERCIO                         13801190010
012000*                  TIPOPRO-E  CREDIFAST                        13801200010
012010*                  TIPOPRO-F  CREDITO HIPOTECARIO              13801201010
012020*                  TIPOPRO-G  CREDITO HIP DIF.VIVIENDA         13801202010
012030*                  TIPOPRO-H  GANACA#A                         13801203010
012040*                  TIPOPRO-I  RESOLUCIONES                     13801204010
012050*                  TIPOPRO-J  FACTORING SIN RECURSOS           13801205010
012060*                  TIPOPRO-K  OTROS ORDINARIOS                 13801206010
012070*                  TIPOPRO-R  REDESCUENTOS                     13801207010
012100* IND-MARCA3        MARCA 3                                    13901210000
012200* UGYCONV           REDEFINIDO DE IND-MARCA3                   13901220000
012300*                   INDICADOR DE CONTROL NOMINAL PERICIAL      13901230000
012400*                  UGYCONV-N NOMINAL                           13901240000
012500*                  UGYCONV-P PERICIAL                          13901250000
012600* LIBRE-IMP1        IMPORTE LIBRE                              14001260000
012700* LIBRE-IMP2        IMPORTE LIBRE                              14701270000
012800* LIBRE-CAR1        CARACTER LIBRE                             15001280000
012900*                   **----- STAMP DE ULTIMA MODIFICACION -----** *01290000
013000* STAMP-UMO                                                    15501300000
013100* ENTIDAD-UMO       ENTIDAD QUE REALIZO LA ULTIMA MODIFICACION 15501310000
013200* CENTRO-UMO        CENTRO QUE REALIZO LA ULTIMA MODIFICACION  15901320000
013300* USERID-UMO        USUARIO QUE REALIZO LA ULTIMA MODIFICACION 16301330000
013400* NETNAME-UMO       TERMINAL QUE REALIZO LA ULTIMA MODIFICACIO 17101340000
013500* TIMESTAMP         FECHA Y HORA DE LA ULTIMA MODIFICACION     17901350000
013600*@IBC JLG                                                         01360000
013700* IMPMINGE          IMPORTE MINIMO GENERAL                        01370000
013800* INDEALER          INDICADOR DE DEALER                           01380000
013900* MONEDA            MONEDA                                        01390000
014000* INDCRSCO          IND. DE OBLIGAT. DE CREDIT SCORING            01400000
014100* INDMASIV          IND. DEL SUBPRODUCTO MASIVO                   01410000
014200* TIPOCOR           PERSONERIA                                    01420000
014300*                   F: PERSONA FISICA                             01430000
014400*                   M: PERSONA JURIDICA                           01440000
014500*@FBC JLG                                                         01450000
014600*                                                                *01460000
014700******************************************************************01470000
014800******************************************************************01480000
014900* MODIFICACION AL0047D  02/94                                    *01490000
015000* SE CAMBIAN LOS CNAE DE CUATRO DIGITOS POR LOS DE CINCO POR     *01500000
015100* IMPERATIVO LEGAL EN LA COPY UGTCPRO, EL OBJETO                 *01510000
015200* ES EL CAMPO UGCDEINI, UGCDEFIN.                                *01520000
015300******************************************************************01530000
015400*                                                                 01540000
015500                                                                  01550000
015600 01 UGTCPRO.                                                      01560000
015700*          **----------------------------------------**           01570000
015800*          **---    CLAVE DE PRODUCTO/SERVICIO    ---**           01580000
015900*          **----------------------------------------**           01590000
016000    05 PRO-CLAVE.                                                 01600000
016100       10 PRO-PRODUCTO                PIC X(02).                  01610000
016200       10 PRO-SUBPRO                  PIC X(04).                  01620000
016300*          **----------------------------------------**           01630000
016400*          **---   DATOS BASICOS DEL SUBPRODUCTO  ---**           01640000
016500*          **----------------------------------------**           01650000
016600    05 PRO-DATOS-BAS.                                             01660000
016700       10 PRO-TEXTORED                PIC X(15).                  01670000
016800       10 PRO-TEXTOLAR                PIC X(50).                  01680000
016900       10 PRO-FECOVALI                PIC X(10).                  01690000
017000       10 PRO-FEFIVALI                PIC X(10).                  01700000
017100*@IBBV-PR                                                         01710000
017200*      10 PRO-IMPMAXGE                PIC S9(13)      COMP-3.     01720000
017300*      10 PRO-CUPOTOPR                PIC S9(13)      COMP-3.     01730000
017400*      10 PRO-CUPODIPR                PIC S9(13)      COMP-3.     01740000
017500       10 PRO-IMPMAXGE                PIC S9(13)V99   COMP-3.     01750000
017600       10 PRO-CUPOTOPR                PIC S9(13)V99   COMP-3.     01760000
017700       10 PRO-CUPODIPR                PIC S9(13)V99   COMP-3.     01770000
017800*@FBBV-PR                                                         01780000
017900       10 PRO-PLAZOMIN                PIC X(04).                  01790000
018000       10 PRO-PLAZOMAX                PIC X(04).                  01800000
018100*LAP   10 PRO-PORINMIN                PIC S9(02)V9(3) COMP-3.     01810000
018200*LAP   10 PRO-PORINMAX                PIC S9(02)V9(3) COMP-3.     01820000
018300       10 PRO-PORINMIN                PIC S9(03)V9(5) COMP-3.     01830000
018400       10 PRO-PORINMAX                PIC S9(03)V9(5) COMP-3.     01840000
018500       10 PRO-INDCUOFI                PIC X(01).                  01850000
018600          88 PRO-88-INDCUOFI-0        VALUE '0'.                  01860000
018700          88 PRO-88-INDCUOFI-1        VALUE '1'.                  01870000
018800          88 PRO-88-INDCUOFI-2        VALUE '2'.                  01880000
018900       10 PRO-INDISSU                 PIC X(01).                  01890000
019000          88 PRO-88-INDISSU-S         VALUE 'S'.                  01900000
019100          88 PRO-88-INDISSU-N         VALUE 'N'.                  01910000
019200       10 PRO-INDENTAN                PIC X(01).                  01920000
019300          88 PRO-88-INDENTAN-S        VALUE 'S'.                  01930000
019400          88 PRO-88-INDENTAN-N        VALUE 'N'.                  01940000
019500*@IBBV-PR                                                         01950000
019600*      10 PRO-IMPMINEA                PIC S9(13)      COMP-3.     01960000
019700*      10 PRO-IMPMIPAR                PIC S9(13)      COMP-3.     01970000
019800       10 PRO-IMPMINEA                PIC S9(13)V99   COMP-3.     01980000
019900       10 PRO-IMPMIPAR                PIC S9(13)V99   COMP-3.     01990000
020000*@FBBV-PR                                                         02000000
020100       10 PRO-NIVCONCE                PIC X(01).                  02010000
020200          88 PRO-88-NIVCONCE-P        VALUE 'P'.                  02020000
020300          88 PRO-88-NIVCONCE-H        VALUE 'H'.                  02030000
020400       10 PRO-PORDISPO                PIC S9(03)      COMP-3.     02040000
020500*                                                                 02050000
020600*@PAL0047D *******************************************************02060000
020700*                                                                 02070000
020800*      10 PRO-UGCDEINI                PIC X(4).                   02080000
020900*      10 PRO-UGCDEFIN                PIC X(4).                   02090000
021000       10 PRO-UGCDEINI                PIC X(5).                   02100000
021100       10 PRO-UGCDEFIN                PIC X(5).                   02110000
021200*                                                                 02120000
021300*@FAL0047D *******************************************************02130000
021400*                                                                 02140000
021500       10 PRO-UGCCAMIN                PIC X(4).                   02150000
021600       10 PRO-UGCCAMAX                PIC X(4).                   02160000
021700       10 PRO-UGQFIMIN                PIC X(1).                   02170000
021800       10 PRO-IND-CONDES              PIC X(01).                  02180000
021900          88 PRO-88-IND-CONDES-S      VALUE 'S'.                  02190000
022000          88 PRO-88-IND-CONDES-N      VALUE 'N'.                  02200000
022100       10 PRO-UGYPRASC                PIC X(1).                   02210000
022200          88 PRO-88-UGYPRASC-S        VALUE 'S'.                  02220000
022300          88 PRO-88-UGYPRASC-N        VALUE 'N'.                  02230000
022400       10 PRO-UGYSEASO                PIC X(1).                   02240000
022500*@IBC JLG                                                         02250000
022600          88 PRO-88-UGYSEASO-N        VALUE 'N'.                  02260000
022700          88 PRO-88-UGYSEASO-S        VALUE 'S'.                  02270000
022800          88 PRO-88-UGYSEASO-I        VALUE 'I'.                  02280000
022900          88 PRO-88-UGYSEASO-V        VALUE 'V'.                  02290000
023000*@FBC JLG                                                         02300000
023100       10 PRO-UGYADPAG                PIC X(1).                   02310000
023200          88 PRO-88-UGYADPAG-S        VALUE 'S'.                  02320000
023300          88 PRO-88-UGYADPAG-N        VALUE 'N'.                  02330000
023400*@IBC JLG SE CAMBIA DE NOMBRE JUL1997                             02340000
023500       10 PRO-UGYPREMP                PIC X(1).                   02350000
023600       10 PRO-TIPOCLI  REDEFINES PRO-UGYPREMP      PIC X(01).     02360000
023700*@        88 PRO-88-UGYPREMP-S        VALUE 'S'.                  02370000
023800*@        88 PRO-88-UGYPREMP-N        VALUE 'N'.                  02380000
023900          88 PRO-88-TIPOCLI-E         VALUE 'E'.                  02390000
024000          88 PRO-88-TIPOCLI-C         VALUE 'C'.                  02400000
024100          88 PRO-88-TIPOCLI-D         VALUE 'D'.                  02410000
024200*@FBC JLG                                                         02420000
024300       10 PRO-PERINT                  PIC X(3).                   02430000
024400       10 PRO-TIPOREDU                PIC X(1).                   02440000
024500          88 PRO-88-TIPOREDU-P        VALUE 'P'.                  02450000
024600          88 PRO-88-TIPOREDU-A        VALUE 'A'.                  02460000
024700          88 PRO-88-TIPOREDU-V        VALUE 'V'.                  02470000
024800       10 PRO-PERIODICI               PIC X(3).                   02480000
024900       10 PRO-TIPODIAS                PIC X(1).                   02490000
025000          88 PRO-88-TIPODIAS-1        VALUE '1'.                  02500000
025100          88 PRO-88-TIPODIAS-2        VALUE '2'.                  02510000
025200          88 PRO-88-TIPODIAS-5        VALUE '5'.                  02520000
025300       10 PRO-DIASCAL                 PIC X(1).                   02530000
025400          88 PRO-88-DIASCAL-N         VALUE 'N'.                  02540000
025500          88 PRO-88-DIASCAL-C         VALUE 'C'.                  02550000
025600       10 PRO-INDINANT                PIC X(1).                   02560000
025700          88 PRO-88-INDINANT-V        VALUE 'V'.                  02570000
025800          88 PRO-88-INDINANT-A        VALUE 'A'.                  02580000
025900       10 PRO-UGPCMAPN                PIC S9(02)V9(3) COMP-3.     02590000
026000       10 PRO-UGPCMAPX                PIC S9(02)V9(3) COMP-3.     02600000
026100       10 PRO-UGPCMATN                PIC S9(02)V9(3) COMP-3.     02610000
026200       10 PRO-UGPCMATX                PIC S9(02)V9(3) COMP-3.     02620000
026300       10 PRO-UGPCMAMN                PIC S9(02)V9(3) COMP-3.     02630000
026400       10 PRO-UGPCMAMX                PIC S9(02)V9(3) COMP-3.     02640000
026500       10 PRO-UGPDFCAN                PIC S9(02)V9(3) COMP-3.     02650000
026600       10 PRO-UGPDFCAX                PIC S9(02)V9(3) COMP-3.     02660000
026700       10 PRO-UGPDFAMN                PIC S9(02)V9(3) COMP-3.     02670000
026800       10 PRO-UGPDFAMX                PIC S9(02)V9(3) COMP-3.     02680000
026900       10 PRO-UGPDPEMN                PIC S9(02)V9(3) COMP-3.     02690000
027000       10 PRO-UGPDPEMX                PIC S9(02)V9(3) COMP-3.     02700000
027100*          **-----------CAMPOS  LIBRES---------------**           02710000
027200       10 PRO-IND-MARCA1              PIC X(01).                  02720000
027300       10 PRO-UGYTIPRO REDEFINES PRO-IND-MARCA1    PIC X(01).     02730000
027400*@-IBC JLG                                                        02740000
027500       10 PRO-IND-MARCA2              PIC X(01).                  02750000
027600       10 PRO-TIPOPRO  REDEFINES PRO-IND-MARCA2    PIC X(01).     02760000
027700          88 PRO-88-TIPOPRO-DESCUB       VALUE 'A'.               02770010
027800          88 PRO-88-TIPOPRO-CONSUMO      VALUE 'C'.               02780010
027900          88 PRO-88-TIPOPRO-COMERCIAL    VALUE 'D'.               02790010
028000          88 PRO-88-TIPOPRO-CREDIFAST    VALUE 'E'.               02800010
028100          88 PRO-88-TIPOPRO-HIPOTECA     VALUE 'F'.               02810010
028120          88 PRO-88-TIPOPRO-HIPO-DIF     VALUE 'G'.               02812010
028130          88 PRO-88-TIPOPRO-GANACA       VALUE 'H'.               02813010
028140          88 PRO-88-TIPOPRO-RESOLUC      VALUE 'I'.               02814010
028150          88 PRO-88-TIPOPRO-FACTORING    VALUE 'J'.               02815010
028160          88 PRO-88-TIPOPRO-OTROS        VALUE 'K'.               02816010
028170          88 PRO-88-TIPOPRO-REDESC       VALUE 'R'.               02817010
028200*@-FBC JLG                                                        02820000
028300       10 PRO-IND-MARCA3              PIC X(01).                  02830000
028400       10 PRO-UGYCONV  REDEFINES PRO-IND-MARCA3    PIC X(01).     02840000
028500          88 PRO-88-UGYCONV-NOMINAL     VALUE 'N'.                02850000
028600          88 PRO-88-UGYCONV-PERICIAL    VALUE 'P'.                02860000
028700*@IBBV-PR                                                         02870000
028800*      10 PRO-LIBRE-IMP1              PIC S9(13)      COMP-3.     02880000
028900*      10 PRO-LIBRE-IMP2              PIC S9(05)      COMP-3.     02890000
029000       10 PRO-LIBRE-IMP1              PIC S9(13)V99   COMP-3.     02900000
029100       10 PRO-LIBRE-IMP2              PIC S9(05)V99   COMP-3.     02910000
029200*@FBBV-PR                                                         02920000
029300       10 PRO-LIBRE-CAR1              PIC X(05).                  02930000
029400*          **----- STAMP DE ULTIMA MODIFICACION -----**           02940000
029500    05 PRO-STAMP-UMO.                                             02950000
029600       10 PRO-ENTIDAD-UMO             PIC X(04).                  02960000
029700       10 PRO-CENTRO-UMO              PIC X(04).                  02970000
029800       10 PRO-USERID-UMO              PIC X(08).                  02980000
029900       10 PRO-NETNAME-UMO             PIC X(08).                  02990000
030000       10 PRO-TIMESTAMP               PIC X(26).                  03000000
030100*@IBC JLG                                                         03010000
030200    05 PRO-NUEVOS-CAMPOS.                                         03020000
030300       10 PRO-IMPMINGE                PIC S9(13)V99   COMP-3.     03030000
030400       10 PRO-INDEALER                PIC X(01).                  03040000
030500       10 PRO-MONEDA                  PIC X(03).                  03050000
030600       10 PRO-INDCRSCO                PIC X(01).                  03060000
030700       10 PRO-INDMASIV                PIC X(01).                  03070000
030800          88 PRO-88-INDMASIV-CENTRAL      VALUE 'C'.              03080000
030900          88 PRO-88-INDMASIV-DESCENT      VALUE 'D'.              03090000
031000          88 PRO-88-INDMASIV-NORMAL       VALUE 'N'.              03100000
031100       10 PRO-TIPOCOR                 PIC X(01).                  03110000
031200          88 PRO-88-TIPOCOR-FISICA        VALUE 'F'.              03120000
031300          88 PRO-88-TIPOCOR-JURIDICA      VALUE 'M'.              03130000
031400*@FBC JLG                                                         03140000
031500******************************************************************03150000
031600*                                                                *03160000
031700*         LONGITUD TOTAL DEL REGISTRO EN BYTES :    XXX          *03170000
031800* MODIFICACION AL0047D    ..........................XXX          *03180000
031900*@IBBV-PR   AUMENTA A XXX                                         03190000
032000******************************************************************03200000