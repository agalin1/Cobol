      *_______________________________________________________________* 00002191
      *                   LOG DE MODIFICACIONES                         00002192
      *_______________________________________________________________* 00002193
      * CODIGO  AUTOR   FECHA       DESCRIPCION                       * 00002194
      * ------- ------- ----------  ----------------------------------* 00002195
      * C804405 JNSS    09/10/2023  SE AJUSTA DCL PARA APUNTAR AL     * 00002196
      * REALIZO  : BBVA-COLOMBIA    OWNER DE CORRECTO Y NO SIEMPRE AL * 00002197
      * MARCA    : COL-01           DE DESARROLLO                     * 00002198
      *                                                               * 00002198
      * PROYECTO : DEPURACION DE PRESTAMOS                            * 00002199
      * FEATURE  : COLWSMANTE-184                                     * 00002200
      * ENABLER  : COLWSMANTE-184                                     * 00002201
      * HUQA     : COLWSMANTE-334                                     * 00002202
      *_______________________________________________________________* 00002203
      * COBOL DECLARATION FOR TABLE UGDTRVE                            *
      ******************************************************************
       01  UGTCRVE.
           10 RVE-ENTIOFI          PIC X(8).
           10 RVE-CUENTA           PIC X(10).
           10 RVE-GAMA-VEH         PIC S9(5)V9(4) USAGE COMP-3.
           10 RVE-DSC-GAMA-VEH     PIC S9(3)V9(3) USAGE COMP-3.
           10 RVE-TIPO-VEH         PIC X(2).
           10 RVE-DSC-TIPO-VEH     PIC S9(3)V9(3) USAGE COMP-3.
           10 RVE-ESTADO-VEH       PIC X(1).
           10 RVE-DSC-ESTD-VEH     PIC S9(3)V9(3) USAGE COMP-3.
           10 RVE-USERID-UMO       PIC X(8).
           10 RVE-NETNAME-UMO      PIC X(4).
           10 RVE-PRGRM-UMO        PIC X(8).
           10 RVE-TIMEST-UMO       PIC X(26).
      ******************************************************************
      * THE NUMBER OF COLUMNS DESCRIBED BY THIS DECLARATION IS 12      *
      ******************************************************************