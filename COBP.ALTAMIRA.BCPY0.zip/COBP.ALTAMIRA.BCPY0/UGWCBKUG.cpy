      *________________________ INICIO COPY ___________________________*
      * APLICACION.: UG                                                *
      * NOMBRE.....: UGWCBKUG.                                         *
      * DESCRIPCION: COPY DE LA ESTRUCTURA DE LA TODAS LA TABLAS UG    *
      * REALIZO....: JUAN SALAZAR (BBVA).                              *
      * FECHA......: 01 DE MARZO DE 2023.                              *
      * FEATURE....: COLWSMANTE-101                                    *
      * ENABLER....: N/A                                               *
      * HUQA.......: COLWSMANTE-231                                    *
      *                                                                *
      * NOMBRE DEL OBJETO:  TABLAS PRESTAMOS                           *
      *                                                                *
      * DESCRIPCION:                                                   *
      * ______________________________________________________________ *
      *                                                                *
      *             TABLA DE CONTRATOS DE PRESTAMOS                    *
      *                                                                *
      *                                                                *
      *________________________________________________________________*
      *          L O G    D E   M O D I F I C A C I O N E S            *
      *________________________________________________________________*
      *    MARCA      AUTOR    FECHA  DESCRIPCION                      *
      * ___________ _________ _______ ________________________________ *
      *                                                                *
      *________________________________________________________________*
       01 UGWCBKUG.
        03 BKUG-ENTRADA.
          05 BKUG-OPCION                   PIC X(02).

        03 BKUG-DATOS.
          05 BKUG-CAMPOS                   PIC X(1000) VALUE SPACES.

        03 BKUG-SALIDA.
          05 BKUG-S-ERROR.
             10 BKUG-RETORNO               PIC 9(02).
             10 BKUG-DESCERROR             PIC X(40).
             10 BKUG-TABLA                 PIC X(07).
             10 BKUG-SQL                   PIC S9(9).

      *________________________FIN COPY________________________________*