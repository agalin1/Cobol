      ******************************************************************00001000
      *   COPY: UGWCNRA                                                *00002000
      *   COPY DE COMMAREA PARA LA RUTINA UG7CCNRA PARA CONSULTAR LA   *00003000
      *   TASA RAR GP17916 CCSS-6856                                   *
      * -------------------------------------------------------------- *00005000
      *    - UGNRA-OPCION      : OPCION DE USO RUTINA                  *
      * -------------------------------------------------------------- *00005000
      *  DATOS DE ENTRADA CONSULTA TASA RAR (OPCION C)                 *00006000
      * -------------------------------------------------------------- *00005000
      *    - UGNRA-BURO        : BURO                                  *00009000
      *    - UGNRA-DOM-NOMINA  : DOMICIALIZACION DE NOMINA             *00010000
      *    - UGNRA-LABORAL     : SITUACION LABORAL                     *00011100
      *    - UGNRA-INGRESOS    : INGRESOS                              *00011100
      *    - UGNRA-MONTO       : MONTO                                 *00011100
      *    - UGNRA-PLAZO       : PLAZO                                 *00011100
      *    - UGNRA-EDAD        : EDAD                                  *00011100
      *    - UGNRA-SEGMENTO    : SEGMENTO DEL CLIENTE                  *00011100
      *    - UGNRA-COLECTIVO   : COLECTIVO                             *00011100
      *    - UGNRA-RIESGO      : RIESGO                                *00011100
      *    - UGNRA-CLIENTEV    : CLIENTE VIP                           *00011100
      *    - UGNRA-FINANCIA    : FINANCIACION                          *00011100
      *    - UGNRA-ESTADO      : ESTADO DEL VEHICULO                   *00011100
      *    - UGNRA-GAMA        : GAMA DEL VEHICULO                     *00011100
      *    - UGNRA-TIPO        : TIPO DEL VEHICULO                     *00011100
      * -------------------------------------------------------------- *00005000
      *  DATOS DE ENTRADA CONTROL DE TASA      (OPCION V)              *00006000
      * -------------------------------------------------------------- *00005000
      *    - UGNRA-TASA-PREF   : TASA PREFERENTE                       *00011100
      *    - UGNRA-TASA-POLI   : TASA POLITICA                         *00011100
      *    - UGNRA-TASA-USURA  : TASA USURA                            *00011100
      *    - UGNRA-TASA-RAR    : TASA RAR                              *00011100
      *    - UGNRA-TASA-PISO   : TASA PISO                             *00011100
      * -------------------------------------------------------------- *00005000
      *  DATOS DE SALIDA  :                                            *00014000
      *    - UGNRA-TASA-RAR   : TASA RAR                               *00015000
      *    - UGNRA-TASA-FORM  : TASA FORMALIZACION                     *00015000
      *    - UGNRA-CLUSTER    : NOMBRE DEL CLUSTER                     *00015000
      *    - UGNRA-RETORNO    : CODIGO DE RETORNO                      *00015000
      *      VALORES          : '00' OPERACION REALIZADA OK            *00016000
      *                         '10' ERROR INGRESO DATOS               *00017000
      *                         '20' ERROR DB2 EN TABLA PERMITIDO      *00018000
      *                         '99' ERROR DB2                         *00019000
      * -------------------------------------------------------------- *00005000
      *  * CUANDO OCURRA UN ERROR EN LA EJECUCION DEL PROGRAMA SE  *   *00022000
      *           DEBERAN INFORMAR LOS SIGUIENTES CAMPOS               *00023000
      *                                                                *00024000
      *    - UGNRA-ERROR        : MENSAJE DE ERROR                     *00042000
      *    - UGNRA-SQLCODE      : CODIGO DE DB2 GENERADO EN EL ERROR   *00029000
      *    - UGNRA-SQLERRM      : CONDICION DEL ERROR                  *00030000
      *                                                                *00036000
      ******************************************************************00069000
      *----------------------------------------------------------------*
      * COL01  04/02/2022  MODIFICACION PARA INCLUIR COLECTIVO-DESTINO *00000421
      * INETUM CE56375     Y CONTROLES TASA RAR LIBRANZA               *00000422
      * SCRUM - SDA36560 - COLWSPREST-54 - COLWSPREST-383 OTORGAR TASAS*00000423
      * PERSONALIZADAS LIBRANZAS                                       *00000424
      *----------------------------------------------------------------*
      *                                                                 00076000
        02  UGWCNRA.                                                    00070000
            05 UGNRA-ENTRADA.                                           00071000
               10 UGNRA-OPCION              PIC X(01).                  00077000
               10 UGNRA-PRODUCTO            PIC X(02).                  00077000
               10 UGNRA-FECHA               PIC X(10).                  00077000
               10 UGNRA-BURO                PIC X(04).                  00077000
               10 UGNRA-NOMINA              PIC X(01).                  00077000
               10 UGNRA-SITLAB              PIC X(01).                  00082000
               10 UGNRA-INGRESOS            PIC 9(05)V9(04).            00082000
               10 UGNRA-MONTO               PIC 9(05)V9(04).            00082000
               10 UGNRA-PLAZO               PIC 9(04).                  00082000
               10 UGNRA-EDAD                PIC 9(02).                  00082000
               10 UGNRA-SEGMENTO            PIC 9(05).                  00082000
               10 UGNRA-COLECTIVO           PIC 9(04).                  00082000
               10 UGNRA-RIESGO              PIC 9(05)V9(04).            00082000
               10 UGNRA-INDVIP              PIC X(01).                  00082000
               10 UGNRA-FINANCIA            PIC 9(01)V9(04).            00082000
               10 UGNRA-ESTADO              PIC X(01).                  00082000
               10 UGNRA-GAMA                PIC 9(05)V9(04).            00082000
               10 UGNRA-TIPVEH              PIC X(01).                  00082000
               10 UGNRA-SUBPRO              PIC X(04).                  00082000
      *COL01-I                                                          00096000
               10 UGNRA-CLTVOLB             PIC 9(02).                  00082000
               10 UGNRA-DESTNLB             PIC 9(02).                  00082000
      *COL01-F                                                          00096000
      *                                                                 00096000
            05 UGNRA-TASA.
               10 UGNRA-TASA-PREF           PIC 9(03)V9(05).
               10 UGNRA-TASA-POLI           PIC 9(03)V9(05).
               10 UGNRA-TASA-USURA          PIC 9(03)V9(05).
               10 UGNRA-TASA-PISO           PIC 9(03)V9(05).
      *                                                                 00096000
            05 UGNRA-SALIDA.                                            00110000
               10 UGNRA-TASA-RAR            PIC 9(03)V9(05).
               10 UGNRA-TASA-FORM           PIC 9(03)V9(05).
               10 UGNRA-CLUSTER             PIC X(25).
               10 UGNRA-COD-RETORNO         PIC X(02).                  00111000
               10 UGNRA-VAR1-ERROR          PIC X(20).                  00103000
               10 UGNRA-VAR2-ERROR          PIC X(20).                  00103000
               10 UGNRA-SQLCODE             PIC S9(3).                  00103000
               10 UGNRA-SQLERRM             PIC X(10).                  00102000
      *                                                                 00109000
      ******************************************************************00127000