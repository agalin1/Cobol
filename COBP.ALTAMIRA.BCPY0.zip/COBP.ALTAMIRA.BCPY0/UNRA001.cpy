      * -------------------------------------------------------------- *00000100
      *   FORMATO DE ENTRADA TRANSACCION UNRA GP17916-HUQA-CCSS-7934   *00000300
      * -------------------------------------------------------------- *00000420
      * COL01  01-02-2022  MODIFICACION PARA INCLUIR COLECTIVO-DESTINO *00000421
      * INETUM CE56375     Y CONTROLES TASA RAR LIBRANZA               *00000422
      * SCRUM - SDA36560 - COLWSPREST-54 - COLWSPREST-383 OTORGAR TASAS*00000423
      * PERSONALIZADAS LIBRANZAS                                       *00000424
      * -------------------------------------------------------------- *00000430
      * C810908  03-06-2022  SE REALIZA AJUSTE PARA MOVER/ACOMODAR     *
      * DCP                  MAPA PARA MOSTRAR EN LA CONSULTA LAS      *
      * COL02                NUEVAS VARIABLES DE CARTERA COMERCIAL.    *
      * IN-137923            SDA35771 COLWSCANAL-1036                  *
      * -------------------------------------------------------------- *
      * COL03    04-03-2026  SE AJUSTA EL COPY PARA INCLUIR COMO       *
      * O008055              CAMPOS NUEVOS LOS TEXTOS A MOSTRAR Y      *
      *                      OCULTAR PARA LAS NUEVAS VARIABLES DE LA   *
      *                      CARTERA HIPOTECARIA Y LEASING HABITACIONAL*
      *                      EXCEPTUANDO LA LINEA DE HIPOTECARIO       *
      *                      SOSTENIBLE.                               *
      *                      SDA-56033 / COLONEPRE1-17074              *
      * -------------------------------------------------------------- *
       01 UNRA001.                                                      00003600
          05 NRA-RELLENO        PIC X(012).                             00003800
          05 NRA-MAPCLUS-L      PIC S9(4) COMP.                         00004000
          05 NRA-MAPCLUS-A      PIC X(01).                              00004100
      *COL02-I
      *   05 NRA-MAPCLUS        PIC X(18).                              00004200
          05 NRA-MAPCLUS        PIC X(23).
      *COL02-F
          05 NRA-ESTCLUST-L     PIC S9(4) COMP.                         00004400
          05 NRA-ESTCLUST-A     PIC X(01).                              00004500
      *COL02-I
      *   05 NRA-ESTCLUST       PIC X(13).                              00004600
          05 NRA-ESTCLUST       PIC X(10).
      *COL02-F
          05 NRA-TIMESTA-L      PIC S9(4) COMP.                         00004800
          05 NRA-TIMESTA-A      PIC X(01).                              00004900
          05 NRA-TIMESTA        PIC X(30).                              00005000
          05 NRA-TIPOIDE-L      PIC S9(4) COMP.                         00005200
          05 NRA-TIPOIDE-A      PIC X(01).                              00005300
          05 NRA-TIPOIDE        PIC X(13).                              00005400
          05 NRA-NUMIDEN-L      PIC S9(4) COMP.                         00005600
          05 NRA-NUMIDEN-A      PIC X(01).                              00005700
      *COL02-I
      *   05 NRA-NUMIDEN        PIC X(13).                              00005800
          05 NRA-NUMIDEN        PIC X(10).
      *COL02-F
          05 NRA-NOMCLIE-L      PIC S9(4) COMP.                         00006000
          05 NRA-NOMCLIE-A      PIC X(01).                              00006100
          05 NRA-NOMCLIE        PIC X(53).                              00006200
          05 NRA-IMPORT-L       PIC S9(4) COMP.                         00006400
          05 NRA-IMPORT-A       PIC X(01).                              00006500
      *COL02-I
      *   05 NRA-IMPORT         PIC X(20).                              00006600
          05 NRA-IMPORT         PIC X(10).
      *COL02-F
          05 NRA-IMPPRES-L      PIC S9(4) COMP.                         00006700
          05 NRA-IMPPRES-A      PIC X(01).                              00006710
      *COL02-I
      *   05 NRA-IMPPRES        PIC X(13).                              00006720
          05 NRA-IMPPRES        PIC X(10).
      *COL02-F
          05 NRA-GARANTI-L      PIC S9(4) COMP.                         00006800
          05 NRA-GARANTI-A      PIC X(01).                              00006900
          05 NRA-GARANTI        PIC X(10).                              00007000
          05 NRA-PRODACT-L      PIC S9(4) COMP.                         00007200
          05 NRA-PRODACT-A      PIC X(01).                              00007300
          05 NRA-PRODACT        PIC X(13).                              00007400
          05 NRA-PRODNEW-L      PIC S9(4) COMP.                         00007600
          05 NRA-PRODNEW-A      PIC X(01).                              00007700
          05 NRA-PRODNEW        PIC X(13).                              00007800
          05 NRA-FECDBLO-L      PIC S9(4) COMP.                         00008000
          05 NRA-FECDBLO-A      PIC X(01).                              00008100
          05 NRA-FECDBLO        PIC X(13).                              00008200
          05 NRA-DIASBLO-L      PIC S9(4) COMP.                         00009200
          05 NRA-DIASBLO-A      PIC X(01).                              00009300
          05 NRA-DIASBLO        PIC X(13).                              00009400
          05 NRA-MRECHAZ-L      PIC S9(4) COMP.                         00009600
          05 NRA-MRECHAZ-A      PIC X(01).                              00009700
          05 NRA-MRECHAZ        PIC X(13).                              00009800
          05 NRA-PLAZOPE-L      PIC S9(4) COMP.                         00010800
          05 NRA-PLAZOPE-A      PIC X(01).                              00010900
          05 NRA-PLAZOPE        PIC X(13).                              00011000
          05 NRA-INDEDAD-L      PIC S9(4) COMP.                         00011100
          05 NRA-INDEDAD-A      PIC X(01).                              00011200
          05 NRA-INDEDAD        PIC X(13).                              00011300
      *COL03-I
          05 NRA-TEXVAR8-L      PIC S9(4) COMP.
          05 NRA-TEXVAR8-A      PIC X(01).
          05 NRA-TEXVAR8        PIC X(24).
      *COL03-F
          05 NRA-INDSEGM-L      PIC S9(4) COMP.                         00011400
          05 NRA-INDSEGM-A      PIC X(01).                              00011500
          05 NRA-INDSEGM        PIC X(13).                              00011600
      *COL03-I
          05 NRA-TEXVAR9-L      PIC S9(4) COMP.
          05 NRA-TEXVAR9-A      PIC X(01).
          05 NRA-TEXVAR9        PIC X(24).
      *COL03-F
          05 NRA-COLECTI-L      PIC S9(4) COMP.                         00011700
          05 NRA-COLECTI-A      PIC X(01).                              00011800
          05 NRA-COLECTI        PIC X(13).                              00011900
          05 NRA-GRUPRIE-L      PIC S9(4) COMP.                         00012000
          05 NRA-GRUPRIE-A      PIC X(01).                              00012100
          05 NRA-GRUPRIE        PIC X(13).                              00012200
      *COL03-I
          05 NRA-TEXVA11-L      PIC S9(4) COMP.
          05 NRA-TEXVA11-A      PIC X(01).
          05 NRA-TEXVA11        PIC X(24).
      *COL03-F
          05 NRA-ESTVEHI-L      PIC S9(4) COMP.                         00012300
          05 NRA-ESTVEHI-A      PIC X(01).                              00012400
          05 NRA-ESTVEHI        PIC X(13).                              00012500
          05 NRA-PORCFIN-L      PIC S9(4) COMP.                         00012600
          05 NRA-PORCFIN-A      PIC X(01).                              00012700
          05 NRA-PORCFIN        PIC X(13).                              00012800
          05 NRA-GAMVEHI-L      PIC S9(4) COMP.                         00012810
          05 NRA-GAMVEHI-A      PIC X(01).                              00012820
          05 NRA-GAMVEHI        PIC X(13).                              00012830
          05 NRA-TIPOUSO-L      PIC S9(4) COMP.                         00012840
          05 NRA-TIPOUSO-A      PIC X(01).                              00012850
          05 NRA-TIPOUSO        PIC X(13).                              00012860
          05 NRA-CLIEVIP-L      PIC S9(4) COMP.                         00012870
          05 NRA-CLIEVIP-A      PIC X(01).                              00012880
          05 NRA-CLIEVIP        PIC X(13).                              00012890
      *COL01-I                                                          00012891
          05 NRA-COLECLB-L      PIC S9(4) COMP.                         00012892
          05 NRA-COLECLB-A      PIC X(01).                              00012893
          05 NRA-COLECLB        PIC X(13).                              00012894
          05 NRA-DESTINO-L      PIC S9(4) COMP.                         00012895
          05 NRA-DESTINO-A      PIC X(01).                              00012896
          05 NRA-DESTINO        PIC X(13).                              00012897
      *COL01-F                                                          00012898
      *COL02-I
          05 NRA-VENTASC-L      PIC S9(4) COMP.
          05 NRA-VENTASC-A      PIC X(01).
          05 NRA-VENTASC        PIC X(17).
          05 NRA-TIPPERS-L      PIC S9(4) COMP.
          05 NRA-TIPPERS-A      PIC X(01).
          05 NRA-TIPPERS        PIC X(13).
          05 NRA-CRATING-L      PIC S9(4) COMP.
          05 NRA-CRATING-A      PIC X(01).
          05 NRA-CRATING        PIC X(13).
          05 NRA-RRATING-L      PIC S9(4) COMP.
          05 NRA-RRATING-A      PIC X(01).
          05 NRA-RRATING        PIC X(13).
          05 NRA-GARANTC-L      PIC S9(4) COMP.
          05 NRA-GARANTC-A      PIC X(01).
          05 NRA-GARANTC        PIC X(13).
          05 NRA-MOPERAC-L      PIC S9(4) COMP.
          05 NRA-MOPERAC-A      PIC X(01).
          05 NRA-MOPERAC        PIC X(17).
          05 NRA-DATOS-COMER-L  PIC S9(4) COMP.
          05 NRA-DATOS-COMER-A  PIC X(01).
          05 NRA-DATOS-COMER    PIC X(34).
      *COL02-F
      * -------------------------------------------------------------- *00012900
          05 NRA-ESTANU-L       PIC S9(4) COMP.                         00013000
          05 NRA-ESTANU-A       PIC X(01).                              00013100
          05 NRA-ESTANU         PIC X(13).                              00013200
          05 NRA-PROPFNG-L      PIC S9(4) COMP.                         00013300
          05 NRA-PROPFNG-A      PIC X(01).                              00013400
          05 NRA-PROPFNG        PIC X(13).                              00013500
          05 NRA-CONFIRM-L      PIC S9(4) COMP.                         00013600
          05 NRA-CONFIRM-A      PIC X(01).                              00013700
          05 NRA-CONFIRM        PIC X(01).                              00013800