      ******************************************************************
      * DCLGEN TABLE(APLIC.UGDTGAR)                                    *
      *        LIBRARY(CAR1.U1.COPY(UGEDGAR))                          *
      *        ACTION(REPLACE)                                         *
      *        STRUCTURE(UGECGAR)                                      *
      *        QUOTE                                                   *
      * ... IS THE DCLGEN COMMAND THAT MADE THE FOLLOWING STATEMENTS   *
      ******************************************************************
           EXEC SQL DECLARE UGDTGAR TABLE
           ( CODIGAR                        CHAR(3) NOT NULL,
             TEXTOLAR                       CHAR(50) NOT NULL,
             TEXTORED                       CHAR(15) NOT NULL,
             CODGAR_CIR                     CHAR(1) NOT NULL,
             ENTIDAD_UMO                    CHAR(4) NOT NULL,
             CENTRO_UMO                     CHAR(4) NOT NULL,
             USERID_UMO                     CHAR(8) NOT NULL,
             NETNAME_UMO                    CHAR(8) NOT NULL,
             TIMESTAMP                      TIMESTAMP NOT NULL,
             GRADGAR                        CHAR(1) NOT NULL,
             PORGAR                         DECIMAL(7,4) NOT NULL,
             CLAGAR                         CHAR(1) NOT NULL,
             GRUPO                          CHAR(1) NOT NULL
           ) END-EXEC.