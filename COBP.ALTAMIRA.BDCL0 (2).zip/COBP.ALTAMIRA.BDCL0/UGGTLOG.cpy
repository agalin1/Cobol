      ******************************************************************
      * DCLGEN TABLE(MBVD.UGDTLOG)                                     *
      *        LIBRARY(MBVD.UG.DCLGEN(UGGTLOG))                        *
      *        ACTION(REPLACE)                                         *
      *        LANGUAGE(COBOL)                                         *
      *        QUOTE                                                   *
      * ... IS THE DCLGEN COMMAND THAT MADE THE FOLLOWING STATEMENTS   *
      ******************************************************************
           EXEC SQL DECLARE UGDTLOG TABLE
           (LOG_ENTIOFI         CHAR(8)       NOT NULL,
            LOG_CUENTA          CHAR(10)      NOT NULL,
            LOG_TIMESTAMP       TIMESTAMP     NOT NULL,
            LOG_CODIGO          CHAR(4)       NOT NULL,
            LOG_FECMOV          DATE          NOT NULL,
            LOG_CONSOPE         DECIMAL(5,0)  NOT NULL,
            LOG_FECANT          DATE          NOT NULL,
            LOG_IMPANT          DECIMAL(15,2) NOT NULL,
            LOG_CARANT          CHAR(30)      NOT NULL,
            LOG_TASA_ANT        DECIMAL(8,5)  NOT NULL,
            LOG_FECNUE          DATE          NOT NULL,
            LOG_IMPNUE          DECIMAL(15,2) NOT NULL,
            LOG_CARNUE          CHAR(30)      NOT NULL,
            LOG_TASA_NUE        DECIMAL(8,5)  NOT NULL,
            LOG_TABLA           CHAR(7)       NOT NULL,
            LOG_COLUMNA         CHAR(15)      NOT NULL,
            LOG_DESCRIPCION     CHAR(80)      NOT NULL,
            LOG_ENTIDAD_UMO     CHAR(4)       NOT NULL,
            LOG_CENTRO_UMO      CHAR(4)       NOT NULL,
            LOG_USERID_UMO      CHAR(8)       NOT NULL,
            LOG_NETNAME_UMO     CHAR(8)       NOT NULL
           ) END-EXEC.