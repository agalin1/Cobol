      ******************************************************************
      * DCLGEN TABLE(DTUG.UGDTNRA)                                     *
      *        LIBRARY(DBG.JUAN.TODO.COBOL)                            *
      *        LANGUAGE(COBOL)                                         *
      *        QUOTE                                                   *
      * ... IS THE DCLGEN COMMAND THAT MADE THE FOLLOWING STATEMENTS   *
      ******************************************************************
           EXEC SQL DECLARE DTUG.UGDTNRA TABLE
           ( NRA_TIPO_PRODUCTO              CHAR(2) NOT NULL,
             NRA_VARIABLE                   CHAR(2) NOT NULL,
             NRA_CONSECUTIVO                DECIMAL(9, 0) NOT NULL,
             NRA_FECHA_INI                  DATE NOT NULL,
             NRA_FECHA_FIN                  DATE NOT NULL,
             NRA_RANGO_INI                  DECIMAL(4, 0) NOT NULL,
             NRA_RANGO_FIN                  DECIMAL(4, 0) NOT NULL,
             NRA_IND_DOM_NOMINA             CHAR(1) NOT NULL,
             NRA_SITUA_LABORAL              CHAR(1) NOT NULL,
             NRA_MONTO_INICIAL              DECIMAL(9, 4) NOT NULL,
             NRA_MONTO_FINAL                DECIMAL(9, 4) NOT NULL,
             NRA_SEGMENTO                   DECIMAL(5, 0) NOT NULL,
             NRA_IND_CLIENTE_VIP            CHAR(1) NOT NULL,
             NRA_RANGO_RIESGO_INI           DECIMAL(9, 4) NOT NULL,
             NRA_RANGO_RIESGO_FIN           DECIMAL(9, 4) NOT NULL,
             NRA_IND_ESTADO_VEH             CHAR(1) NOT NULL,
             NRA_IND_TIPO_VEH               CHAR(1) NOT NULL,
             NRA_CLAVE_ID                   CHAR(25) NOT NULL,
             NRA_CLUSTER                    CHAR(25) NOT NULL,
             NRA_ESTADO                     CHAR(2) NOT NULL,
             NRA_TASA                       DECIMAL(7, 4) NOT NULL,
             NRA_CENTRO_UMO                 CHAR(4) NOT NULL,
             NRA_USERID_UMO                 CHAR(8) NOT NULL,
             NRA_NETNAME_UMO                CHAR(4) NOT NULL,
             NRA_TIMESTAMP                  TIMESTAMP NOT NULL,
             NRA_RATING                     CHAR(5) NOT NULL,
             NRA_RANGO_RATING               CHAR(1) NOT NULL,
             NRA_GARANTIA                   CHAR(1) NOT NULL,
             NRA_PORCENTA                   DECIMAL(4, 2) NOT NULL
           ) END-EXEC.
      ******************************************************************
      * COBOL DECLARATION FOR TABLE DTUG.UGDTNRA                       *
      ******************************************************************