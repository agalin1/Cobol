000100******************************************************************00010002
000200* DCLGEN TABLE(MBVD.UGDTPRO)                                     *00020002
000300*        LIBRARY(MBVD.UG.DCLGEN(UGGTPRO))                        *00030002
000400*        ACTION(REPLACE)                                         *00040002
000500*        LANGUAGE(COBOL)                                         *00050002
000600*        QUOTE                                                   *00060002
000700* ... IS THE DCLGEN COMMAND THAT MADE THE FOLLOWING STATEMENTS   *00070002
000800******************************************************************00080002
000900     EXEC SQL DECLARE UGDTPRO TABLE                               00090002
001000     ( PRODUCTO                       CHAR(2) NOT NULL,           00100002
001100       SUBPRO                         CHAR(4) NOT NULL,           00110002
001200       TEXTORED                       CHAR(15) NOT NULL,          00120002
001300       TEXTOLAR                       CHAR(50) NOT NULL,          00130002
001400       FECOVALI                       DATE NOT NULL,              00140002
001500       FEFIVALI                       DATE NOT NULL,              00150002
001600       IMPMAXGE                       DECIMAL(15, 2) NOT NULL,    00160002
001700       CUPOTOPR                       DECIMAL(15, 2) NOT NULL,    00170002
001800       CUPODIPR                       DECIMAL(15, 2) NOT NULL,    00180002
001900       PLAZOMIN                       CHAR(4) NOT NULL,           00190002
002000       PLAZOMAX                       CHAR(4) NOT NULL,           00200002
002100*LAP   PORINMIN                       DECIMAL(5, 3) NOT NULL,     00210003
002200*LAP   PORINMAX                       DECIMAL(5, 3) NOT NULL,     00220003
002210       PORINMIN                       DECIMAL(8, 5) NOT NULL,     00221003
002220       PORINMAX                       DECIMAL(8, 5) NOT NULL,     00222003
002300       INDCUOFI                       CHAR(1) NOT NULL,           00230002
002400       INDISSU                        CHAR(1) NOT NULL,           00240002
002500       INDENTAN                       CHAR(1) NOT NULL,           00250002
002600       IMPMINEA                       DECIMAL(15, 2) NOT NULL,    00260002
002700       IMPMIPAR                       DECIMAL(15, 2) NOT NULL,    00270002
002800       NIVCONCE                       CHAR(1) NOT NULL,           00280002
002900       PORDISPO                       DECIMAL(3, 0) NOT NULL,     00290002
003000       UGCDEINI                       CHAR(5) NOT NULL,           00300002
003100       UGCDEFIN                       CHAR(5) NOT NULL,           00310002
003200       UGCCAMIN                       CHAR(4) NOT NULL,           00320002
003300       UGCCAMAX                       CHAR(4) NOT NULL,           00330002
003400       UGQFIMIN                       CHAR(1) NOT NULL,           00340002
003500       IND_CONDES                     CHAR(1) NOT NULL,           00350002
003600       UGYPRASC                       CHAR(1) NOT NULL,           00360002
003700       UGYSEASO                       CHAR(1) NOT NULL,           00370002
003800       UGYADPAG                       CHAR(1) NOT NULL,           00380002
003900       UGYPREMP                       CHAR(1) NOT NULL,           00390002
004000       IND_MARCA1                     CHAR(1) NOT NULL,           00400002
004100       IND_MARCA2                     CHAR(1) NOT NULL,           00410002
004200       IND_MARCA3                     CHAR(1) NOT NULL,           00420002
004300       LIBRE_IMP1                     DECIMAL(15, 2) NOT NULL,    00430002
004400       LIBRE_IMP2                     DECIMAL(7, 2) NOT NULL,     00440002
004500       LIBRE_CAR1                     CHAR(5) NOT NULL,           00450002
004600       ENTIDAD_UMO                    CHAR(4) NOT NULL,           00460002
004700       CENTRO_UMO                     CHAR(4) NOT NULL,           00470002
004800       USERID_UMO                     CHAR(8) NOT NULL,           00480002
004900       NETNAME_UMO                    CHAR(8) NOT NULL,           00490002
005000       TIMESTAMP                      TIMESTAMP NOT NULL,         00500002
005100       PERINT                         CHAR(3) NOT NULL,           00510002
005200       TIPOREDU                       CHAR(1) NOT NULL,           00520002
005300       PERIODICI                      CHAR(3) NOT NULL,           00530002
005400       TIPODIAS                       CHAR(1) NOT NULL,           00540002
005500       DIASCAL                        CHAR(1) NOT NULL,           00550002
005600       INDINANT                       CHAR(1) NOT NULL,           00560002
005700       UGPCMAPN                       DECIMAL(5, 3) NOT NULL,     00570002
005800       UGPCMAPX                       DECIMAL(5, 3) NOT NULL,     00580002
005900       UGPCMATN                       DECIMAL(5, 3) NOT NULL,     00590002
006000       UGPCMATX                       DECIMAL(5, 3) NOT NULL,     00600002
006100       UGPCMAMN                       DECIMAL(5, 3) NOT NULL,     00610002
006200       UGPCMAMX                       DECIMAL(5, 3) NOT NULL,     00620002
006300       UGPDFCAN                       DECIMAL(5, 3) NOT NULL,     00630002
006400       UGPDFCAX                       DECIMAL(5, 3) NOT NULL,     00640002
006500       UGPDFAMN                       DECIMAL(5, 3) NOT NULL,     00650002
006600       UGPDFAMX                       DECIMAL(5, 3) NOT NULL,     00660002
006700       UGPDPEMN                       DECIMAL(5, 3) NOT NULL,     00670002
006800       UGPDPEMX                       DECIMAL(5, 3) NOT NULL,     00680002
006900       IMPMINGE                       DECIMAL(15,2) NOT NULL,     00690002
007000       INDEALER                       CHAR(1)       NOT NULL,     00700002
007100       MONEDA                         CHAR(3)       NOT NULL,     00710002
007200       INDCRSCO                       CHAR(1)       NOT NULL,     00720002
007300       INDMASIV                       CHAR(1)       NOT NULL,     00730002
007400       TIPOCOR                        CHAR(1)       NOT NULL      00740002
007500     ) END-EXEC.                                                  00750002
007600******************************************************************00760002