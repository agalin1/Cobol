      *_______________________________________________________________* 00002191
      *                   LOG DE MODIFICACIONES                         00002192
      *_______________________________________________________________* 00002193
      * CODIGO  AUTOR   FECHA       DESCRIPCION                       * 00002194
      * ------- ------- ----------  ----------------------------------* 00002195
      * C804405 JNSS    09/10/2023  SE AJUSTA DCL PARA APUNTAR AL     * 00002196
      * REALIZO  : BBVA-COLOMBIA    OWNER DE CORRECTO Y NO SIEMPRE AL * 00002197
      * MARCA    : COL-01           DE DESARROLLO                     * 00002198
      *                                                               * 00002198
      * PROYECTO : DEPURACION DE PRESTAMOS                            * 00002199
      * FEATURE  : COLWSMANTE-184                                     * 00002200
      * ENABLER  : COLWSMANTE-184                                     * 00002201
      * HUQA     : COLWSMANTE-334                                     * 00002202
      *_______________________________________________________________* 00002203
      * DCLGEN TABLE(UGDTRVE)                                          *
      *        LIBRARY(DBG.CE24703M.DIANA(UGGTRVE))                    *
      *        LANGUAGE(COBOL)                                         *
      *        QUOTE                                                   *
      * ... IS THE DCLGEN COMMAND THAT MADE THE FOLLOWING STATEMENTS   *
      ******************************************************************
           EXEC SQL DECLARE UGDTRVE TABLE
           ( RVE_ENTIOFI                    CHAR(8) NOT NULL,
             RVE_CUENTA                     CHAR(10) NOT NULL,
             RVE_GAMA_VEH                   DECIMAL(9, 4) NOT NULL,
             RVE_DSC_GAMA_VEH               DECIMAL(6, 3) NOT NULL,
             RVE_TIPO_VEH                   CHAR(2) NOT NULL,
             RVE_DSC_TIPO_VEH               DECIMAL(6, 3) NOT NULL,
             RVE_ESTADO_VEH                 CHAR(1) NOT NULL,
             RVE_DSC_ESTD_VEH               DECIMAL(6, 3) NOT NULL,
             RVE_USERID_UMO                 CHAR(8) NOT NULL,
             RVE_NETNAME_UMO                CHAR(4) NOT NULL,
             RVE_PRGRM_UMO                  CHAR(8) NOT NULL,
             RVE_TIMEST_UMO                 TIMESTAMP NOT NULL
           ) END-EXEC.
      ******************************************************************
      * THE NUMBER OF COLUMNS DESCRIBED BY THIS DECLARATION IS 12      *
      ******************************************************************