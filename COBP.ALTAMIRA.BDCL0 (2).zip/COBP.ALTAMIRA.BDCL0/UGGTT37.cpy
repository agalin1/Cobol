      ******************************************************************
      * DCLGEN TABLE(MBVD.UGDTT37)                                     *
      *        LIBRARY(MBVD.UG.DCLGEN(UGGTT37))                        *
      *        ACTION(REPLACE)                                         *
      *        LANGUAGE(COBOL)                                         *
      *        QUOTE                                                   *
      * ... IS THE DCLGEN COMMAND THAT MADE THE FOLLOWING STATEMENTS   *
      ******************************************************************
           EXEC SQL DECLARE UGDTT37 TABLE
           ( SECCION                        CHAR(04) NOT NULL,
             ELEMENTO                       CHAR(22) NOT NULL,
             RESTO                          CHAR(250) NOT NULL,
             ENTIDAD_UMO                    CHAR(4) NOT NULL,
             CENTRO_UMO                     CHAR(4) NOT NULL,
             USERID_UMO                     CHAR(8) NOT NULL,
             NETNAME_UMO                    CHAR(8) NOT NULL,
             TIMESTAMP                      TIMESTAMP NOT NULL
           ) END-EXEC.