//PUGDRAR1 JOB CLASS=B,                                                 00000100
//             REGION=0M,                                               00000200
//             MSGCLASS=R,                                              00000300
//             MSGLEVEL=(1,1)                                           00000400
//JOBLIB    DD    DSN=COBP.ALTAMIRA.LOADLIB.BATCH,DISP=SHR              00000500
//*--------------------------------------------------------------------*00000600
//* PROCESO PARA VERIFICAR EXISTENCIA ARCHIVO NUEVO MODELO RAR          00000700
//* DE TANTIA A HOST                                                    00000800
//*--------------------------------------------------------------------*00001700
//UGRAR100 EXEC PGM=IDCAMS
//SYSOUT   DD SYSOUT=X
//SYSPRINT DD SYSOUT=X
//SYSIN    DD *
  DEL COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRAR
  SET MAXCC=0
//*--------------------------------------------------------------------*
//* VERIFICAR EXISTENCIA DE ARCHIVO DEL NUEVO MODELO RAR                00001800
//*--------------------------------------------------------------------*00001900
//UGRAR110 EXEC PGM=DMBATCH,PARM=(YYSLYNNY),COND=(0,LT)
//*
//STEPLIB  DD DISP=SHR,DSN=SYS3.CONNECT.TGT.LINKLIB
//DMNETMAP DD DISP=SHR,DSN=SYS3.CONNECT.DAT.NETMAP
//DMPUBLIB DD DISP=SHR,DSN=COBP.ALTAMIRA.PROCESS
//DMMSGFIL DD DISP=SHR,DSN=SYS3.CONNECT.DAT.MSG
//DMPRINT  DD SYSOUT=*
//SYSDUMP  DD SYSOUT=*
//SYSPRINT DD SYSOUT=*
//SYSIN    DD *
  SIGNON CASE(YES) ESF=NO
  SUBMIT PROC=CRMHDDX1  -
  &HOST=COLP.CDCOLP -
  &DIST=D-CLUSTER -
  &DSNO='COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRAR' -
  &DCB=(LRECL=239,BLKSIZE=0,RECFM=FB,DSORG=PS) -
  &DSNI=\'F:\\\ || -
  \TX\\ENVIO_HOST\\INTELIGENCIA_COMERCIAL\\\        || -
  \Advanced_Analytics\\COE_AACS\\envios\\\        || -
  \ARCHIVO_CARGUE_MODRAR_F%%ODATE.TXT'\  -
  &SYSOPTS='datatype(text) xlate.tbl(swcbpt14.CDX)'
  SIGNOFF
//*********************************************************************
//*        SE VALIDA SI EXISTE O NO EL ARCHIVO DE TANTIA
//********************************************************************
//UGRAR120 EXEC  PGM=IDCAMS,COND=(16,LT)
//SYSPRINT DD  SYSOUT=(*,,)
//SYSOUT   DD  SYSOUT=(*,,)
//OFILE    DD  SYSOUT=(*,,)
//SYSIN    DD  *
   LISTCAT -
      ENTRIES(COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRAR)
//**********************************************************************00003100
//* SISTEMA  : UG (PRESTAMOS)                                          *00003200
//* PROCESO  : PUGDRAR1                                                *00003300
//* OBJETIVO : TRANSMISION TANTIA 2.0                                  *00003400
//* EJECUCION: DIARIO                                                  *00003500
//* REALIZO  : INETUM - CE66059                                        *00003600
//* FECHA    : JUNIO  - 2021                                           *00003700
//* GP       : GP17916-HUQA-CCSS-6856                                  *00003700
//**********************************************************************00003800
//*--------------------------------------------------------------------*00003900
//*                     LOG DE MODIFICACIONES                          *00004000
//*--------------------------------------------------------------------*00004100
//* CONSEC  USUARIO   FECHA MODIF    DESCRIPCION:                      *
//*--------------------------------------------------------------------*
//*COL01    CE56375   2022-01-20     SE MODIFICA LRECL=164 A LRECL=170 *
//*                                  PARA INCLUIR COLECTIVO Y DESTINO  *
//*         GP-36560-COLWSPREST-383                                    *
//*--------------------------------------------------------------------*
//*COL02    C810908   2022-03-24    SE REALIZA AJUSTE PARA MODIFICAR   *
//*         DCP                     PASO UGRAR110 LRECL=170 A LRECL=239*
//*                                 INCLUIR NUEVAS VARIABLES PARA      *
//*                                 CARTERA COMERCIAL:                 *
//*                                 -RANGO PARA VENTAS                 *
//*                                 -TIPO PERSONA                      *
//*                                 -CALIFICACION DEL RIESGO - RATING  *
//*                                 -RANGO CALIFICACION RATING
//*                                 -IND GARANTIA                      *
//*                                 -RANGO MONTO OPERACION             *
//*                                 -PORCENTAJE PERDIDA ESPERADA       *
//*                                 -PORCENTAJE RORC                   *
//*                                 -PORCENTAJE RAROEC                 *
//*                                 -CAPITAL ECONOMICO                 *
//* GP-35771 COLWSCANAL-1036                                           *
//**********************************************************************
//*--------------------------------------------------------------------*