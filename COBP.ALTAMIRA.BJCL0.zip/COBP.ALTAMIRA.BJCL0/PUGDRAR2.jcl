//PUGDRAR2  JOB CLASS=B,REGION=0M,MSGCLASS=H,MSGLEVEL=(1,1)
//JOBLIB   DD  DSN=COBP.ALTAMIRA.LOADLIB.BATCH,DISP=SHR
//*--------------------------------------------------------------------
//* SISTEMA  : UG(NUEVO MODELO RAR )                                   *
//* PROCESO  : PUGDRAR2                                                *
//* EJECUCION: DIARIA.                                                 *
//* OBJETIVO : CREAR ARCHIVO EN VACIO DEL NUEVO MODELO RAR SI NO EXISTE*
//* REALIZO  : INETUM - CE66059                                        *
//* FECHA    : JUNIO  - 17- DEL 2021.                                  *
//* GP       : GP17916-HUQA-CCSS-6856                                  *
//*--------------------------------------------------------------------
//********************************************************************
//*SI EL ARCHIVO NO ESTA RETORNO MAYOR A 0 CREO EL ACHIVO EN BLANCO
//********************************************************************
//UGRAR200 EXEC  PGM=IDCAMS
//IFILE    DD  DUMMY
//OFILE    DD  DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRAR,
//             DISP=(NEW,CATLG,DELETE),
//             RECFM=FB,LRECL=164,BLKSIZE=0,
//             SPACE=(CYL,(100,50,),RLSE),UNIT=SYSDA
//SYSOUT   DD  SYSOUT=(*,,)
//SYSPRINT DD  SYSOUT=(*,,)
//SYSIN    DD  *
  REPRO  IFILE(IFILE) OFILE(OFILE)
//**********************************************************************00003800
//*--------------------------------------------------------------------*00003900
//*                     LOG DE MODIFICACIONES                          *00004000
//*--------------------------------------------------------------------*00004100
//*--------------------------------------------------------------------*00004700