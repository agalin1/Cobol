//PUGDRAR3 JOB CLASS=B,                                                 00010000
//             MSGCLASS=H,                                              00020000
//             REGION=0M,                                               00030000
//             MSGLEVEL=(1,1)                                           00040000
//JOBLIB  DD   DSN=COBP.ALTAMIRA.LOADLIB.BATCH,DISP=SHR                 00050000
//*¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯00030000
//*  %%SET %%FDIA    = %%$ODATE                                        |00040000
//*  %%SET %%ANIO    = %%SUBSTR %%FDIA 1 4                             |00050000
//*  %%SET %%MES     = %%SUBSTR %%FDIA 5 2                             |00060000
//*  %%SET %%DIA     = %%SUBSTR %%FDIA 7 2                             |00070000
//*  %%SET %%FECDIA  = %%ANIO-%%MES-%%DIA                              |00080000
//*¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯00030000
//*                                                                     00060000
//**********************************************************************00070000
//* APLICACION : PRESTAMOS                                             *00080000
//* PROCESO    : PUGDRAR3                                              *00100000
//* OBJETIVO   : PROCESO CARGAR TABLA UGDTDTE CON LAS TRES COLUMNAS DE *00120000
//*              MAS.                                                  *00130000
//* REALIZÓ    : INETUM - CE66059                                      *00150000
//* FECHA      : JUNIO  - 2021.                                        *00170000
//* PROYECTO   : GP17916-HUQA-CCSS-6856                                *00180000
//**********************************************************************
//* CONSEC  USUARIO   FECHA MODIF    DESCRIPCION:                      *
//*--------------------------------------------------------------------*
//*COL01    CE56375   2021-11-08     SE MODIFICA PASO UGRAR310/312/440 *
//*                                  Y BORRADO ARCHIVOS                *
//*         RSD INC000007720682                                        *
//*         RUN PROGRAM(UG4CRAR2) PLAN(BVPUGPB) PARM('%%FECDIA,0500')  *
//*         COBP.UG.FWSD1.UGDTRAR.UGRAR312.F%%ODATE.SAL                *
//*         COBP.UG.FWSD1.UGDTRAR.UGRAR312.F%%ODATE.ERR                *
//**********************************************************************
//*COL02    CE56375   2022-01-20     SE MODIFICA PASOS UGRAR305        *
//*         OUTFIL FNAMES=SALIDA1,INCLUDE=(151,2,CH,EQ,C'BA')          *
//*         TODOS LOS PASOS BUILD 140 A 150 INCLUIR COLECTIVO/DESTINO  *
//*         OUTREC IFTHEN=(WHEN=INIT,BUILD(1,150))                     *
//*         ADICION DE PASOS UGRAR382/UGRAR384                         *
//*         MODIFICACION DE PASOS UGRAR400 INCUIR ARCHIVO COLEC/DESTINO*
//*         MODIFICACION UGRAR300 INCLUIR BORRADO ARCHIVOS             *
//*         COBP.UG.FWSD1.UGDTRAR.UGRAR382.DTNRA16                     *
//*         COBP.UG.FWSD1.UGDTRAR.UGRAR384.DTNRA17                     *
//*         GP-36560-COLWSPREST-383                                    *
//**********************************************************************
//*COL03   C810908   2022-03-25 -MODIFICACION PASO UGRAR305:           *
//*        DCP                   INCLUDE=(151,2,CH,EQ,C'BA') POR       *
//*                              INCLUDE=(220,2,CH,EQ,C'BA')           *
//*                             -MODIFICACION PASOS UGRAR315 A UGRAR384*
//*                              IFTHEN=(WHEN=INIT,BUILD(1,150))  POR  *
//*                              IFTHEN=(WHEN=INIT,BUILD(1,219))       *
//*                             -SE INCLUYEN PASOS: UGRAR386,UGRAR387, *
//*                              UGRAR388,UGRAR389,UGRAR390,UGRAR391,  *
//*                             -MODIFICACION DE PASO UGRAR400:        *
//*                              INCLUIR ARCHIVOS NUEVAS VARIABLES     *
//*                              MODIFICACION PASO UGRAR300:           *
//*                              INCLUIR BORRADO ARCHIVOS NUEVAS VARIA *
//*                              COBP.UG.FWSD1.UGDTRAR.UGRAR386.DTNRA18*
//*                              COBP.UG.FWSD1.UGDTRAR.UGRAR387.DTNRA19*
//*                              COBP.UG.FWSD1.UGDTRAR.UGRAR388.DTNRA20*
//*                              COBP.UG.FWSD1.UGDTRAR.UGRAR389.DTNRA21*
//*                              COBP.UG.FWSD1.UGDTRAR.UGRAR390.DTNRA22*
//*                              COBP.UG.FWSD1.UGDTRAR.UGRAR391.DTNRA23*
//*                             -MODIFICACION PASO UGRAR410:           *
//*                              SORT FIELDS=(1,33,CH,A) POR           *
//*                              SORT FIELDS=(1,38,CH,A)               *
//*                             -MODIFICACION PASO UGRAR420:           *
//*                              SORT FIELDS=(1,33,CH,A)               *
//*                              OUTREC FIELDS=(1,33)   POR            *
//*                              SORT FIELDS=(1,38,CH,A)               *
//*                              OUTREC FIELDS=(1,38)                  *
//*                             -MODIFICACION PASO UGRAR470:           *
//*                              OUTREC FIELDS=(1,218) POR             *
//*                              OUTREC FIELDS=(1,332)                 *
//* GP-35771 COLWSCANAL-1036   CARTERA COMERCIAL                       *
//**********************************************************************
//*COL04   C810846   2023-07-31 SE AJUSTE PARA REALIZAR EL BORRADO DE  *
//*GLADIADORES TEAM             LOS CLUSTERS ACTIVOS VS CUANDO SE REA- *
//*                             LICE UN NUEVO CARGUE DE MODELO.        *
//*                             COLWSPREST-7249.                       *
//**********************************************************************
//* REFERENCIA : COL05                                                 *
//* REALIZO    : EDINSON CALENO - T016395 - ACCENTURE LTDA             *
//* FECHA      : 15/07/2024                                            *
//* SDA-FEATURE: SDA-41748 / COLONECAPN-38                             *
//* DESCRIPCION: CUOTA FIJA - TASA VARIABLE PARA CREDITOS DE           *
//*              CONSUMO Y VEHICULO                                    *
//* METODOLOGIA  SE REALIZA AJUSTE PARA REALIZAR FILTRO POR SECCION    *
//* TRADICIONAL: MEDIANTE T37 PARA VALIDACION DE CLUSTERS ACTIVOS.     *
//**********************************************************************
//* REFERENCIA : COL06                                                 *
//* REALIZO    : LUIS SANDON - C808648 - BBVA COLOMBIA                 *
//* FECHA      : 01/02/2026                                            *
//* SDA-FEATURE: COLONEPRE1-16282                                      *
//* HU         : COLONEPRE1-16737                                      *
//* DESCRIPCION: SE AJUSTA PARA OPTIMIZAR EL PROCESO Y MEJORAR EL      *
//*              CONSUMO DE CPU Y MEJORAR TIEMPOS DE RESPUEST          *
//**********************************************************************
//**********************************************************************00180100
//*  BORRADO ARCHIVOS DE TRABAJO                                       *00210000
//**********************************************************************00220000
//UGRAR300 EXEC PGM=IDCAMS                                              00230001
//SYSPRINT DD  SYSOUT=(*,,)                                             00240000
//SYSIN    DD  *                                                        00250000
  DELETE COBP.UG.FWSD1.UGDTRAR.UGRAR310.F%%ODATE.SAL                    00260001
  DELETE COBP.UG.FWSD1.UGDTRAR.UGRAR310.F%%ODATE.ERR                    00260001
  DELETE COBP.UG.FWSD1.UGDTRAR.UGRAR315.DTNRA01                         00260001
  DELETE COBP.UG.FWSD1.UGDTRAR.UGRAR320.DTNRA02                         00260001
  DELETE COBP.UG.FWSD1.UGDTRAR.UGRAR325.DTNRA03                         00260001
  DELETE COBP.UG.FWSD1.UGDTRAR.UGRAR330.DTNRA04                         00260001
  DELETE COBP.UG.FWSD1.UGDTRAR.UGRAR335.DTNRA05                         00260001
  DELETE COBP.UG.FWSD1.UGDTRAR.UGRAR340.DTNRA06                         00260001
  DELETE COBP.UG.FWSD1.UGDTRAR.UGRAR345.DTNRA07                         00260001
  DELETE COBP.UG.FWSD1.UGDTRAR.UGRAR350.DTNRA08                         00260001
  DELETE COBP.UG.FWSD1.UGDTRAR.UGRAR355.DTNRA09                         00260001
  DELETE COBP.UG.FWSD1.UGDTRAR.UGRAR360.DTNRA10                         00260001
  DELETE COBP.UG.FWSD1.UGDTRAR.UGRAR365.DTNRA11                         00260001
  DELETE COBP.UG.FWSD1.UGDTRAR.UGRAR370.DTNRA12                         00260001
  DELETE COBP.UG.FWSD1.UGDTRAR.UGRAR375.DTNRA13                         00260001
  DELETE COBP.UG.FWSD1.UGDTRAR.UGRAR380.DTNRA14                         00260001
  DELETE COBP.UG.FWSD1.UGDTRAR.UGRAR382.DTNRA16                         00260001
  DELETE COBP.UG.FWSD1.UGDTRAR.UGRAR384.DTNRA17                         00260001
  DELETE COBP.UG.FWSD1.UGDTRAR.UGRAR386.DTNRA18                         00260001
  DELETE COBP.UG.FWSD1.UGDTRAR.UGRAR387.DTNRA19                         00260001
  DELETE COBP.UG.FWSD1.UGDTRAR.UGRAR388.DTNRA20
  DELETE COBP.UG.FWSD1.UGDTRAR.UGRAR389.DTNRA21
  DELETE COBP.UG.FWSD1.UGDTRAR.UGRAR390.DTNRA22
  DELETE COBP.UG.FWSD1.UGDTRAR.UGRAR391.DTNRA23
  DELETE COBP.UG.FJSD1.UGDTRAR.UGRAR400.UNIRAR                          00260001
  DELETE COBP.UG.FJSD1.UGDTRAR.UGRAR410.UNIRAR                          00260001
  DELETE COBP.UG.FWSD1.UGDTRAR.UGRAR430.F%%ODATE.SALP                   00260001
  DELETE COBP.UG.FWSD1.UGDTRAR.UGRAR430.F%%ODATE.ERRP                   00260001
  DELETE COBP.UG.FWSD1.UGDTRAR.UGRAR440.F%%ODATE.SAL                    00260001
  DELETE COBP.UG.FWSD1.UGDTRAR.UGRAR440.F%%ODATE.ERR                    00260001
  DELETE COBP.UG.FWSD1.UGDTRAR.UGRAR450.F%%ODATE.SAL                    00260001
  DELETE COBP.UG.FWSD1.UGDTRAR.UGRAR460.F%%ODATE.SAL                    00260001
  DELETE COBP.UG.FWSD1.UGDTRAR.UGRAR470.F%%ODATE.SAL                    00260001
  DELETE COBP.UG.FWSD1.UGDRAR3.CMODRAR.F%%ODATE                         00260001
  DELETE COBP.UG.FJSD1.UGDRAR3.UGDTNRA.F%%ODATE                         00260001
  DELETE COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRARS                         00260001
  DELETE COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRVS                          00280000
  SET MAXCC=0                                                           00270000
//*                                                                     00280000
//*COL06-I                                                              00280000
//* SE ELIMINAN DEL BORRADO LOS SIGUIENTES ARCHIVOS                     00280000
//* DELETE COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRBA                        00280000
//* DELETE COBP.UG.FJSD1.UGDRAR3.SDTNRABA.F%%ODATE                      00280000
//* DELETE COBP.UG.FWSD1.UGDTRAR.UGRAR312.F%%ODATE.SAL                  00280000
//* DELETE COBP.UG.FWSD1.UGDTRAR.UGRAR312.F%%ODATE.ERR                  00280000
//* DELETE COBP.UG.FJSD1.UGDRAR3.UDTNRABA.F%%ODATE                      00260001
//* DELETE COBP.UG.FJSD1.UGDTRAR.UGRAR420.UNIRAR                        00260001
//* SE AGREGA EL BORRADO DEL ARCHIVO
//* COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRARS
//*COL06-F                                                              00280000
//*COL04-I                                                              00280000
//*DELETE COBP.UG.FWSD1.UGDRAR3.CMODRAR.F%%ODATE                        00260001
//*DELETE COBP.UG.FJSD1.UGDRAR3.UGDTNRA.F%%ODATE                        00260001
//*DELETE COBP.UG.FJSD1.UGDRAR3.UDTNRAVS.F%%ODATE                       00260001
//*DELETE COBP.UG.FJSD1.UGDRAR3.UDTNRABA.F%%ODATE                       00260001
//*DELETE COBP.UG.FJSD1.UGDRAR3.SDTNRABA.F%%ODATE                       00260001
//*COL04-F                                                              00280000
//*--------------------------------------------------------------------*00001900
//*   REALIZAR PROCESO DE BAJAS PRIMERO                                *00002000
//*--------------------------------------------------------------------*00002200
//*COL06-I
//*UGRAR305 EXEC  PGM=ICEMAN,COND=(4,LT)                                00670400
//*SORTIN   DD  DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRAR,              00670500
//*             DISP=(SHR)                                              00670600
//*SALIDA1  DD  DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRBA,              00670700
//*             DISP=(NEW,CATLG,DELETE),                                00670800
//*             DCB=(RECFM=FB,BLKSIZE=0,DSORG=PS),                      00670900
//*             SPACE=(CYL,(200,100),RLSE),UNIT=SYSDA                   00671000
//*SALIDA2  DD  DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRVS,              00670700
//*             DISP=(NEW,CATLG,DELETE),                                00670800
//*             DCB=(RECFM=FB,BLKSIZE=0,DSORG=PS),                      00670900
//*             SPACE=(CYL,(200,100),RLSE),UNIT=SYSDA                   00671000
//*SYSOUT   DD  SYSOUT=(*,,)                                            00155402
//*SYSIN    DD  *                                                       00155502
//*SORT FIELDS=(1,20,CH,A)                                              00155602
//*OUTFIL FNAMES=SALIDA2,INCLUDE=(220,2,CH,NE,C'BA')                    00155902
//*OUTFIL FNAMES=SALIDA1,INCLUDE=(220,2,CH,EQ,C'BA')                    00155702
//*END                                                                  00156002
//**********************************************************************
//* SE ORDENA EL ARCHIVO DE ENTRADA POR EL TIPO DE CARTERA             *
//**********************************************************************
//UGRAR3A5 EXEC  PGM=SYNCSORT,COND=(4,LT)
//SYSOUT   DD  SYSOUT=(*,,)
//SYSPRINT DD  SYSOUT=(*,,)
//SORTIN   DD  DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRAR,
//             DISP=(SHR)
//SORTOUT  DD  DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRAS,
//             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,
//             SPACE=(CYL,(2000,2000,),RLSE),UNIT=SYSDA
//SYSIN    DD  *
  SORT  FIELDS=(1,2,CH,A)
//*
//*COL06-F
//*                                                                     00661003
//*COL04-I                                                              00661003
//**********************************************************************
//* FILTRA OPERACIONES QUE SE VAN A CARGAR                             *
//**********************************************************************
//UGRAR3A5 EXEC  PGM=ICEMAN,COND=(4,LT)
//SYSOUT   DD  SYSOUT=(*,,)
//SYSPRINT DD  SYSOUT=(*,,)
//SORTIN   DD  DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRAR,
//             DISP=(SHR)
//SORTOUT  DD  DSN=COBP.UG.FWSD1.UGDRAR3.CMODRAR.F%%ODATE,
//             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,
//             SPACE=(CYL,(300,150,),RLSE),UNIT=SYSDA
//SYSIN    DD  *
  SORT  FIELDS=(1,2,CH,A)
  SUM FIELDS=NONE
  END
//**********************************************************************
//* DESCARGA DE LA TABLA UGDTNRA                                       *
//**********************************************************************
//UGRAR3B5 EXEC  UNLOAD,COND=(0,LT),
//         PARM='DB2P,UGDRAR3UGRAR3B5,NEW/RESTART,,MSGLEVEL(1)'
//*        PARM='DB2P,UGDRAR3UGRAR3B5,TERM,,MSGLEVEL(1)'
//ABNLIGNR DD  DUMMY
//DSSPRINT DD  SYSOUT=(*,,)
//SYSPRINT DD  SYSOUT=(*,,)
//UTPRINT  DD  SYSOUT=(*,,)
//SYSOUT   DD  SYSOUT=(*,,)
//SYSREC1  DD  DSN=COBP.UG.FJSD1.UGDRAR3.UGDTNRA.F%%ODATE,
//             DISP=(NEW,CATLG,DELETE),
//             SPACE=(CYL,(100,50),RLSE),UNIT=SYSDA,
//             DCB=(BLKSIZE=0)
//SYSIN    DD  *
    UNLOAD SHRLEVEL CHANGE CONSISTENT NO
    SELECT *
      FROM PADB2.UGDTNRA
//*
//**********************************************************************
//* FILTRA OPERACIONES ACTIVAS DE LA UGDTNRA                           *
//**********************************************************************
//UGRAR3C5 EXEC PGM=ICEMAN,COND=(4,LT)                                  00430000
//SORTIN   DD  DSN=COBP.UG.FJSD1.UGDRAR3.UGDTNRA.F%%ODATE,              00440000
//             DISP=(SHR)                                               00450000
//SORTOUT  DD  DSN=COBP.UG.FJSD1.UGDRAR3.UDTNRAVS.F%%ODATE,             00460000
//             DISP=(NEW,CATLG,DELETE),                                 00470000
//             DCB=(RECFM=FB,BLKSIZE=0,DSORG=PS),                       00480000
//             SPACE=(CYL,(1500,750,),RLSE),UNIT=SYSDA,BUFNO=30         00490000
//SYSPRINT DD  SYSOUT=(*,,)                                             00500000
//SYSOUT   DD  SYSOUT=(*,,)                                             00510000
//SYSIN    DD  *                                                        00520000
  SORT FIELDS=(1,2,CH,A)
  INCLUDE COND=(114,2,CH,EQ,C'VS')
//**********************************************************************
//* REALIZA CRUCE PARA OBTENER LOS REGISTROS QUE SE LE VAN A CAMBIAR   *
//* EL ESTADO A BA                                                     *
//**********************************************************************
//UGRAR3D5 EXEC  PGM=ICEMAN,COND=(4,LT),                                00044626
//         PARM=('SIZE=MAX,HIPRMAX=OPTIMAL,DSPSIZE=MAX')                00044627
//SYSOUT   DD  SYSOUT=(*,,)                                             00044628
//SYSPRINT DD  SYSOUT=(*,,)                                             00044629
//SORTJNF1 DD  DSN=COBP.UG.FJSD1.UGDRAR3.UDTNRAVS.F%%ODATE,             00044630
//             DISP=(SHR),BUFNO=30                                      00044631
//SORTJNF2 DD  DSN=COBP.UG.FWSD1.UGDRAR3.CMODRAR.F%%ODATE,              00044632
//             DISP=(SHR)                                               00044633
//*COL05-I
//*BOTH     DD  DSN=COBP.UG.FJSD1.UGDRAR3.UDTNRABA.F%%ODATE,            00044634
//BOTH     DD  DSN=COBP.UG.FJSD1.UGDRAR3.UDTNRAB1.F%%ODATE,             00044634
//*COL05-F
//             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,              00044635
//             SPACE=(CYL,(300,150,),RLSE),UNIT=SYSDA                   00044636
//SYSIN    DD  *                                                        00044637
  SORT FIELDS=COPY
  JOINKEYS FILES=F1,FIELDS=(1,2,A),SORTED,NOSEQCK                       00044640
  JOINKEYS FILES=F2,FIELDS=(1,2,A),SORTED,NOSEQCK                       00044641
  REFORMAT FIELDS=(F1:1,171,?)                                          00044643
  OUTFIL FNAMES=BOTH,INCLUDE=(172,1,CH,EQ,C'B'),                        00044645
  OUTREC=(1,19,C'%%FECDIA',30,84,C'BA',116,56,829X)
//*
//*COL06-I
//* SE AGREGA OUTREC=(1,1935), SORTED,NOSEQCK
//* SE CAMBIA REFORMAT FIELDS=(F1:1,169)
//*COL06-F
//*COL05-I
//**********************************************************************
//* DESCARGA DE LA TABLA UGDTT37 CON CLUSTERS ACTIVOS                  *
//**********************************************************************
//UGRAR3D6 EXEC PGM=SYNCSORT,COND=(4,LT)
//SORTIN    DD DSN=COBP.UG.FWSD7.UGD0550.UGPD15A.T37,
//             DISP=SHR
//SORTOUT   DD DSN=COBP.UG.FJSD1.UGDRAR3.UGDTT37.F%%ODATE,
//             DISP=(NEW,CATLG,DELETE),
//             SPACE=(CYL,(100,50,),RLSE),UNIT=SYSDA
//SYSOUT    DD SYSOUT=*
//SYSIN     DD *
  SORT FIELDS=(1,6,CH,A)
  INCLUDE COND=(1,4,CH,EQ,C'9967')
  OUTREC FIELDS=(5,2)
  END
//*
//*COL06-I
//**********************************************************************
//* REALIZA CRUCE PARA OBTENER LOS REGISTROS QUE CONTIENEN CLUSTERS    *
//* ACTIVOS                                                            *
//**********************************************************************
//UGRAR421 EXEC  PGM=SYNCSORT,COND=(4,LT),                              00044626
//         PARM=('SIZE=MAX,HIPRMAX=OPTIMAL,DSPSIZE=MAX')                00044627
//SYSOUT   DD  SYSOUT=(*,,)                                             00044628
//SYSPRINT DD  SYSOUT=(*,,)                                             00044629
//SORTJNF1 DD  DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRAS,               00044630
//             DISP=(SHR),BUFNO=30                                      00044631
//SORTJNF2 DD  DSN=COBP.UG.FJSD1.UGDRAR3.UGDTT37.F%%ODATE,              00044632
//             DISP=(SHR)                                               00044633
//BOTH     DD  DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRVS,               00044634
//             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,              00044635
//             SPACE=(CYL,(2000,2000,),RLSE),UNIT=SYSDA                 00044636
//SYSIN    DD  *                                                        00044637
  SORT FIELDS=(1,2,CH,A)
  JOINKEYS FILES=F1,FIELDS=(1,2,A),SORTED,NOSEQCK                       00044640
  JOINKEYS FILES=F2,FIELDS=(1,2,A),SORTED,NOSEQCK                       00044641
  JOIN UNPAIRED,F1
  REFORMAT FIELDS=(F1:1,239,?)                                          00044643
  OUTFIL FNAMES=BOTH,INCLUDE=(240,1,CH,EQ,C'B'),                        00044645
  OUTREC=(1,239)
//*
//**********************************************************************
//* REALIZA CRUCE PARA OBTENER LOS REGISTROS QUE CONTIENEN CLUSTERS    *
//* ACTIVOS                                                            *
//**********************************************************************
//*UGRAR3D7 EXEC  PGM=ICEMAN,COND=(4,LT),                               00044626
//*         PARM=('SIZE=MAX,HIPRMAX=OPTIMAL,DSPSIZE=MAX')               00044627
//*SYSOUT   DD  SYSOUT=(*,,)                                            00044628
//*SYSPRINT DD  SYSOUT=(*,,)                                            00044629
//*SORTJNF1 DD  DSN=COBP.UG.FJSD1.UGDRAR3.UDTNRAB1.F%%ODATE,            00044630
//*             DISP=(SHR),BUFNO=30                                     00044631
//*SORTJNF2 DD  DSN=COBP.UG.FJSD1.UGDRAR3.UGDTT37.F%%ODATE,             00044632
//*             DISP=(SHR)                                              00044633
//*BOTH     DD  DSN=COBP.UG.FJSD1.UGDRAR3.UDTNRABA.F%%ODATE,            00044634
//*             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,             00044635
//*             SPACE=(CYL,(300,150,),RLSE),UNIT=SYSDA                  00044636
//*SYSIN    DD  *                                                       00044637
//*SORT FIELDS=COPY
//*JOINKEYS FILES=F1,FIELDS=(1,2,A)                                     00044640
//*JOINKEYS FILES=F2,FIELDS=(1,2,A)                                     00044641
//*JOIN UNPAIRED,F1
//*REFORMAT FIELDS=(F1:1,169,?)                                         00044643
//*OUTFIL FNAMES=BOTH                                                   00044645
//*COL05-F
//**********************************************************************
//* ARMA ESTRUCTURA ARCHIVO PARA QUE SEA PROCESADO POR UG4CRAR2        *
//**********************************************************************
//*UGRAR3E5 EXEC  PGM=ICEMAN,COND=(4,LT)
//*SYSOUT   DD  SYSOUT=(*,,)
//*SYSPRINT DD  SYSOUT=(*,,)
//*SORTIN   DD  DSN=COBP.UG.FJSD1.UGDRAR3.UDTNRABA.F%%ODATE,
//*             DISP=(SHR)
//*SORTOUT  DD  DSN=COBP.UG.FJSD1.UGDRAR3.SDTNRABA.F%%ODATE,
//*             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,
//*             SPACE=(CYL,(300,150,),RLSE),UNIT=SYSDA
//*SYSIN    DD  *
//*SORT  FIELDS=COPY
//*OUTREC FIELDS=(1,2,C'00000000',C'  ',
//*               10,10,
//*               C'00000.000000000.000000000.0000',
//*               C'0000000000000000',
//*               5,5,PD,TO=ZD,LENGTH=9,
//*               C'00000.000000000.0000',
//*               1X,
//*               C'00000.000000000.000000000.000000000.0000',
//*               1X,
//*               C'000000',
//*               C'00000.000000000.0000',
//*               3,2,7X,
//*               C'00000.000000000.0000',
//*               25X,
//*               87,20,
//*               170,1)
//*END
//*COL06-F
//*COL05-I
//*              87,20)
//*              170,1)
//*COL05-F
//*
//********************************************************************* 00460000
//*  CARGA LA TABLA UGDTNRA NUEVO MODELO RAR - TASAS Y CLUSTER BAJAS    00470002
//********************************************************************* 00480000
//*UGRAR310 EXEC  PGM=IKJEFT1A,COND=(4,LT)                              00490002
//*EUGDNRA  DD DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRBA,               00500002
//*            DISP=SHR                                                 00510000
//*SALIDA   DD DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR310.F%%ODATE.SAL,         00540002
//*            DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,              00550002
//*            SPACE=(CYL,(400,200,),RLSE),UNIT=SYSDA                   00560002
//*ERRORES  DD DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR310.F%%ODATE.ERR,         00570002
//*            DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,              00571002
//*            SPACE=(CYL,(400,200,),RLSE),UNIT=SYSDA                   00572002
//*QRLSDB2  DD  SYSOUT=(*,,)                                            00580000
//*SYSOUT   DD  SYSOUT=(*,,)                                            00590000
//*SYSPRINT DD  SYSOUT=(*,,)                                            00600000
//*SYSTSPRT DD  SYSOUT=(*,,)                                            00610000
//*SYSUDUMP DD  DUMMY                                                   00620000
//*SYSIN    DD  DUMMY                                                   00630000
//*SYSTSIN  DD  *                                                       00640000
//*    DSN SYSTEM(DB2P)                                                 00650002
//*    RUN PROGRAM(UG4CRAR2) PLAN(BVPUGPB) PARM('%%FECDIA,01,0500')     00660002
//*    END                                                              00661002
//*                                                                     00661003
//*COL04-F                                                              00661003
//********************************************************************* 00460000
//*  CARGA LA TABLA UGDTNRA NUEVO MODELO RAR - TASAS Y CLUSTER BAJAS    00470002
//********************************************************************* 00480000
//*COL06-I
//*UGRAR312 EXEC  PGM=IKJEFT1A,COND=(4,LT)                              00490002
//**COL04-I                                                             00661003
//**EUGDNRA  DD DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRBA,              00500002
//*EUGDNRA  DD DSN=COBP.UG.FJSD1.UGDRAR3.SDTNRABA.F%%ODATE,             00500002
//**COL04-F                                                             00661003
//*            DISP=SHR                                                 00510000
//*SALIDA   DD DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR312.F%%ODATE.SAL,         00540002
//*            DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,              00550002
//*            SPACE=(CYL,(400,200,),RLSE),UNIT=SYSDA                   00560002
//*ERRORES  DD DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR312.F%%ODATE.ERR,         00570002
//*            DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,              00571002
//*            SPACE=(CYL,(400,200,),RLSE),UNIT=SYSDA                   00572002
//*QRLSDB2  DD  SYSOUT=(*,,)                                            00580000
//*SYSOUT   DD  SYSOUT=(*,,)                                            00590000
//*SYSPRINT DD  SYSOUT=(*,,)                                            00600000
//*SYSTSPRT DD  SYSOUT=(*,,)                                            00610000
//*SYSUDUMP DD  DUMMY                                                   00620000
//*SYSIN    DD  DUMMY                                                   00630000
//*SYSTSIN  DD  *                                                       00640000
//*  DSN SYSTEM(DB2P)                                                   00650002
//*  RUN PROGRAM(UG4CRAR2) PLAN(BVPUGPB) PARM('%%FECDIA,02,0500')       00660002
//*  END                                                                00661002
//*                                                                     00661003
//**********************************************************************00290000
//* SE ORDENA EL ARCHIVO DE ENTRADA POR VARIABLE BURO - 01              00300001
//**********************************************************************00330000
//*UGRAR315 EXEC  PGM=ICEMAN,COND=(4,LT)                                00340001
//*SORTLIB  DD  DSN=SYS1.SORTLIB,DISP=(SHR)                             00350000
//*SORTIN   DD  DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRVS,              00360001
//*             DISP=SHR                                                00370000
//*SORTOUT  DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR315.DTNRA01,             00380001
//*             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,             00390000
//*             SPACE=(CYL,(100,50),RLSE),UNIT=SYSDA                    00400000
//*SYSOUT   DD  SYSOUT=(*,,)                                            00410000
//*SYSIN    DD  *                                                       00420000
//*SORT FIELDS=(1,2,CH,A,3,4,CH,A)
//*INCLUDE COND=(3,4,CH,GE,C'0000')
//*OUTREC IFTHEN=(WHEN=INIT,BUILD(1,219)),
//*      IFTHEN=(WHEN=(3,4,CH,GE,C'0000'),BUILD(1,2,C'01',3,8,
//*              C'00000.000000000.0000'))
//*
//**********************************************************************00290000
//* SE ORDENA EL ARCHIVO DE ENTRADA POR VARIABLE NOMINA - 02            00300001
//**********************************************************************00330000
//*UGRAR320 EXEC  PGM=ICEMAN,COND=(4,LT)                                00340001
//*SORTLIB  DD  DSN=SYS1.SORTLIB,DISP=(SHR)                             00350000
//*SORTIN   DD  DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRVS,              00360001
//*             DISP=SHR                                                00370000
//*SORTOUT  DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR320.DTNRA02,             00380001
//*             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,             00390000
//*             SPACE=(CYL,(100,50),RLSE),UNIT=SYSDA                    00400000
//*SYSOUT   DD  SYSOUT=(*,,)                                            00410000
//*SYSIN    DD  *                                                       00420000
//*SORT FIELDS=(1,2,CH,A,11,1,CH,A)
//*INCLUDE COND=(11,1,CH,EQ,C'N',OR,11,1,CH,EQ,C'S')
//*OUTREC IFTHEN=(WHEN=INIT,BUILD(1,219)),
//*      IFTHEN=(WHEN=(11,1,CH,EQ,C'N'),BUILD(1,2,C'02',C'00000000',
//*              C'00000.000000000.0000',11,1)),
//*      IFTHEN=(WHEN=(11,1,CH,EQ,C'S'),BUILD(1,2,C'02',C'00000000',
//*              C'00000.000000000.0000',11,1))
//*
//**********************************************************************00290000
//* SE ORDENA EL ARCHIVO DE ENTRADA POR VARIABLE SITUA.LABORA - 03      00300001
//**********************************************************************00330000
//*UGRAR325 EXEC  PGM=ICEMAN,COND=(4,LT)                                00340001
//*SORTLIB  DD  DSN=SYS1.SORTLIB,DISP=(SHR)                             00350000
//*SORTIN   DD  DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRVS,              00360001
//*             DISP=SHR                                                00370000
//*SORTOUT  DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR325.DTNRA03,             00380001
//*             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,             00390000
//*             SPACE=(CYL,(100,50),RLSE),UNIT=SYSDA                    00400000
//*SYSOUT   DD  SYSOUT=(*,,)                                            00410000
//*SYSIN    DD  *                                                       00420000
//*SORT FIELDS=(1,2,CH,A,12,1,CH,A)
//*INCLUDE COND=(12,1,CH,NE,C'0')
//*OUTREC IFTHEN=(WHEN=INIT,BUILD(1,219)),
//*      IFTHEN=(WHEN=(12,1,CH,NE,C'0'),BUILD(1,2,C'03',C'00000000',
//*              C'00000.000000000.0000',12,1))
//*
//**********************************************************************00290000
//* SE ORDENA EL ARCHIVO DE ENTRADA POR VARIABLE INGRESOS - 04          00300001
//**********************************************************************00330000
//*UGRAR330 EXEC  PGM=ICEMAN,COND=(4,LT)                                00340001
//*SORTLIB  DD  DSN=SYS1.SORTLIB,DISP=(SHR)                             00350000
//**SORTIN   DD  DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRVS,             00360001
//*             DISP=SHR                                                00370000
//*SORTOUT  DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR330.DTNRA04,             00380001
//*             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,             00390000
//*             SPACE=(CYL,(100,50),RLSE),UNIT=SYSDA                    00400000
//*SYSOUT   DD  SYSOUT=(*,,)                                            00410000
//*SYSIN    DD  *                                                       00420000
//*SORT FIELDS=(1,2,CH,A,13,10,CH,A)
//*INCLUDE COND=(13,10,CH,GE,C'00000.0000')
//*OUTREC IFTHEN=(WHEN=INIT,BUILD(1,219)),
//*      IFTHEN=(WHEN=(13,1,CH,EQ,C'0'),BUILD(1,2,C'04',C'00000000',
//*              13,20))
//*
//**********************************************************************00290000
//* SE ORDENA EL ARCHIVO DE ENTRADA POR VARIABLE MONTO FINC 05          00300001
//**********************************************************************00330000
//*UGRAR335 EXEC  PGM=ICEMAN,COND=(4,LT)                                00340001
//*SORTLIB  DD  DSN=SYS1.SORTLIB,DISP=(SHR)                             00350000
//*SORTIN   DD  DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRVS,              00360001
//*             DISP=SHR                                                00370000
//*SORTOUT  DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR335.DTNRA05,             00380001
//*             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,             00390000
//*             SPACE=(CYL,(100,50),RLSE),UNIT=SYSDA                    00400000
//*SYSOUT   DD  SYSOUT=(*,,)                                            00410000
//*SYSIN    DD  *                                                       00420000
//*SORT FIELDS=(1,2,CH,A,33,10,CH,A)
//*INCLUDE COND=(33,10,CH,GE,C'00000.0000')
//*OUTREC IFTHEN=(WHEN=INIT,BUILD(1,219)),
//*      IFTHEN=(WHEN=(33,1,CH,EQ,C'0'),BUILD(1,2,C'05',C'00000000',
//*              33,20))
//*
//**********************************************************************00290000
//* SE ORDENA EL ARCHIVO DE ENTRADA POR VARIABLE PLAZO OPR - 06         00300001
//**********************************************************************00330000
//*UGRAR340 EXEC  PGM=ICEMAN,COND=(4,LT)                                00340001
//*SORTLIB  DD  DSN=SYS1.SORTLIB,DISP=(SHR)                             00350000
//*SORTIN   DD  DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRVS,              00360001
//*             DISP=SHR                                                00370000
//*SORTOUT  DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR340.DTNRA06,             00380001
//*             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,             00390000
//*             SPACE=(CYL,(100,50),RLSE),UNIT=SYSDA                    00400000
//*SYSOUT   DD  SYSOUT=(*,,)                                            00410000
//*SYSIN    DD  *                                                       00420000
//*SORT FIELDS=(1,2,CH,A,53,04,CH,A)
//*INCLUDE COND=(53,04,CH,GE,C'0000')
//*OUTREC IFTHEN=(WHEN=INIT,BUILD(1,219)),
//*      IFTHEN=(WHEN=(53,1,CH,EQ,C'0'),BUILD(1,2,C'06',53,8,
//*              C'00000.000000000.0000'))
//*
//**********************************************************************00290000
//* SE ORDENA EL ARCHIVO DE ENTRADA POR VARIABLE EDAD - 07              00300001
//**********************************************************************00330000
//*UGRAR345 EXEC  PGM=ICEMAN,COND=(4,LT)                                00340001
//*SORTLIB  DD  DSN=SYS1.SORTLIB,DISP=(SHR)                             00350000
//*SORTIN   DD  DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRVS,              00360001
//*             DISP=SHR                                                00370000
//*SORTOUT  DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR345.DTNRA07,             00380001
//*             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,             00390000
//*             SPACE=(CYL,(100,50),RLSE),UNIT=SYSDA                    00400000
//*SYSOUT   DD  SYSOUT=(*,,)                                            00410000
//*SYSIN    DD  *                                                       00420000
//*SORT FIELDS=(1,2,CH,A,61,04,CH,A)
//*INCLUDE COND=(61,04,CH,GE,C'0000')
//*OUTREC IFTHEN=(WHEN=INIT,BUILD(1,219)),
//*      IFTHEN=(WHEN=(61,1,CH,EQ,C'0'),BUILD(1,2,C'07',61,8,
//*              C'00000.000000000.0000'))
//*
//**********************************************************************00290000
//* SE ORDENA EL ARCHIVO DE ENTRADA POR VARIABLE SEGMENTO - 08          00300001
//**********************************************************************00330000
//*UGRAR350 EXEC  PGM=ICEMAN,COND=(4,LT)                                00340001
//*SORTLIB  DD  DSN=SYS1.SORTLIB,DISP=(SHR)                             00350000
//*SORTIN   DD  DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRVS,              00360001
//*             DISP=SHR                                                00370000
//*SORTOUT  DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR350.DTNRA08,             00380001
//*             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,             00390000
//*             SPACE=(CYL,(100,50),RLSE),UNIT=SYSDA                    00400000
//*SYSOUT   DD  SYSOUT=(*,,)                                            00410000
//*SYSIN    DD  *                                                       00420000
//*SORT FIELDS=(1,2,CH,A,69,05,CH,A)
//*INCLUDE COND=(69,05,CH,GE,C'00000')
//*OUTREC IFTHEN=(WHEN=INIT,BUILD(1,219)),
//*      IFTHEN=(WHEN=(69,1,CH,GE,C'0'),BUILD(1,2,C'08',C'00000000',
//*              69,05,C'.000000000.0000'))
//*
//**********************************************************************00290000
//* SE ORDENA EL ARCHIVO DE ENTRADA POR VARIABLE COLECTIVO - 09         00300001
//**********************************************************************00330000
//*UGRAR355 EXEC  PGM=ICEMAN,COND=(4,LT)                                00340001
//*SORTLIB  DD  DSN=SYS1.SORTLIB,DISP=(SHR)                             00350000
//*SORTIN   DD  DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRVS,              00360001
//*             DISP=SHR                                                00370000
//*SORTOUT  DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR355.DTNRA09,             00380001
//*             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,             00390000
//*             SPACE=(CYL,(100,50),RLSE),UNIT=SYSDA                    00400000
//*SYSOUT   DD  SYSOUT=(*,,)                                            00410000
//*SYSIN    DD  *                                                       00420000
//*SORT FIELDS=(1,2,CH,A,74,04,CH,A)
//*INCLUDE COND=(74,04,CH,GE,C'0000')
//*OUTREC IFTHEN=(WHEN=INIT,BUILD(1,219)),
//*      IFTHEN=(WHEN=(74,1,CH,GE,C'0'),BUILD(1,2,C'09',C'000000000',
//*              74,04,C'.000000000.0000'))
//*
//**********************************************************************00290000
//* SE ORDENA EL ARCHIVO DE ENTRADA POR VARIABLE GRUPO RIESGO - 10      00300001
//**********************************************************************00330000
//*UGRAR360 EXEC  PGM=ICEMAN,COND=(4,LT)                                00340001
//*SORTLIB  DD  DSN=SYS1.SORTLIB,DISP=(SHR)                             00350000
//*SORTIN   DD  DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRVS,              00360001
//*             DISP=SHR                                                00370000
//*SORTOUT  DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR360.DTNRA10,             00380001
//*             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,             00390000
//*             SPACE=(CYL,(100,50),RLSE),UNIT=SYSDA                    00400000
//*SYSOUT   DD  SYSOUT=(*,,)                                            00410000
//*SYSIN    DD  *                                                       00420000
//*SORT FIELDS=(1,2,CH,A,78,10,CH,A)
//*INCLUDE COND=(78,10,CH,GE,C'00000.0000')
//*OUTREC IFTHEN=(WHEN=INIT,BUILD(1,219)),
//*      IFTHEN=(WHEN=(78,1,CH,EQ,C'0'),BUILD(1,2,C'10',C'00000000',
//*              78,20))
//*
//**********************************************************************00290000
//* SE ORDENA EL ARCHIVO DE ENTRADA POR VARIABLE ESTADO VEHIC - 11      00300001
//**********************************************************************00330000
//*UGRAR365 EXEC  PGM=ICEMAN,COND=(4,LT)                                00340001
//*SORTLIB  DD  DSN=SYS1.SORTLIB,DISP=(SHR)                             00350000
//*SORTIN   DD  DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRVS,              00360001
//*             DISP=SHR                                                00370000
//*SORTOUT  DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR365.DTNRA11,             00380001
//*             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,             00390000
//*             SPACE=(CYL,(100,50),RLSE),UNIT=SYSDA                    00400000
//*SYSOUT   DD  SYSOUT=(*,,)                                            00410000
//*SYSIN    DD  *                                                       00420000
//*SORT FIELDS=(1,2,CH,A,98,1,CH,A)
//*INCLUDE COND=(98,1,CH,EQ,C'N',OR,98,1,CH,EQ,C'U')
//*OUTREC IFTHEN=(WHEN=INIT,BUILD(1,219)),
//*      IFTHEN=(WHEN=(98,1,CH,EQ,C'N'),BUILD(1,2,C'11',C'00000000',
//*              C'00000.000000000.0000',98,1)),
//*      IFTHEN=(WHEN=(98,1,CH,EQ,C'U'),BUILD(1,2,C'11',C'00000000',
//*              C'00000.000000000.0000',98,1))
//*
//**********************************************************************00290000
//* SE ORDENA EL ARCHIVO DE ENTRADA POR VARIABLE % FINANCIACION - 12    00300001
//**********************************************************************00330000
//*UGRAR370 EXEC  PGM=ICEMAN,COND=(4,LT)                                00340001
//*SORTLIB  DD  DSN=SYS1.SORTLIB,DISP=(SHR)                             00350000
//*SORTIN   DD  DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRVS,              00360001
//*             DISP=SHR                                                00370000
//*SORTOUT  DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR370.DTNRA12,             00380001
//*             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,             00390000
//*             SPACE=(CYL,(100,50),RLSE),UNIT=SYSDA                    00400000
//*SYSOUT   DD  SYSOUT=(*,,)                                            00410000
//*SYSIN    DD  *                                                       00420000
//*SORT FIELDS=(1,2,CH,A,99,10,CH,A)
//*INCLUDE COND=(99,10,CH,GE,C'00000.0000')
//*OUTREC IFTHEN=(WHEN=INIT,BUILD(1,219)),
//*      IFTHEN=(WHEN=(99,1,CH,EQ,C'0'),BUILD(1,2,C'12',C'00000000',
//*              99,20))
//*
//**********************************************************************00290000
//* SE ORDENA EL ARCHIVO DE ENTRADA POR VARIABLE GAMA VEHICULO - 13     00300001
//**********************************************************************00330000
//*UGRAR375 EXEC  PGM=ICEMAN,COND=(4,LT)                                00340001
//*SORTLIB  DD  DSN=SYS1.SORTLIB,DISP=(SHR)                             00350000
//*SORTIN   DD  DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRVS,              00360001
//*             DISP=SHR                                                00370000
//*SORTOUT  DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR375.DTNRA13,             00380001
//*             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,             00390000
//*             SPACE=(CYL,(100,50),RLSE),UNIT=SYSDA                    00400000
//*SYSOUT   DD  SYSOUT=(*,,)                                            00410000
//*SYSIN    DD  *                                                       00420000
//*SORT FIELDS=(1,2,CH,A,99,10,CH,A)
//*INCLUDE COND=(119,10,CH,GE,C'00000.0000')
//*OUTREC IFTHEN=(WHEN=INIT,BUILD(1,219)),
//*      IFTHEN=(WHEN=(119,1,CH,EQ,C'0'),BUILD(1,2,C'13',C'00000000',
//*             119,20))
//*
//**********************************************************************00290000
//* SE ORDENA EL ARCHIVO DE ENTRADA POR VARIABLE TIPO VEHIC - 14 P/S    00300001
//**********************************************************************00330000
//*UGRAR380 EXEC  PGM=ICEMAN,COND=(4,LT)                                00340001
//*SORTLIB  DD  DSN=SYS1.SORTLIB,DISP=(SHR)                             00350000
//*SORTIN   DD  DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRVS,              00360001
//*             DISP=SHR                                                00370000
//*SORTOUT  DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR380.DTNRA14,             00380001
//*             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,             00390000
//*             SPACE=(CYL,(100,50),RLSE),UNIT=SYSDA                    00400000
//*SYSOUT   DD  SYSOUT=(*,,)                                            00410000
//*SYSIN    DD  *                                                       00420000
//*SORT FIELDS=(1,2,CH,A,139,1,CH,A)
//*INCLUDE COND=(139,1,CH,EQ,C'P',OR,139,1,CH,EQ,C'S')
//*OUTREC IFTHEN=(WHEN=INIT,BUILD(1,219)),
//*      IFTHEN=(WHEN=(139,1,CH,EQ,C'P'),BUILD(1,2,C'14',C'00000000',
//*              C'00000.000000000.0000',139,1)),
//*      IFTHEN=(WHEN=(139,1,CH,EQ,C'S'),BUILD(1,2,C'14',C'00000000',
//*              C'00000.000000000.0000',139,1))
//*
//**********************************************************************00290000
//* SE ORDENA EL ARCHIVO DE ENTRADA POR VARIABLE COLECTIVO- 16          00300001
//**********************************************************************00330000
//*UGRAR382 EXEC  PGM=ICEMAN,COND=(4,LT)                                00340001
//*SORTLIB  DD  DSN=SYS1.SORTLIB,DISP=(SHR)                             00350000
//*SORTIN   DD  DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRVS,              00360001
//*             DISP=SHR                                                00370000
//*SORTOUT  DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR382.DTNRA16,             00380001
//*             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,             00390000
//*             SPACE=(CYL,(100,50),RLSE),UNIT=SYSDA                    00400000
//*SYSOUT   DD  SYSOUT=(*,,)                                            00410000
//*SYSIN    DD  *                                                       00420000
//*SORT FIELDS=(1,2,CH,A,140,03,CH,A)
//*INCLUDE COND=(140,03,CH,GT,C'000')
//*OUTREC IFTHEN=(WHEN=INIT,BUILD(1,219)),
//*      IFTHEN=(WHEN=(140,1,CH,GE,C'0'),BUILD(1,2,C'16',C'0000000000',
//*              140,03,C'.000000000.0000'))
//*
//**********************************************************************00290000
//* SE ORDENA EL ARCHIVO DE ENTRADA POR VARIABLE DESTINO  - 17          00300001
//**********************************************************************00330000
//*UGRAR384 EXEC  PGM=ICEMAN,COND=(4,LT)                                00340001
//*SORTLIB  DD  DSN=SYS1.SORTLIB,DISP=(SHR)                             00350000
//*SORTIN   DD  DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRVS,              00360001
//*             DISP=SHR                                                00370000
//*SORTOUT  DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR384.DTNRA17,             00380001
//*             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,             00390000
//*             SPACE=(CYL,(100,50),RLSE),UNIT=SYSDA                    00400000
//*SYSOUT   DD  SYSOUT=(*,,)                                            00410000
//*SYSIN    DD  *                                                       00420000
//*SORT FIELDS=(1,2,CH,A,143,03,CH,A)
//*INCLUDE COND=(143,03,CH,GT,C'000')
//*OUTREC IFTHEN=(WHEN=INIT,BUILD(1,219)),
//*      IFTHEN=(WHEN=(143,1,CH,GE,C'0'),BUILD(1,2,C'17',C'0000000000',
//*              143,03,C'.000000000.0000'))
//*
//*COL03-I
//**********************************************************************00290000
//* SE ORDENA EL ARCHIVO DE ENTRADA POR VARIABLE VENTAS - 18   COMERCIAL00300001
//**********************************************************************00330000
//*UGRAR386 EXEC  PGM=ICEMAN,COND=(4,LT)                                00340001
//*SORTLIB  DD  DSN=SYS1.SORTLIB,DISP=(SHR)                             00350000
//*SORTIN   DD  DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRVS,              00360001
//*             DISP=SHR                                                00370000
//*SORTOUT  DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR386.DTNRA18,             00380001
//*             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,             00390000
//*             SPACE=(CYL,(100,50),RLSE),UNIT=SYSDA                    00400000
//*SYSOUT   DD  SYSOUT=(*,,)                                            00410000
//*SYSIN    DD  *                                                       00420000
//*SORT FIELDS=(1,2,CH,A,146,10,CH,A)
//*INCLUDE COND=(146,10,CH,GE,C'00000.0000')
//*OUTREC IFTHEN=(WHEN=INIT,BUILD(1,219)),
//*      IFTHEN=(WHEN=(146,10,CH,GE,C'00000.0000'),BUILD(1,2,C'18',
//*                    C'00000000',146,20))
//*
//**********************************************************************00290000
//* SE ORDENA EL ARCHIVO DE ENTRADA POR VARIABLE TIP.PERSONA - 19  COMER00300001
//**********************************************************************00330000
//*UGRAR387 EXEC  PGM=ICEMAN,COND=(4,LT)                                00340001
//*SORTLIB  DD  DSN=SYS1.SORTLIB,DISP=(SHR)                             00350000
//*SORTIN   DD  DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRVS,              00360001
//*             DISP=SHR                                                00370000
//*SORTOUT  DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR387.DTNRA19,             00380001
//*             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,             00390000
//*             SPACE=(CYL,(100,50),RLSE),UNIT=SYSDA                    00400000
//*SYSOUT   DD  SYSOUT=(*,,)                                            00410000
//*SYSIN    DD  *                                                       00420000
//*SORT FIELDS=(1,2,CH,A,166,2,CH,A)
//*INCLUDE COND=(166,2,CH,EQ,C'PJ',OR,166,2,CH,EQ,C'PN')
//*OUTREC IFTHEN=(WHEN=INIT,BUILD(1,219)),
//*      IFTHEN=(WHEN=(166,2,CH,EQ,C'PJ'),BUILD(1,2,C'19',C'00000000',
//*              C'00000.000000000.0000',C' ',166,2)),
//*      IFTHEN=(WHEN=(166,2,CH,EQ,C'PN'),BUILD(1,2,C'19',C'00000000',
//*              C'00000.000000000.0000',C' ',166,2))
//*
//**********************************************************************00290000
//* SE ORDENA EL ARCHIVO DE ENTRADA POR VARIABLE CAL.RATING - 20  COMERC00300001
//**********************************************************************00330000
//*UGRAR388 EXEC  PGM=ICEMAN,COND=(4,LT)                                00340001
//*SORTLIB  DD  DSN=SYS1.SORTLIB,DISP=(SHR)                             00350000
//*SORTIN   DD  DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRVS,              00360001
//*             DISP=SHR                                                00370000
//*SORTOUT  DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR388.DTNRA20,             00380001
//*             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,             00390000
//*             SPACE=(CYL,(100,50),RLSE),UNIT=SYSDA                    00400000
//*SYSOUT   DD  SYSOUT=(*,,)                                            00410000
//*SYSIN    DD  *                                                       00420000
//*SORT FIELDS=(1,2,CH,A,168,5,CH,A)
//*INCLUDE COND=(168,5,CH,NE,C'     ')
//*OUTREC IFTHEN=(WHEN=INIT,BUILD(1,219)),
//*      IFTHEN=(WHEN=(168,1,CH,NE,C' '),BUILD(1,2,C'20',C'00000000',
//*              C'00000.000000000.0000',C' ',168,5))
//*
//**********************************************************************00290000
//* SE ORDENA EL ARCHIVO DE ENTRADA POR VARIABLE RANG.RATING- 21  COMERC00300001
//**********************************************************************00330000
//*UGRAR389 EXEC  PGM=ICEMAN,COND=(4,LT)                                00340001
//*SORTLIB  DD  DSN=SYS1.SORTLIB,DISP=(SHR)                             00350000
//*SORTIN   DD  DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRVS,              00360001
//*             DISP=SHR                                                00370000
//*SORTOUT  DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR389.DTNRA21,             00380001
//*             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,             00390000
//*             SPACE=(CYL,(100,50),RLSE),UNIT=SYSDA                    00400000
//*SYSOUT   DD  SYSOUT=(*,,)                                            00410000
//*SYSIN    DD  *                                                       00420000
//*SORT FIELDS=(1,2,CH,A,173,1,CH,A)
//*INCLUDE COND=(173,1,CH,NE,C' ')
//*OUTREC IFTHEN=(WHEN=INIT,BUILD(1,219)),
//*      IFTHEN=(WHEN=(173,1,CH,NE,C' '),BUILD(1,2,C'21',C'00000000',
//*              C'00000.000000000.0000',C' ',173,1))
//*
//**********************************************************************00290000
//* SE ORDENA EL ARCHIVO DE ENTRADA POR VARIABLE GARANTIA - 22   COMERCI00300001
//**********************************************************************00330000
//*UGRAR390 EXEC  PGM=ICEMAN,COND=(4,LT)                                00340001
//*SORTLIB  DD  DSN=SYS1.SORTLIB,DISP=(SHR)                             00350000
//*SORTIN   DD  DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRVS,              00360001
//*             DISP=SHR                                                00370000
//*SORTOUT  DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR390.DTNRA22,             00380001
//*             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,             00390000
//*             SPACE=(CYL,(100,50),RLSE),UNIT=SYSDA                    00400000
//*SYSOUT   DD  SYSOUT=(*,,)                                            00410000
//*SYSIN    DD  *                                                       00420000
//*SORT FIELDS=(1,2,CH,A,174,1,CH,A)
//*INCLUDE COND=(174,1,CH,EQ,C'S',OR,174,1,CH,EQ,C'N')
//*OUTREC IFTHEN=(WHEN=INIT,BUILD(1,219)),
//*      IFTHEN=(WHEN=(174,1,CH,EQ,C'S'),BUILD(1,2,C'22',C'00000000',
//*              C'00000.000000000.0000',C' ',174,1)),
//*      IFTHEN=(WHEN=(174,1,CH,EQ,C'N'),BUILD(1,2,C'22',C'00000000',
//*              C'00000.000000000.0000',C' ',174,1))
//*
//**********************************************************************00290000
//* SE ORDENA EL ARCHIVO DE ENTRADA POR VARIABLE MON.OPER -23  COMERCIAL00300001
//**********************************************************************00330000
//*UGRAR391 EXEC  PGM=ICEMAN,COND=(4,LT)                                00340001
//*SORTLIB  DD  DSN=SYS1.SORTLIB,DISP=(SHR)                             00350000
//*SORTIN   DD  DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRVS,              00360001
//*             DISP=SHR                                                00370000
//*SORTOUT  DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR391.DTNRA23,             00380001
//*             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,             00390000
//*             SPACE=(CYL,(100,50),RLSE),UNIT=SYSDA                    00400000
//*SYSOUT   DD  SYSOUT=(*,,)                                            00410000
//*SYSIN    DD  *                                                       00420000
//*SORT FIELDS=(1,2,CH,A,175,10,CH,A)
//*INCLUDE COND=(175,10,CH,GE,C'00000.0000')
//*OUTREC IFTHEN=(WHEN=INIT,BUILD(1,219)),
//*       IFTHEN=(WHEN=(175,10,CH,GE,C'00000.0000'),BUILD(1,2,C'23',
//*                     C'00000000',175,20))
//*
//**********************************************************************
//* OPTIMIZACION: REEMPLAZA 22 PASOS DE LECTURA CON UN SOLO PASO OUTFIL
//**********************************************************************
//UGRAR390 EXEC PGM=SYNCSORT,COND=(4,LT)
//SORTIN   DD  DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRVS,
//             DISP=SHR
//SYSOUT   DD  SYSOUT=(*,,)
//**********************************************************************
//* DEFINICION DE LOS 22 ARCHIVOS DE SALIDA (OUTFIL)
//**********************************************************************
//SORTOF01 DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR315.DTNRA01,
//             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,
//             SPACE=(CYL,(2000,1000),RLSE),UNIT=SYSDA
//SORTOF02 DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR320.DTNRA02,
//             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,
//             SPACE=(CYL,(2000,1000),RLSE),UNIT=SYSDA
//SORTOF03 DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR325.DTNRA03,
//             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,
//             SPACE=(CYL,(2000,1000),RLSE),UNIT=SYSDA
//SORTOF04 DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR330.DTNRA04,
//             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,
//             SPACE=(CYL,(2000,1000),RLSE),UNIT=SYSDA
//SORTOF05 DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR335.DTNRA05,
//             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,
//             SPACE=(CYL,(2000,1000),RLSE),UNIT=SYSDA
//SORTOF06 DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR340.DTNRA06,
//             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,
//             SPACE=(CYL,(2000,1000),RLSE),UNIT=SYSDA
//SORTOF07 DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR345.DTNRA07,
//             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,
//             SPACE=(CYL,(2000,1000),RLSE),UNIT=SYSDA
//SORTOF08 DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR350.DTNRA08,
//             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,
//             SPACE=(CYL,(2000,1000),RLSE),UNIT=SYSDA
//SORTOF09 DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR355.DTNRA09,
//             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,
//             SPACE=(CYL,(2000,1000),RLSE),UNIT=SYSDA
//SORTOF10 DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR360.DTNRA10,
//             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,
//             SPACE=(CYL,(2000,1000),RLSE),UNIT=SYSDA
//SORTOF11 DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR365.DTNRA11,
//             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,
//             SPACE=(CYL,(2000,1000),RLSE),UNIT=SYSDA
//SORTOF12 DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR370.DTNRA12,
//             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,
//             SPACE=(CYL,(2000,1000),RLSE),UNIT=SYSDA
//SORTOF13 DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR375.DTNRA13,
//             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,
//             SPACE=(CYL,(2000,1000),RLSE),UNIT=SYSDA
//SORTOF14 DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR380.DTNRA14,
//             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,
//             SPACE=(CYL,(2000,1000),RLSE),UNIT=SYSDA
//SORTOF15 DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR382.DTNRA16,
//             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,
//             SPACE=(CYL,(2000,1000),RLSE),UNIT=SYSDA
//SORTOF16 DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR384.DTNRA17,
//             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,
//             SPACE=(CYL,(2000,1000),RLSE),UNIT=SYSDA
//SORTOF17 DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR386.DTNRA18,
//             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,
//             SPACE=(CYL,(2000,1000),RLSE),UNIT=SYSDA
//SORTOF18 DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR387.DTNRA19,
//             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,
//             SPACE=(CYL,(2000,1000),RLSE),UNIT=SYSDA
//SORTOF19 DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR388.DTNRA20,
//             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,
//             SPACE=(CYL,(2000,1000),RLSE),UNIT=SYSDA
//SORTOF20 DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR389.DTNRA21,
//             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,
//             SPACE=(CYL,(2000,1000),RLSE),UNIT=SYSDA
//SORTOF21 DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR390.DTNRA22,
//             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,
//             SPACE=(CYL,(2000,1000),RLSE),UNIT=SYSDA
//SORTOF22 DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR391.DTNRA23,
//             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,
//             SPACE=(CYL,(2000,1000),RLSE),UNIT=SYSDA
//SYSIN    DD  *
  OPTION COPY
    OUTFIL FILES=01,
      INCLUDE=(3,4,CH,GE,C'0000'),
      OUTREC=(1,2,C'01',3,8,C'00000.000000000.0000',207X)
    OUTFIL FILES=02,
      INCLUDE=(11,1,SS,EQ,C'N,S'),
      OUTREC=(1,2,C'02',C'00000000',C'00000.000000000.0000',11,1,
              206X)
    OUTFIL FILES=03,
      INCLUDE=(12,1,CH,NE,C'0'),
      OUTREC=(1,2,C'03',C'00000000',C'00000.000000000.0000',12,1,
              206X)
    OUTFIL FILES=04,
      INCLUDE=(13,10,CH,GE,C'00000.0000',AND,13,1,CH,EQ,C'0'),
      OUTREC=(1,2,C'04',C'00000000',13,20,207X)
    OUTFIL FILES=05,
      INCLUDE=(33,10,CH,GE,C'00000.0000',AND,33,1,CH,EQ,C'0'),
      OUTREC=(1,2,C'05',C'00000000',33,20,207X)
    OUTFIL FILES=06,
      INCLUDE=(53,04,CH,GE,C'0000',AND,53,1,CH,EQ,C'0'),
      OUTREC=(1,2,C'06',53,8,C'00000.000000000.0000',207X)
    OUTFIL FILES=07,
      INCLUDE=(61,04,CH,GE,C'0000',AND,61,1,CH,EQ,C'0'),
      OUTREC=(1,2,C'07',61,8,C'00000.000000000.0000',207X)
    OUTFIL FILES=08,
      INCLUDE=(69,05,CH,GE,C'00000',AND,69,1,CH,GE,C'0'),
      OUTREC=(1,2,C'08',C'00000000',69,05,C'.000000000.0000',
              207X)
    OUTFIL FILES=09,
      INCLUDE=(74,04,CH,GE,C'0000',AND,74,1,CH,GE,C'0'),
      OUTREC=(1,2,C'09',C'000000000',74,04,C'.000000000.0000',
              207X)
    OUTFIL FILES=10,
      INCLUDE=(78,10,CH,GE,C'00000.0000',AND,78,1,CH,EQ,C'0'),
      OUTREC=(1,2,C'10',C'00000000',78,20,207X)
    OUTFIL FILES=11,
      INCLUDE=(98,1,SS,EQ,C'N,U'),
      OUTREC=(1,2,C'11',C'00000000',C'00000.000000000.0000',98,1,
              206X)
    OUTFIL FILES=12,
      INCLUDE=(99,10,CH,GE,C'00000.0000',AND,99,1,CH,EQ,C'0'),
      OUTREC=(1,2,C'12',C'00000000',99,20,207X)
    OUTFIL FILES=13,
      INCLUDE=(119,10,CH,GE,C'00000.0000',AND,119,1,CH,EQ,C'0'),
      OUTREC=(1,2,C'13',C'00000000',119,20,207X)
    OUTFIL FILES=14,
      INCLUDE=(139,1,SS,EQ,C'P,S'),
      OUTREC=(1,2,C'14',C'00000000',C'00000.000000000.0000',139,1,
              206X)
    OUTFIL FILES=15,
      INCLUDE=(140,03,CH,GT,C'000',AND,140,1,CH,GE,C'0'),
      OUTREC=(1,2,C'16',C'0000000000',140,03,C'.000000000.0000',207X)
    OUTFIL FILES=16,
      INCLUDE=(143,03,CH,GT,C'000',AND,143,1,CH,GE,C'0'),
      OUTREC=(1,2,C'17',C'0000000000',143,03,C'.000000000.0000',207X)
    OUTFIL FILES=17,
      INCLUDE=(146,10,CH,GE,C'00000.0000'),
      OUTREC=(1,2,C'18',C'00000000',146,20,207X)
    OUTFIL FILES=18,
      INCLUDE=(166,2,SS,EQ,C'PJ,PN'),
      OUTREC=(1,2,C'19',C'00000000',C'00000.000000000.0000',C' ',166,2,
              204X)
    OUTFIL FILES=19,
      INCLUDE=(168,5,CH,NE,C'     ',AND,168,1,CH,NE,C' '),
      OUTREC=(1,2,C'20',C'00000000',C'00000.000000000.0000',C' ',168,5,
              201X)
    OUTFIL FILES=20,
      INCLUDE=(173,1,CH,NE,C' '),
      OUTREC=(1,2,C'21',C'00000000',C'00000.000000000.0000',C' ',173,1,
              205X)
    OUTFIL FILES=21,
      INCLUDE=(174,1,CH,EQ,C'S,N'),
      OUTREC=(1,2,C'22',C'00000000',C'00000.000000000.0000',C' ',174,1,
              205X)
    OUTFIL FILES=22,
      INCLUDE=(175,10,CH,GE,C'00000.0000'),
      OUTREC=(1,2,C'23',C'00000000',175,20,207X)
//*COL06-F                                                              00661003
//*COL03-F
//*--------------------------------------------------------------------*00460000
//*          UNIFICACION DE ARCHIVOS                                   *00002000
//*--------------------------------------------------------------------*00460000
//UGRAR400 EXEC PGM=ICEMAN,COND=(4,LT)
//SORTIN   DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR315.DTNRA01,
//             DISP=(SHR)
//         DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR320.DTNRA02,
//             DISP=(SHR)
//         DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR325.DTNRA03,
//             DISP=(SHR)
//         DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR330.DTNRA04,
//             DISP=(SHR)
//         DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR335.DTNRA05,
//             DISP=(SHR)
//         DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR340.DTNRA06,
//             DISP=(SHR)
//         DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR345.DTNRA07,
//             DISP=(SHR)
//         DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR350.DTNRA08,
//             DISP=(SHR)
//         DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR355.DTNRA09,
//             DISP=(SHR)
//         DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR360.DTNRA10,
//             DISP=(SHR)
//         DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR365.DTNRA11,
//             DISP=(SHR)
//         DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR370.DTNRA12,
//             DISP=(SHR)
//         DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR375.DTNRA13,
//             DISP=(SHR)
//         DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR380.DTNRA14,
//             DISP=(SHR)
//         DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR382.DTNRA16,
//             DISP=(SHR)
//         DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR384.DTNRA17,
//             DISP=(SHR)
//         DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR386.DTNRA18,
//             DISP=(SHR)
//         DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR387.DTNRA19,
//             DISP=(SHR)
//         DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR388.DTNRA20,
//             DISP=(SHR)
//         DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR389.DTNRA21,
//             DISP=(SHR)
//         DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR390.DTNRA22,
//             DISP=(SHR)
//         DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR391.DTNRA23,
//             DISP=(SHR)
//SORTOUT  DD  DSN=COBP.UG.FJSD1.UGDTRAR.UGRAR400.UNIRAR,
//             DISP=(NEW,CATLG,DELETE),
//             DCB=(RECFM=FB,BLKSIZE=0,DSORG=PS),
//             SPACE=(CYL,(200,100),RLSE),UNIT=SYSDA
//SYSOUT   DD  SYSOUT=(*,,)
//SYSIN    DD  *
   SORT FIELDS=(1,4,CH,A)
   OUTREC FIELDS=(1,38)
//*
//* COL06 SE AGREGRA EL OUTREC
//*--------------------------------------------------------------------*
//*          ELIMINA DUPLICADOS DE UNIFICACION REGISTROS               *
//*--------------------------------------------------------------------*
//UGRAR410 EXEC  PGM=ICEMAN,COND=(4,LT)
//SYSOUT   DD  SYSOUT=(*,,)
//SYSPRINT DD  SYSOUT=(*,,)
//SORTIN   DD  DSN=COBP.UG.FJSD1.UGDTRAR.UGRAR400.UNIRAR,
//             DISP=(SHR)
//SORTOUT  DD  DSN=COBP.UG.FJSD1.UGDTRAR.UGRAR410.UNIRAR,
//             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,
//             SPACE=(CYL,(300,150,),RLSE),UNIT=SYSDA
//SYSIN    DD  *
  SORT FIELDS=(1,38,CH,A)
  SUM FIELDS=NONE
//*
//*--------------------------------------------------------------------*
//*          DEJA REGISTRO 38 CARACTER PARA CARGUE RANGOS              *
//*--------------------------------------------------------------------*
//*COL06-I
//*UGRAR420 EXEC  PGM=ICEMAN,COND=(4,LT)
//*SYSOUT   DD  SYSOUT=(*,,)
//*SYSPRINT DD  SYSOUT=(*,,)
//*SORTIN   DD  DSN=COBP.UG.FJSD1.UGDTRAR.UGRAR410.UNIRAR,
//*             DISP=(SHR)
//**COL05-I
//**SORTOUT  DD  DSN=COBP.UG.FJSD1.UGDTRAR.UGRAR420.UNIRAR,
//*SORTOUT  DD  DSN=COBP.UG.FJSD1.UGDTRAR.UGRAR421.UNIRAR,
//**COL05-F
//*             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,
//*             SPACE=(CYL,(300,150,),RLSE),UNIT=SYSDA
//*SYSIN    DD  *
//*SORT FIELDS=(1,38,CH,A)
//*OUTREC FIELDS=(1,38)
//*END
//*
//*COL05-I
//**********************************************************************
//* REALIZA CRUCE PARA OBTENER LOS REGISTROS QUE CONTIENEN CLUSTERS    *
//* ACTIVOS                                                            *
//**********************************************************************
//*UGRAR421 EXEC  PGM=ICEMAN,COND=(4,LT),                               00044626
//*         PARM=('SIZE=MAX,HIPRMAX=OPTIMAL,DSPSIZE=MAX')               00044627
//*SYSOUT   DD  SYSOUT=(*,,)                                            00044628
//*SYSPRINT DD  SYSOUT=(*,,)                                            00044629
//*SORTJNF1 DD  DSN=COBP.UG.FJSD1.UGDTRAR.UGRAR421.UNIRAR,              00044630
//*             DISP=(SHR),BUFNO=30                                     00044631
//*SORTJNF2 DD  DSN=COBP.UG.FJSD1.UGDRAR3.UGDTT37.F%%ODATE,             00044632
//*             DISP=(SHR)                                              00044633
//*BOTH     DD  DSN=COBP.UG.FJSD1.UGDTRAR.UGRAR420.UNIRAR,              00044634
//*             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,             00044635
//*             SPACE=(CYL,(300,150,),RLSE),UNIT=SYSDA                  00044636
//*SYSIN    DD  *                                                       00044637
//*SORT FIELDS=COPY
//*JOINKEYS FILES=F1,FIELDS=(1,2,A)                                     00044640
//*JOINKEYS FILES=F2,FIELDS=(1,2,A)                                     00044641
//*JOIN UNPAIRED,F1
//*REFORMAT FIELDS=(F1:1,38,?)                                          00044643
//*OUTFIL FNAMES=BOTH                                                   00044645
//*COL06-F
//*COL05-F
//*--------------------------------------------------------------------*00001900
//*          ACTUALIZA RANGOS EN TABLA UGDTNRA                         *00002000
//*--------------------------------------------------------------------*00002200
//UGRAR430 EXEC  PGM=IKJEFT1A,COND=(4,LT)                               00490002
//EUNIRAR  DD DSN=COBP.UG.FJSD1.UGDTRAR.UGRAR410.UNIRAR,                00500002
//            DISP=SHR                                                  00510000
//SALIDA   DD DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR430.F%%ODATE.SALP,         00540002
//            DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,               00550002
//            SPACE=(CYL,(400,200,),RLSE),UNIT=SYSDA                    00560002
//ERRORES  DD DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR430.F%%ODATE.ERRP,         00570002
//            DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,               00571002
//            SPACE=(CYL,(400,200,),RLSE),UNIT=SYSDA                    00572002
//SUGDTNRA DD DSN=COBP.UG.FWSD1.UGDTNRA.UGRAR430.F%%ODATE.INS,          00570002
//            DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,               00571002
//            SPACE=(CYL,(400,200,),RLSE),UNIT=SYSDA                    00572002
//QRLSDB2  DD  SYSOUT=(*,,)                                             00580000
//SYSOUT   DD  SYSOUT=(*,,)                                             00590000
//SYSPRINT DD  SYSOUT=(*,,)                                             00600000
//SYSTSPRT DD  SYSOUT=(*,,)                                             00610000
//SYSUDUMP DD  DUMMY                                                    00620000
//SYSIN    DD  DUMMY                                                    00630000
//SYSTSIN  DD  *                                                        00640000
    DSN SYSTEM(DB2P)                                                    00650002
    RUN PROGRAM(UG4CRAR1) PLAN(BVPUGPB) PARM('%%FECDIA,0500')           00660002
    END                                                                 00661002
//*                                                                     00661003
//*COL06-I
//* SE CAMBIA EL NOMBRE DEL ARCHIVO DE ENTRADA                          00661003
//* COBP.UG.FJSD1.UGDTRAR.UGRAR420.UNIRAR                               00661003
//* SE AGREGA EL ARCHIVO DE SALIDA SUGDTNRA                             00661003
//*COL05-I
//**********************************************************************
//* REALIZA CRUCE PARA OBTENER LOS REGISTROS QUE CONTIENEN CLUSTERS    *
//* ACTIVOS                                                            *
//**********************************************************************
//*UGRAR431 EXEC  PGM=ICEMAN,COND=(4,LT),                               00044626
//*         PARM=('SIZE=MAX,HIPRMAX=OPTIMAL,DSPSIZE=MAX')               00044627
//*SYSOUT   DD  SYSOUT=(*,,)                                            00044628
//*SYSPRINT DD  SYSOUT=(*,,)                                            00044629
//*SORTJNF1 DD  DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRVS,              00044630
//*             DISP=(SHR),BUFNO=30                                     00044631
//*SORTJNF2 DD  DSN=COBP.UG.FJSD1.UGDRAR3.UGDTT37.F%%ODATE,             00044632
//*             DISP=(SHR)                                              00044633
//*BOTH     DD  DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRV1,              00044634
//*             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,             00044635
//*             SPACE=(CYL,(300,150,),RLSE),UNIT=SYSDA                  00044636
//*SYSIN    DD  *                                                       00044637
//*SORT FIELDS=COPY
//*JOINKEYS FILES=F1,FIELDS=(1,2,A)                                     00044640
//*JOINKEYS FILES=F2,FIELDS=(1,2,A)                                     00044641
//*JOIN UNPAIRED,F1
//*REFORMAT FIELDS=(F1:1,239,?)                                         00044643
//*OUTFIL FNAMES=BOTH                                                   00044645
//*COL06-F
//*COL05-F
//********************************************************************* 00460000
//*  CARGA LA TABLA UGDTNRA NUEVO MODELO RAR - TASAS Y CLUSTER          00470002
//********************************************************************* 00480000
//UGRAR440 EXEC  PGM=IKJEFT1A,COND=(4,LT)                               00490002
//*COL05-I
//*EUGDNRA  DD DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRVS,               00500002
//*COL06-I
//*EUGDNRA  DD DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRV1,               00500002
//*COL05-F
//*            DISP=SHR                                                 00510000
//EUGDNRA  DD DSN=COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRVS,                00500002
//            DISP=SHR                                                  00510000
//EUGDTNRA DD DSN=COBP.UG.FWSD1.UGDTNRA.UGRAR430.F%%ODATE.INS,          00500002
//            DISP=SHR                                                  00510000
//SUGDTNRA DD DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR440.F%%ODATE.INS,          00540002
//            DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,               00550002
//            SPACE=(CYL,(1000,500,),RLSE),UNIT=SYSDA                   00560002
//*COL06-F
//SALIDA   DD DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR440.F%%ODATE.SAL,          00540002
//            DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,               00550002
//            SPACE=(CYL,(400,200,),RLSE),UNIT=SYSDA                    00560002
//ERRORES  DD DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR440.F%%ODATE.ERR,          00570002
//            DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,               00571002
//            SPACE=(CYL,(400,200,),RLSE),UNIT=SYSDA                    00572002
//QRLSDB2  DD  SYSOUT=(*,,)                                             00580000
//SYSOUT   DD  SYSOUT=(*,,)                                             00590000
//SYSPRINT DD  SYSOUT=(*,,)                                             00600000
//SYSTSPRT DD  SYSOUT=(*,,)                                             00610000
//SYSUDUMP DD  DUMMY                                                    00620000
//SYSIN    DD  DUMMY                                                    00630000
//SYSTSIN  DD  *                                                        00640000
    DSN SYSTEM(DB2P)                                                    00650002
    RUN PROGRAM(UG4CRAR2) PLAN(BVPUGPB) PARM('%%FECDIA,03,0500')        00660002
    END                                                                 00661002
//*COL06-I
//*-----------------------------------------------------------------*   00005800
//*  SE ELIMINAN LOS DUPLICADOS DE LOS DATOS A INSERTAR UGDTNRA     *   00005900
//*-----------------------------------------------------------------*   00006000
//UGRAR44A EXEC PGM=SYNCSORT,COND=(4,LT)
//SYSPRINT DD  SYSOUT=(*,,)
//SYSOUT   DD SYSOUT=(*,,)
//SORTIN   DD DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR440.F%%ODATE.INS,
//            DISP=(SHR),BUFNO=30
//SORTOUT  DD DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR44A.F%%ODATE.INS,
//            DISP=(NEW,CATLG,DELETE),
//            DCB=(RECFM=FB,BLKSIZE=0,DSORG=PS),
//            SPACE=(CYL,(1000,500,),RLSE),UNIT=SYSDA
//SORTXSUM DD DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR44A.F%%ODATE.DUP,
//            DISP=(NEW,CATLG,DELETE),
//            DCB=(RECFM=FB,BLKSIZE=0,DSORG=PS),
//            SPACE=(CYL,(500,250,),RLSE),UNIT=SYSDA
//SYSIN    DD *
   SORT FIELDS=(1,4,CH,A,64,23,CH,A)
   SUM FIELDS=NONE,XSUM
//*                                                                     00007200
//*-----------------------------------------------------------------*   00005800
//*  VALIDA SI ARCHIVO DE DUPLICADOS TIENE REGISTROS                *   00005900
//*-----------------------------------------------------------------*   00006000
//UGRAR44B EXEC PGM=ICETOOL,COND=(4,LT)
//TOOLMSG  DD SYSOUT=*
//DFSMSG   DD SYSOUT=*
//IN       DD DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR44A.F%%ODATE.DUP,
//            DISP=SHR
//TOOLIN   DD *
 COUNT FROM(IN) EMPTY RC4
/*
//*                                                                     00007200
// IF (UGRAR44B.RC = 4) THEN
//*____________________________________________________________________*
//* %%SET %%NRATB=UGDTNRA
//* %%SET %%NRALG=0171
//* %%SET %%NRART=UG9C0NRA
//* %%SET %%NRAOP=U1
//* %%SET %%COMMIT=00100
//* %%SET %%NRAVAR=%%NRATB.%%NRALG.%%NRART.%%NRAOP.%%COMMIT
//*____________________________________________________________________*
//*  SE LE DA DE BAJA A LOS REGISTROS ANTIGUOS DE ACUERDO A LA CARGA   *
//*____________________________________________________________________*
//UGRAR44C EXEC PGM=IKJEFT1A,COND=(4,LT)
//QRLSDB2  DD SYSOUT=(*,,)
//SYSOUT   DD SYSOUT=(*,,)
//SYSPRINT DD SYSOUT=(*,,)
//SYSTSPRT DD SYSOUT=(*,,)
//E1DTBKUG DD DSN=COBP.UG.FJSD1.UGDRAR3.UDTNRAB1.F%%ODATE,
//            DISP=(SHR)
//S1DTBKUG DD DSN=COBP.UG.FJSD1.UGDRAR3.UGRAR44C.F%%ODATE.OK,
//            DISP=(NEW,CATLG,DELETE),
//            RECFM=FB,LRECL=1000,BLKSIZE=0,
//            SPACE=(CYL,(1000,500,),RLSE),UNIT=SYSDA
//S2DTBKUG DD DSN=COBP.UG.FJSD1.UGDRAR3.UGRAR44C.F%%ODATE.ER,
//            DISP=(NEW,CATLG,DELETE),
//            RECFM=FB,LRECL=1000,BLKSIZE=0,
//            SPACE=(CYL,(100,50,),RLSE),UNIT=SYSDA
//QGFW0000 DD *
COMBA
//SYSTSIN  DD *
  DSN SYSTEM(DB2P)
  RUN PROGRAM(UG4CBKUG) PLAN(BVPUGPB) PARM('%%NRAVAR')
  END
//*
//*____________________________________________________________________*
//* %%SET %%NRATB=UGDTNRA
//* %%SET %%NRALG=0171
//* %%SET %%NRART=UG9C0NRA
//* %%SET %%NRAOP=I1
//* %%SET %%COMMIT=00100
//* %%SET %%NRAVAR=%%NRATB.%%NRALG.%%NRART.%%NRAOP.%%COMMIT
//*____________________________________________________________________*
//*           SE INSERTAN LOS REGISTROS DE VARIABLES EN LA UGDTNRA     *
//*____________________________________________________________________*
//UGRAR44D EXEC PGM=IKJEFT1A,COND=(4,LT)
//QRLSDB2  DD SYSOUT=(*,,)
//SYSOUT   DD SYSOUT=(*,,)
//SYSPRINT DD SYSOUT=(*,,)
//SYSTSPRT DD SYSOUT=(*,,)
//E1DTBKUG DD DSN=COBP.UG.FWSD1.UGDTNRA.UGRAR430.F%%ODATE.INS,
//            DISP=(SHR)
//S1DTBKUG DD DSN=COBP.UG.FJSD1.UGDRAR3.UGRAR44D.F%%ODATE.OK,
//            DISP=(NEW,CATLG,DELETE),
//            RECFM=FB,LRECL=1000,BLKSIZE=0,
//            SPACE=(CYL,(1000,500,),RLSE),UNIT=SYSDA
//S2DTBKUG DD DSN=COBP.UG.FJSD1.UGDRAR3.UGRAR44D.F%%ODATE.ER,
//            DISP=(NEW,CATLG,DELETE),
//            RECFM=FB,LRECL=1000,BLKSIZE=0,
//            SPACE=(CYL,(100,50,),RLSE),UNIT=SYSDA
//QGFW0000 DD *
COMBA
//SYSTSIN  DD *
  DSN SYSTEM(DB2P)
  RUN PROGRAM(UG4CBKUG) PLAN(BVPUGPB) PARM('%%NRAVAR')
  END
//*
//*____________________________________________________________________*
//* %%SET %%NRATB=UGDTNRA
//* %%SET %%NRALG=0171
//* %%SET %%NRART=UG9C0NRA
//* %%SET %%NRAOP=I1
//* %%SET %%COMMIT=00100
//* %%SET %%NRAVAR=%%NRATB.%%NRALG.%%NRART.%%NRAOP.%%COMMIT
//*____________________________________________________________________*
//*           SE INSERTAN LOS REGISTROS DE CLUSTER EN LA UGDTNRA       *
//*____________________________________________________________________*
//UGRAR44E EXEC PGM=IKJEFT1A,COND=(4,LT)
//QRLSDB2  DD SYSOUT=(*,,)
//SYSOUT   DD SYSOUT=(*,,)
//SYSPRINT DD SYSOUT=(*,,)
//SYSTSPRT DD SYSOUT=(*,,)
//E1DTBKUG DD DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR44A.F%%ODATE.INS,
//            DISP=(SHR)
//S1DTBKUG DD DSN=COBP.UG.FJSD1.UGDRAR3.UGRAR44E.F%%ODATE.OK,
//            DISP=(NEW,CATLG,DELETE),
//            RECFM=FB,LRECL=1000,BLKSIZE=0,
//            SPACE=(CYL,(1000,500,),RLSE),UNIT=SYSDA
//S2DTBKUG DD DSN=COBP.UG.FJSD1.UGDRAR3.UGRAR44E.F%%ODATE.ER,
//            DISP=(NEW,CATLG,DELETE),
//            RECFM=FB,LRECL=1000,BLKSIZE=0,
//            SPACE=(CYL,(100,50,),RLSE),UNIT=SYSDA
//QGFW0000 DD *
COMBA
//SYSTSIN  DD *
  DSN SYSTEM(DB2P)
  RUN PROGRAM(UG4CBKUG) PLAN(BVPUGPB) PARM('%%NRAVAR')
  END
//*
// ENDIF
//*
//*COL04-I
//*--------------------------------------------------------------------*
//*CARGA TABLA  UGDTNRA EN CASO DE ERROR EN PASO                       *
//*--------------------------------------------------------------------*
//* IF (UGRAR440.RC > 0) THEN
//*UGRAR455 EXEC CBMCLOAD,COND=(4,LT),
//*         UID=PUGDRAR3UGRAR480,
//*         CREATOR=PADB2,
//*         NOMTAB=UGDTNRA,
//*         OPTION=REPLACE,
//*         NPART=' ',
//*         INPPUN=DSN=COBP.ALTAMIRA.CONTROL($$SPNULL),
//*         INPREC=DSN=COBP.UG.FJSD1.UGDRAR3.UGDTNRA.F%%ODATE
//* ENDIF
//*COL06-F
//*COL04-F
//*------------------------------------------------------------------   00005800
//*  BORRADO DE 2 LINEAS DE TITULO ANTES UNIFICACION ARCHIVOS           00005900
//*------------------------------------------------------------------   00006000
//*COL04-I                                                              00006000
//*UGRAR450 EXEC PGM=ICEMAN,COND=(0,LT)
//UGRAR450 EXEC PGM=ICEMAN,COND=(4,LT)
//*COL04-F                                                              00006000
//SYSPRINT DD  SYSOUT=(*,,)
//SYSOUT   DD SYSOUT=(*,,)
//SORTIN   DD DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR440.F%%ODATE.SAL,
//            DISP=(SHR),BUFNO=30
//SORTOUT  DD DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR450.F%%ODATE.SAL,
//            DISP=(NEW,CATLG,DELETE),
//            DCB=(RECFM=FB,BLKSIZE=0,DSORG=PS),
//            SPACE=(CYL,(1000,500,),RLSE),UNIT=SYSDA
//SYSIN    DD *
   OPTION SKIPREC=2
   SORT FIELDS=COPY
//*                                                                     00007200
//*--------------------------------------------------------------------*00460000
//*          UNIFICACION DE ARCHIVOS                                   *00002000
//*--------------------------------------------------------------------*00460000
//UGRAR460 EXEC PGM=ICEMAN,COND=(4,LT)
//*COL04-I
//*SORTIN   DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR310.F%%ODATE.SAL,
//*             DISP=(SHR)
//*         DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR450.F%%ODATE.SAL,
//SORTIN   DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR440.F%%ODATE.SAL,
//*COL04-F
//             DISP=(SHR)
//SORTOUT  DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR460.F%%ODATE.SAL,
//             DISP=(NEW,CATLG,DELETE),
//             DCB=(RECFM=FB,BLKSIZE=0,DSORG=PS),
//             SPACE=(CYL,(200,100),RLSE),UNIT=SYSDA
//SYSOUT   DD  SYSOUT=(*,,)
//SYSIN    DD  *
   SORT FIELDS=COPY
//*                                                                     00661003
//*--------------------------------------------------------------------*
//*   M      DEJA REGISTRO 218 CARACTERES ARCHIVO SALIDA               *
//*--------------------------------------------------------------------*
//UGRAR470 EXEC  PGM=ICEMAN,COND=(4,LT)
//SYSOUT   DD  SYSOUT=(*,,)
//SYSPRINT DD  SYSOUT=(*,,)
//SORTIN   DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR460.F%%ODATE.SAL,
//             DISP=(SHR)
//SORTOUT  DD  DSN=COBP.UG.FWSD1.UGDTRAR.UGRAR470.F%%ODATE.SAL,
//             DISP=(NEW,CATLG,DELETE),RECFM=FB,BLKSIZE=0,
//             SPACE=(CYL,(300,150,),RLSE),UNIT=SYSDA
//SYSIN    DD  *
  SORT FIELDS=COPY
  OUTREC FIELDS=(1,332)
  END
//*
//*COL05-I
//**********************************************************************00180100
//*  BORRADO ARCHIVOS EN EL PROCESO                                    *00210000
//**********************************************************************00220000
//UGRAR480 EXEC PGM=IDCAMS,COND=(4,LT)                                  00230001
//SYSPRINT DD  SYSOUT=(*,,)                                             00240000
//SYSIN    DD  *                                                        00250000
  DELETE COBP.UG.FJSD1.UGDRAR3.UDTNRAB1.F%%ODATE
  DELETE COBP.UG.FJSD1.UGDRAR3.UGDTT37.F%%ODATE
  DELETE COBP.UG.FJSD1.UGDTRAR.UGRAR421.UNIRAR
  DELETE COBP.UG.FJSD1.UGDTRAR.F%%ODATE.MODRV1
  SET MAXCC=0                                                           00270000
//*                                                                     00280000
//*COL05-F