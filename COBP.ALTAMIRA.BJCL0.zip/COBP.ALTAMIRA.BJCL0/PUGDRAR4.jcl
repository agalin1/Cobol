//PUGDRAR4 JOB CLASS=B,
//             MSGLEVEL=(1,1),
//             MSGCLASS=R,
//             REGION=0M
//JOBLIB  DD   DSN=COBP.ALTAMIRA.LOADLIB.BATCH,DISP=SHR
//********************************************************************
//**********************************************************************
//* APLICA   : PRESTAMOS                                               *
//* PROCESO  : PUGDRAR4.                                               *
//* OBJETIVO : ENVIO DE ARCHIVO DE INFORMES CARGUE NUEVO MODELO RAR    *
//*            ARCHIVO SALIDA / ERRPRES                                *
//* REALIZO  : INETUM SAS                                              *
//* FECHA    : JUNIO - 2021.                                           *
//* PROYECTO : GP17916-HUQA-CCSS-6856                                  *00180000
//**********************************************************************
//*                 LOG DE MODIFICACIONES                              *
//**********************************************************************
//* CONSEC  FECHA MODIF              DESCRIPCION:                      *
//*--------------------------------------------------------------------*
//* COL01   19-10-2021    SE REALIZAN AJUSTES PARA CORREGIR NOMBRE ARCH*
//* INVICTUS              PASO UGRAR420                                *
//*                       COBP.UG.FWSD1.UGDTRAR.UGRAR530.F%%ODATE.SALP *
//* CE56375               RSD INC000007679018                          *
//*--------------------------------------------------------------------*
//**********************************************************************
//UGRAR410 EXEC PGM=DMBATCH,PARM=(YYSLYNNY),COND=(4,LT)
//*
//STEPLIB  DD DISP=SHR,DSN=SYS3.CONNECT.TGT.LINKLIB
//DMNETMAP DD DISP=SHR,DSN=SYS3.CONNECT.DAT.NETMAP
//DMPUBLIB DD DISP=SHR,DSN=COBP.ALTAMIRA.PROCESS
//DMMSGFIL DD DISP=SHR,DSN=SYS3.CONNECT.DAT.MSG
//DMPRINT  DD SYSOUT=*
//SYSDUMP  DD SYSOUT=*
//SYSPRINT DD SYSOUT=*
//SYSIN    DD *
  SIGNON CASE(YES) ESF=NO
  SUBMIT PROC=CSMHDDX1  -
  &HOST=COLP.CDCOLP -
  &DIST=D-CLUSTER        -
  &DSNI='COBP.UG.FWSD1.UGDTRAR.UGRAR470.F%%ODATE.SAL' -
  &DSNO=\'F:\\\ || -
  \TX\\ENVIO_HOST\\INTELIGENCIA_COMERCIAL\\\        || -
  \Advanced_Analytics\\COE_AACS\\recibidos\\\       || -
  \CARGUE_TASAS_PREF_SALIDA.F%%ODATE.TXT'\  -
  &SYSOPTS='xlate.tbl(RWCBPT14.CDX) codepage(20284,65001)'
  SIGNOFF
//**********************************************************************
//UGRAR420 EXEC PGM=DMBATCH,PARM=(YYSLYNNY),COND=(4,LT)
//*
//STEPLIB  DD DISP=SHR,DSN=SYS3.CONNECT.TGT.LINKLIB
//DMNETMAP DD DISP=SHR,DSN=SYS3.CONNECT.DAT.NETMAP
//DMPUBLIB DD DISP=SHR,DSN=COBP.ALTAMIRA.PROCESS
//DMMSGFIL DD DISP=SHR,DSN=SYS3.CONNECT.DAT.MSG
//DMPRINT  DD SYSOUT=*
//SYSDUMP  DD SYSOUT=*
//SYSPRINT DD SYSOUT=*
//SYSIN    DD *
  SIGNON CASE(YES) ESF=NO
  SUBMIT PROC=CSMHDDX1  -
  &HOST=COLP.CDCOLP -
  &DIST=D-CLUSTER        -
  &DSNI='COBP.UG.FWSD1.UGDTRAR.UGRAR430.F%%ODATE.SALP' -
  &DSNO=\'F:\\\ || -
  \TX\\ENVIO_HOST\\INTELIGENCIA_COMERCIAL\\\        || -
  \Advanced_Analytics\\COE_AACS\\recibidos\\\       || -
  \CARGUE_TASAS_PREF_SALP.F%%ODATE.TXT'\  -
  &SYSOPTS='xlate.tbl(RWCBPT14.CDX) codepage(20284,65001)'
  SIGNOFF
//UGRAR430 EXEC PGM=DMBATCH,PARM=(YYSLYNNY),COND=(4,LT)
//*
//STEPLIB  DD DISP=SHR,DSN=SYS3.CONNECT.TGT.LINKLIB
//DMNETMAP DD DISP=SHR,DSN=SYS3.CONNECT.DAT.NETMAP
//DMPUBLIB DD DISP=SHR,DSN=COBP.ALTAMIRA.PROCESS
//DMMSGFIL DD DISP=SHR,DSN=SYS3.CONNECT.DAT.MSG
//DMPRINT  DD SYSOUT=*
//SYSDUMP  DD SYSOUT=*
//SYSPRINT DD SYSOUT=*
//SYSIN    DD *
  SIGNON CASE(YES) ESF=NO
  SUBMIT PROC=CSMHDDX1  -
  &HOST=COLP.CDCOLP -
  &DIST=D-CLUSTER        -
  &DSNI='COBP.UG.FWSD1.UGDTRAR.UGRAR440.F%%ODATE.ERR' -
  &DSNO=\'F:\\\ || -
  \TX\\ENVIO_HOST\\INTELIGENCIA_COMERCIAL\\\        || -
  \Advanced_Analytics\\COE_AACS\\recibidos\\\       || -
  \CARGUE_TASAS_PREF_ERROR.F%%ODATE.TXT'\  -
  &SYSOPTS='xlate.tbl(RWCBPT14.CDX) codepage(20284,65001)'
//UGRAR440 EXEC PGM=DMBATCH,PARM=(YYSLYNNY),COND=(4,LT)
//*
//STEPLIB  DD DISP=SHR,DSN=SYS3.CONNECT.TGT.LINKLIB
//DMNETMAP DD DISP=SHR,DSN=SYS3.CONNECT.DAT.NETMAP
//DMPUBLIB DD DISP=SHR,DSN=COBP.ALTAMIRA.PROCESS
//DMMSGFIL DD DISP=SHR,DSN=SYS3.CONNECT.DAT.MSG
//DMPRINT  DD SYSOUT=*
//SYSDUMP  DD SYSOUT=*
//SYSPRINT DD SYSOUT=*
//SYSIN    DD *
  SIGNON CASE(YES) ESF=NO
  SUBMIT PROC=CSMHDDX1  -
  &HOST=COLP.CDCOLP -
  &DIST=D-CLUSTER        -
  &DSNI='COBP.UG.FWSD1.UGDTRAR.UGRAR430.F%%ODATE.ERRP' -
  &DSNO=\'F:\\\ || -
  \TX\\ENVIO_HOST\\INTELIGENCIA_COMERCIAL\\\        || -
  \Advanced_Analytics\\COE_AACS\\recibidos\\\       || -
  \CARGUE_TASAS_PREF_ERRP.F%%ODATE.TXT'\  -
  &SYSOPTS='xlate.tbl(RWCBPT14.CDX) codepage(20284,65001)'
//