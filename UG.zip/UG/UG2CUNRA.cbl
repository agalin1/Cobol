      * -------------------------------------------------------------- *
      *                    DESCRIPCION PROGRAMA                        *
      * -------------------------------------------------------------- *
      * APLICATIVO INVICTUS RETAIL GP17916-HUQA-CCSS-7934 EN DONDE SE  *
      * PUEDE REVISAR EN DETALLE EL ESTADO DE UN CLUSTER Y SE VISUALIZA*
      * LA TASA RAR APLICABLE                                          *
      * -------------------------------------------------------------- *
      *                    DESCRIPCION FUNCIONAL                       *
      * -------------------------------------------------------------- *
      * -------------------------------------------------------------- *
      *                    LOG DE MODIFICACIONES                       *
      * -------------------------------------------------------------- *
      * AUTOR/MARCA FECHA                 DESCRIPCION                  *
      * -------------------------------------------------------------- *
      * COL01  05-11-2021  SE REALIZAN AJUSTES EN CONSULTA DE CLUSTER  *
      * INETUM CE56375     PARA TENER ENCUENTA ESTADO                  *
      *                    RSD INC000007720682 PROCESO PUGDRAR1        *
      * -------------------------------------------------------------- *00001800
      * COL02  01-01-2022  SE REALIZAN MODIFICACION PARA INLUIR EL     *
      * INETUM CE43229     CLUSTER 17 CARACTERES PARA LIBRANZA         *
      *        CE59519     VARIABLES COLECTIVO Y DESTINO               *
      * SCRUM - SDA36560 - COLWSPREST-54 - COLWSPREST-383 OTORGAR TASAS*
      * PERSONALIZADAS LIBRANZAS *
      * -------------------------------------------------------------- *00002100
      * COL03  04-04-2022  SE REALIZAN MODIFICACION PARA INLUIR LOS TI-*00002310
      * C810846            POS DE OPERACION HS(HIPOTECARIO SOSTENIBLE) *00002320
      *                    Y HV(HIPOTECARIO VIS) PARA EL TEMA DE       *00002330
      *                    PRICING HIPOTECARIO. CCSS-13169.            *00002340
      * -------------------------------------------------------------- *00002351
      * COL04  03-06-2022  SE REALIZA AJUSTE PARA MOVER/ACOMODAR MAPA  *00002352
      * C810908            PARA MOSTRAR EN LA CONSULTA LAS NUEVAS      *00002353
      * DCP                VARIABLES DE CARTERA COMERCIAL.             *00002354
      *                    SE INCLUYE CARTERA COMERCIAL EN LA CONSULTA.*00002355
      *                     -RANGO PARA VENTAS                         *
      *                     -TIPO PERSONA                              *
      *                     -CALIFICACION DEL RIESGO - RATING          *
      *                     -RANGO CALIFICACION RATING                 *
      *                     -IND GARANTIA                              *
      *                     -RANGO MONTO OPERACION                     *
      * IN-137923          SDA35771 COLWSCANAL-1036                    *00002356
      * -------------------------------------------------------------- *00002360
      * COL06  13-06-2023  SE REALIZA AJUSTE PARA CAMBIAR LA VISUALIZA-*
      * C810846            CION DE LOS DATOS.                          *
      * GLADIADORES TEAM   COLWSPREST-15688.                           *
      * -------------------------------------------------------------- *00002360
      * REFERENCIA : COL07                                             *
      * REALIZO    : EDINSON CALENO - T016395 - ACCENTURE LTDA         *
      * FECHA      : 15/07/2024                                        *
      * SDA-FEATURE: SDA-41748 / COLONECAPN-38                         *
      * DESCRIPCION: CUOTA FIJA - TASA VARIABLE PARA CREDITOS DE       *
      *              CONSUMO Y VEHICULO                                *
      * METODOLOGIA  SE REALIZA AJUSTE PARA INCLUIR PARAMETRIA         *
      * TRADICIONAL: MEDIANTE T37 PARA VALIDACION DE CLUSTERS ACTIVOS  *
      * -------------------------------------------------------------- *00002360
      * REFERENCIA : COL08                                             *
      * REALIZO    : RUBEN DAVID GUTIERREZ                             *
      * FECHA      : 04/03/2026                                        *
      * SDA/FEATURE: SDA-56033 / COLONEPRE1-17074                      *
      * DESCRIPCION: SE AJUSTA EL PROGRAMA PARA ASEGURAR LA CORRECTA   *
      *              CONSULTA DE LOS CLUSTERS DE VIVIENDA DE TASA RAR, *
      *              MOSTRANDO UNICAMENTE LAS VARIABLES CORRESPONDIEN- *
      *              TES A ESTAS LINEAS DE CREDITO Y EN CASO CONTRARIO *
      *              MANTENER LAS VARIABLES DE LAS DEMAS LINEAS.       *
      * -------------------------------------------------------------- *
      ******************************************************************00001000
      *                                                                *
      *                                                                *
      * -------------------------------------------------------------- *
       IDENTIFICATION DIVISION.
      * -------------------------------------------------------------- *
       PROGRAM-ID.    UG2CUNRA.
       AUTHOR.        JORGE BUITRAGO HERNANDEZ (INETUM).
       DATE-WRITTEN.  2021/08/23.
       DATE-COMPILED. 2021/08/23.
      * -------------------------------------------------------------- *
       ENVIRONMENT DIVISION.
      * -------------------------------------------------------------- *
       CONFIGURATION SECTION.
           EJECT
      * -------------------------------------------------------------- *
       DATA DIVISION.
      * -------------------------------------------------------------- *
       WORKING-STORAGE SECTION.
           EXEC SQL INCLUDE SQLCA   END-EXEC.
           EXEC SQL INCLUDE UGTCNRA END-EXEC.
           EXEC SQL INCLUDE UGGTNRA END-EXEC.
      *COL02-I
           EXEC SQL INCLUDE UGGTT37 END-EXEC.
           EXEC SQL INCLUDE UGTCT37 END-EXEC.
      *COL02-F
           EJECT
      *COL02-I
      *----------------------------------------------------------------*00039700
      * DECLARAR CURSOR DE LA TABLA UGDTT37                            *00039800
      *----------------------------------------------------------------*00039900
           EXEC SQL                                                     00040000
              DECLARE  CURSOR-T37 CURSOR FOR                            00040100
               SELECT  SECCION,
                       ELEMENTO,
                       RESTO
               FROM  UGDTT37
               WHERE SECCION = '9965'
                  OR SECCION = '9966'
               ORDER BY SECCION, ELEMENTO
           END-EXEC.
      *COL02-F
      * ----- COPY DE ATRIBUTOS -------------------------------------- *
          COPY DFHBMSCA.
          COPY BRECOF1.
      * ----- COPY PARA EL PROGRAMA DE ABEND ------------------------- *
       01 QGECABC-01.
          COPY QGECABC.
       01 TCWC0200-01.
          COPY TCWC0200.
      * -------------------------------------------------------------- *
       01 PEWC5200-01.
          COPY PEWC5200.
      * -------------------------------------------------------------- *
       01 TCWC0750-AREA.
          COPY TCWC0750.
      * -------------------------------------------------------------- *
          COPY TCWC1750.
      * ----- CAMPOS CONSTANTES -------------------------------------- *
          COPY UFRWCTE.
      *---------------------------------------------------------------* 00179000
      *       COPYS  PARA LAS RUTINAS DE CONTABILIZACION              * 00179100
      *---------------------------------------------------------------* 00179200
      *---------------------------------------------------------------* 00179300
      *               COPY DE CONSTANTES PARA EL MODULO QH            * 00179400
      *---------------------------------------------------------------* 00179500
       COPY QHWCCTE.                                                    00179600
       01 AREA-UR2CVSB.                                                 00179800
          05 AREA-URWCVSB        PIC X(80).                             00179900
          05 AREA-URWCMOD        PIC X(120).                            00180000
      *---------------------------------------------------------------* 00180200
      *               COPY DE COMUNICACIONES CON QH6CCOH0             * 00180300
      *---------------------------------------------------------------* 00180400
       01  QHECCOH-01.                                                  00180500
           COPY QHECCOH.                                                00180600
      *---------------------------------------------------------------* 00180800
      *               COPY DE COMUNICACIONES CON QH6CAPU0             * 00180900
      *---------------------------------------------------------------* 00181000
       01  QHECAPU-01.                                                  00181100
           COPY QHECAPU.                                                00181200
      *---------------------------------------------------------------* 00181400
      *               COPY DE COMUNICACIONES CON QH6CCIP0             * 00181500
      *---------------------------------------------------------------* 00181600
       01  QHECCIP-01.                                                  00181700
           COPY QHECCIP.                                                00181800
      *---------------------------------------------------------------* 00182000
      *               COPY DE COMUNICACIONES CON QH6CCRE0             * 00182100
      *---------------------------------------------------------------* 00182200
       01  QHECCRE-01.                                                  00182300
           COPY QHECCRE.                                                00182400
      *---------------------------------------------------------------* 00182600
      *               COPY DE COMUNICACIONES CON QH6CDEL0             * 00182700
      *---------------------------------------------------------------* 00182800
       01  QHECDEL-01.                                                  00182900
           COPY QHECDEL.                                                00183000
      *---------------------------------------------------------------* 00183200
      *               COPY DE COMUNICACIONES CON QH6CAPE0             * 00183300
      *---------------------------------------------------------------* 00183400
       01  QHECAPE-01.                                                  00183500
           COPY QHECAPE.                                                00183600
      *---------------------------------------------------------------* 00183800
      *               COPY DE COMUNICACIONES CON QH6CCPT0             * 00183900
      *---------------------------------------------------------------* 00184000
       01  QHECCPT-01.                                                  00184100
           COPY QHECCPT.                                                00184200
      *---------------------------------------------------------------* 00184400
      *               COPY DE ATRIBUTOS CONTABLES                     * 00184500
      *---------------------------------------------------------------* 00184600
       COPY UGWCUTR.                                                    00184900
      *COL08-I
      *----------------------------------------------------------------*
      *           COPY DE COMUNICACION CON LA RUTINA UR2CIT37          *
      *----------------------------------------------------------------*
       01 UGWCIT37-REG-1.
          COPY URWCIT37.
      *COL08-F
       01 CONSTANTES.
          05 CTE-1              PIC 9(01) VALUE 1.
          05 CTE-2              PIC 9(01) VALUE 2.
          05 CTE-3              PIC 9(01) VALUE 3.
          05 CTE-4              PIC 9(01) VALUE 4.
          05 CTE-5              PIC 9(01) VALUE 5.
          05 CTE-6              PIC 9(01) VALUE 6.
          05 CTE-7              PIC 9(01) VALUE 7.
          05 CTE-8              PIC 9(01) VALUE 8.
          05 CTE-9              PIC 9(01) VALUE 9.
          05 CTE-16             PIC 9(02) VALUE 16.
          05 CTE-21             PIC 9(02) VALUE 21.
          05 CTE-0              PIC X(01) VALUE '0'.
          05 CTE-00             PIC X(02) VALUE '00'.
          05 CTE-01             PIC X(02) VALUE '01'.
          05 CTE-02             PIC X(02) VALUE '02'.
          05 CTE-03             PIC X(02) VALUE '03'.
          05 CTE-04             PIC X(02) VALUE '04'.
          05 CTE-05             PIC X(02) VALUE '05'.
          05 CTE-06             PIC X(02) VALUE '06'.
          05 CTE-07             PIC X(02) VALUE '07'.
          05 CTE-08             PIC X(02) VALUE '08'.
          05 CTE-09             PIC X(02) VALUE '09'.
          05 CTE-10             PIC X(02) VALUE '10'.
      *COL01-I
          05 CTE-90             PIC X(02) VALUE '90'.
      *COL01-I
          05 CTE-A              PIC X(01) VALUE 'A'.
          05 CTE-C              PIC X(01) VALUE 'C'.
          05 CTE-F              PIC X(01) VALUE 'F'.
          05 CTE-O              PIC X(01) VALUE 'O'.
          05 CTE-R              PIC X(01) VALUE 'R'.
          05 CTE-P              PIC X(01) VALUE 'P'.
          05 CTE-S              PIC X(01) VALUE 'S'.
          05 CTE-T              PIC X(01) VALUE 'T'.
          05 CTE-ESTADO         PIC X(01) VALUE 'O'.
          05 CTE-ESTANU         PIC X(01) VALUE 'T'.
          05 CTE-ENV            PIC X(03) VALUE 'ENV'.
          05 CTE-UNRA           PIC X(04) VALUE 'UNRA'.
          05 CTE-UNRC           PIC X(04) VALUE 'UNRC'.
          05 CTE-0026           PIC X(04) VALUE '0026'.
          05 CTE-0543           PIC X(04) VALUE '0543'.
          05 CTE-UGE0939        PIC X(07) VALUE 'UGE0939'.
          05 CTE-UGA0939        PIC X(07) VALUE 'UGA0939'.
          05 CTE-UGDTT37        PIC X(07) VALUE 'UGDTT37'.
          05 CTE-UGA0001        PIC X(07) VALUE 'UGA0001'.
          05 CTE-UGA0003        PIC X(07) VALUE 'UGA0003'.
          05 CTE-CNE9997        PIC X(07) VALUE 'CNE9997'.
          05 CTE-BGE0900        PIC X(07) VALUE 'BGE0900'.
          05 CTE-UG2CUNRA       PIC X(08) VALUE 'UG2CUNRA'.
          05 CTE-PE9C5200       PIC X(08) VALUE 'PE9C5200'.
          05 CTE-TC8C1220       PIC X(08) VALUE 'TC8C1220'.
          05 CTE-VALNUMER       PIC X(10) VALUE '0123456789'.
          05 CTE-FECINICIAL     PIC X(10) VALUE '0001-01-01'.
          05 CTE-PENDIENTE      PIC X(11) VALUE 'PEND.REQUIS'.
          05 CTE-FORMALIZADO    PIC X(11) VALUE 'FORMALIZADO'.
          05 CTE-DIAS_BLOQUEO   PIC X(12) VALUE 'DIAS_BLOQUEO'.
          05 CTE-NA             PIC X(13) VALUE 'NO APLICA    '.
      *COL08-I
          05 CTE-ALF-D          PIC X(01) VALUE 'D'.
          05 CTE-ALF-9639       PIC X(04) VALUE '9639'.
          05 CTE-UR2CIT37       PIC X(08) VALUE 'UR2CIT37'.
      *COL08-F
      * ----- CAMPOS MMRIABLES Y AUXILIARES -------------------------- *
       01 VARIABLES.
           05 WS-LETRA          PIC X(01).
           05 WS-STRING         PIC X(20).
           05 WS-ESTADO         PIC X(11).
           05 WS-CONTADOR-1     PIC 9(02).
           05 WS-CONTADOR-2     PIC 9(02).
           05 WS-CONTADOR-3     PIC 9(02).
           05 WS-CONTADOR-4     PIC 9(02).
      *COL04-I
      *    05 WS-EDITABLE       PIC Z,Z99.99.
           05 WS-EDITABLE       PIC 99.99.
           05 WS-CONCATENA      PIC X(17).
           05 WS-PE             PIC 99.99.
           05 WS-RORC           PIC 99.99.
           05 WS-CAPI           PIC 99.99.
      *COL04-F
           05 WS-IMPCONCE       PIC S9(13) COMP-3.
           05 WS-NRA-CLAVE-ID   PIC X(01).
           05 WS-NRA-VARIABLE   PIC X(02).
      *COL01-I
           05 WS-NRA-ESTADO     PIC X(02).
      *COL01-F
      *COL02-I
           05 WS-VAL-LIBRAN     PIC 9(04).
      *COL02-F
      *COL08-I
           05 WS-SEG-AUX        PIC 9(01).
      *COL08-F
           05 WS-PERFORM        PIC X(20).
           05 VARIABLES-VARIAS.
              10 WS-FECHA-ACTUAL PIC X(10).
           05 WS-DETICLUSTE.
              10 WS-BURO         PIC X(01).
              10 WS-DOM-DOMINA   PIC X(01).
              10 WS-SIT-LABORAL  PIC X(01).
              10 WS-INGRESOS     PIC X(01).
              10 WS-MONT-FINAN   PIC X(01).
              10 WS-PLAZO-OPER   PIC X(01).
              10 WS-EDAD         PIC X(01).
              10 WS-SEGMENTO     PIC X(01).
              10 WS-COLECTIVO    PIC X(01).
              10 WS-GRUP-RIESG   PIC X(01).
              10 WS-EST-VEHIC    PIC X(01).
              10 WS-PORC-FINAN   PIC X(01).
              10 WS-GAMA-VEHIC   PIC X(01).
              10 WS-TIPO-USO     PIC X(01).
              10 WS-CLIENT-VIP   PIC X(01).
      *COL02-I
              10 WS-CLTVLB       PIC X(01).
              10 WS-DESTLB       PIC X(01).
      *COL02-F
      *COL04-I
              10 WS-VENTASC      PIC X(01).
              10 WS-TIPPERS      PIC X(01).
              10 WS-CRATING      PIC X(01).
              10 WS-RRATING      PIC X(01).
              10 WS-GARANTC      PIC X(01).
              10 WS-MOPERAC      PIC X(01).
      *COL04-F
           05 WS-BURO-ED.
              10 WS-BURO-INI     PIC 9(04).
              10 FILLER          PIC X(03) VALUE ' A '.
              10 WS-BURO-FIN     PIC 9(04).
              10 FILLER          PIC X(02) VALUE ' '.
           05 WS-INGRESO-ED.
              10 WS-INGR-INI     PIC 9.99.
              10 FILLER          PIC X(03) VALUE ' A '.
              10 WS-INGR-FIN     PIC ZZ9.99.
           05 WS-RIESGOS-ED.
              10 WS-RIES-INI     PIC 9.999.
              10 FILLER          PIC X(03) VALUE ' A '.
              10 WS-RIES-FIN     PIC 9.999.
           05 WS-MONTFIN-ED.
      * COL02-I
      *       10 WS-MONT-INI     PIC 9.99.
              10 WS-MONT-INI     PIC 999.9.
              10 FILLER          PIC X(03) VALUE ' A '.
      *       10 WS-MONT-FIN     PIC ZZ9.99.
              10 WS-MONT-FIN     PIC 999.9.
      * COL02-F
      *COL04-I
           05 WS-VENTAS-ED.
              10 WS-VENT-INI     PIC 99999.9.
              10 FILLER          PIC X(01) VALUE '-'.
              10 WS-VENT-FIN     PIC 99999.9.

           05 WS-MONOPE-ED.
              10 WS-OPER-INI     PIC 99999.9.
              10 FILLER          PIC X(01) VALUE '-'.
              10 WS-OPER-FIN     PIC 99999.9.
      *COL04-F
           05 WS-FECHA-DB2.
              10 WS-FSIGANO-DB2.
                 20 WS-FSIG-DB2 PIC 9(02).
                 20 WS-FANO-DB2 PIC 9(02).
               10 FILLER        PIC X(01) VALUE '-'.
               10 WS-FMES-DB2   PIC 9(02).
               10 FILLER        PIC X(01) VALUE '-'.
               10 WS-FDIA-DB2   PIC 9(02).
           05 WS-TIME.
               10 WS-HORA       PIC 9(02).
               10 WS-MINUTOS    PIC 9(02).
               10 WS-SEGUNDOS   PIC 9(02).
      *COL05-I
           05 WS-COD-OPER       PIC X(03).
           05 W-VALOR-GARANTIA  PIC 9(13)V99.
           05 CTE-ESTCLUST-ANT  PIC X(02) VALUE SPACES.
           05 WS-INC-PORCE      PIC 9(01).
           05 WS-VALOR          PIC S9(13)V99 COMP-3.
           05 WS-VALOR-CUP      PIC S9(13)V99 COMP-3.
           05 WS-CUP-UTI        PIC S9(13)V99 COMP-3 VALUE 0.
           05 WS-CUP-UTI-V      PIC S9(13)V99 COMP-3 VALUE 0.
           05 W-TS.
              10 W-DC           PIC X(4) VALUE SPACES.
              10 W-SUFIJO-TS    PIC X(4) VALUE SPACES.
           05 WS-REFERENCIA     PIC X(20).
      *COL05-F
      * ----- MENSAJES DE INFORMATIVOS ------------------------------- *
        01 WS-MENSAJE.
           05 WS-MENSAJE-1      PIC X(20) VALUE 'OFERTA COMERCIAL    '.
           05 WS-MENSAJE-2      PIC X(20) VALUE 'ACTUALIZADA CORRECTO'.
           05 WS-MENSAJE-3      PIC X(20) VALUE 'ERROR AL ACTUALIZAR '.
           05 WS-MENSAJE-4      PIC X(20) VALUE 'NO PROCESABLE       '.
           05 WS-MENSAJE-5      PIC X(20) VALUE 'OPCION NO DISPONIBLE'.
           05 WS-MENSAJE-6      PIC X(20) VALUE 'PARA LA TRANSACCION '.
           05 WS-MENSAJE-7      PIC X(20) VALUE 'ESTE CAMPO ES OBLIGA'.
           05 WS-MENSAJE-8      PIC X(20) VALUE 'TORIA PARA PROCESAR.'.
           05 WS-MENSAJE-9      PIC X(20) VALUE 'NO PROCESABLE ESTADO'.
           05 WS-MENSAJE-10     PIC X(20) VALUE 'NO VIABLE ESTADO    '.
           05 WS-MENSAJE-11     PIC X(20) VALUE 'NO SE PUEDE PROCESAR'.
           05 WS-MENSAJE-12     PIC X(20) VALUE 'CALCULO FECH BLOQUEO'.
           05 WS-MENSAJE-13     PIC X(20) VALUE 'FORMALIZADA CORRECTO'.
           05 WS-MENSAJE-14     PIC X(20) VALUE 'NO EXISTE CLUSTER   '.
           05 WS-MENSAJE-15     PIC X(20) VALUE 'DE CONSULTA         '.
           05 WS-MENSAJE-16     PIC X(20) VALUE 'ERROR AL FORMALIZAR '.
           05 WS-MENSAJE-17     PIC X(20) VALUE 'CONSULTA EXITOSA    '.
           05 WS-MENSAJE-18     PIC X(20) VALUE 'FEC CONTABLE ERRADA '.
           05 WS-MENSAJE-19     PIC X(20) VALUE 'NO PROCESABLE       '.
           05 WS-MENSAJE-20     PIC X(20) VALUE 'RECHAZADA OK        '.
           05 WS-MENSAJE-21     PIC X(20) VALUE 'SIN PARAMETRIA DIAS '.
           05 WS-MENSAJE-22     PIC X(20) VALUE 'DE BLOQUEO          '.
           05 WS-MENSAJE-23     PIC X(20) VALUE 'ERROR DELETE UGDTFGH'.
           05 WS-MENSAJE-24     PIC X(20) VALUE 'ERROR SELECT UGDTFGH'.
           05 WS-MENSAJE-25     PIC X(20) VALUE 'DEBE INFORMAR ESTE  '.
           05 WS-MENSAJE-26     PIC X(20) VALUE ' UN CAMPO           '.
           05 WS-MENSAJE-27     PIC X(20) VALUE 'DEBE INFORMAR ALGUN '.
           05 WS-MENSAJE-28     PIC X(20) VALUE 'DEBE INFORMAR SOLO  '.
      * ----- SWITCHES  ---------------------------------------------- *
       01 SWITCHES-CORRECTO.
          05 SW-CORRECTO        PIC X(1) VALUE 'S'.
             88 CORRECTO        VALUE 'S'.
             88 NO-CORRECTO     VALUE 'N'.
          05 SW-ERROR-VL        PIC X(1) VALUE 'S'.
             88 SW-ERROR-SI     VALUE 'S'.
             88 SW-ERROR-NO     VALUE 'N'.
          05 SW-CONFIRMA        PIC X(1) VALUE ' '.
             88 SW-OPCION-1     VALUE '1'.
             88 SW-OPCION-2     VALUE '2'.
      *COL02-I
          05 SW-FET37           PIC X(1) VALUE 'S'.
             88 SW-SVA-FET37    VALUE 'S'.
             88 SW-NVA-FET37    VALUE 'N'.
      *COL08-I
          05 SW-PARAM-T37       PIC X(1) VALUE 'N'.
             88 SW-SI-PARAM-T37 VALUE 'S'.
             88 SW-NO-PARAM-T37 VALUE 'N'.
      *COL08-F
      * ----- TABLAS INTERNAS ---------------------------------------- *
          05 W-TAB-COLECTI.
             10 WTL-COLECTI                      OCCURS 99 TIMES
                                           INDEXED BY IND-COLECTI.
                15 W-COL-VALOR         PIC 9(03) VALUE ZERO.
                15 W-COL-DESCRI        PIC X(20) VALUE SPACE.
          05 W-TAB-DESTINO.
             10 WTL-DESTINO                      OCCURS 99 TIMES
                                           INDEXED BY IND-DESTINO.
                15 W-DES-VALOR         PIC 9(03) VALUE ZERO.
                15 W-DES-DESCRI        PIC X(20) VALUE SPACE.
      *COL02-F
      * ----- VARIABLES DB2 ------------------------------------------ *
       01 DB2-RETURN-CDE        PIC S9(9) COMP.
          88 DB2-OK             VALUE +0.
          88 DB2-NOTFND         VALUE +100.
          88 DB2-DATE           VALUE -181.
          88 DB2-DUPREC         VALUE -803.
      *COL02-I
       01 VARIABLE-SQLCODE-ED.
           05 WVS-SQLCODE-ED                   PIC -ZZZ9.
      *COL02-F
      * -------------------------------------------------------------- *
       LINKAGE SECTION.
      * -------------------------------------------------------------- *
       01  DFHCOMMAREA.
      * ----- REGISTRO DE CONTROL DE LA SESION ----------------------- *
                COPY QGECCAA.
           EJECT
                COPY UNWCSPA.
           EJECT
                COPY UFRP001.
           EJECT
      * ----- WORKA DE LA PANTALLA UGFUNRA --------------------------- *
                COPY UNRA001.
           EJECT
      * -------------------------------------------------------------- *
       PROCEDURE DIVISION.
      * -------------------------------------------------------------- *
            PERFORM 100000-PROCESO-INI.
            PERFORM 200000-PROCESO-PRC.
            PERFORM 300000-PROCESO-FIN.
            GOBACK.
            EJECT
      * -------------------------------------------------------------- *
       100000-PROCESO-INI.
            SET ADDRESS OF UNRA001    TO CAA-PTR-COPYIN
            SET ADDRESS OF SPA-PRESTA TO CAA-PTRDATA
            INITIALIZE          CAA-COD-AVISO1 CAA-COD-AVISO2
            INITIALIZE          CAA-COD-ERROR  VARIABLES
            MOVE CTE-UNRA       TO CAA-CODTRAN-SIG
            PERFORM 100000-POSICIO-INI.
            EJECT
      * -------------------------------------------------------------- *
       100000-POSICIO-INI.
            MOVE CTE-CON-0-COMP TO NRA-MAPCLUS-L NRA-ESTCLUST-L
            MOVE CTE-CON-0-COMP TO NRA-TIMESTA-L NRA-TIPOIDE-L
            MOVE CTE-CON-0-COMP TO NRA-NUMIDEN-L NRA-NOMCLIE-L
            MOVE CTE-CON-0-COMP TO NRA-IMPORT-L  NRA-GARANTI-L
            MOVE CTE-CON-0-COMP TO NRA-PRODACT-L NRA-PRODNEW-L
            MOVE CTE-CON-0-COMP TO NRA-FECDBLO-L NRA-IMPPRES-L
            MOVE CTE-CON-0-COMP TO NRA-CONFIRM-L NRA-MRECHAZ-L
            MOVE CTE-CON-0-COMP TO NRA-PLAZOPE-L NRA-INDEDAD-L
            MOVE CTE-CON-0-COMP TO NRA-INDSEGM-L NRA-COLECTI-L
            MOVE CTE-CON-0-COMP TO NRA-GRUPRIE-L NRA-ESTVEHI-L
            MOVE CTE-CON-0-COMP TO NRA-PORCFIN-L NRA-GAMVEHI-L
      *COL02-I
            MOVE CTE-CON-0-COMP TO NRA-COLECLB-L NRA-DESTINO-L
            PERFORM 100000-LLENA-TABLA-T37
      *COL02-F
      *COL04-I
            MOVE CTE-CON-0-COMP TO NRA-VENTASC-L NRA-TIPPERS-L
            MOVE CTE-CON-0-COMP TO NRA-CRATING-L NRA-RRATING-L
            MOVE CTE-CON-0-COMP TO NRA-GARANTC-L NRA-MOPERAC-L
            MOVE CTE-CON-0-COMP TO NRA-DATOS-COMER-L
      *COL04-F
            MOVE CTE-CON-0-COMP TO NRA-TIPOUSO-L NRA-CLIEVIP-L
      *COL08-I
            MOVE CTE-CON-0-COMP TO NRA-TEXVAR8-L NRA-TEXVAR9-L
            MOVE CTE-CON-0-COMP TO NRA-TEXVA11-L.
      *COL08-F
      *COL02-I
      * -------------------------------------------------------------- *
       100000-LLENA-TABLA-T37.

           SET  SW-NVA-FET37           TO TRUE
           EXEC SQL
             OPEN CURSOR-T37
           END-EXEC

           MOVE SQLCODE            TO DB2-RETURN-CDE
                                      WVS-SQLCODE-ED

           EVALUATE SQLCODE
               WHEN ZEROS
                   SET IND-COLECTI TO 1
                   SET IND-COLECTI UP BY -1
                   SET IND-DESTINO TO 1
                   SET IND-DESTINO UP BY -1
               WHEN OTHER
                   MOVE CTE-UGE0939   TO CAA-COD-ERROR
                   MOVE 'ERROR EN UGDTT37 OPEN' TO CAA-VAR1-ERROR
                   MOVE WVS-SQLCODE-ED          TO CAA-VAR2-ERROR
           END-EVALUATE
           PERFORM UNTIL SQLCODE NOT EQUAL ZERO
               EXEC SQL
                  FETCH CURSOR-T37
                  INTO  :T37-SECCION,
                        :T37-ELEMENTO,
                        :T37-RESTO
               END-EXEC

               MOVE SQLCODE               TO DB2-RETURN-CDE
                                             WVS-SQLCODE-ED

               EVALUATE SQLCODE
                  WHEN ZERO
                     SET  SW-SVA-FET37           TO TRUE
                     EVALUATE T37-SECCION
                       WHEN '9965'
                         SET IND-COLECTI UP BY 1
                         MOVE T37-ELEMENTO(1:2)
                                            TO W-COL-VALOR(IND-COLECTI)
                         MOVE T37-RESTO TO W-COL-DESCRI(IND-COLECTI)
                       WHEN '9966'
                         SET IND-DESTINO UP BY 1
                         MOVE T37-ELEMENTO(1:2)
                                            TO W-DES-VALOR(IND-DESTINO)
                         MOVE T37-RESTO TO W-DES-DESCRI(IND-DESTINO)
                     END-EVALUATE
                  WHEN 100
                     IF SW-NVA-FET37
                        MOVE CTE-UGE0939   TO CAA-COD-ERROR
                        MOVE 'SIN REGISTROS UGDTT37' TO CAA-VAR1-ERROR
                        MOVE WVS-SQLCODE-ED          TO CAA-VAR2-ERROR
                     END-IF
                  WHEN OTHER
                     MOVE CTE-UGE0939   TO CAA-COD-ERROR
                     MOVE 'ERROR EN UGDTT37 FETCH' TO CAA-VAR1-ERROR
                     MOVE WVS-SQLCODE-ED           TO CAA-VAR2-ERROR
               END-EVALUATE                                                 0016
           END-PERFORM
           .
      *COL02-F
      * -------------------------------------------------------------- *
       200000-PROCESO-PRC.
            EVALUATE CAA-ESTADO
                 WHEN CTE-CON-INICIO
                      PERFORM 21-INICIACION
                 WHEN CTE-CON-CONTINUACION
                      PERFORM 220000-CONTINU-PRC
            END-EVALUATE.
            EJECT
      * -------------------------------------------------------------- *
       21-INICIACION.
            MOVE CTE-CON-CONTINUACION          TO CAA-ESTADO
            MOVE CTE-CON-TERMINAL              TO CAA-ACCION
            PERFORM 212-COMPROBAR-CASO.
            EJECT
      * -------------------------------------------------------------- *
       212-COMPROBAR-CASO.
           EVALUATE CAA-CASO
              WHEN SPACES
                   PERFORM 999999-INICIAL-VAR
                   PERFORM 2121-INICIALIZAR-MAPA
                   MOVE CTE-CON-MENOS-1 TO NRA-MAPCLUS-L
              WHEN CTE-3
                   PERFORM 999999-PROCESO-CSC
              WHEN OTHER
                   PERFORM 999999-CONSULTANRA
           END-EVALUATE.
           EJECT
      * -------------------------------------------------------------- *
       2121-INICIALIZAR-MAPA.
            MOVE SPACES         TO NRA-MAPCLUS NRA-NOMCLIE NRA-PRODACT
            MOVE SPACES         TO NRA-ESTADO  NRA-PRODNEW NRA-IMPORT
            MOVE SPACES         TO NRA-TIMESTA NRA-GARANTI NRA-FECDBLO
            MOVE SPACES         TO NRA-TIPOIDE NRA-NUMIDEN NRA-MRECHAZ
            MOVE SPACES         TO NRA-IMPPRES
            MOVE SPACES         TO NRA-PLAZOPE   NRA-INDEDAD
            MOVE SPACES         TO NRA-INDSEGM   NRA-COLECTI
            MOVE SPACES         TO NRA-GRUPRIE   NRA-ESTVEHI
            MOVE SPACES         TO NRA-PORCFIN   NRA-GAMVEHI
            MOVE SPACES         TO NRA-TIPOUSO   NRA-CLIEVIP
      *COL02-I
            MOVE SPACES         TO NRA-COLECLB   NRA-DESTINO
      *COL02-F
      *COL04-I
            MOVE SPACES         TO NRA-VENTASC   NRA-TIPPERS
            MOVE SPACES         TO NRA-CRATING   NRA-RRATING
            MOVE SPACES         TO NRA-GARANTC   NRA-MOPERAC
            MOVE SPACES         TO NRA-DATOS-COMER
      *COL04-F
            MOVE ZEROS          TO NRA-DIASBLO
            MOVE DFHBMPRO       TO NRA-MAPCLUS-A
            MOVE DFHBMPRO       TO NRA-GARANTI-A
            MOVE DFHBMPRO       TO NRA-ESTCLUST-A NRA-TIMESTA-A
            MOVE DFHBMPRO       TO NRA-TIPOIDE-A NRA-NUMIDEN-A
            MOVE DFHBMPRO       TO NRA-NOMCLIE-A NRA-IMPORT-A
            MOVE DFHBMPRO       TO NRA-PRODNEW-A NRA-FECDBLO-A
            MOVE DFHBMPRO       TO NRA-DIASBLO-A NRA-PRODACT-A
            MOVE DFHBMPRO       TO NRA-ESTANU-A  NRA-PROPFNG-A
            MOVE DFHBMPRO       TO NRA-IMPPRES-A NRA-MRECHAZ-A
            MOVE DFHBMPRO       TO NRA-PLAZOPE-A NRA-INDEDAD-A
            MOVE DFHBMPRO       TO NRA-INDSEGM-A NRA-COLECTI-A
            MOVE DFHBMPRO       TO NRA-GRUPRIE-A NRA-ESTVEHI-A
            MOVE DFHBMPRO       TO NRA-PORCFIN-A NRA-GAMVEHI-A
      *COL02-I
            MOVE DFHBMPRO       TO NRA-COLECLB-A NRA-DESTINO-A
      *COL02-F
      *COL04-I
            MOVE DFHBMPRO       TO NRA-VENTASC-A NRA-TIPPERS-A
            MOVE DFHBMPRO       TO NRA-CRATING-A NRA-RRATING-A
            MOVE DFHBMPRO       TO NRA-GARANTC-A NRA-MOPERAC-A
            MOVE DFHBMPRO       TO NRA-DATOS-COMER-A
      *COL04-F
            MOVE DFHBMPRO       TO NRA-TIPOUSO-A NRA-CLIEVIP-A
      *COL08-I
            MOVE DFHBMPRO       TO NRA-TEXVAR8-A NRA-TEXVAR9-A
                                   NRA-TEXVA11-A
            PERFORM 2122-MOVER-TEXTOS-VARIABLES.
      *COL08-F
            EJECT
      *COL08-I
      * -------------------------------------------------------------- *
      *                2122-MOVER-TEXTOS-VARIABLES                     *
      *  MUEVE LOS TEXTOS DESCRIPTIVOS DE TODAS LAS VARIABLES POSIBLES *
      *  PARA LOS CLUSTER DE TASA RAR                                  *
      * -------------------------------------------------------------- *
       2122-MOVER-TEXTOS-VARIABLES.
            MOVE '08. INDICADOR SEGMENTO :'    TO NRA-TEXVAR8
            MOVE '09. INDICADOR COLECTIVO:'    TO NRA-TEXVAR9
            MOVE '11. ESTADO VEHICULO    :'    TO NRA-TEXVA11.
      *
      * -------------------------------------------------------------- *
      *                2123-CARGAR-TEXTOS-HIP-LEA                      *
      *  CARGA LOS TEXTOS DE VARIABLES 10 Y 13 A 23 PARA PRODUCTOS     *
      *  HIPOTECARIOS Y LEASING HABITACIONAL (EXCEPTO HIP.SOSTENIBLE)  *
      * -------------------------------------------------------------- *
       2123-CARGAR-TEXTOS-HIP-LEA.
            MOVE '08. PROYECTO FIN/ALIADO:'    TO NRA-TEXVAR8
            MOVE '09. DESTINO            :'    TO NRA-TEXVAR9
            MOVE '11. ESTADO BIEN        :'    TO NRA-TEXVA11.
      *COL08-F
      * -------------------------------------------------------------- *
       220000-CONTINU-PRC.
            EVALUATE CAA-TECLA
                 WHEN CTE-04
                      PERFORM 224000-CONS-PENDIE
                 WHEN CTE-05
                      PERFORM 225000-CONS-HISTOR
                 WHEN OTHER
                      MOVE CTE-UGE0939      TO CAA-COD-ERROR
                      MOVE WS-MENSAJE-5 TO CAA-VAR1-ERROR
                      MOVE WS-MENSAJE-6 TO CAA-VAR2-ERROR
                      MOVE CTE-CON-MENOS-1  TO NRA-MRECHAZ-L
                      PERFORM 300000-PROCESO-FIN
            END-EVALUATE.
            EJECT
      * -------------------------------------------------------------- *
       221000-CONS-CLUSTER.
            PERFORM 999999-VALIDACLUST
            PERFORM 999999-CONSULTANRA.
      * -------------------------------------------------------------- *
       226000-LILM-PANTAL.
            PERFORM 2121-INICIALIZAR-MAPA                               06720007
            MOVE CTE-CON-MENOS-1 TO NRA-MAPCLUS-L                       06730086
            SET CAA-88-TIPO-SALIDA-ENT TO TRUE                          06800007
            SET CAA-88-ACCION-TERMINAL TO TRUE                          06810007
            SET CAA-88-ESTADO-CONTIN TO TRUE.                           06820007
      * -------------------------------------------------------------- *
       224000-CONS-PENDIE.
            MOVE CTE-UNRC       TO CAA-CODTRAN-SIG                      06822199
            MOVE CTE-CON-CAMBIO-PROGRAMA TO CAA-ACCION                  06822299
            MOVE CTE-CON-INICIO TO CAA-ESTADO                           06822499
            MOVE CTE-CON-3      TO CAA-CASO.                            06822599
      * -------------------------------------------------------------- *
       225000-CONS-HISTOR.
            MOVE CTE-UNRC       TO CAA-CODTRAN-SIG                      06822199
            MOVE CTE-CON-CAMBIO-PROGRAMA TO CAA-ACCION                  06822299
            MOVE CTE-CON-INICIO TO CAA-ESTADO                           06822499
            MOVE CTE-CON-3      TO CAA-CASO.                            06822599
      * -------------------------------------------------------------- *
       999999-ABEND-DB2.
            INITIALIZE          QGECABC
            MOVE CTE-S          TO ABC-ABEND
            MOVE CTE-UG2CUNRA   TO ABC-PROGRAMA
            MOVE CAA-VAR1-ERROR TO ABC-OBJETO-ERROR
            MOVE SQLCODE        TO ABC-SQLCODE
            MOVE SQLERRM        TO ABC-SQLERRM
            EXEC CICS
                 LINK PROGRAM ('QG1CABC')
                 COMMAREA (QGECABC)
            END-EXEC.
      * -------------------------------------------------------------- *
       999999-INICIAL-VAR.
            MOVE ZERO           TO SPA-CONSULTAR SPA-MARGRED
            MOVE SPACES         TO SPA-ENTIDAD SPA-PCAPMIN SPA-FINMES
            MOVE SPACES         TO SPA-DESCENT SPA-PCAPMAX SPA-FINANO
            MOVE SPACES         TO SPA-CODCONV SPA-DIVISA  SPA-PINTMIN
            MOVE SPACES         TO SPA-DESCRIL SPA-INDTASA SPA-PINTMAX
            MOVE SPACES         TO SPA-DESCRIR SPA-FINANO  SPA-INIANO
            MOVE SPACES         TO SPA-INIDIA  SPA-PINTMIN SPA-FINDIA
            MOVE SPACES         TO SPA-INIMES  SPA-PINTMAX SPA-FINMES
            MOVE SPACES         TO SPA-CODTASA SPA-FINDEST SPA-PREPAG
            MOVE SPACES         TO SPA-INIDEST.
      * -------------------------------------------------------------- *
       999999-PROCESO-CSC.
            PERFORM 2121-INICIALIZAR-MAPA
            IF (SPA-CLAVCTA NOT = LOW-VALUES)
               MOVE SPA-CLAVCTA TO NRA-CLUSTER
               PERFORM 221000-CONS-CLUSTER
               MOVE CTE-CON-MENOS-1 TO NRA-TIPOIDE-L
               MOVE CTE-CON-1   TO SPA-CONSULTAR
            END-IF
            MOVE CTE-CON-MENOS-1 TO NRA-MAPCLUS-L.
      * -------------------------------------------------------------- *
       999999-VALIDACLUST.
            SET SW-ERROR-NO     TO TRUE
            EVALUATE TRUE
               WHEN (NRA-CLUSTER = SPACES)OR(NRA-CLUSTER = LOW-VALUES)
                    SET SW-ERROR-SI TO TRUE
            END-EVALUATE
            IF SW-ERROR-SI
               MOVE CTE-CON-UGE0031 TO CAA-COD-ERROR
               MOVE DFHBMBRY    TO NRA-MAPCLUS-A
               MOVE CTE-CON-MENOS-1 TO NRA-MAPCLUS-L
               PERFORM 300000-PROCESO-FIN
            END-IF.
      * ------------------------------------------------------------- *
       999999-PASAINFORMA.
            MOVE NRA-CLAVE-ID   TO NRA-MAPCLUS
            MOVE NRA-TIMESTAMP  TO NRA-TIMESTA
            MOVE NRA-CLUSTER    TO NRA-TIPOIDE
            MOVE NRA-TASA       TO WS-EDITABLE
            MOVE WS-EDITABLE    TO NRA-NUMIDEN
            MOVE NRA-FECHA-INI  TO NRA-IMPORT
            MOVE NRA-FECHA-FIN  TO NRA-IMPPRES
      *COL04-I
            IF NRA-TIPO-PRODUCTO = 'C'
               PERFORM 9999-PASAINFORMA-COMER
            END-IF
      *COL04-F
      *COL01-I
            MOVE NRA-ESTADO     TO WS-NRA-ESTADO
      *COL01-F
            EVALUATE NRA-ESTADO
               WHEN 'VS'
                    MOVE ' ACTIVO' TO NRA-ESTCLUST
               WHEN 'BA'
                    MOVE ' BAJA  ' TO NRA-ESTCLUST
               WHEN OTHER
                    MOVE CTE-UGE0939           TO CAA-COD-ERROR
                    MOVE 'ERROR CONSULTA NRA ' TO CAA-VAR1-ERROR
                    MOVE 'ESTADO CLUSTER     ' TO CAA-VAR2-ERROR
                    MOVE CTE-CON-MENOS-1       TO NRA-MAPCLUS-L
                    PERFORM 300000-PROCESO-FIN
            END-EVALUATE.
      * ------------------------------------------------------------- *
       999999-CONSULTANRA.

            INITIALIZE          WS-DETICLUSTE
            MOVE NRA-CLUSTER    TO NRA-CLAVE-ID WS-DETICLUSTE
            MOVE SPA-CODENTS    TO NRA-CONSECUTIVO
      *COL07-I
            MOVE SPA-CLU-ID     TO NRA-TIPO-PRODUCTO
            MOVE SPA-CLU-DES    TO NRA-NOMCLIE
      *COL06-I
      *     EVALUATE SPA-IDCLIEN
      *        WHEN 'HIPOTECARIO'
      *        WHEN 'HIP  '
      *COL06-F
      *             MOVE 'H'           TO NRA-TIPO-PRODUCTO
      *             MOVE 'HIPOTECARIO' TO NRA-NOMCLIE
      *COL06-I
      *        WHEN 'LEASIND-HAB'
      *        WHEN 'LEH  '
      *COL06-F
      *             MOVE 'L'           TO NRA-TIPO-PRODUCTO
      *             MOVE 'LEASING HABITACIONAL' TO NRA-NOMCLIE
      *COL06-I
      *        WHEN 'CONSUMO    '
      *        WHEN 'CON  '
      *COL06-F
      *             MOVE 'N'           TO NRA-TIPO-PRODUCTO
      *             MOVE 'CONSUMO    ' TO NRA-NOMCLIE
      *COL06-I
      *        WHEN 'VEHICULO   '
      *        WHEN 'VEH  '
      *COL06-F
      *             MOVE 'V'           TO NRA-TIPO-PRODUCTO
      *             MOVE 'VEHICULO   ' TO NRA-NOMCLIE
      *COL06-I
      *        WHEN 'VEHICUL-CCT'
      *        WHEN 'VCK  '
      *COL06-F
      *             MOVE 'VC'          TO NRA-TIPO-PRODUCTO
      *             MOVE 'VEHICULO COMPRA DE CARTERA' TO NRA-NOMCLIE
      *COL06-I
      *        WHEN 'CONSUMO-CCT'
      *        WHEN 'CCK  '
      *COL06-F
      *             MOVE 'NC'          TO NRA-TIPO-PRODUCTO
      *             MOVE 'CONSUMO COMPRA DE CARTERA'  TO NRA-NOMCLIE
      *COL06-I
      *        WHEN 'HIPOTEC-CCT'
      *        WHEN 'HCK  '
      *COL06-F
      *             MOVE 'HC'          TO NRA-TIPO-PRODUCTO
      *             MOVE 'HIPOTECARIO COMPRA DE CARTERA'  TO NRA-NOMCLIE
      *COL06-I
      *        WHEN 'HIPOTEC-UVR'
      *        WHEN 'HIPU '
      *COL06-F
      *             MOVE 'HU'          TO NRA-TIPO-PRODUCTO
      *             MOVE 'HIPOTECARIO UVR'  TO NRA-NOMCLIE
      *COL06-I
      *        WHEN 'HIP-CCT-UVR'
      *        WHEN 'HCKU '
      *COL06-F
      *             MOVE 'HK'          TO NRA-TIPO-PRODUCTO
      *             MOVE 'HIPOTECARIO COMPRA DE CARTERA UVR'
      *                                     TO NRA-NOMCLIE
      *COL02-I
      *COL06-I
      *        WHEN 'LIBRANZA   '
      *        WHEN 'LIB  '
      *COL06-F
      *             MOVE 'Z'           TO NRA-TIPO-PRODUCTO
      *             MOVE 'PRODUCTOS LIBRANZA               '
      *                                     TO NRA-NOMCLIE
      *COL02-F
      *COL03-I
      *COL06-I
      *        WHEN 'HIPOTEC-SOS'
      *        WHEN 'HSOS '
      *COL06-F
      *             MOVE 'HS'          TO NRA-TIPO-PRODUCTO
      *             MOVE 'HIPOTECARIO SOSTENIBLE           '
      *                                     TO NRA-NOMCLIE
      *COL06-I
      *        WHEN 'HIPOTEC-VIS'
      *        WHEN 'HVIS '
      *COL06-F
      *             MOVE 'HV'          TO NRA-TIPO-PRODUCTO
      *             MOVE 'HIPOTECARIO VIS                  '
      *                                     TO NRA-NOMCLIE
      *COL03-F
      *COL04-I
      *COL06-I
      *        WHEN 'COMERCIAL  '
      *        WHEN 'CIAL '
      *COL06-F
      *             MOVE 'C'           TO NRA-TIPO-PRODUCTO
      *             MOVE 'PRODUCTOS COMERCIAL              '
      *                                     TO NRA-NOMCLIE
      *COL04-F
      *     END-EVALUATE
      *COL07-F
      *COL06-I
            MOVE SPA-FECHA-1           TO NRA-FECHA-INI
      *COL06-F
            PERFORM 999999-SELECT-PNRA
            IF  SQLCODE EQUAL ZEROS
                PERFORM 999999-PASAINFORMA
                PERFORM 9999-INFORMACIONBURO
                PERFORM 9999-INFO-DOM-DOMINA
                PERFORM 9999-INFO-SIT-LABORA
                PERFORM 9999-INFO-INGRESALAR
                PERFORM 9999-INFO-MONTOFINAN
                PERFORM 9999-INFO-PLAZO-OPER
                PERFORM 9999-INFO-EDAD-CLIEN
                PERFORM 9999-INFOR-SEGMENTOS
                PERFORM 9999-INFOR-COLECTIVO
                PERFORM 9999-GRUPO-DE-RIESGO
                PERFORM 9999-INFOR-ESTVEHICU
                PERFORM 9999-PORC-FINANCIACI
                PERFORM 9999-INFGAMAVEHICULO
                PERFORM 9999-INFO-TIPODE-USO
                PERFORM 9999-INFO-CLIENTE-VIP
      *COL02-I
                PERFORM 9999-INFO-COLECTI-LIB
                PERFORM 9999-INFO-DESTINO-LIB
      *COL02-F
      *COL04-I
                PERFORM 9999-INFO-VENTAS-COMER
                PERFORM 9999-INFO-TIPO-PER-COMER
                PERFORM 9999-INFO-RATING-COMER
                PERFORM 9999-INFO-RANG-RATNG-COMER
                PERFORM 9999-INFO-GARANTIA-COMER
                PERFORM 9999-INFO-MONTOPER-COMER
      *COL04-F
      *COL08-I
                IF (NRA-TIPO-PRODUCTO(1:1) = 'H'
                    OR NRA-TIPO-PRODUCTO(1:1) = 'L')
                    AND NRA-TIPO-PRODUCTO NOT = 'HS'
                   PERFORM 2123-CARGAR-TEXTOS-HIP-LEA
                ELSE
                   PERFORM 2122-MOVER-TEXTOS-VARIABLES
                END-IF
      *COL08-F
            ELSE
                IF SQLCODE = 100
                   MOVE CTE-UGE0939   TO CAA-COD-ERROR
                   MOVE WS-MENSAJE-14 TO CAA-VAR1-ERROR
                   MOVE WS-MENSAJE-15 TO CAA-VAR2-ERROR
                   MOVE CTE-CON-MENOS-1 TO NRA-MAPCLUS-L
                   PERFORM 300000-PROCESO-FIN
                ELSE
                   MOVE CTE-UGE0939   TO CAA-COD-ERROR
                   MOVE 'ERROR GRAVE' TO CAA-VAR1-ERROR
                   MOVE 'DB2'         TO CAA-VAR2-ERROR
                   MOVE SQLCODE       TO CAA-VAR2-ERROR(5:)
                   MOVE CTE-CON-MENOS-1 TO NRA-MAPCLUS-L
                   PERFORM 300000-PROCESO-FIN
                END-IF
            END-IF
            MOVE CTE-CON-MENOS-1 TO NRA-MAPCLUS-L
            MOVE CTE-CON-1      TO SPA-CONSULTAR.
      * ------------------------------------------------------------- *
      *       CONSULTAS DB2 PROCESOS                                  *
      * ------------------------------------------------------------- *
       999999-SELECT-PNRA.
            EXEC SQL
                SELECT NRA_TIPO_PRODUCTO, NRA_VARIABLE, NRA_CONSECUTIVO,
                       NRA_CLAVE_ID, NRA_CLUSTER, NRA_ESTADO, NRA_TASA,
                       NRA_TIMESTAMP, NRA_FECHA_INI, NRA_FECHA_FIN,
      *COL04-I
      *                NRA_TIPO_PRODUCTO
                       NRA_TIPO_PRODUCTO, NRA_PORCENTA,
                       NRA_RANGO_RIESGO_INI, NRA_MONTO_INICIAL
      *COL04-F
               INTO :NRA-TIPO-PRODUCTO, :NRA-VARIABLE, :NRA-CONSECUTIVO,
                    :NRA-CLAVE-ID, :NRA-CLUSTER, :NRA-ESTADO, :NRA-TASA,
                    :NRA-TIMESTAMP, :NRA-FECHA-INI, :NRA-FECHA-FIN,
      *COL04-I
      *             :NRA-TIPO-PRODUCTO
                    :NRA-TIPO-PRODUCTO, :NRA-PORCENTA,
                    :NRA-RANGO-RIESGO-INI, :NRA-MONTO-INICIAL
      *COL04-F
               FROM UGDTNRA
               WHERE
      *COL01-I
               NRA_VARIABLE      = :CTE-90 AND
      *COL01-F
               NRA_CLAVE_ID      = :NRA-CLAVE-ID  AND
               NRA_TIPO_PRODUCTO = :NRA-TIPO-PRODUCTO AND
               NRA_CONSECUTIVO   = :NRA-CONSECUTIVO
      *COL06-I
               AND NRA_FECHA_INI = :NRA-FECHA-INI
      *COL06-F
           END-EXEC.
      * ------------------------------------------------------------- *
       999999-ROLLBACK.
           EXEC CICS
               SYNCPOINT ROLLBACK
           END-EXEC
           PERFORM 300000-PROCESO-FIN.
      * -------------------------------------------------------------- *
       9999-VALIDARESPUESTA.
            EVALUATE SQLCODE
               WHEN ZEROS
                   PERFORM 9999-PASADATADETALLE
              WHEN 100
                   PERFORM 9999-PASADATANOVEDAD
              WHEN OTHER
                   MOVE CTE-UGE0939   TO CAA-COD-ERROR
                   MOVE 'NOVEDAD AL CONSULTAR' TO CAA-VAR1-ERROR
                   MOVE WS-PERFORM             TO CAA-VAR2-ERROR
            END-EVALUATE.
      * -------------------------------------------------------------- *
       9999-INFORMACIONBURO.
            INITIALIZE          WS-NRA-CLAVE-ID WS-NRA-VARIABLE
                                WS-PERFORM WS-BURO-INI WS-BURO-FIN
                                NRA-PRODACT
            MOVE '01'           TO WS-NRA-VARIABLE
            MOVE WS-BURO        TO WS-NRA-CLAVE-ID
            MOVE ' RANGOS DE BURO     ' TO WS-PERFORM
            PERFORM 9999-CONSULT-UGDTNRA
            PERFORM 9999-VALIDARESPUESTA.
      * -------------------------------------------------------------- *
       9999-INFO-DOM-DOMINA.
            INITIALIZE          NRA-PRODNEW
            MOVE '02'           TO WS-NRA-VARIABLE
            MOVE WS-DOM-DOMINA  TO WS-NRA-CLAVE-ID
            MOVE ' INFO DOM DOMINA    ' TO WS-PERFORM
            PERFORM 9999-CONSULT-UGDTNRA
            PERFORM 9999-VALIDARESPUESTA.
      * -------------------------------------------------------------- *
       9999-INFO-SIT-LABORA.
            INITIALIZE          NRA-FECDBLO
            MOVE '03'           TO WS-NRA-VARIABLE
            MOVE WS-SIT-LABORAL TO WS-NRA-CLAVE-ID
            MOVE ' SITUACION LABORAL  ' TO WS-PERFORM
            PERFORM 9999-CONSULT-UGDTNRA
            PERFORM 9999-VALIDARESPUESTA.
      * -------------------------------------------------------------- *
       9999-INFO-INGRESALAR.
            INITIALIZE          NRA-DIASBLO WS-INGR-INI WS-INGR-FIN
            MOVE '04'           TO WS-NRA-VARIABLE
            MOVE WS-INGRESOS    TO WS-NRA-CLAVE-ID
            MOVE ' INGRESOS SALARIAL  ' TO WS-PERFORM
            PERFORM 9999-CONSULT-UGDTNRA
            PERFORM 9999-VALIDARESPUESTA.
      * -------------------------------------------------------------- *
       9999-INFO-MONTOFINAN.
            INITIALIZE          NRA-MRECHAZ WS-MONT-INI WS-MONT-FIN
            MOVE '05'           TO WS-NRA-VARIABLE
            MOVE WS-MONT-FINAN  TO WS-NRA-CLAVE-ID
            MOVE ' MONTO FINANCIACION ' TO WS-PERFORM
            PERFORM 9999-CONSULT-UGDTNRA
            PERFORM 9999-VALIDARESPUESTA.
      * -------------------------------------------------------------- *
       9999-INFO-PLAZO-OPER.
            INITIALIZE          NRA-PLAZOPE
            MOVE '06'           TO WS-NRA-VARIABLE
            MOVE WS-PLAZO-OPER  TO WS-NRA-CLAVE-ID
            MOVE ' PLAZO OPERACION    ' TO WS-PERFORM
            PERFORM 9999-CONSULT-UGDTNRA
            PERFORM 9999-VALIDARESPUESTA.
      * -------------------------------------------------------------- *
       9999-INFO-EDAD-CLIEN.
            INITIALIZE          NRA-INDEDAD
            MOVE '07'           TO WS-NRA-VARIABLE
            MOVE WS-EDAD        TO WS-NRA-CLAVE-ID
            MOVE ' INDICADOR EDAD     ' TO WS-PERFORM
            PERFORM 9999-CONSULT-UGDTNRA
            PERFORM 9999-VALIDARESPUESTA.
      * -------------------------------------------------------------- *
       9999-INFOR-SEGMENTOS.
            INITIALIZE          NRA-INDSEGM
            MOVE '08'           TO WS-NRA-VARIABLE
            MOVE WS-SEGMENTO    TO WS-NRA-CLAVE-ID
            MOVE ' INDICADOR SEGMENTO ' TO WS-PERFORM
            PERFORM 9999-CONSULT-UGDTNRA
            PERFORM 9999-VALIDARESPUESTA.
      * -------------------------------------------------------------- *
       9999-INFOR-COLECTIVO.
            INITIALIZE          NRA-COLECTI
            MOVE '09'           TO WS-NRA-VARIABLE
            MOVE WS-COLECTIVO   TO WS-NRA-CLAVE-ID
            MOVE ' INDICADOR SEGMENTO ' TO WS-PERFORM
            PERFORM 9999-CONSULT-UGDTNRA
            PERFORM 9999-VALIDARESPUESTA.
      * -------------------------------------------------------------- *
       9999-GRUPO-DE-RIESGO.
            INITIALIZE          NRA-GRUPRIE
            MOVE '10'           TO WS-NRA-VARIABLE
            MOVE WS-GRUP-RIESG  TO WS-NRA-CLAVE-ID
            MOVE ' INDICADOR SEGMENTO ' TO WS-PERFORM
            PERFORM 9999-CONSULT-UGDTNRA
            PERFORM 9999-VALIDARESPUESTA.
      * -------------------------------------------------------------- *
       9999-INFOR-ESTVEHICU.
            INITIALIZE          NRA-ESTVEHI
            MOVE '11'           TO WS-NRA-VARIABLE
            MOVE WS-EST-VEHIC   TO WS-NRA-CLAVE-ID
            MOVE ' INDICADOR SEGMENTO ' TO WS-PERFORM
            PERFORM 9999-CONSULT-UGDTNRA
            PERFORM 9999-VALIDARESPUESTA.
      * -------------------------------------------------------------- *
       9999-PORC-FINANCIACI.
            INITIALIZE          NRA-PORCFIN
            MOVE '12'           TO WS-NRA-VARIABLE
            MOVE WS-PORC-FINAN  TO WS-NRA-CLAVE-ID
            MOVE ' INDICADOR SEGMENTO ' TO WS-PERFORM
            PERFORM 9999-CONSULT-UGDTNRA
            PERFORM 9999-VALIDARESPUESTA.
      * -------------------------------------------------------------- *
       9999-INFGAMAVEHICULO.
            INITIALIZE          NRA-GAMVEHI
            MOVE '13'           TO WS-NRA-VARIABLE
            MOVE WS-GAMA-VEHIC  TO WS-NRA-CLAVE-ID
            MOVE ' INDICADOR SEGMENTO ' TO WS-PERFORM
            PERFORM 9999-CONSULT-UGDTNRA
            PERFORM 9999-VALIDARESPUESTA.
      * -------------------------------------------------------------- *
       9999-INFO-TIPODE-USO.
            INITIALIZE          NRA-TIPOUSO
            MOVE '14'           TO WS-NRA-VARIABLE
            MOVE WS-TIPO-USO    TO WS-NRA-CLAVE-ID
            MOVE ' TIPO DE USO        ' TO WS-PERFORM
            PERFORM 9999-CONSULT-UGDTNRA
            PERFORM 9999-VALIDARESPUESTA.
      * -------------------------------------------------------------- *
       9999-INFO-CLIENTE-VIP.
            INITIALIZE          NRA-CLIEVIP
            MOVE '15'           TO WS-NRA-VARIABLE
            MOVE WS-CLIENT-VIP  TO WS-NRA-CLAVE-ID
            MOVE ' IND CLIENTE VIP    ' TO WS-PERFORM
            PERFORM 9999-CONSULT-UGDTNRA
            PERFORM 9999-VALIDARESPUESTA.
      *COL02-I
      * -------------------------------------------------------------- *
       9999-INFO-COLECTI-LIB.
            INITIALIZE          NRA-COLECLB
            MOVE '16'           TO WS-NRA-VARIABLE
            MOVE WS-CLTVLB      TO WS-NRA-CLAVE-ID
            MOVE ' COLECTIVO LIBRANZA ' TO WS-PERFORM
            PERFORM 9999-CONSULT-UGDTNRA
            PERFORM 9999-VALIDARESPUESTA.
      * -------------------------------------------------------------- *
       9999-INFO-DESTINO-LIB.
            INITIALIZE          NRA-DESTINO
            MOVE '17'           TO WS-NRA-VARIABLE
            MOVE WS-DESTLB      TO WS-NRA-CLAVE-ID
            MOVE ' DESTINO LIBRANZA   ' TO WS-PERFORM
            PERFORM 9999-CONSULT-UGDTNRA
            PERFORM 9999-VALIDARESPUESTA.
      *COLO2-F
      * -------------------------------------------------------------- *
      *COL04-I
       9999-INFO-VENTAS-COMER.
            INITIALIZE          NRA-VENTASC
            MOVE '18'           TO WS-NRA-VARIABLE
            MOVE WS-VENTASC     TO WS-NRA-CLAVE-ID
            MOVE ' VENTAS COMERCIAL   ' TO WS-PERFORM
            PERFORM 9999-CONSULT-UGDTNRA
            PERFORM 9999-VALIDARESPUESTA.
      * -------------------------------------------------------------- *
       9999-INFO-TIPO-PER-COMER.
            INITIALIZE          NRA-TIPPERS
            MOVE '19'           TO WS-NRA-VARIABLE
            MOVE WS-TIPPERS     TO WS-NRA-CLAVE-ID
            MOVE ' TIPO PERSONA COMERC' TO WS-PERFORM
            PERFORM 9999-CONSULT-UGDTNRA
            PERFORM 9999-VALIDARESPUESTA.
      * -------------------------------------------------------------- *
       9999-INFO-RATING-COMER.
            INITIALIZE          NRA-CRATING
            MOVE '20'           TO WS-NRA-VARIABLE
            MOVE WS-CRATING     TO WS-NRA-CLAVE-ID
            MOVE ' CALF.RATING COMERCI' TO WS-PERFORM
            PERFORM 9999-CONSULT-UGDTNRA
            PERFORM 9999-VALIDARESPUESTA.
      * -------------------------------------------------------------- *
       9999-INFO-RANG-RATNG-COMER.
            INITIALIZE          NRA-RRATING
            MOVE '21'           TO WS-NRA-VARIABLE
            MOVE WS-RRATING     TO WS-NRA-CLAVE-ID
            MOVE ' RANGO RATING COMERC' TO WS-PERFORM
            PERFORM 9999-CONSULT-UGDTNRA
            PERFORM 9999-VALIDARESPUESTA.
      * -------------------------------------------------------------- *
       9999-INFO-GARANTIA-COMER.
            INITIALIZE          NRA-GARANTC
            MOVE '22'           TO WS-NRA-VARIABLE
            MOVE WS-GARANTC     TO WS-NRA-CLAVE-ID
            MOVE ' GARANTIA COMERCIAL ' TO WS-PERFORM
            PERFORM 9999-CONSULT-UGDTNRA
            PERFORM 9999-VALIDARESPUESTA.
      * -------------------------------------------------------------- *
       9999-INFO-MONTOPER-COMER.
            INITIALIZE          NRA-MOPERAC
            MOVE '23'           TO WS-NRA-VARIABLE
            MOVE WS-MOPERAC     TO WS-NRA-CLAVE-ID
            MOVE ' MONTO OPERAC COMERC' TO WS-PERFORM
            PERFORM 9999-CONSULT-UGDTNRA
            PERFORM 9999-VALIDARESPUESTA.
      * -------------------------------------------------------------- *
       9999-PASAINFORMA-COMER.
            MOVE NRA-PORCENTA               TO WS-PE
            MOVE NRA-RANGO-RIESGO-INI       TO WS-RORC
            MOVE NRA-MONTO-INICIAL          TO WS-CAPI
            MOVE SPACES                     TO NRA-DATOS-COMER
            MOVE 'PE:'                      TO NRA-DATOS-COMER(1:3)
            MOVE WS-PE                      TO NRA-DATOS-COMER(4:5)
            MOVE SPACES                     TO NRA-DATOS-COMER(9:1)
            MOVE 'RORC:'                    TO NRA-DATOS-COMER(10:5)
            MOVE WS-RORC                    TO NRA-DATOS-COMER(15:5)
            MOVE SPACES                     TO NRA-DATOS-COMER(20:1)
            MOVE 'CAP-ECON:'                TO NRA-DATOS-COMER(21:9)
            MOVE WS-CAPI                    TO NRA-DATOS-COMER(30:5).
      *COL04-F
      * -------------------------------------------------------------- *
       9999-CONSULT-UGDTNRA.
            EXEC SQL
               SELECT NRA_TIPO_PRODUCTO,
                      NRA_VARIABLE,
                      NRA_CONSECUTIVO,
                      NRA_FECHA_INI,
                      NRA_FECHA_FIN,
                      NRA_RANGO_INI,
                      NRA_RANGO_FIN,
                      NRA_IND_DOM_NOMINA,
                      NRA_SITUA_LABORAL,
                      NRA_MONTO_INICIAL,
                      NRA_MONTO_FINAL,
                      NRA_SEGMENTO,
                      NRA_IND_CLIENTE_VIP,
                      NRA_RANGO_RIESGO_INI,
                      NRA_RANGO_RIESGO_FIN,
                      NRA_IND_ESTADO_VEH,
                      NRA_IND_TIPO_VEH,
                      NRA_CLAVE_ID,
                      NRA_CLUSTER,
                      NRA_ESTADO,
                      NRA_TASA,
                      NRA_CENTRO_UMO,
                      NRA_USERID_UMO,
                      NRA_NETNAME_UMO,
      *COL04-I
      *               NRA_TIMESTAMP
                      NRA_TIMESTAMP,
                      NRA_RATING,
                      NRA_RANGO_RATING,
                      NRA_GARANTIA
      *COL04-F
               INTO : NRA-TIPO-PRODUCTO,
                    : NRA-VARIABLE,
                    : NRA-CONSECUTIVO,
                    : NRA-FECHA-INI,
                    : NRA-FECHA-FIN,
                    : NRA-RANGO-INI,
                    : NRA-RANGO-FIN,
                    : NRA-IND-DOM-NOMINA,
                    : NRA-SITUA-LABORAL,
                    : NRA-MONTO-INICIAL,
                    : NRA-MONTO-FINAL,
                    : NRA-SEGMENTO,
                    : NRA-IND-CLIENTE-VIP,
                    : NRA-RANGO-RIESGO-INI,
                    : NRA-RANGO-RIESGO-FIN,
                    : NRA-IND-ESTADO-VEH,
                    : NRA-IND-TIPO-VEH,
                    : NRA-CLAVE-ID,
                    : NRA-CLUSTER,
                    : NRA-ESTADO,
                    : NRA-TASA,
                    : NRA-CENTRO-UMO,
                    : NRA-USERID-UMO,
                    : NRA-NETNAME-UMO,
      *COL04-I
      *             : NRA-TIMESTAMP
                    : NRA-TIMESTAMP,
                    : NRA-RATING,
                    : NRA-RANGO-RATING,
                    : NRA-GARANTIA
      *COL04-F
               FROM UGDTNRA
               WHERE
      *COL01-I
               NRA_ESTADO        = :WS-NRA-ESTADO     AND
      *COL01-I
               NRA_VARIABLE      = :WS-NRA-VARIABLE   AND
               NRA_TIPO_PRODUCTO = :NRA-TIPO-PRODUCTO AND
               NRA_CLAVE_ID      = :WS-NRA-CLAVE-ID
            END-EXEC.
      * -------------------------------------------------------------- *
       9999-PASADATADETALLE.
            EVALUATE WS-NRA-VARIABLE
               WHEN '01'
                   MOVE NRA-RANGO-INI TO WS-BURO-INI
                   MOVE NRA-RANGO-FIN TO WS-BURO-FIN
                   MOVE WS-BURO-ED    TO NRA-PRODACT
               WHEN '02'
                   MOVE NRA-IND-DOM-NOMINA TO NRA-PRODNEW
               WHEN '03'
                   EVALUATE NRA-SITUA-LABORAL
                      WHEN 1
                         MOVE 'EMPLEO FIJO   ' TO NRA-FECDBLO
                      WHEN 2
                         MOVE 'EMP. TEMPORAL ' TO NRA-FECDBLO
                      WHEN 3
      *COL01-I
      *                  MOVE 'INDEPENDIENTE ' TO NRA-PRODNEW
                         MOVE 'INDEPENDIENTE ' TO NRA-FECDBLO
      *COL01-F
                      WHEN 4
      *COL01-I
      *                  MOVE 'OTROS EMPLEOS ' TO NRA-PRODNEW
                         MOVE 'OTROS EMPLEOS ' TO NRA-FECDBLO
      *COL01-F
                      WHEN 5
                         MOVE 'PENSIONADO    ' TO NRA-FECDBLO
      *COL08-I
                      WHEN 6
                         MOVE 'INDEP. NICHO  ' TO NRA-FECDBLO
      *COL08-F
                   END-EVALUATE
               WHEN '04'
                   MOVE NRA-MONTO-INICIAL TO WS-INGR-INI
                   MOVE NRA-MONTO-FINAL   TO WS-INGR-FIN
                   INSPECT WS-INGR-FIN REPLACING ALL SPACE  BY ZERO
                   MOVE WS-INGRESO-ED  TO NRA-DIASBLO
               WHEN '05'
                   MOVE NRA-MONTO-INICIAL TO WS-MONT-INI
                   MOVE NRA-MONTO-FINAL   TO WS-MONT-FIN
                   INSPECT WS-MONT-FIN REPLACING ALL SPACE  BY ZERO
                   MOVE WS-MONTFIN-ED  TO NRA-MRECHAZ
               WHEN '06'
                   MOVE NRA-RANGO-INI TO WS-BURO-INI
                   MOVE NRA-RANGO-FIN TO WS-BURO-FIN
                   MOVE WS-BURO-ED    TO NRA-PLAZOPE
               WHEN '07'
                   MOVE NRA-RANGO-INI TO WS-BURO-INI
                   MOVE NRA-RANGO-FIN TO WS-BURO-FIN
                   MOVE WS-BURO-ED    TO NRA-INDEDAD
               WHEN '08'
      *COL08-I
                   IF (NRA-TIPO-PRODUCTO(1:1) = 'H'
                      OR NRA-TIPO-PRODUCTO(1:1) = 'L')
                      AND NRA-TIPO-PRODUCTO NOT = 'HS'
                      EVALUATE NRA-SEGMENTO
                         WHEN 0
                            MOVE 'NO APLICA'  TO NRA-INDSEGM
                         WHEN 1
                            MOVE 'SI'         TO NRA-INDSEGM
                         WHEN 2
                            MOVE 'NO'         TO NRA-INDSEGM
                      END-EVALUATE
                   ELSE
      *COL08-F
                      MOVE NRA-SEGMENTO   TO NRA-INDSEGM
      *COL08-I
                   END-IF
      *COL08-F
               WHEN '09'
      *COL08-I
                   IF (NRA-TIPO-PRODUCTO(1:1) = 'H'
                      OR NRA-TIPO-PRODUCTO(1:1) = 'L')
                      AND NRA-TIPO-PRODUCTO NOT = 'HS'
                      IF NRA-SEGMENTO = ZEROS
                         MOVE 'NO APLICA' TO NRA-COLECTI
                      ELSE
                         PERFORM 9999-CONSULTA-DESTINO-T37
                      END-IF
                   ELSE
      *COL08-F
                      MOVE NRA-SEGMENTO   TO NRA-COLECTI
      *COL08-I
                   END-IF
      *COL08-F
               WHEN '10'
                   MOVE NRA-RANGO-RIESGO-INI TO WS-RIES-INI
                   MOVE NRA-RANGO-RIESGO-FIN TO WS-RIES-FIN
                   MOVE WS-RIESGOS-ED TO NRA-GRUPRIE
               WHEN '11'
      *COL08-I
                   IF (NRA-TIPO-PRODUCTO(1:1) = 'H'
                      OR NRA-TIPO-PRODUCTO(1:1) = 'L')
                      AND NRA-TIPO-PRODUCTO NOT = 'HS'
                      EVALUATE WS-EST-VEHIC
                         WHEN 'A'
                            MOVE 'NUEVO        ' TO NRA-ESTVEHI
                         WHEN 'B'
                            MOVE 'USADO        ' TO NRA-ESTVEHI
                         WHEN OTHER
                            MOVE 'SIN CATALOGAR' TO NRA-ESTVEHI
                      END-EVALUATE
                   ELSE
      *COL08-F
                      EVALUATE WS-EST-VEHIC
                         WHEN 'A'
                            MOVE 'VEH NUEVO    ' TO NRA-ESTVEHI
                         WHEN 'B'
                            MOVE 'VEH USADO    ' TO NRA-ESTVEHI
                         WHEN OTHER
                            MOVE 'SIN CATALOGAR' TO NRA-TIPOUSO
                      END-EVALUATE
      *COL08-I
                   END-IF
      *COL08-F
               WHEN '12'
                   MOVE NRA-MONTO-INICIAL   TO WS-INGR-INI
                   MOVE NRA-MONTO-FINAL     TO WS-INGR-FIN
                   MOVE WS-INGRESO-ED TO NRA-PORCFIN
               WHEN '13'
                   MOVE NRA-MONTO-INICIAL   TO WS-BURO-INI
                   MOVE NRA-MONTO-FINAL     TO WS-BURO-FIN
                   MOVE WS-BURO-ED    TO NRA-GAMVEHI
               WHEN '14'
                   EVALUATE  WS-TIPO-USO
                     WHEN 'A'
                       MOVE 'PARTICULAR   ' TO NRA-TIPOUSO
                     WHEN 'B'
                       MOVE 'PUBLICO      ' TO NRA-TIPOUSO
                     WHEN OTHER
                       MOVE 'SIN CATALOGAR' TO NRA-TIPOUSO
                   END-EVALUATE
               WHEN '15'
                   MOVE NRA-IND-CLIENTE-VIP TO NRA-CLIEVIP
      *COL02-I
               WHEN '16'
                   IF NRA-SEGMENTO EQUAL ZERO
                       MOVE CTE-NA          TO NRA-COLECLB
                   ELSE
                       PERFORM 9999-CONSULTATABLT37
                   END-IF
               WHEN '17'
                   IF NRA-SEGMENTO EQUAL ZERO
                       MOVE CTE-NA          TO NRA-DESTINO
                   ELSE
                       PERFORM 9999-CONSULTATABLT37
                   END-IF
      *COL02-F
      *COL04-I
               WHEN '18'
                   MOVE NRA-MONTO-INICIAL   TO WS-VENT-INI
                   MOVE NRA-MONTO-FINAL     TO WS-VENT-FIN
                   STRING ': ', WS-VENTAS-ED
                   DELIMITED BY SIZE
                     INTO WS-CONCATENA
                   MOVE WS-CONCATENA        TO NRA-VENTASC
               WHEN '19'
                   IF NRA-IND-CLIENTE-VIP = 'N'
                      MOVE 'P.NATURAL    '  TO NRA-TIPPERS
                   ELSE
                      MOVE 'P.JURIDICA   '  TO NRA-TIPPERS
                   END-IF
               WHEN '20'
                   MOVE NRA-RATING          TO NRA-CRATING
               WHEN '21'
                   MOVE NRA-RANGO-RATING    TO NRA-RRATING
               WHEN '22'
                   MOVE NRA-GARANTIA        TO NRA-GARANTC
               WHEN '23'
                   MOVE NRA-MONTO-INICIAL   TO WS-OPER-INI
                   MOVE NRA-MONTO-FINAL     TO WS-OPER-FIN
                   STRING ': ', WS-MONOPE-ED
                   DELIMITED BY SIZE
                     INTO WS-CONCATENA
                   MOVE WS-CONCATENA        TO NRA-MOPERAC
      *COL04-F
            END-EVALUATE.
      *COL02-I
      * -------------------------------------------------------------- *
       9999-CONSULTATABLT37.
           IF WS-NRA-VARIABLE = '16'
               MOVE NRA-SEGMENTO                 TO WS-VAL-LIBRAN
               SET IND-COLECTI TO 1
               SEARCH WTL-COLECTI
                AT END
                  MOVE CTE-UGE0939               TO CAA-COD-ERROR
                  MOVE 'ERROR COLECTIVO LIB.'    TO CAA-VAR1-ERROR
                  MOVE WS-VAL-LIBRAN             TO CAA-VAR2-ERROR
                  MOVE 'NO EN UGDTT37 9965  '    TO CAA-VAR2-ERROR(5:)
                  MOVE 'SIN CATALOGAR'           TO NRA-COLECLB
                WHEN W-COL-VALOR(IND-COLECTI) = WS-VAL-LIBRAN
                  MOVE W-COL-DESCRI(IND-COLECTI) TO NRA-COLECLB
               END-SEARCH
           END-IF
           IF WS-NRA-VARIABLE='17'
               MOVE NRA-SEGMENTO                 TO WS-VAL-LIBRAN
               SET IND-DESTINO TO 1
               SEARCH WTL-DESTINO
                AT END
                  MOVE CTE-UGE0939               TO CAA-COD-ERROR
                  MOVE 'ERROR DESTINO   LIB.'    TO CAA-VAR1-ERROR
                  MOVE WS-VAL-LIBRAN             TO CAA-VAR2-ERROR
                  MOVE 'NO EN UGDTT37 9966  '    TO CAA-VAR2-ERROR(5:)
                  MOVE 'SIN CATALOGAR'           TO NRA-DESTINO
                WHEN W-DES-VALOR(IND-DESTINO) = WS-VAL-LIBRAN
                  MOVE W-DES-DESCRI(IND-DESTINO) TO NRA-DESTINO
               END-SEARCH
           END-IF
           .
      *COL02-F
      *COL08-I
      * -------------------------------------------------------------- *
      *                 9999-CONSULTA-DESTINO-T37                      *
      *  CONSULTA LA SECCION 9639 CON PREFIJO D- PARA OBTENER LA       *
      *  DESCRIPCION DEL DESTINO DEL CLUSTER EN LINEAS HIPOTECARIO     *
      *  O LEASING.                                                    *
      * -------------------------------------------------------------- *
       9999-CONSULTA-DESTINO-T37.
           SET SW-NO-PARAM-T37              TO TRUE
           INITIALIZE UGWCIT37-REG
           MOVE CTE-ALF-9639               TO IT37-SECCION
           MOVE 'D-'                       TO IT37-ELEMENTO(1:2)
           MOVE NRA-SEGMENTO               TO WS-SEG-AUX
           MOVE WS-SEG-AUX                 TO IT37-ELEMENTO(3:1)
           MOVE CTE-ALF-D                  TO IT37-CICS
           EXEC CICS
                LINK PROGRAM(CTE-UR2CIT37)
                COMMAREA(UGWCIT37-REG)
                NOHANDLE
           END-EXEC
           EVALUATE IT37-CODRETORNO
              WHEN '00'
                 SET SW-SI-PARAM-T37        TO TRUE
                 MOVE IT37-RESTO(1:13)      TO NRA-COLECTI
              WHEN OTHER
                 SET SW-NO-PARAM-T37        TO TRUE
                 MOVE 'DEST. NO PARAM'      TO NRA-COLECTI
           END-EVALUATE.
      *COL08-F
      * -------------------------------------------------------------- *
       9999-PASADATANOVEDAD.
            EVALUATE WS-NRA-VARIABLE
               WHEN '01'
                   MOVE CTE-NA        TO NRA-PRODACT
               WHEN '02'
                   MOVE CTE-NA        TO NRA-PRODNEW
               WHEN '03'
                   MOVE CTE-NA        TO NRA-FECDBLO
               WHEN '04'
                   MOVE CTE-NA        TO NRA-DIASBLO
               WHEN '05'
                   MOVE CTE-NA        TO NRA-MRECHAZ
               WHEN '06'
                   MOVE CTE-NA        TO NRA-PLAZOPE
               WHEN '07'
                   MOVE CTE-NA        TO NRA-INDEDAD
               WHEN '08'
                   MOVE CTE-NA        TO NRA-INDSEGM
               WHEN '09'
                   MOVE CTE-NA        TO NRA-COLECTI
               WHEN '10'
                   MOVE CTE-NA        TO NRA-GRUPRIE
               WHEN '11'
                   MOVE CTE-NA        TO NRA-ESTVEHI
               WHEN '12'
                   MOVE CTE-NA        TO NRA-PORCFIN
               WHEN '13'
                   MOVE CTE-NA        TO NRA-GAMVEHI
               WHEN '14'
                   MOVE CTE-NA        TO NRA-TIPOUSO
               WHEN '15'
                   MOVE CTE-NA        TO NRA-CLIEVIP
      *COL02-I
               WHEN '16'
                   MOVE CTE-NA        TO NRA-COLECLB
      *            MOVE 'C2345678911' TO NRA-COLECLB
               WHEN '17'
                   MOVE CTE-NA        TO NRA-DESTINO
      *            MOVE 'D2345678911' TO NRA-DESTINO
      *COL02-F
      *COL04-I
               WHEN '18'
                   STRING '  : ', CTE-NA
                   DELIMITED BY SIZE
                     INTO WS-CONCATENA
                   MOVE WS-CONCATENA  TO NRA-VENTASC
               WHEN '19'
                   MOVE CTE-NA        TO NRA-TIPPERS
               WHEN '20'
                   MOVE CTE-NA        TO NRA-CRATING
               WHEN '21'
                   MOVE CTE-NA        TO NRA-RRATING
               WHEN '22'
                   MOVE CTE-NA        TO NRA-GARANTC
               WHEN '23'
                   STRING '  : ', CTE-NA
                   DELIMITED BY SIZE
                     INTO WS-CONCATENA
                   MOVE WS-CONCATENA  TO NRA-MOPERAC
      *COL04-F
            END-EVALUATE.
      * -------------------------------------------------------------- *
       300000-PROCESO-FIN.
           IF CAA-COD-ERROR NOT EQUAL SPACES AND LOW-VALUES
              MOVE '+TOT'                        TO W-DC
              MOVE CAA-TERMINAL                  TO W-SUFIJO-TS
              PERFORM 31-BORRAR-TS
           END-IF
            EXEC CICS RETURN END-EXEC.
      *----------------------------------------------------------------*
      *                         31-BORRAR-TS                           *
      *  - SE BORRA LA POSIBLE COLA TS +TOTXXXX QUE PUDIESE EXISTIR    *
      *----------------------------------------------------------------*
       31-BORRAR-TS.
            EXEC CICS
                 DELETEQ TS
                 QUEUE(W-TS)
                 NOHANDLE
            END-EXEC
            EVALUATE EIBRESP
                 WHEN (DFHRESP(NORMAL))
                      CONTINUE
                 WHEN (DFHRESP(QIDERR))
                      CONTINUE
                 WHEN OTHER
                      MOVE 'BORRAR TS'         TO WS-REFERENCIA
                      PERFORM 999999-ABEND-CICS
            END-EVALUATE.
      * -------------------------------------------------------------- *
       999999-ABEND-CICS.
            INITIALIZE          QGECABC
            MOVE '+TOT'         TO W-DC                                 00827200
            MOVE CAA-TERMINAL   TO W-SUFIJO-TS                          00827300
            PERFORM 241-BORRAR-TS                                       00827400
            MOVE '+DC2'         TO W-DC                                 00827500
            MOVE CAA-TERMINAL   TO W-SUFIJO-TS                          00827600
            PERFORM 241-BORRAR-TS                                       00827700
                                                                        00827810
            MOVE '+QH1'         TO W-DC                                 00827820
            MOVE CAA-TERMINAL   TO W-SUFIJO-TS                          00827830
            PERFORM 241-BORRAR-TS                                       00827840
            MOVE CTE-S          TO ABC-ABEND
            MOVE CTE-UG2CUNRA   TO ABC-PROGRAMA
            MOVE EIBFN          TO ABC-EIBFN
            MOVE EIBRSRCE       TO ABC-EIBRSRCE
            MOVE EIBRCODE       TO ABC-EIBRCODE
            MOVE EIBRESP        TO ABC-EIBRESP1
            MOVE EIBRESP2       TO ABC-EIBRESP2
            EXEC CICS
                 LINK PROGRAM ('QG1CABC')
                 COMMAREA (QGECABC)
            END-EXEC.
            EJECT
      * -------------------------------------------------------------- *
      *                 241-BORRAR-TS                                  *00818600
      *  - SE BORRA LA POSIBLE COLA TS +DC1XXXX QUE PUDIESE EXISTIR    *00818800
      *----------------------------------------------------------------*00818400
       241-BORRAR-TS.                                                   00819100
           EXEC CICS                                                    00819300
              DELETEQ TS                                                00819400
              QUEUE(W-TS)                                               00819500
              NOHANDLE                                                  00819600
           END-EXEC                                                     00819700
           EVALUATE EIBRESP                                             00819900
              WHEN (DFHRESP(NORMAL))                                    00820000
                 CONTINUE                                               00820100
              WHEN (DFHRESP(QIDERR))                                    00820200
                 CONTINUE                                               00820300
              WHEN OTHER                                                00820400
                 MOVE 'BORRAR TS'      TO ABC-REFERENCIA                00820500
                 PERFORM 999999-ABEND-CICS                              00820600
           END-EVALUATE.                                                00820700
      *----------------------------------------------------------------*