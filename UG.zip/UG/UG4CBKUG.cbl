      *_____________________ INICIO PROGRAMA __________________________*
       IDENTIFICATION DIVISION.
       PROGRAM-ID. UG4CBKUG.
       AUTHOR. CARLOS FABIAN GONZALEZ CORTES(BBVA)
       DATE-WRITTEN.  04/03/2024.
      *________________________________________________________________*
      *                     DESCRIPCION DEL PROCESO                    *
      *                                                                *
      *   REALIZA LA CRUD DE LA TODAS LAS TABLA DE PRESTAMOS           *
      *                                                                *
      * FEATURE....: COLWSMANTE-185                                    *
      * ENABLER....: N/A                                               *
      *                                                                *
      *________________________________________________________________*
      *                    LOG DE MODIFICACIONES                       *
      *________________________________________________________________*
      *  AUTOR   FECHA     PETICION          DESCRIPCION               *
      * _______ __________ _________ ________________________________  *
      * COL01   2024-07-04 COLWSMANTE-187 SE AJUSTA PROGRAMA DEL COMMIT*
      * CFGC               AL IR PARALELOS SE CRUZAN CON OTRAS TABLAS  *
      * C342057 VD1                                                    *
      * _______ __________ _________ ________________________________  *
      * COL02   2024-11-15 COLONEPRE1-3561 MN - MEJORAS AL PROCESO DE
      * CE56756            DEPURACIóN DE PRESTAMOS                     *
      * _______ __________ _________ ________________________________  *
      * COL03   2024-11-25 COLONEPRE1-5047 INC000102438012 - CANCELACIóN
      * CE56756            JCL PRESTAMOS PUGSRT01                      *
      *________________________________________________________________*
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
      *________________________________________________________________*
      *                   FICHERO DE ENTRADA 1 (TABLA UGDTMAE)         *
      *________________________________________________________________*
           SELECT E1DTBKUG  ASSIGN       TO E1DTBKUG
                            FILE STATUS  IS WSS-FSVALOR.

      *________________________________________________________________*
      *                   FICHERO DE SALIDA  (DATOS OKEY)              *
      *________________________________________________________________*
           SELECT S1DTBKUG  ASSIGN       TO S1DTBKUG
                            FILE STATUS  IS WSS-FSVALOR.

      *________________________________________________________________*
      *                   FICHERO DE SALIDA2 (DATOS RECHAZADOS)        *
      *________________________________________________________________*
           SELECT S2DTBKUG  ASSIGN       TO S2DTBKUG
                            FILE STATUS  IS WSS-FSVALOR.

      *________________________________________________________________*
      *                   DATA DIVISION                                *
      *________________________________________________________________*
       DATA DIVISION.
       FILE SECTION.

       FD   E1DTBKUG
            RECORDING MODE IS F
            BLOCK CONTAINS 0 RECORDS
            LABEL RECORD IS STANDARD.
       01   REG-ENTRADA           PIC X(1000).

       FD   S1DTBKUG
            RECORDING MODE IS F
            BLOCK CONTAINS 0 RECORDS
            LABEL RECORD IS STANDARD.
       01   REG-SALIDA1           PIC X(1000).

       FD   S2DTBKUG
            RECORDING MODE IS F
            BLOCK CONTAINS 0 RECORDS
            LABEL RECORD IS STANDARD.
       01   REG-SALIDA2           PIC X(1000).

       WORKING-STORAGE SECTION.
      *________________________________________________________________*
      *                          CONSTANTES                            *
      *________________________________________________________________*
       01 WSC-CONSTANTES.
          05 WSC-ERROR-OPEN-F1   PIC X(20) VALUE 'ERROR OPEN E1DTBKUG'.
          05 WSC-ERROR-OPEN-F3   PIC X(20) VALUE 'ERROR OPEN S1DTBKUG'.
          05 WSC-ERROR-OPEN-F4   PIC X(20) VALUE 'ERROR OPEN S2DTBKUG'.
          05 WSC-ERROR-READ-F1   PIC X(20) VALUE 'ERROR READ E1DTBKUG'.
          05 WSC-ERROR-WRITE-F3  PIC X(20) VALUE 'ERROR WRITE S1DTBKUG'.
          05 WSC-ERROR-WRITE-F4  PIC X(20) VALUE 'ERROR WRITE S2DTBKUG'.
          05 WSC-ERROR-CLOSE-F1  PIC X(20) VALUE 'ERROR CLOSE E1DTBKUG'.
          05 WSC-ERROR-CLOSE-F3  PIC X(20) VALUE 'ERROR CLOSE S1DTBKUG'.
          05 WSC-ERROR-CLOSE-F4  PIC X(20) VALUE 'ERROR CLOSE S2DTBKUG'.
          05 WSC-N-12                      PIC 9(02) VALUE 12.
          05 WSC-N-1                       PIC 9(01) VALUE 1.
          05 WSC-00                        PIC 9(02) VALUE 00.
          05 WSC-PROGRAMA                  PIC X(08) VALUE 'UG4CBKUG'.

      *________________________________________________________________*
      *                            SWITCHES                            *
      *________________________________________________________________*
       01 WSS-SWITCHES.
          05 WSS-FSVALOR                   PIC X(02) VALUE SPACES.
             88 WSS-FSVALOR-NORMAL                   VALUE '00'.
             88 WSS-FSVALOR-EOF                      VALUE '10'.
          05 WSS-EOF-FILE1                 PIC X(01) VALUE SPACES.
             88 WSS-EOF-FILE1-SI                     VALUE 'S'.
             88 WSS-EOF-FILE1-NO                     VALUE 'N'.

      *________________________________________________________________*
      *                         VARIABLES                              *
      *________________________________________________________________*
       01 WSV-VARIABLES.
          05 WSV-LEIDOS-E1                 PIC 9(08) VALUE ZEROS.
          05 WSV-GRABADOS-S1               PIC 9(08) VALUE ZEROS.
          05 WSV-GRABADOS-S2               PIC 9(08) VALUE ZEROS.
          05 WSV-ERRORES                   PIC X(40) VALUE SPACES.
          05 WSV-COD-ERROR                 PIC X(09) VALUE SPACES.
          05 WSV-COD-TIPO                  PIC X(20) VALUE SPACES.
          05 WK-MASCARA                    PIC ZZ,ZZZ,ZZ9.
          05 WSV-COPY                      PIC 9(04) VALUE ZEROS.
      *--------------------------------------------------------------*
      *    VARIABLES PARA HACER LOS RELANZAMIENTOS                    *
      *--------------------------------------------------------------*
       01  VARIABLES-DE-CALL.
           03 W-QG9C0020               PIC X(08) VALUE 'QG9C0020'.
       01  VARIABLES-COMMIT.
           03 VARC-CONTADOR            PIC 9(06) COMP VALUE 0.
           03 VARC-PROGRAMA            PIC X(08) VALUE 'UG4CBKUG'.
           03 VARC-RECUPERA.
              05 VARC-LEIDOS           PIC 9(10) COMP VALUE 0.
              05 VARC-LLAVE.
                 07 VARC-MAE-ENTIOFI   PIC X(08).
                 07 VARC-MAE-CUENTA    PIC X(10).

      *COL01-I
      *----------------------------------------------------------------*
      *         INCLUDE DE LOS MENSAJES DE ERROR DB2                   *
      *----------------------------------------------------------------*
           EXEC SQL
              INCLUDE SQLCA
           END-EXEC.
      *COL01-F
      *________________________________________________________________*
      *                          COPYS                                 *
      *________________________________________________________________*

      *COPY DE LA RUTINA TODAS LAS RUTINAS DE PRESTAMOS
       COPY UGWCBKUG.
      *----------------------------------------------------------------*
      * COPY PARA LA RUTINA DE RELANZAMIENTO QG9C0020                  *
      *----------------------------------------------------------------*
       COPY QGWC002.

      *________________________________________________________________*
      *                     LINKAGE SECTION
      *________________________________________________________________*
       LINKAGE SECTION.

       01 LNK-AREA.
          03 LNK-LONGITUD                        PIC X(02).
          03 LNK-TABLA                           PIC X(07).
          03 LNK-LONGUITUD                       PIC 9(04).
          03 LNK-RUTINA                          PIC X(08).
          03 LNK-OPCION                          PIC X(02).
          03 LNK-COMMIT                          PIC 9(05).

      *________________________________________________________________*
      *                      PROCEDURE DIVISION                        *
      *________________________________________________________________*
       PROCEDURE DIVISION USING LNK-AREA.

      *________________________________________________________________*
      *                        000000-CONTROL                          *
      *________________________________________________________________*
       000000-CONTROL.

           DISPLAY '*_________________________________________*'
           DISPLAY '                 BANCO BBVA'
           DISPLAY '             PROGRAMA UG4CBKUG'
           DISPLAY '*_________________________________________*'
           DISPLAY ' '

           PERFORM 100000-INICIO
           PERFORM 200000-PROCESO UNTIL WSS-EOF-FILE1-SI
           PERFORM 300000-FINAL.

      *________________________________________________________________*
      *                        100000-INICIO                           *
      *________________________________________________________________*
       100000-INICIO.

           INITIALIZE WSV-VARIABLES
      *COL01-I
           MOVE LNK-RUTINA                 TO VARC-PROGRAMA
      *COL01-F

           SET WSS-EOF-FILE1-NO            TO TRUE

           PERFORM 100100-ABRIR-ARCHIVOS
           PERFORM 22-CONT-RELANZA
           PERFORM 100200-LEER-ARCHIVO1.

      *________________________________________________________________*
      *                 100100-ABRIR-ARCHIVOS                          *
      *________________________________________________________________*
       100100-ABRIR-ARCHIVOS.

           OPEN INPUT E1DTBKUG
           IF NOT WSS-FSVALOR-NORMAL
               MOVE WSC-ERROR-OPEN-F1      TO WSV-ERRORES
               MOVE WSS-FSVALOR            TO WSV-COD-ERROR
               MOVE WSC-N-12               TO RETURN-CODE
               PERFORM 300400-MENSAJES
               STOP RUN
           END-IF

           OPEN OUTPUT S1DTBKUG
           IF NOT WSS-FSVALOR-NORMAL
               MOVE WSC-ERROR-OPEN-F3      TO WSV-ERRORES
               MOVE WSS-FSVALOR            TO WSV-COD-ERROR
               MOVE WSC-N-12               TO RETURN-CODE
               PERFORM 300400-MENSAJES
               STOP RUN
           END-IF

           OPEN OUTPUT S2DTBKUG
           IF NOT WSS-FSVALOR-NORMAL
               MOVE WSC-ERROR-OPEN-F4      TO WSV-ERRORES
               MOVE WSS-FSVALOR            TO WSV-COD-ERROR
               MOVE WSC-N-12               TO RETURN-CODE
               PERFORM 300400-MENSAJES
               STOP RUN
           END-IF.

      *________________________________________________________________*
      *                     100200-LEER-ARCHIVO1                       *
      *________________________________________________________________*
       100200-LEER-ARCHIVO1.

           INITIALIZE REG-ENTRADA

           READ E1DTBKUG AT END SET WSS-EOF-FILE1-SI TO TRUE
                     NOT AT END ADD WSC-N-1 TO WSV-LEIDOS-E1
           END-READ

           IF WSS-EOF-FILE1-SI
              CONTINUE
           ELSE
              IF NOT WSS-FSVALOR-NORMAL AND NOT WSS-FSVALOR-EOF
                 MOVE WSC-ERROR-READ-F1      TO WSV-ERRORES
                 MOVE WSS-FSVALOR            TO WSV-COD-ERROR
                 MOVE WSC-N-12               TO RETURN-CODE
                 PERFORM 300000-FINAL
              END-IF
           END-IF.

      *________________________________________________________________*
      *                         200000-PROCESO                         *
      *________________________________________________________________*
       200000-PROCESO.

           PERFORM 100100-ELIMINA-REGISTRO
           PERFORM 100200-LEER-ARCHIVO1.

      *________________________________________________________________*
      *                         200000-PROCESO                         *
      *________________________________________________________________*
       100100-ELIMINA-REGISTRO.

           INITIALIZE UGWCBKUG

           MOVE LNK-OPCION                 TO BKUG-OPCION
           MOVE REG-ENTRADA                TO BKUG-DATOS

           COMPUTE WSV-COPY = LNK-LONGUITUD + 60
           END-COMPUTE

           CALL LNK-RUTINA USING UGWCBKUG(1:WSV-COPY)

           MOVE SPACES
             TO UGWCBKUG((WSV-COPY + 1):)
           MOVE UGWCBKUG((LNK-LONGUITUD + 3):58)
             TO BKUG-SALIDA

           PERFORM 23-ACTUALIZA-RELANZA

           EVALUATE BKUG-RETORNO
               WHEN ZEROS
                    PERFORM 999999-ESCRIBIR-OK
               WHEN '10'
      *COL03-I
               WHEN '20'
      *COL03-F
                    PERFORM 999999-ESCRIBIR-NK
               WHEN OTHER
                    MOVE BKUG-DESCERROR    TO WSV-ERRORES
                    MOVE BKUG-SQL          TO WSV-COD-ERROR
                    MOVE BKUG-TABLA        TO WSV-COD-TIPO
      *COL01-I
                    DISPLAY 'UGWCBKUG: ' UGWCBKUG(1:WSV-COPY)
                    MOVE WSC-N-12               TO RETURN-CODE
                    PERFORM 300400-MENSAJES
                    STOP RUN
      *COL01-F
           END-EVALUATE.

      *________________________________________________________________*
      *                        999999-ESCRIBIR-OK                      *
      *________________________________________________________________*
       999999-ESCRIBIR-OK.

           INITIALIZE REG-SALIDA1

           MOVE BKUG-DATOS                 TO REG-SALIDA1

           WRITE REG-SALIDA1 END-WRITE

           EVALUATE TRUE
               WHEN WSS-FSVALOR-NORMAL
                    ADD WSC-N-1             TO WSV-GRABADOS-S1
               WHEN OTHER
                    MOVE WSC-ERROR-WRITE-F3 TO WSV-ERRORES
                    MOVE WSS-FSVALOR        TO WSV-COD-ERROR
                    MOVE WSC-N-12           TO RETURN-CODE
                    PERFORM 300000-FINAL
           END-EVALUATE.

      *________________________________________________________________*
      *                     999999-ESCRIBIR-NK                         *
      *________________________________________________________________*
       999999-ESCRIBIR-NK.

           INITIALIZE REG-SALIDA2

           MOVE BKUG-DATOS                 TO REG-SALIDA2

           WRITE REG-SALIDA2 END-WRITE

           EVALUATE TRUE
               WHEN WSS-FSVALOR-NORMAL
                    ADD WSC-N-1             TO WSV-GRABADOS-S2
               WHEN OTHER
                    MOVE WSC-ERROR-WRITE-F4 TO WSV-ERRORES
                    MOVE WSS-FSVALOR        TO WSV-COD-ERROR
                    MOVE WSC-N-12           TO RETURN-CODE
                    PERFORM 300000-FINAL
           END-EVALUATE.

      *________________________________________________________________*
      *                         300000-FINAL                           *
      *________________________________________________________________*
       300000-FINAL.

           PERFORM 300200-CERRAR-ARCHIVOS
           PERFORM 300300-ESTADISTICAS
           PERFORM 31-COMMIT-FINAL
           STOP RUN.

      *----------------------------------------------------------------*00202200
      * VERIFICA SI ES COMIENZO DE PROGRAMA O SI ES RELANZAMIENTO      *
      *----------------------------------------------------------------*00202200
       22-CONT-RELANZA.
           INITIALIZE QGWC002
           MOVE VARC-PROGRAMA          TO QGWC002-MPRGEX
           MOVE 'INI'                  TO QGWC002-CFUNEX
           CALL  W-QG9C0020           USING QGWC002
           IF QGWC002-CSTAMO = 111
              MOVE QGWC002-WBFREL      TO VARC-RECUPERA
              DISPLAY 'RELANZA DESDE CONTRATO: ' VARC-LLAVE
              DISPLAY 'REGISTRO :' VARC-LEIDOS
      *COL01-I
      *       PERFORM 100200-LEER-ARCHIVO1 VARC-LEIDOS TIMES
              PERFORM VARC-LEIDOS TIMES
                PERFORM 100200-LEER-ARCHIVO1
                MOVE REG-ENTRADA     TO BKUG-DATOS
                PERFORM 999999-ESCRIBIR-OK
              END-PERFORM
      *COL01-I
              MOVE    VARC-LEIDOS  TO  WSV-LEIDOS-E1
           END-IF.
      *----------------------------------------------------------------*00202200
      * SE REALIZA COMMIT PARCIAL                                      *
      *----------------------------------------------------------------*00202200
       23-ACTUALIZA-RELANZA.
           ADD 1 TO VARC-CONTADOR
           IF VARC-CONTADOR >= LNK-COMMIT
              INITIALIZE VARC-CONTADOR
              INITIALIZE QGWC002
              MOVE REG-ENTRADA(1:18) TO VARC-LLAVE
              MOVE WSV-LEIDOS-E1     TO VARC-LEIDOS
              MOVE VARC-PROGRAMA     TO QGWC002-MPRGEX
              MOVE VARC-RECUPERA     TO QGWC002-WBFREL
              MOVE 'COM'             TO QGWC002-CFUNEX
              MOVE 'P'               TO QGWC002-YOPREL
              CALL W-QG9C0020        USING QGWC002
           END-IF.
      *----------------------------------------------------------------*00202200
      * SE REALIZA COMMIT FINAL                                        *
      *----------------------------------------------------------------*00202200
       31-COMMIT-FINAL.
           INITIALIZE QGWC002
           MOVE REG-ENTRADA(1:18) TO VARC-LLAVE
           MOVE WSV-LEIDOS-E1     TO VARC-LEIDOS
           MOVE VARC-PROGRAMA     TO QGWC002-MPRGEX
           MOVE VARC-RECUPERA     TO QGWC002-WBFREL
           MOVE 'COM'             TO QGWC002-CFUNEX
           MOVE ' '               TO QGWC002-YOPREL
           CALL W-QG9C0020        USING QGWC002.

      *________________________________________________________________*
      *                    300200-CERRAR-ARCHIVOS                      *
      *________________________________________________________________*
       300200-CERRAR-ARCHIVOS.

           CLOSE E1DTBKUG
           IF NOT WSS-FSVALOR-NORMAL
               MOVE WSC-ERROR-CLOSE-F1     TO WSV-ERRORES
               MOVE WSS-FSVALOR            TO WSV-COD-ERROR
               MOVE WSC-N-12               TO RETURN-CODE
               PERFORM 300400-MENSAJES
               STOP RUN
           END-IF

           CLOSE S1DTBKUG
           IF NOT WSS-FSVALOR-NORMAL
               MOVE WSC-ERROR-CLOSE-F3     TO WSV-ERRORES
               MOVE WSS-FSVALOR            TO WSV-COD-ERROR
               MOVE WSC-N-12               TO RETURN-CODE
               PERFORM 300400-MENSAJES
               STOP RUN
           END-IF

           CLOSE S2DTBKUG
           IF NOT WSS-FSVALOR-NORMAL
               MOVE WSC-ERROR-CLOSE-F4     TO WSV-ERRORES
               MOVE WSS-FSVALOR            TO WSV-COD-ERROR
               MOVE WSC-N-12               TO RETURN-CODE
               PERFORM 300400-MENSAJES
               STOP RUN
           END-IF.

      *________________________________________________________________*
      *                        300300-ESTADISTICAS                     *
      *________________________________________________________________*
       300300-ESTADISTICAS.

           DISPLAY '*_________________________________________*'
           DISPLAY '*               ESTADISTICAS              *'
           DISPLAY '*            PROGRAMA UG4CBKUG            *'
           DISPLAY '*_________________________________________*'
           DISPLAY ' '
           DISPLAY ' '
           MOVE WSV-LEIDOS-E1                       TO WK-MASCARA
           DISPLAY ' REG LEIDOS DE ENTRADA A BORRAR   : ' WK-MASCARA
           DISPLAY ' '
           MOVE WSV-GRABADOS-S1                     TO WK-MASCARA
           DISPLAY ' REG BORRADOS DE LA TABLA 'LNK-TABLA' : ' WK-MASCARA
           MOVE WSV-GRABADOS-S2                     TO WK-MASCARA
           DISPLAY ' REG NO ENCONTRADOS TABLA 'LNK-TABLA' : ' WK-MASCARA
           DISPLAY '*_________________________________________*'

           IF RETURN-CODE > ZEROES
              DISPLAY ' EL PROGRAMA FINALIZO NOK'
           ELSE
              DISPLAY ' EL PROGRAMA FINALIZO OK'
           END-IF

           DISPLAY ' '
           DISPLAY '*_________________________________________*'.

      *________________________________________________________________*
      *                   300300-CANCELAR-PROGRAMA                     *
      *               SE CANCELA LA EJECUCION DEL PROGRAMA             *
      *________________________________________________________________*
       300300-CANCELAR-PROGRAMA.

           MOVE WSC-N-12                   TO RETURN-CODE
           STOP RUN.

      *________________________________________________________________*
      *                          300400-MENSAJES                       *
      *________________________________________________________________*
       300400-MENSAJES.

      *COL01-I
           PERFORM 999900-ROLLBACK
      *COL01-F
           DISPLAY '*_________________________________________*'
           DISPLAY '*               ESTADISTICAS              *'
           DISPLAY '*            PROGRAMA UG4CBKUG            *'
           DISPLAY '*_________________________________________*'
           DISPLAY ' '
           DISPLAY ' '
           DISPLAY ' DESCRIPCION = 'WSV-ERRORES
           DISPLAY ' CODIGO      = 'WSV-COD-ERROR
           DISPLAY ' TIPO        = 'WSV-COD-TIPO
           DISPLAY ' '
      *COL02-I
      *    DISPLAY '*_________________________________________*'.
           DISPLAY '*_________________________________________*'
           PERFORM  300300-CANCELAR-PROGRAMA
           .
      *COL02-F
      *COL01-I
      *----------------------------------------------------------------*
      *                     999900-ROLLBACK.                           *
      * - SE PRODUCE UN ERROR DB2 Y SE CANCELA EL PROGRAMA             *
      *----------------------------------------------------------------*
       999900-ROLLBACK.

           EXEC SQL
                ROLLBACK
           END-EXEC.

      *COL01-F

      *________________________ FIN PROGRAMA __________________________*