      ******************************************************************
      *        I D E N T I F I C A T I O N   D I V I S I O N           *
      ******************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID.    UG4CRAR1.
       AUTHOR.        INETUM.
       INSTALLATION.  BBVA.
       DATE-WRITTEN.  30-JUNIO-2021.
       DATE-COMPILED. JUNIO 2021.
      *
      *---------------------------------------------------------------* 00000100
      * AUTHOR.   INETUM - CE66059                                    * 00000200
      *           05-07-2021                                          * 00000300
      *           REALIZA LA CARGA MASIVA EN LA TABLA UGDTNRA RANGOS  * 00000400
      *           GP17916-HUQA-CCSS-6856                              * 00000500
      *---------------------------------------------------------------* 00000600
      *----------------------------------------------------------------*
      *                   LOG DE MODIFICACIONES                        *
      *                   ---------------------                        *
      *    USER     AAAA-MM-DD           MODIFICACION                  *
      *    ----     ----------           ------------                  *
      *----------------------------------------------------------------*
      * CE56375  28-10-2021 SE REALIZA AJUSTE VALIDAR CAMPOS NUMERICOS *
      *                     NO REALIZE CANCELACION                     *
      * COL01               RSD INC000007707205 PROCESO PUGDRAR3       *
      *----------------------------------------------------------------*
      * CE56375  28-10-2021 SE REALIZA AJUSTE VALIDAR ESTADO CLUSTER   *
      *                     EN CONSULTA                                *
      * COL02               RSD INC000007720682 PROCESO PUGDRAR1       *
      *--------------------------------------------------------------- *00000800
      * INETUM   21-01-2022 SE ADICIONA 2 COLUMNAS PARA INCLUIR CAMPOS *
      * COL03               COLECTIVO Y DESTINO MODELO RAR LIBRANZAS   *
      * SCRUM - SDA36560 - COLWSPREST-54 - COLWSPREST-383 OTORGAR TASAS*
      * PERSONALIZADAS LIBRANZAS                                       *
      *---------------------------------------------------------------* 00000800
      * C810846  10-03-2022 SE AJUSTA PARA VALIDAR LOS TIPOS DE PRODUC*
      * COL04               TOS HS Y HV PARA PRICING HIPOTECARIO      *
      *                     CCSS-13169                                *
      *----------------------------------------------------------------*00000800
      * C810908  01-04-2022 SE ADICIONAN NUEVAS COLUMNAS PARA INCLUIR  *
      * DCP                 NUEVAS VARIABLES AL MODELO RAR PARA        *
      * COL05               CARTERA COMERCIAL.                         *
      *                     -RANGO PARA VENTAS                         *
      *                     -TIPO PERSONA                              *
      *                     -CALIFICACION DEL RIESGO - RATING          *
      *                     -RANGO CALIFICACION RATING                 *
      *                     -IND GARANTIA                              *
      *                     -RANGO MONTO OPERACION                     *
      *                     -PORCENTAJE PERDIDA ESPERADA               *
      *                     -PORCENTAJE RORC                           *
      *                     -PORCENTAJE RAROEC                         *
      *                     -CAPITAL ECONOMICO                         *
      *                     GP-35771 COLWSCANAL-1036                   *
      *----------------------------------------------------------------*00000800
      * C810846  13-06-2023  SE REALIZA AJUSTE PARA CAMBIAR DE TAMA#O -*
      * GLADIADORES TEAM     VARIABLES CONSECUTIVO A NUMERICO(9).      *
      * COL06                COLWSPREST-15688.                         *
      *----------------------------------------------------------------*00000800
      * C810846  03-08-2023  SE REALIZA AJUSTE PARA QUE EL CAMPO       *
      * GLADIADORES TEAM     NRA_CONSECUTIVO INCIALICE EN 1 CADA VEZ   *
      * COL07                QUE SE REALICE UN NUEVO CARGUE.           *
      *                      COLWSPREST-7249.                          *
      *----------------------------------------------------------------*00000800
      * T000607  07-05-2024  SE REALIZA AJUSTE PARA ORDENAR EL CURSOR  *
      * GLADIADORES TEAM     CURSOR-NRA POR EL CAMPO NRA_CONSECUTIVO.  *
      * COL08                                                          *
      *                      COLWSINCID-11310. INC000101643446         *
      *----------------------------------------------------------------*00000800
      *COLWSPREST-26059
      *----------------------------------------------------------------*00000800
      * CE59519  09-08-2024  SE REALIZA AJUSTE PARA QUE EL CAMPO MONTOS*
      * GLADIADORES TEAM     SE OBSERVE DE MANERA CORRECTA.            *
      * COL09                COLONEPRE1-1629  CASO IM-663182-1-296701  *
      *----------------------------------------------------------------*00000800
      * REFERENCIA : COL10                                             *00002393
      * REALIZO    : EDINSON CALENO - T016395 - ACCENTURE LTDA         *00002394
      * FECHA      : 07/07/2024                                        *00002395
      * SDA-FEATURE: SDA-41748 / COLONECAPN-38                         *00002396
      * DESCRIPCION: CUOTA FIJA - TASA VARIABLE PARA CREDITOS DE       *00002397
      *              CONSUMO Y VEHICULO                                *00002398
      * METODOLOGIA  SE REALIZA AJUSTE PARA INCLUIR PARAMETRIA         *00002399
      * TRADICIONAL: MEDIANTE T37 PARA VALIDACION DE CLUSTERS ACTIVOS  *00002400
      *              SE COMENTAN LINEAS DE CONSTANTES DE VALIDACION Y  *00002400
      *              SE AGREGA CAMPO INDICADOR DE CLUSTER ACTIVO       *00002400
      *----------------------------------------------------------------*00002403
      * REFERENCIA : COL11                                             *00002393
      * REALIZO    : LUIS SANDON - C808648 - BBVA COLOMBIA             *00002394
      * FECHA      : 01/02/2026                                        *00002395
      * SDA-FEATURE: COLONEPRE1-16282                                  *00002396
      * HU         : COLONEPRE1-16737                                  *00002397
      * DESCRIPCION: SE AJUSTA PARA OPTIMIZAR EL PROCESO Y MEJORAR EL  *00002398
      *              CONSUMO DE CPU Y MEJORAR TIEMPOS DE RESPUEST      *00002399
      *----------------------------------------------------------------*00002403
      * REFERENCIA : COL12                                             *00002393
      * REALIZO    : JAYSON GABRIEL PINILLA SUAREZ - INETUM            *00002394
      * FECHA      : 26/03/2026                                        *00002395
      * SDA-FEATURE: COLONEPRE1-17080                                  *00002396
      * DESCRIPCION: AJUSTE PARA A#ADIR SITUACION LAB. 06 IND. NICHO   *00002398
      *----------------------------------------------------------------*00002403
      ******************************************************************
      *           E N V I R O N M E N T   D I V I S I O N              *
      ******************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
      *
      *----------------------------------------------------------------*
      *                   ARCHIVO DE ENTRADA
      *         DATOS DE ENTADA DEL NUEVO MODELO RAR
      *----------------------------------------------------------------*
           SELECT EUNIRAR             ASSIGN TO EUNIRAR
                  FILE STATUS                IS VAR-ESTADO.
      *
      *----------------------------------------------------------------*
      *                   ARCHIVO DE SALIDA 1
      *         DATOS DE SALIDA PARA GENERAR LA PARAMETRIA
      *----------------------------------------------------------------*
           SELECT SALIDA              ASSIGN TO SALIDA
                  FILE STATUS                IS VAR-SALIDA.
      *----------------------------------------------------------------*
      *                   ARCHIVO DE SALIDA 2
      *         DATOS DE ERRORES PARA GENERAR LA PARAMETRIA
      *----------------------------------------------------------------*
           SELECT ERRORES             ASSIGN TO ERRORES
                  FILE STATUS                IS VAR-ERROR.
      *
      *COL11-I
      *----------------------------------------------------------------*
      *                   ARCHIVO DE SALIDA 3                          *
      *         DATOS DE PARA INSERTAR EN LA UGDTNRA                   *
      *----------------------------------------------------------------*
           SELECT SUGDTNRA            ASSIGN TO SUGDTNRA
                  FILE STATUS                IS VAR-SUGDTNRA.
      *
      *COL11-F
      ******************************************************************
      *                  D A T A    D I V I S I O N                    *
      ******************************************************************
       DATA DIVISION.
       FILE SECTION.
      *
       FD  EUNIRAR   LABEL RECORD STANDARD
           RECORDING MODE IS F
           BLOCK CONTAINS 0.

       01  ENT-UGDTNRA.                                                 00000500
           10  ENT-TIPO-PRODUCTO            PIC X(02).                  00000800
           10  ENT-VALIDA-VARIABLE          PIC X(02).                  00000600
           10  ENT-VALIDA-VARIABLE-9 REDEFINES ENT-VALIDA-VARIABLE
                                            PIC 9(02).
      *COL01-I
      *    10  ENT-RANGO-INI                PIC 9(04).                  00001200
      *    10  ENT-RANGO-FIN                PIC 9(04).                  00001300
           10  ENT-RANGO-INIA               PIC X(04).
           10  ENT-RANGO-INI REDEFINES ENT-RANGO-INIA
                                            PIC 9(04).
           10  ENT-RANGO-FINA               PIC X(04).
           10  ENT-RANGO-FIN REDEFINES ENT-RANGO-FINA
                                            PIC 9(04).
      *COL01-F
           10  ENT-MONTO-INI                PIC X(10).                  00001500
           10  ENT-MONTO-FIN                PIC X(10).                  00001600
           10  ENT-IND-CLIENTE              PIC X(01).                  00001900
           10  ENT-IND-CLIENTE-9  REDEFINES ENT-IND-CLIENTE             00001900
                                            PIC 9(01).
      *COL05-I
           10  ENT-DATOS-COMER              PIC X(05).                  00001900
      *COL05-F
      *COL10-I
COL11 *    10  ENT-IND-ACTIVO               PIC X(01).                  00001900
      *COL10-F

       FD  SALIDA
           RECORDING   MODE        IS F
           LABEL RECORD           ARE  STANDARD
           BLOCK       CONTAINS     0 RECORDS
           RECORD      CONTAINS   179 CHARACTERS
           DATA        RECORD      IS SAL-UGTCNRA.
       01  SAL-UGTCNRA            PIC X(179).                           00000500
      *
       FD  ERRORES
           RECORDING   MODE        IS F
           LABEL RECORD           ARE  STANDARD
           BLOCK       CONTAINS     0 RECORDS
           RECORD      CONTAINS   150 CHARACTERS
           DATA        RECORD      IS REG-ERRORES.
       01  REG-ERRORES            PIC X(150).                           00000500
      *COL11-I
       FD  SUGDTNRA
           RECORDING   MODE        IS F
           LABEL RECORD           ARE  STANDARD
           BLOCK       CONTAINS     0 RECORDS
           RECORD      CONTAINS  1000 CHARACTERS
           DATA        RECORD      IS SAL-UGDTNRA.
       01  SAL-UGDTNRA            PIC X(1000).                          00000500
      *COL11-F
      *
      ******************************************************************
      *         W O R K I N G - S T O R A G E   S E C T I O N          *
      ******************************************************************
       WORKING-STORAGE SECTION.
      *
       01 W-ENT-MONTO-INI1.
          05 WA-ENT-MONTO-INI-E5-1          PIC X(05) VALUE SPACES.
          05 WA-ENT-MONTO-INI-PP-0          PIC X(01) VALUE SPACES.
          05 WA-ENT-MONTO-INI-D4-2          PIC X(04) VALUE SPACES.

       01 W-ENT-MONTO-INI2.
          05 WE-ENT-MONTO-INI2.
             10 WA-ENT-MONTO-INI-E5-R1      PIC X(05) VALUE SPACES.
             10 WA-ENT-MONTO-INI-D4-R2      PIC X(04) VALUE SPACES.
          05 WS-MONTO-INI-X9             REDEFINES WE-ENT-MONTO-INI2
                                            PIC X(09).

       01 W-ENT-MONTO-INI-N.
          05 WEMIN-ENT-MONTO-INI-9          PIC 9(09) VALUE ZEROES.

       01 W-ENT-MONTO-INI-FINAL.
          05 WMIF-ENT-MONTO-RFIN-1.
             10 WMIF-ENT-MONTO-REDFIN-9     PIC 9(09) VALUE ZEROES.
         05 WEMIF-ENT-MONTO-INI-REDFIN  REDEFINES WMIF-ENT-MONTO-RFIN-1
                                           PIC 9(05)V9(04).
      *
       01 W-ENT-MONTO-FIN1.
          05 WA-ENT-MONTO-FIN-E5-1          PIC X(05) VALUE SPACES.
          05 WA-ENT-MONTO-FIN-PP-0          PIC X(01) VALUE SPACES.
          05 WA-ENT-MONTO-FIN-D4-2          PIC X(04) VALUE SPACES.

       01 W-ENT-MONTO-FIN2.
          05 WE-ENT-MONTO-FIN2.
             10 WA-ENT-MONTO-FIN-E5-1R      PIC X(05) VALUE SPACES.
             10 WA-ENT-MONTO-FIN-D4-2R      PIC X(04) VALUE SPACES.
          05 WS-MONTO-FIN-X9                REDEFINES WE-ENT-MONTO-FIN2
                                            PIC X(09).

       01 W-ENT-MONTO-FIN-N.
          05 WEMIN-ENT-MONTO-FIN-9          PIC 9(09) VALUE ZEROES.

       01 W-ENT-MONTO-FIN-FINAL.
          05 WMIF-ENT-MONTO-RFON-1.
             10 WMIF-ENT-MONTO-REDFON-9     PIC 9(09) VALUE ZEROES.
         05 WEMIF-ENT-MONTO-INI-REDFON REDEFINES WMIF-ENT-MONTO-RFON-1
                                           PIC 9(05)V9(04).
       01 W-MONTO-INI-TAB.
          05 WMIT-MONTO-INI                PIC 9(05)V9(04).

       01 W-MONTO-FIN-TAB.
          05 WMFT-MONTO-FIN                PIC 9(05)V9(04).
      *COL05-I
       01 WS-TIP-PERSON                    PIC X(01).
       01 WS-NU                            PIC 9(05).
      *COL05-F
      *---------------------------------------------------------------*
      *  LINEA DE ENCABEZADO PARA EL GRABADO DE SALIDA                *
      *---------------------------------------------------------------*
      *
       01 W-ENCABEZADO-1.
          05 FILLER                         PIC X(09) VALUE 'PRODUCTO '.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 FILLER                         PIC X(08) VALUE 'VARIABLE'.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 FILLER                         PIC X(30) VALUE
                          'DESCRIPCION                   '.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 FILLER                         PIC X(12) VALUE
      *COL06-I
      *                   'CONSENCUTIVO'.
                          'CONSECUTIVO '.
      *COL06-F
          05 FILLER                         PIC X(01) VALUE '|'.
          05 FILLER                         PIC X(09) VALUE
                          'RANGO-INI'.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 FILLER                         PIC X(09) VALUE
                          'RANGO-FIN'.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 FILLER                         PIC X(10) VALUE
                          'MONTO-INI '.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 FILLER                         PIC X(10) VALUE
                          'MONTO-FIN '.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 FILLER                         PIC X(03) VALUE
                          'IND'.
          05 FILLER                         PIC X(01) VALUE '|'.
      *COL05-I
      *   05 FILLER                         PIC X(30) VALUE
      *                   'NOMBRE                        '.
          05 FILLER                         PIC X(07) VALUE
                          'DTS-COM'.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 FILLER                         PIC X(22) VALUE
                          'NOMBRE                '.
      *COL05-F
          05 FILLER                         PIC X(01) VALUE '|'.
          05 FILLER                         PIC X(10) VALUE
                          'FECHA-INI '.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 FILLER                         PIC X(25) VALUE
                          'CLAVE                   '.
      *
       01 W-ENCABEZADO-2.
          05 FILLER                         PIC X(179) VALUE ALL '-'.
      *
       01 W-LINEA-DETALLE-1.
          05 WLD1-PRODUCTO                  PIC X(09).
          05 FILLER                         PIC X(01) VALUE '|'.
          05 WLD1-VARIABLE                  PIC X(08).
          05 FILLER                         PIC X(01) VALUE '|'.
          05 WLD1-DESCRIPCION               PIC X(30).
          05 FILLER                         PIC X(01) VALUE '|'.
      *COL06-I
      *   05 WLD1-CONSENCUTIVO              PIC 99999.
          05 WLD1-CONSENCUTIVO              PIC 999999999.
      *   05 FILLER                         PIC X(07) VALUE SPACES.
          05 FILLER                         PIC X(03) VALUE SPACES.
      *COL06-F
          05 FILLER                         PIC X(01) VALUE '|'.
          05 WLD1-RANGO-INI                 PIC 9999.
          05 FILLER                         PIC X(05) VALUE SPACES.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 WLD1-RANGO-FIN                 PIC 9999.
          05 FILLER                         PIC X(05) VALUE SPACES.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 WLD1-MONTO-INI                 PIC 99999.9999.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 WLD1-MONTO-FIN                 PIC 99999.9999.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 WLD1-IND                       PIC X(01).
          05 FILLER                         PIC X(02) VALUE SPACES.
          05 FILLER                         PIC X(01) VALUE '|'.
      *COL05-I
      *   05 WLD1-NOMBRE                    PIC X(30).
          05 WLD1-DTOS-COMER                PIC X(07).
          05 FILLER                         PIC X(01) VALUE '|'.
          05 WLD1-NOMBRE                    PIC X(22).
      *COL05-F
          05 FILLER                         PIC X(01) VALUE '|'.
          05 WLD1-FECHA-INI                 PIC X(10).
          05 FILLER                         PIC X(01) VALUE '|'.
          05 WLD1-CLAVE                     PIC X(25).
      *---------------------------------------------------------------- 00044200
      * LINEA DE ENCABEZADO PARA EL GRABADO DE ERRORES                 *00044300
      *---------------------------------------------------------------- 00044400
      *                                                                 00044500
       01 W-ENCABEZADO-3.
          05 FILLER                         PIC X(09) VALUE 'PRODUCTO '.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 FILLER                         PIC X(08) VALUE 'VARIABLE'.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 FILLER                         PIC X(30) VALUE
                          'DESCRIPCION                   '.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 FILLER                         PIC X(12) VALUE
      *COL06-I
      *                   'CONSENCUTIVO'.
                          'CONSECUTIVO '.
      *COL06-F
          05 FILLER                         PIC X(01) VALUE '|'.
          05 FILLER                         PIC X(09) VALUE
                          'RANGO-INI'.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 FILLER                         PIC X(09) VALUE
                          'RANGO-FIN'.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 FILLER                         PIC X(10) VALUE
                          'MONTO-INI '.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 FILLER                         PIC X(10) VALUE
                          'MONTO-FIN '.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 FILLER                         PIC X(03) VALUE
                          'IND'.
          05 FILLER                         PIC X(01) VALUE '|'.

       01 W-ENCABEZADO-4.
          05 FILLER                         PIC X(128) VALUE ALL '-'.

       01 W-LINEA-DETALLE-2.
          05 WLD2-PRODUCTO                  PIC X(09).
          05 FILLER                         PIC X(01) VALUE '|'.
          05 WLD2-VARIABLE                  PIC X(08).
          05 FILLER                         PIC X(01) VALUE '|'.
          05 WLD2-DESCRIPCION               PIC X(30).
          05 FILLER                         PIC X(01) VALUE '|'.
      *COL06-I
      *   05 WLD2-CONSENCUTIVO              PIC 99999.
          05 WLD2-CONSENCUTIVO              PIC 999999999.
      *   05 FILLER                         PIC X(07) VALUE SPACES.
          05 FILLER                         PIC X(03) VALUE SPACES.
      *COL06-F
          05 FILLER                         PIC X(01) VALUE '|'.
          05 WLD2-RANGO-INI                 PIC 9999.
          05 FILLER                         PIC X(05) VALUE SPACES.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 WLD2-RANGO-FIN                 PIC 9999.
          05 FILLER                         PIC X(05) VALUE SPACES.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 WLD2-MONTO-INI                 PIC 99999.9999.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 WLD2-MONTO-FIN                 PIC 99999.9999.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 WLD2-IND                       PIC X(01).
          05 FILLER                         PIC X(02) VALUE SPACES.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 SERR-DETALLE-ERROR             PIC X(60).
      *----------------------------------------------------------------*
      *                    VARIABLES DE TRABAJO                        *
      *----------------------------------------------------------------*
      *
       01 WS-VARIABLES.
          05 WS-LLAVE                       PIC X(04).
          05 WS-LLAVE-AUX                   PIC X(04).
      *COL06-I
      *   05 WS-CONSECUTIVO                 PIC 9(05) VALUE ZEROES.
          05 WS-CONSECUTIVO                 PIC 9(09) VALUE ZEROES.
      *COL06-F
          05 WS-CONTA-REGS                  PIC S9(5) COMP.
          05 WS-CSC                         PIC 9(5) VALUE ZEROS.
      *COL01-I
          05 WS-C                           PIC X(01).
          05 WS-CN REDEFINES WS-C.
             10 WS-N                      PIC 9(01).
          05 WS-I                         PIC 9(02) VALUE ZEROS.
          05 WS-IND                       PIC 9(02) VALUE ZEROS.
          05 WS-STRING                    PIC X(10) VALUE SPACES.
      *COL11-I
      *   05 WS-RANGO-INI                 PIC 9(04) VALUE ZEROS.
      *   05 WS-RANGO-FIN                 PIC 9(04) VALUE ZEROS.
          05 WS-TIPO-PRODUCTO             PIC X(02) VALUE SPACES.
          05 WS-VARABLES-TRABAJO.
            10 WS-RANGO-INI                 PIC 9(04) VALUE ZEROS.
            10 WS-RANGO-FIN                 PIC 9(04) VALUE ZEROS.
            10 WS-DATOS-COMER               PIC X(02) VALUE SPACES.
            10 WS-IND-CLIENTE               PIC X(01) VALUE SPACES.
            10 WS-VIP-CLIENTE               PIC X(01) VALUE SPACES.
            10 WS-GARANTIA                  PIC X(01) VALUE SPACES.
            10 WS-TIP-VEHICULO              PIC X(01) VALUE SPACES.
            10 WS-ESTADO-VEHICULO           PIC X(01) VALUE SPACES.
            10 WS-SIT-LABORAL               PIC 9(01) VALUE ZEROS.
            10 WS-MIN-MONTO-INI             PIC 9(09) VALUE ZEROES.
            10 WS-MAX-MONTO-FIN             PIC 9(09) VALUE ZEROES.
            10 WS-FINA-MONTO-INI            PIC 9(09) VALUE ZEROES.
            10 WS-FINA-MONTO-FIN            PIC 9(09) VALUE ZEROES.
            10 WS-PORCFINA-MONTO-INI        PIC 9(09) VALUE ZEROES.
            10 WS-PORCFINA-MONTO-FIN        PIC 9(09) VALUE ZEROES.
            10 WS-GAMA-MONTO-INI            PIC 9(09) VALUE ZEROES.
            10 WS-GAMA-MONTO-FIN            PIC 9(09) VALUE ZEROES.
            10 WS-GRUP-MONTO-INI            PIC 9(09) VALUE ZEROES.
            10 WS-GRUP-MONTO-FIN            PIC 9(09) VALUE ZEROES.
            10 WS-VENT-MONTO-INI            PIC 9(09) VALUE ZEROES.
            10 WS-VENT-MONTO-FIN            PIC 9(09) VALUE ZEROES.
            10 WS-MONOPER-COMER-INI         PIC 9(09) VALUE ZEROES.
            10 WS-MONOPER-COMER-FIN         PIC 9(09) VALUE ZEROES.
            10 WS-PLAZO-INI                 PIC 9(04) VALUE ZEROS.
            10 WS-PLAZO-FIN                 PIC 9(04) VALUE ZEROS.
            10 WS-EDAD-INI                  PIC 9(04) VALUE ZEROS.
            10 WS-EDAD-FIN                  PIC 9(04) VALUE ZEROS.
            10 WS-SEGMENTO-INI              PIC 9(09) VALUE ZEROS.
            10 WS-COLECTIVO-INI             PIC 9(09) VALUE ZEROS.
          05 CURRENT-TIMESTAMP              PIC X(26).
      *COL11-F
       01 CONSTANTES.
COL11     05 CTEN-1                       PIC 9(01) VALUE 1.
          05 CTEN-04                      PIC 9(02) VALUE 04.
      *COL01-F
      *COL05-I
          05 CTEN-05                      PIC 9(02) VALUE 05.
      *COL05-F
      * COL03-I
          05 CTE-NA             PIC X(09) VALUE '000990000'.
      * COL03-F
      *
       01 WS-VARIABLES-COM.
          05 WS-PARM-COMMIT               PIC 9(04).
          05 WS-CONT-COMMIT               PIC 9(04).
      *----------------------------------------------------------------*
      *                         SWITCHES                               *
      *----------------------------------------------------------------*
      *
       01 SW-CORRECTO-PRODUCTO         PIC X(01) VALUE ZEROES.
           88 SI-CORRECTO-PROD                   VALUE 'S'.
           88 NO-CORRECTO-PROD                   VALUE 'N'.

       01 SW-CORRECTO                  PIC X(01) VALUE ZEROES.
           88 SI-CORRECTO                        VALUE 'S'.
           88 NO-CORRECTO                        VALUE 'N'.

       01 SW-CORRECTO-RANG             PIC X(01) VALUE ZEROES.
           88 SI-CORRECTO-RANGO                  VALUE 'S'.
           88 NO-CORRECTO-RANGO                  VALUE 'N'.

       01 SW-CORRECTO-RANG-FIN         PIC X(01) VALUE ZEROES.
           88 SI-CORRECTO-RANG-FIN               VALUE 'S'.
           88 NO-CORRECTO-RANG-FIN               VALUE 'N'.

       01 SW-VAL-DTE                   PIC X(01) VALUE 'S'.
           88 SI-VAL-NRA                         VALUE 'S'.
           88 NO-VAL-NRA                         VALUE 'N'.

       01  SW-FIN-EUNIRAR              PIC X(02)  VALUE 'NO'.
           88 SW-E1-FIN-SI                        VALUE 'SI'.
           88 SW-E1-FIN-NO                        VALUE 'NO'.

       01  VAR-ESTADO                  PIC X(02).
           88 ESTADO-OK                           VALUE '00'.
           88 ESTADO-10                           VALUE '10'.
       01  VAR-SALIDA                  PIC X(02).
           88 SALIDA-OK                           VALUE '00'.
           88 SALIDA-10                           VALUE '10'.
       01  VAR-ERROR                   PIC X(02).
           88 ERROR-OK                            VALUE '00'.
           88 ERROR-10                            VALUE '10'.
      *COL11-I
       01  VAR-SUGDTNRA                PIC X(02).
           88 SUGDTNRA-OK                         VALUE '00'.
           88 SUGDTNRA-10                         VALUE '10'.
      *COL11-F
      *
       01 W-FETCH.
      *COL11-I
      *    05 WS-FETCH                       PIC X(01) VALUE SPACES.
      *       88 WSF-SI-FETCH                         VALUE 'S'.
      *       88 WSF-NO-FETCH                         VALUE 'N'.
      *    05 WS-FETCH-FIN                   PIC X(01) VALUE SPACES.
      *       88 WSF-SFI-FETCH                        VALUE 'S'.
      *       88 WSF-NFI-FETCH                        VALUE 'N'.
      *    05 WS-VALIDA-INI                  PIC X(01) VALUE SPACES.
      *       88 WSF-SVA-FETCH                        VALUE 'S'.
      *       88 WSF-NVA-FETCH                        VALUE 'N'.
      *COL11-F
      *COL03-I
           05 WS-VALIDA-T37                  PIC X(01) VALUE SPACES.
              88 WSF-SVA-FET37                        VALUE 'S'.
              88 WSF-NVA-FET37                        VALUE 'N'.
      *COL03-F
      *COL01-I
           05 SW-NUMERICO                   PIC X(01)   VALUE 'S'.
              88 SI-NUMERICO                          VALUE 'S'.
              88 NO-NUMERICO                          VALUE 'N'.
      *COL01-F
      *
       01 WS-SWITCHES.                                                  00040900
          05 DB2-RETURN-CDE               PIC S9(9) COMP.               00041000
      *CUANDO REALIZAS UNA CONSULTA Y ENCUENTRA DATOS.
             88 DB2-OK                         VALUE +0.
      *CUANDO REALIZAS UNA CONSULTA Y NO ENCUENTRA DATOS.
             88 DB2-NOTFND                     VALUE +100.
      *CUANDO QUIERES EL MAXIMO Y NO ENCUENTRA REGISTRO REGRESA NULOS.
             88 DB2-NULL                       VALUE -305.
      *CUANDO REALIZAS UN .NSERT O ACTUALIZAR UN REGISTRO Y YA EXISTE.
             88 DB2-DUPL                       VALUE -803.
      *CUANDO REALIZAS UN UPDATE O SELECT Y EXISTE MAS DE UN REGISTRO.
             88 DB2-VARIOS                     VALUE -811.
      *CUANDO LA TABALA ESTA OCUPADA EN ELGUN PROCESO O POR UN USUARIO.
             88 DB2-NODISP                     VALUE -911.              00041400
      *CUANDO REALIZAS UN UPDATE O INSERT Y ESTAN OCUPANDO LA TABLA.
             88 DB2-ATRAPA                     VALUE -904.              00041500

       01 VARIABLE-SQLCODE-ED.
           05 WVS-SQLCODE-ED                   PIC -ZZZ9.
      *
      *----------------------------------------------------------------*
      *     VARIABLES FECHAS.                                          *
      *----------------------------------------------------------------*
       01  WS-FECHA-SQL.
           05 WSV-TIMESTAMP-INI             PIC X(26) VALUE SPACES.
      *----------------------------------------------------------------*
      *     TABLA CLAVE DE INDENTIFICACION NRA_CLAVE_ID                *
      *----------------------------------------------------------------*
       01 TABLA1.
           05 W-TABLA-DESCR.
              10 FILLER       PIC X(23) VALUE 'BURO                   '.
              10 FILLER       PIC X(23) VALUE 'DOM NOMINA             '.
              10 FILLER       PIC X(23) VALUE 'SITUACION LABORAL      '.
              10 FILLER       PIC X(23) VALUE 'INGRESO                '.
              10 FILLER       PIC X(23) VALUE 'MONTO FINANCIADO       '.
              10 FILLER       PIC X(23) VALUE 'PLAZO OPERACION        '.
              10 FILLER       PIC X(23) VALUE 'EDAD                   '.
              10 FILLER       PIC X(23) VALUE 'SEGMENTO               '.
              10 FILLER       PIC X(23) VALUE 'COLECTIVO              '.
              10 FILLER       PIC X(23) VALUE 'GRUPO RIESGO           '.
              10 FILLER       PIC X(23) VALUE 'ESTADO VEHI NUEVO/USADO'.
              10 FILLER       PIC X(23) VALUE '% FINANCIACION         '.
              10 FILLER       PIC X(23) VALUE 'GAMA VEHICULO          '.
              10 FILLER       PIC X(23) VALUE 'TIPO USO/PART/PUBLICO  '.
              10 FILLER       PIC X(23) VALUE 'CLIENTE VIP            '.
      *COL03-I
              10 FILLER       PIC X(23) VALUE 'COLECTIVO LIBRANZA     '.
              10 FILLER       PIC X(23) VALUE 'DESTINO LIBRANZA       '.
      *COL03-F
      *COL05-I
              10 FILLER       PIC X(23) VALUE 'VENTAS COMERCIAL       '.
              10 FILLER       PIC X(23) VALUE 'TIPO PERSONA PJ/PN     '.
              10 FILLER       PIC X(23) VALUE 'CALIF RIESGO COMERCIAL '.
              10 FILLER       PIC X(23) VALUE 'RANGO RATING COMERCIAL '.
              10 FILLER       PIC X(23) VALUE 'IND GARANTIA S/N       '.
              10 FILLER       PIC X(23) VALUE 'MONTO OPERACION COMER  '.
      *COL05-F
           05 W-TAB-DESCP
              REDEFINES W-TABLA-DESCR.
      *COL03-I
      *       10 WTD-DESCR               PIC X(23) OCCURS 15 TIMES.
      *COL05-I
      *       10 WTD-DESCR               PIC X(23) OCCURS 17 TIMES.
              10 WTD-DESCR               PIC X(23) OCCURS 23 TIMES.
      *COL05-F
      *COL03-F

       01 TABLA2.
           05 W-TABLA-LETRAS.
              10 FILLER                     PIC X(01) VALUE 'A'.
              10 FILLER                     PIC X(01) VALUE 'B'.
              10 FILLER                     PIC X(01) VALUE 'C'.
              10 FILLER                     PIC X(01) VALUE 'D'.
              10 FILLER                     PIC X(01) VALUE 'E'.
              10 FILLER                     PIC X(01) VALUE 'F'.
              10 FILLER                     PIC X(01) VALUE 'G'.
              10 FILLER                     PIC X(01) VALUE 'H'.
              10 FILLER                     PIC X(01) VALUE 'I'.
              10 FILLER                     PIC X(01) VALUE 'J'.
              10 FILLER                     PIC X(01) VALUE 'K'.
              10 FILLER                     PIC X(01) VALUE 'L'.
              10 FILLER                     PIC X(01) VALUE 'M'.
              10 FILLER                     PIC X(01) VALUE 'N'.
              10 FILLER                     PIC X(01) VALUE '#'.
              10 FILLER                     PIC X(01) VALUE 'O'.
              10 FILLER                     PIC X(01) VALUE 'P'.
              10 FILLER                     PIC X(01) VALUE 'Q'.
              10 FILLER                     PIC X(01) VALUE 'R'.
              10 FILLER                     PIC X(01) VALUE 'S'.
              10 FILLER                     PIC X(01) VALUE 'T'.
              10 FILLER                     PIC X(01) VALUE 'U'.
              10 FILLER                     PIC X(01) VALUE 'V'.
              10 FILLER                     PIC X(01) VALUE 'W'.
              10 FILLER                     PIC X(01) VALUE 'X'.
              10 FILLER                     PIC X(01) VALUE 'Y'.
              10 FILLER                     PIC X(01) VALUE 'Z'.
           05 W-TAB-LETRAS
              REDEFINES W-TABLA-LETRAS.
              10 WTL-LETRAS                 PIC X(01) OCCURS 27 TIMES.

       01 TABLA3.
           05 W-TABLA-LABORAL.
              10 FILLER                 PIC X(13) VALUE 'FIJO         '.
              10 FILLER                 PIC X(13) VALUE 'TEMPORAL     '.
              10 FILLER                 PIC X(13) VALUE 'INDEPENDIENTE'.
              10 FILLER                 PIC X(13) VALUE 'OTRO         '.
              10 FILLER                 PIC X(13) VALUE 'PENSIONADO   '.
      *COL12-I
              10 FILLER                 PIC X(13) VALUE 'INDEP. NICHO '.
      *COL12-F
           05 W-TAB-LABORAL
              REDEFINES W-TABLA-LABORAL.
      *COL12-I
      *       10 WTL-LABORAL            PIC X(13) OCCURS 05 TIMES.
              10 WTL-LABORAL            PIC X(13) OCCURS 06 TIMES.
      *COL12-F
      *COL03-I
           05 W-TAB-COLECTI.
              10 WTL-COLECTI                      OCCURS 99 TIMES
                                            INDEXED BY IND-COLECTI.
                 15 W-COL-VALOR         PIC 9(03) VALUE ZERO.
                 15 W-COL-DESCRI        PIC X(20) VALUE SPACE.
           05 W-TAB-DESTINO.
              10 WTL-DESTINO                      OCCURS 99 TIMES
                                            INDEXED BY IND-DESTINO.
                 15 W-DES-VALOR         PIC 9(03) VALUE ZERO.
                 15 W-DES-DESCRI        PIC X(20) VALUE SPACE.
      *COL03-F

      ******************************************************************
      *     DEFINICION DE VARIABLES PARA EL MANEJO DE FECHAS           *
      ******************************************************************
       01  W-FECHAS.
           03 W-FECHA-HOY.
              05 W-ANO-HOY             PIC  9(02).
              05 W-MES-HOY             PIC  9(02).
              05 W-DIA-HOY             PIC  9(02).
           03 W-FECHA-DISPLAY.
              05 W-ANO-DIS             PIC  9(04).
              05 FILLER                PIC  X(01)        VALUE '-'.
              05 W-MES-DIS             PIC  9(02).
              05 FILLER                PIC  X(01)        VALUE '-'.
              05 W-DIA-DIS             PIC  9(02).
           03 W-HORA-HOY.
              05 W-HH-HOY              PIC  9(02).
              05 W-MM-HOY              PIC  9(02).
              05 W-SS-HOY              PIC  9(02).
              05 W-MS-HOY              PIC  9(02).
           03 W-HORA-DISPLAY.
              05 W-HH-DIS              PIC  9(02).
              05 FILLER                PIC  X(01)        VALUE '.'.
              05 W-MM-DIS              PIC  9(02).
              05 FILLER                PIC  X(01)        VALUE '.'.
              05 W-SS-DIS              PIC  9(02).
              05 FILLER                PIC  X(01)        VALUE '.'.
              05 W-MS-DIS              PIC  9(02).
           03 WS-FECHA-1.
              05 WS-ANO                  PIC X(04)   VALUE ZEROES.
              05 WS-RELLENO1             PIC X(01)   VALUE ZEROES.
              05 WS-MES                  PIC X(02)   VALUE ZEROES.
              05 WS-RELLENO2             PIC X(01)   VALUE ZEROES.
              05 WS-DIA                  PIC X(02)   VALUE ZEROES.

       01 WS-TIMESTAMP.
          05 WS-FECHA                    PIC  X(10).
          05 FILLER                      PIC  X(1)  VALUE '-'.
          05 WS-HORA                     PIC  X(11) VALUE '-'.
          05 WS-MILISEG                  PIC  9(4).
      *
      ******************************************************************
      *                     CONSTANTES                                 *
      ******************************************************************
       01  WC-CONSTANTES.

          05 BBVA-TC8C1220               PIC X(08) VALUE 'TC8C1220'.
          05 WC-FECHA-FIN                PIC X(10) VALUE '2099-12-30'.

      ******************************************************************
      *                     VARIABLES DE FECHA                 *
      ******************************************************************
       01 W-AAAAPMMPDD.
          05 W-AAAAPMMPDD-AAAA.
             10 W-AAAAPMMPDD-SS             PIC 99.
             10 W-AAAAPMMPDD-AA             PIC 99.
          05 FILLER                         PIC X     VALUE '-'.
          05 W-AAAAPMMPDD-MM                PIC 99.
          05 FILLER                         PIC X     VALUE '-'.
          05 W-AAAAPMMPDD-DD                PIC 99.

      ******************************************************************
      *                     CONTADORES                                 *
      ******************************************************************
       01 W-CONTADORES.

          03 WC-LEI-ENTRADA                 PIC 9(9) VALUE ZEROS.
          03 WC-GRABADO-TABLA               PIC 9(9) VALUE ZEROS.
          03 WC-GRABADO-ERROR               PIC 9(9) VALUE ZEROS.
          03 WC-GRABADO-SALIDA              PIC 9(9) VALUE ZEROS.
COL11     03 WC-GRABADO-SUGDTNRA            PIC 9(9) VALUE ZEROS.
COL11     03 WS-CONSECUTIVO01               PIC 9(9) VALUE ZEROES.
      *
      ******************************************************************
      *                 AREA DE COMUNICACION CON DB2                   *
      ******************************************************************
           EXEC SQL
               INCLUDE SQLCA
           END-EXEC.
      *
      ******************************************************************
      *      INCLUDE DE LA TABLA : UGDTNRA                             *
      ******************************************************************

           EXEC SQL
              INCLUDE UGGTNRA
           END-EXEC.

           EXEC SQL
              INCLUDE UGTCNRA
           END-EXEC.
      *COL03-I
      ******************************************************************
      *       WORKAS DE LA TABLA DE DB2: UGDTT37                       *
      ******************************************************************
           EXEC SQL
             INCLUDE UGGTT37
           END-EXEC

           EXEC SQL
             INCLUDE UGTCT37
           END-EXEC
      *COL03-F

      *----------------------------------------------------------------*00039700
      * DECLARAR CURSOR DE LA TABLA UGDTNRA                            *00039800
      *----------------------------------------------------------------*00039900
      *COL11-I
      *    EXEC SQL                                                     00040000
      *       DECLARE  CURSOR-NRA CURSOR FOR                            00040100
      *        SELECT  NRA_TIPO_PRODUCTO,
      *                NRA_VARIABLE,
      *                NRA_CONSECUTIVO,
      *                NRA_RANGO_INI,
      *                NRA_RANGO_FIN,
      *                NRA_IND_DOM_NOMINA,
      *                NRA_SITUA_LABORAL,
      *                NRA_MONTO_INICIAL,
      *                NRA_MONTO_FINAL,
      *                NRA_SEGMENTO,
      *                NRA_IND_CLIENTE_VIP,
      *                NRA_RANGO_RIESGO_INI,
      *                NRA_RANGO_RIESGO_FIN,
      *                NRA_IND_ESTADO_VEH,
      *                NRA_IND_TIPO_VEH,
      *                NRA_CLAVE_ID,
      *                NRA_CLUSTER,
      *COL05-I
      *                NRA_ESTADO
      *                NRA_ESTADO,
      *                NRA_RATING,
      *                NRA_RANGO_RATING,
      *                NRA_GARANTIA,
      *                NRA_PORCENTA
      *COL05-F
      *        FROM  UGDTNRA
      *        WHERE NRA_TIPO_PRODUCTO = :NRA-TIPO-PRODUCTO
      *          AND NRA_VARIABLE      = :NRA-VARIABLE
      *          AND NRA_ESTADO        = :NRA-ESTADO
      *COL08-I
      *        ORDER BY NRA_CONSECUTIVO
      *COL08-F
      *    END-EXEC.
      *COL11-F
      *COL03-I
      *----------------------------------------------------------------*00039700
      * DECLARAR CURSOR DE LA TABLA UGDTT37                            *00039800
      *----------------------------------------------------------------*00039900
           EXEC SQL                                                     00040000
              DECLARE  CURSOR-T37 CURSOR FOR                            00040100
               SELECT  SECCION,
                       ELEMENTO,
                       RESTO
               FROM  UGDTT37
               WHERE SECCION = '9965'
                  OR SECCION = '9966'
               ORDER BY SECCION, ELEMENTO
           END-EXEC.
      *COL03-F
      *
      ******************************************************************00064300
      *                   L I N K A G E   S E C T I O N                *00064400
      ******************************************************************00064500
      *                                                                 00064600
       LINKAGE SECTION.                                                 00064700
          01 REG-PARM.                                                  00064800
             05 LK-PARM-LONG   PIC X(02).                               00064900
             05 LK-PARM-FECDIA PIC X(10).
             05 LK-PARM-COMMIT PIC X(04).                               00065000
      *                                                                 00065100
      ******************************************************************
      *             P R O C E D U R E   D I V I S I O N                *
      ******************************************************************
       PROCEDURE DIVISION.
      *
           PERFORM 10000-INICIO
           PERFORM 20000-PROCESO
                   UNTIL SW-E1-FIN-SI
           PERFORM 30000-FINAL
           .
      *
      ******************************************************************
      *                     10000-INICIO                               *
      ******************************************************************
       10000-INICIO.
      *
           MOVE LK-PARM-COMMIT                TO WS-PARM-COMMIT

           PERFORM 10000-FECHA-TIMESTAMP
           PERFORM 11000-ABRIR-ARCHIVOS
           PERFORM 11000-IMPRIME-ENC1-ENC2
           PERFORM 11100-IMPRIME-ENC1-ERROR
      *COL03-I
           PERFORM 11200-LLENA-TABLA-T37
      *COL03-F
           PERFORM 12000-INICIALIZAR
           PERFORM 13000-LEER-EUNIRAR
           .
      *
      ******************************************************************
      *                   10000-FECHA-TIMESTAMP                        *
      ******************************************************************
       10000-FECHA-TIMESTAMP.
      *
           EXEC SQL
                SET : WSV-TIMESTAMP-INI  = CURRENT TIMESTAMP
           END-EXEC
           .
      *
      ******************************************************************
      *                   11000-ABRE-ARCHIVOS                          *
      ******************************************************************
       11000-ABRIR-ARCHIVOS.

           OPEN  INPUT  EUNIRAR

           IF (VAR-ESTADO NOT = '00' AND NOT = '97') THEN
              MOVE 12            TO RETURN-CODE
              STOP RUN
           END-IF

           OPEN OUTPUT SALIDA

           IF (VAR-SALIDA NOT = '00' AND NOT = '97') THEN
              DISPLAY 'ERROR ABRIENDO EL ARCHIVO SALIDA  : ' VAR-SALIDA
              MOVE 12            TO RETURN-CODE
              CLOSE EUNIRAR SALIDA
              STOP RUN
           END-IF

           OPEN OUTPUT ERRORES

           IF (VAR-ERROR  NOT = '00' AND NOT = '97') THEN
              DISPLAY 'ERROR ABRIENDO EL ARCHIVO ERRORES : ' VAR-ERROR
              MOVE 12            TO RETURN-CODE
              CLOSE EUNIRAR ERRORES
              STOP RUN
           END-IF

      *COL11-I
           OPEN OUTPUT SUGDTNRA

           IF (VAR-SUGDTNRA NOT = '00' AND NOT = '97') THEN
              DISPLAY 'ERROR ABRIENDO EL ARCHIVO ERRORES : '
                                                      VAR-SUGDTNRA
              MOVE 12            TO RETURN-CODE
              CLOSE EUNIRAR ERRORES
              STOP RUN
           END-IF
      *COL11-F
           .
      *
      ******************************************************************
      *                   11000-IMPRIME-ENC1-ENC2                      *
      ******************************************************************
       11000-IMPRIME-ENC1-ENC2.

           WRITE SAL-UGTCNRA         FROM  W-ENCABEZADO-1
           WRITE SAL-UGTCNRA         FROM  W-ENCABEZADO-2
           .
      ******************************************************************
      *                   11100-IMPRIME-ENC1-ERROR                     *
      ******************************************************************
       11100-IMPRIME-ENC1-ERROR.

           WRITE REG-ERRORES         FROM  W-ENCABEZADO-3
           WRITE REG-ERRORES         FROM  W-ENCABEZADO-4
           .
      *COL03-I
      ******************************************************************
      *                   11200-LLENA-TABLA-T37                        *
      ******************************************************************
       11200-LLENA-TABLA-T37.

           SET  WSF-NVA-FET37          TO TRUE
           EXEC SQL
             OPEN CURSOR-T37
           END-EXEC

           MOVE SQLCODE            TO DB2-RETURN-CDE
                                      WVS-SQLCODE-ED

           EVALUATE TRUE
               WHEN DB2-OK
                    CONTINUE
               WHEN OTHER
                    MOVE  'ERROR OPEN CURSOR UGDTT37' TO
                                          SERR-DETALLE-ERROR(01:50)
                    MOVE   WVS-SQLCODE-ED TO SERR-DETALLE-ERROR(51:10)
                    PERFORM 2111-GRABA-SALIDA-ERROR
           END-EVALUATE
           PERFORM UNTIL NOT DB2-OK
               EXEC SQL
                  FETCH CURSOR-T37
                  INTO  :T37-SECCION,
                        :T37-ELEMENTO,
                        :T37-RESTO
               END-EXEC

               MOVE SQLCODE               TO DB2-RETURN-CDE
                                             WVS-SQLCODE-ED

               EVALUATE TRUE
                  WHEN DB2-OK
                     SET  WSF-SVA-FET37          TO TRUE
                     EVALUATE T37-SECCION
                       WHEN '9965'
                         SET IND-COLECTI UP BY 1
                         MOVE T37-ELEMENTO(1:2)
                                            TO W-COL-VALOR(IND-COLECTI)
                         MOVE T37-RESTO TO W-COL-DESCRI(IND-COLECTI)
                       WHEN '9966'
                         SET IND-DESTINO UP BY 1
                         MOVE T37-ELEMENTO(1:2)
                                            TO W-DES-VALOR(IND-DESTINO)
                         MOVE T37-RESTO TO W-DES-DESCRI(IND-DESTINO)
                     END-EVALUATE
                  WHEN DB2-NOTFND
                     IF WSF-NVA-FET37
                         MOVE  'SIN REGISTROS CURSOR UGDTT37' TO
                                           SERR-DETALLE-ERROR(01:50)
                         MOVE   WVS-SQLCODE-ED TO
                                           SERR-DETALLE-ERROR(51:10)
                         PERFORM 2111-GRABA-SALIDA-ERROR
                     END-IF
                  WHEN OTHER
                     MOVE 'ERROR FETCH T37' TO SERR-DETALLE-ERROR(01:50)
                     MOVE  WVS-SQLCODE-ED   TO SERR-DETALLE-ERROR(51:10)
                     PERFORM 2111-GRABA-SALIDA-ERROR
               END-EVALUATE                                                 0016
           END-PERFORM
           .
      *COL03-F
      ******************************************************************
      *                   12000-INICIALIZAR                            *
      ******************************************************************
       12000-INICIALIZAR.

COL11      MOVE ZEROS                    TO WS-CONSECUTIVO01
           INITIALIZE                       W-CONTADORES
                                            SAL-UGTCNRA
                                            REG-ERRORES
                                            ENT-UGDTNRA
                                            UGTCNRA.
      ******************************************************************
      *                   13000-LEER-EUNIRAR                           *
      ******************************************************************
       13000-LEER-EUNIRAR.

           READ EUNIRAR

           EVALUATE VAR-ESTADO
               WHEN '00'
                    ADD 1                     TO WC-LEI-ENTRADA
                    CONTINUE
               WHEN '10'
                    SET SW-E1-FIN-SI          TO TRUE

                    IF WC-LEI-ENTRADA = ZEROES
                       DISPLAY '***************************************'
                       DISPLAY '*ARCHIVO DE ENTRADA ESTADO VACIO      *'
                       DISPLAY '*-------------------------------------*'
                       DISPLAY '*ESTATUS DEL ARCHIVO : ' VAR-ESTADO
                       DISPLAY '*-------------------------------------*'
                    END-IF

               WHEN OTHER
                    DISPLAY '***************************************'
                    DISPLAY '*ERROR AL LEER ARCHIVO ENT. ESTADO    *'
                    DISPLAY '*-------------------------------------*'
                    DISPLAY '*ESTATUS DEL ARCHIVO : ' VAR-ESTADO
                    DISPLAY '*-------------------------------------*'
                    STOP RUN
           END-EVALUATE
           .
      *----------------------------------------------------------------*
      *                      20000-PROCESO                             *
      *----------------------------------------------------------------*
       20000-PROCESO.
      *
           MOVE ENT-MONTO-INI          TO W-ENT-MONTO-INI1
           MOVE WA-ENT-MONTO-INI-E5-1  TO WA-ENT-MONTO-INI-E5-R1
           MOVE WA-ENT-MONTO-INI-D4-2  TO WA-ENT-MONTO-INI-D4-R2
           MOVE ZEROES                 TO WEMIN-ENT-MONTO-INI-9
           MOVE WS-MONTO-INI-X9        TO WEMIN-ENT-MONTO-INI-9
      *VARIABLE DEL MONTO FIN
           MOVE ENT-MONTO-FIN          TO W-ENT-MONTO-FIN1
           MOVE WA-ENT-MONTO-FIN-E5-1  TO WA-ENT-MONTO-FIN-E5-1R
           MOVE WA-ENT-MONTO-FIN-D4-2  TO WA-ENT-MONTO-FIN-D4-2R
           MOVE ZEROES                 TO WEMIN-ENT-MONTO-FIN-9
           MOVE WS-MONTO-FIN-X9        TO WEMIN-ENT-MONTO-FIN-9

           SET SI-CORRECTO             TO TRUE

           PERFORM 2100-VALIDA-DATOS
      *COL11-I
      *    IF WS-CONT-COMMIT = WS-PARM-COMMIT
      *       PERFORM 000500-HACER-COMMIT
      *       MOVE ZEROS TO WS-CONT-COMMIT
      *    END-IF
      *COL11-F
           PERFORM 13000-LEER-EUNIRAR
           .
      *----------------------------------------------------------------*
      *                    2100-VALIDA-DATOS                           *
      *----------------------------------------------------------------*
       2100-VALIDA-DATOS.
      *
           PERFORM 2110-VALIDA-PRODUCTO
      *
           IF SI-CORRECTO
              PERFORM 2200-VALIDA-VARIABLE
           END-IF
           .
      *----------------------------------------------------------------*
      *                  2110-VALIDA-PRODUCTO                          *
      * VALIDA EL TIPO DE PRODUCTO H(HIPOTECARIO) L(LEASING HAB)       *
      * Z(LIBRANZA) N(CONSUMO) V(VEHICULO) C(COMERCIAL)                *
      *----------------------------------------------------------------*
       2110-VALIDA-PRODUCTO.
      *
      *COL10-I
      *    IF ENT-TIPO-PRODUCTO  EQUAL 'H ' OR 'L ' OR 'V ' OR 'VC'
      *                             OR 'NC' OR 'HC' OR 'HU' OR 'N '
      *                             OR 'HK'
      *COL10-F
      *COL03-I
      *COL05-I
      *                             OR 'Z'
      *COL10-I
      *                             OR 'Z'  OR 'C'
      *COL10-F
      *COL05-F
      *COL03-F
      *COL04-I
      *COL10-I
      *                             OR 'HS' OR 'HV'
      *COL11-I
      *    IF ENT-IND-ACTIVO     EQUAL 'B'
      *COL10-F
      *COL04-F
      *COL11-F
              SET SI-CORRECTO      TO TRUE
      *COL11-I
              .
      *       CONTINUE
      *    ELSE
      *       SET NO-CORRECTO      TO TRUE
      *       MOVE 'TIPO DE PRODUCTO NO ES CORRECTO' TO
      *                                             SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *    END-IF
      *    .
      *----------------------------------------------------------------*
      * GRABA SALIDA PARA INSERTAR EN LA UGDTNERA                      *
      *----------------------------------------------------------------*
       2112-GRABA-SALIDA-UGDTNRA.
      *

           WRITE SAL-UGDTNRA      FROM UGTCNRA

           IF SUGDTNRA-OK
              ADD 1    TO   WC-GRABADO-SUGDTNRA
                            WC-GRABADO-TABLA
                            WS-CONT-COMMIT
              PERFORM 2211-GRABA-SALIDA
           ELSE
              DISPLAY '**************************************'
              DISPLAY '*ERROR AL GRABAR ARHIVO DE UGDTNRA   *'
              DISPLAY '*------------------------------------*'
              DISPLAY '*ESTATUS DEL ARCHIVO : ' VAR-SUGDTNRA
              DISPLAY '*------------------------------------*'
              STOP RUN
           END-IF
           .
      *
      *----------------------------------------------------------------*
      *             SE OBTIENE LA TIMESTAP PARA LA UGDTNRA             *
      *----------------------------------------------------------------*
       2110-OBTENER-FECHA.
           EXEC SQL
              SET :CURRENT-TIMESTAMP = CURRENT TIMESTAMP
           END-EXEC
           .
      *COL11-F
      *----------------------------------------------------------------*
      * GRABA SALIDA DE TIPO DE PRODUCTO INCORRECTO                    *
      *----------------------------------------------------------------*
       2111-GRABA-SALIDA-ERROR.
      *
           MOVE ENT-TIPO-PRODUCTO       TO WLD2-PRODUCTO
           MOVE ENT-VALIDA-VARIABLE     TO WLD2-VARIABLE
           MOVE WTD-DESCR(ENT-VALIDA-VARIABLE-9)  TO WLD2-DESCRIPCION
           MOVE WS-CONSECUTIVO          TO WLD2-CONSENCUTIVO
      *COL01-I
      *    MOVE ENT-RANGO-INI           TO WLD2-RANGO-INI
      *    MOVE ENT-RANGO-FIN           TO WLD2-RANGO-FIN
      *    MOVE WEMIN-ENT-MONTO-INI-9   TO WLD2-MONTO-INI
      *    MOVE WEMIN-ENT-MONTO-FIN-9   TO WLD2-MONTO-FIN
      *    MOVE ENT-IND-CLIENTE         TO WLD2-IND
      *COL01-F

           WRITE REG-ERRORES      FROM W-LINEA-DETALLE-2

           IF VAR-ERROR = '00'
              ADD 1    TO   WC-GRABADO-ERROR
              CONTINUE
           ELSE
              DISPLAY '**************************************'
              DISPLAY '*ERROR AL GRABAR ARHIVO DE ERRORES   *'
              DISPLAY '*------------------------------------*'
              DISPLAY '*ESTATUS DEL ARCHIVO : ' VAR-ERROR
              DISPLAY '*------------------------------------*'
              STOP RUN
           END-IF
           .
      *----------------------------------------------------------------*
      * VALIDA VARIABLE                                                *
      *----------------------------------------------------------------*
       2200-VALIDA-VARIABLE.
      *
      *COL11-I
           IF WS-TIPO-PRODUCTO NOT EQUAL ENT-VALIDA-VARIABLE
              MOVE SPACES                   TO WS-DATOS-COMER
                                               WS-IND-CLIENTE
                                               WS-VIP-CLIENTE
                                               WS-GARANTIA
                                               WS-TIP-VEHICULO
                                               WS-ESTADO-VEHICULO
              MOVE ZEROS                    TO WS-CONSECUTIVO
                                               WS-RANGO-INI
                                               WS-RANGO-FIN
                                               WS-SIT-LABORAL
                                               WS-MIN-MONTO-INI
                                               WS-MAX-MONTO-FIN
                                               WS-FINA-MONTO-INI
                                               WS-FINA-MONTO-FIN
                                               WS-PORCFINA-MONTO-INI
                                               WS-PORCFINA-MONTO-FIN
                                               WS-GAMA-MONTO-INI
                                               WS-GAMA-MONTO-FIN
                                               WS-GRUP-MONTO-INI
                                               WS-GRUP-MONTO-FIN
                                               WS-VENT-MONTO-INI
                                               WS-VENT-MONTO-FIN
                                               WS-MONOPER-COMER-INI
                                               WS-MONOPER-COMER-FIN
                                               WS-PLAZO-INI
                                               WS-PLAZO-FIN
                                               WS-EDAD-INI
                                               WS-EDAD-FIN
                                               WS-SEGMENTO-INI
                                               WS-COLECTIVO-INI
              MOVE ENT-VALIDA-VARIABLE      TO WS-TIPO-PRODUCTO
           END-IF
      *COL11-F
           EVALUATE ENT-VALIDA-VARIABLE
              WHEN '01'
                   PERFORM 21-VALIDA-BURO
              WHEN '02'
                   PERFORM 24-DOM-NOMINA
              WHEN '03'
                   PERFORM 35-SITUACION-LABORAL
              WHEN '04'
                   PERFORM 23-VALIDA-INGRESOS
              WHEN '05'
                   PERFORM 26-MONTO-FINANCIADO
              WHEN '06'
                   PERFORM 27-PLAZO-OPERACION
              WHEN '07'
                   PERFORM 34-EDAD
              WHEN '08'
                   PERFORM 32-SEGMENTO
              WHEN '09'
                   PERFORM 33-COLECTIVO
              WHEN '10'
                   PERFORM 22-VALIDA-GRUPO-RIESGOS
              WHEN '11'
                   PERFORM 30-TIPO-VEHICULO
              WHEN '12'
                   PERFORM 31-FINANCIACION
              WHEN '13'
                   PERFORM 28-GAMA-VEHICULO
              WHEN '14'
                   PERFORM 29-TIPO-PART-PUBLICO
              WHEN '15'
                   PERFORM 25-VALIDA-CLIENTE
      *COL03-I
              WHEN '16'
                   PERFORM 36-VALIDA-COLECTI-LIB
              WHEN '17'
                   PERFORM 37-VALIDA-DESTINO-LIB
      *COL03-F
      *COL05-I
              WHEN '18'
                   PERFORM 38-VALIDA-VENTAS-COMER
              WHEN '19'
                   PERFORM 39-VALIDA-TIPERS-COMER
              WHEN '20'
                   PERFORM 40-VALIDA-RATING-COMER
              WHEN '21'
                   PERFORM 41-VALIDA-RANG-RATING-COMER
              WHEN '22'
                   PERFORM 42-VALIDA-GARANTIA-COMER
              WHEN '23'
                   PERFORM 43-VALIDA-MONOPER-COMER
      *COL05-F
              WHEN OTHER
                   SET NO-CORRECTO          TO TRUE
                   MOVE 'CODIGO DE VARIABLE ERRONEO' TO
                                               SERR-DETALLE-ERROR
                   PERFORM 2111-GRABA-SALIDA-ERROR
            END-EVALUATE
            .
      *----------------------------------------------------------------*
      *                  21-VALIDA-BURO                                *
      *   VALIDA EL RANGO INICIAL Y FINAL DEL BURO                     *
      *----------------------------------------------------------------*
       21-VALIDA-BURO.
      *
      *COL01-I
           MOVE ENT-RANGO-INIA            TO WS-STRING
           MOVE CTEN-04                   TO WS-IND
           PERFORM 22-VALIDA-STRING
           IF SI-NUMERICO
              MOVE ENT-RANGO-FINA         TO WS-STRING
              MOVE CTEN-04                TO WS-IND
              PERFORM 22-VALIDA-STRING
           ELSE
              SET NO-CORRECTO             TO TRUE
              MOVE SPACES                 TO SERR-DETALLE-ERROR
              STRING 'RANGO_INI INVALIDO ' DELIMITED BY SIZE
                        WS-STRING         DELIMITED BY SIZE
                                          INTO SERR-DETALLE-ERROR
              END-STRING
              PERFORM 2111-GRABA-SALIDA-ERROR
           END-IF
           IF SI-NUMERICO
              MOVE ENT-RANGO-INI          TO WLD2-RANGO-INI
              MOVE ENT-RANGO-FIN          TO WLD2-RANGO-FIN
      *COL01-F

           IF ENT-RANGO-INI IS NOT NUMERIC
              SET NO-CORRECTO             TO TRUE
              MOVE SPACES                 TO SERR-DETALLE-ERROR
              MOVE 'BURO INICIAL DEBE SER NUMERICO' TO
                                             SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           END-IF

           IF ENT-RANGO-FIN IS NOT NUMERIC
              SET NO-CORRECTO          TO TRUE
              MOVE SPACES              TO SERR-DETALLE-ERROR
              MOVE 'BURO FINAL DEBE SER NUMERICO' TO
                                          SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           END-IF
      *
           IF ENT-RANGO-INI       =   ENT-RANGO-FIN
              SET NO-CORRECTO          TO TRUE
              MOVE SPACES              TO SERR-DETALLE-ERROR
              MOVE 'BURO INICIAL NO DEBE SER IGUAL BURO FIN' TO
                                          SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           END-IF

           IF ENT-RANGO-INI       = ZEROES AND
              ENT-RANGO-FIN       = ZEROES
              SET NO-CORRECTO          TO TRUE
              MOVE SPACES              TO SERR-DETALLE-ERROR
              MOVE 'BURO INICIAL ES 0 BURO FINAL ES 0' TO
                                          SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           END-IF

           IF ENT-RANGO-INI        > ENT-RANGO-FIN
              SET NO-CORRECTO          TO TRUE
              MOVE SPACES              TO SERR-DETALLE-ERROR
              MOVE 'BURO INICIAL DEBE SER <  BURO FINAL' TO
                                          SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           END-IF
      *COL11-I
           IF ENT-RANGO-INI       <= WS-RANGO-INI
              AND ENT-RANGO-INI > ZEROS
              AND WS-RANGO-INI  > ZEROS
              AND SI-CORRECTO
              SET NO-CORRECTO          TO TRUE
              MOVE SPACES              TO SERR-DETALLE-ERROR
              MOVE 'BURO INICIAL DEBE SER >  BURO ANTERI' TO
                                          SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           ELSE
              MOVE ENT-RANGO-INI            TO WS-RANGO-INI
           END-IF
           IF ENT-RANGO-FIN       <= WS-RANGO-FIN
              AND ENT-RANGO-FIN > ZEROS
              AND SI-CORRECTO
              SET NO-CORRECTO          TO TRUE
              MOVE SPACES              TO SERR-DETALLE-ERROR
              MOVE 'BURO FINAL DEBE SER >  BURO ANTERIOR' TO
                                          SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           ELSE
              MOVE ENT-RANGO-FIN            TO WS-RANGO-FIN
           END-IF
      *COL11-F
      *
           IF SI-CORRECTO
              PERFORM 2211-CONSULTA-UGDTNRA
           END-IF
      *COL01-I
           ELSE
              SET NO-CORRECTO          TO TRUE
              MOVE SPACES              TO SERR-DETALLE-ERROR
              STRING 'RANGO_FIN INVALIDO ' DELIMITED BY SIZE
                        WS-STRING         DELIMITED BY SIZE
                                          INTO SERR-DETALLE-ERROR
              END-STRING
           END-IF
      *COL01-F
           .
      *
      *----------------------------------------------------------------*
      *                    22-VALIDA-STRING                            *
      *----------------------------------------------------------------*
      *
       22-VALIDA-STRING.
             SET SI-NUMERICO             TO TRUE
             PERFORM VARYING WS-I FROM 1  BY 1 UNTIL WS-I > WS-IND
                 MOVE WS-STRING (WS-I:1) TO WS-C
                 IF WS-N             IS NOT NUMERIC
                    SET NO-NUMERICO  TO TRUE
                 END-IF
             END-PERFORM.

      *----------------------------------------------------------------*
      *                   2211-CONSULTA-UGDTNRA                        *
      *----------------------------------------------------------------*
       2211-CONSULTA-UGDTNRA.
      *
      *COL11-I
           ADD 1 TO WS-CONSECUTIVO
           PERFORM 2211-MOVER-DATOS-UGDTNRA-INS
           .
      *    INITIALIZE                     UGTCNRA
      *                                   DB2-RETURN-CDE
      *COL07-I
      *                                   WS-CONSECUTIVO
      *COL07-F
      *
      *    MOVE ENT-TIPO-PRODUCTO      TO NRA-TIPO-PRODUCTO
      *    MOVE ENT-VALIDA-VARIABLE    TO NRA-VARIABLE
      *COL02-I
      *    MOVE 'VS'                   TO NRA-ESTADO
      *COL02-F
      *
      *    EXEC SQL
      *         SELECT  NRA_TIPO_PRODUCTO,
      *                 NRA_VARIABLE,
      *                 NRA_CONSECUTIVO,
      *                 NRA_FECHA_INI,
      *                 NRA_FECHA_FIN,
      *                 NRA_RANGO_INI,
      *                 NRA_RANGO_FIN,
      *                 NRA_IND_DOM_NOMINA,
      *                 NRA_SITUA_LABORAL,
      *                 NRA_MONTO_INICIAL,
      *                 NRA_MONTO_FINAL,
      *                 NRA_SEGMENTO,
      *                 NRA_IND_CLIENTE_VIP,
      *                 NRA_RANGO_RIESGO_INI,
      *                 NRA_RANGO_RIESGO_FIN,
      *                 NRA_IND_ESTADO_VEH,
      *                 NRA_IND_TIPO_VEH,
      *                 NRA_CLAVE_ID,
      *                 NRA_CLUSTER,
      *                 NRA_ESTADO,
      *                 NRA_TASA,
      *                 NRA_CENTRO_UMO,
      *                 NRA_USERID_UMO,
      *                 NRA_NETNAME_UMO,
      *COL05-I
      *                 NRA_TIMESTAMP
      *                 NRA_TIMESTAMP,
      *                 NRA_RATING,
      *                 NRA_RANGO_RATING,
      *                 NRA_GARANTIA,
      *                 NRA_PORCENTA
      *COL05-F
      *           INTO :NRA-TIPO-PRODUCTO,
      *                :NRA-VARIABLE,
      *                :NRA-CONSECUTIVO,
      *                :NRA-FECHA-INI,
      *                :NRA-FECHA-FIN,
      *                :NRA-RANGO-INI,
      *                :NRA-RANGO-FIN,
      *                :NRA-IND-DOM-NOMINA,
      *                :NRA-SITUA-LABORAL,
      *                :NRA-MONTO-INICIAL,
      *                :NRA-MONTO-FINAL,
      *                :NRA-SEGMENTO,
      *                :NRA-IND-CLIENTE-VIP,
      *                :NRA-RANGO-RIESGO-INI,
      *                :NRA-RANGO-RIESGO-FIN,
      *                :NRA-IND-ESTADO-VEH,
      *                :NRA-IND-TIPO-VEH,
      *                :NRA-CLAVE-ID,
      *                :NRA-CLUSTER,
      *                :NRA-ESTADO,
      *                :NRA-TASA,
      *                :NRA-CENTRO-UMO,
      *                :NRA-USERID-UMO,
      *                :NRA-NETNAME-UMO,
      *COL05-I
      *                :NRA-TIMESTAMP
      *                :NRA-TIMESTAMP,
      *                :NRA-RATING,
      *                :NRA-RANGO-RATING,
      *                :NRA-GARANTIA,
      *                :NRA-PORCENTA
      *COL05-F
      *           FROM  UGDTNRA
      *          WHERE  NRA_TIPO_PRODUCTO = :NRA-TIPO-PRODUCTO
      *            AND  NRA_VARIABLE      = :NRA-VARIABLE
      *COL02-I
      *            AND  NRA_ESTADO        = :NRA-ESTADO
      *COL02-F
      *    END-EXEC
      *
      *    MOVE SQLCODE                     TO DB2-RETURN-CDE
      *                                        WVS-SQLCODE-ED
      *
      *    EVALUATE TRUE
      *        WHEN DB2-OK
      *COL07-I
      *             MOVE NRA-CONSECUTIVO          TO WS-CONSECUTIVO
      *             ADD 1                         TO WS-CONSECUTIVO
      *COL07-F
      *             PERFORM 2211-VALIDA-DATOS-ENT-TABLA
      *        WHEN DB2-NOTFND
      *COL07-I
      *             ADD 1 TO WS-CONSECUTIVO
      *             PERFORM 2211-SELECT-MAXTABLA-UGDTNRA
      *COL07-F
      *             PERFORM 2211-MOVER-DATOS-UGDTNRA-INS
      *        WHEN DB2-VARIOS
      *             PERFORM 24-CURSOR-UGDTNRA
      *        WHEN OTHER
      *             MOVE 'ERROR SELECT UGDTNRA' TO
      *                                       SERR-DETALLE-ERROR(01:50)
      *             MOVE WVS-SQLCODE-ED    TO SERR-DETALLE-ERROR(51:10)
      *             PERFORM 2111-GRABA-SALIDA-ERROR
      *    END-EVALUATE
      *    .
      *----------------------------------------------------------------*
      *                   2211-VALIDA-DATOS-ENT-TABLA                  *
      *----------------------------------------------------------------*
      *2211-VALIDA-DATOS-ENT-TABLA.
      *
      *    IF ENT-VALIDA-VARIABLE = '01'
      *       PERFORM 2211-VALIDA-RANGOS-BURO-01
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '02'
      *       PERFORM 2211-VALIDA-DOM-NOMINA
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '03'
      *       PERFORM 2211-VALIDA-SITUACION-LABORAL
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '04'
      *       PERFORM 2211-VALIDA-INGRESO
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '05'
      *       PERFORM 2211-VALIDA-MONTO-FINANCIADO
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '06'
      *       PERFORM 2211-VALIDA-PLAZO-OPERACION
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '07'
      *       PERFORM 2211-VALIDA-EDAD
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '08'
      *       PERFORM 2211-VALIDA-SEGMENTO
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '09'
      *       PERFORM 2211-VALIDA-COLECTIVO
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '10'
      *       PERFORM 2211-VALIDA-GRUPO-RIESGOS
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '11'
      *       PERFORM 2211-VALIDA-ESTADO-VEHI-NUEVO
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '12'
      *       PERFORM 2211-VALIDA-FINANCIACION
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '13'
      *       PERFORM 2211-VALIDA-GAMA-VEHICULO
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '14'
      *       PERFORM 2211-VALIDA-TIPO-USO-PART
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '15'
      *       PERFORM 2211-VALIDA-CLIENTE-VIP-05
      *    END-IF
      *COL03-I
      *    IF ENT-VALIDA-VARIABLE = '16'
      *       PERFORM 2211-VALIDA-COLECTI-LIB
      *    END-IF
      *    IF ENT-VALIDA-VARIABLE = '17'
      *       PERFORM 2211-VALIDA-DESTINO-LIB
      *    END-IF
      *COL03-F
      *COL05-I
      *    IF ENT-VALIDA-VARIABLE = '18'
      *       PERFORM 2211-VALIDA-VENTAS-COMER
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '19'
      *       PERFORM 2211-VALIDA-TIPERS-COMER
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '20'
      *       PERFORM 2211-VALIDA-RATING-COMER
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '21'
      *       PERFORM 2211-VALIDA-RANG-RATING-COMER
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '22'
      *       PERFORM 2211-VALIDA-GARANTIA-COMER
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '23'
      *       PERFORM 2211-VALIDA-MONOPER-COMER
      *    END-IF
      *COL05-F
      *    .
      *----------------------------------------------------------------*
      *                   2211-VALIDA-ENT-FETCH                        *
      *----------------------------------------------------------------*
      *2211-VALIDA-ENT-FETCH.
      *
      *    IF ENT-VALIDA-VARIABLE = '01'
      *       PERFORM 2211-VALIDA-RANGOS-FETCH
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '02'
      *       PERFORM 2211-VALIDA-DOM-NOMINA-FETCH
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '03'
      *       PERFORM 2211-VAL-SITUA-LABORAL-FETCH
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '04'
      *       PERFORM 2211-VALIDA-INGRESO-FETCH
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '05'
      *       PERFORM 2211-VALIDA-FINANCIADO-FETCH
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '06'
      *       PERFORM 2211-VALIDA-PLAZO-OPE-FETCH
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '07'
      *       PERFORM 2211-VALIDA-EDAD-FETCH
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '08'
      *       PERFORM 2211-VALIDA-SEGMENTO-FETCH
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '09'
      *       PERFORM 2211-VALIDA-COLECTIVO-FETCH
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '10'
      *       PERFORM 2211-VALIDA-GRUPO-FETCH
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '11'
      *       PERFORM 2211-VALIDA-VEHI-NUEVO-FETCH
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '12'
      *       PERFORM 2211-VALIDA-FINANCIACION-FETCH
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '13'
      *       PERFORM 2211-VALIDA-VEHICULO-FETCH
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '14'
      *       PERFORM 2211-VALIDA-TIPO-USO-FETCH
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '15'
      *       PERFORM 2211-VALIDA-CLI-VIP-05-FETCH
      *    END-IF
      *COL03-I
      *    IF ENT-VALIDA-VARIABLE = '16'
      *       PERFORM 2211-VALIDA-COLECTI-LIB-FETCH
      *    END-IF
      *    IF ENT-VALIDA-VARIABLE = '17'
      *       PERFORM 2211-VALIDA-DESTINO-LIB-FETCH
      *    END-IF
      *COL03-F
      *COL05-I
      *    IF ENT-VALIDA-VARIABLE = '18'
      *       PERFORM 2211-VALIDA-VENTAS-COMER-FETCH
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '19'
      *       PERFORM 2211-VALIDA-TIPERS-COMER-FETCH
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '20'
      *       PERFORM 2211-VALIDA-RATING-COMER-FETCH
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '21'
      *       PERFORM 2211-VALIDA-RANGRA-COMER-FETCH
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '22'
      *       PERFORM 2211-VALIDA-GARANT-COMER-FETCH
      *    END-IF
      *
      *    IF ENT-VALIDA-VARIABLE = '23'
      *       PERFORM 2211-VALIDA-MONOPE-COMER-FETCH
      *    END-IF
      *COL05-F
      *    .
      *----------------------------------------------------------------*
      * CONSULTA TABLA     2211-VALIDA-RANGOS-BURO-01                  *
      *----------------------------------------------------------------*
      *2211-VALIDA-RANGOS-BURO-01.
      *
      *    IF ENT-RANGO-INI  =   NRA-RANGO-INI   AND
      *       ENT-RANGO-FIN  =   NRA-RANGO-FIN
      *       MOVE 'RANGO-INI Y RANGO-FIN DUPLICADOS' TO
      *                                  SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *    ELSE
      *      IF (ENT-RANGO-INI  <=  NRA-RANGO-FIN OR
      *          ENT-RANGO-INI  =   NRA-RANGO-INI OR
      *          ENT-RANGO-FIN  =   NRA-RANGO-FIN) AND
      *          NRA-RANGO-FIN > 0
      *          MOVE 'RANGO INVALIDO FUERA INTERVALO ' TO
      *                                    SERR-DETALLE-ERROR
      *         PERFORM 2111-GRABA-SALIDA-ERROR
      *      ELSE
      *COL07-I
      *         PERFORM 2211-SELECT-MAXTABLA-UGDTNRA
      *COL07-F
      *         PERFORM 2211-MOVER-DATOS-UGDTNRA-INS
      *      END-IF
      *    END-IF
      *    .
      *----------------------------------------------------------------*
      * CONSULTA FETCH     2211-VALIDA-RANGOS-FETCH
      *----------------------------------------------------------------*
      *2211-VALIDA-RANGOS-FETCH.
      *
      *    IF ENT-RANGO-INI  =   NRA-RANGO-INI   AND
      *       ENT-RANGO-FIN  =   NRA-RANGO-FIN
      *       MOVE 'RANGO-INI Y RANGO-FIN DUPLICADOS' TO
      *                                  SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *       SET WSF-SVA-FETCH      TO TRUE
      *    END-IF
      *    .
      *----------------------------------------------------------------*
      *                 2211-SELECT-MAXTABLA-UGDTNRA                   *
      *----------------------------------------------------------------*
      *2211-SELECT-MAXTABLA-UGDTNRA.
      *
      *    INITIALIZE                          DB2-RETURN-CDE
      *                                        WS-CONSECUTIVO
      *
      *    MOVE ENT-TIPO-PRODUCTO      TO NRA-TIPO-PRODUCTO
      *    MOVE ENT-VALIDA-VARIABLE    TO NRA-VARIABLE
      *
      *    EXEC SQL
      *         SELECT  MAX(NRA_CONSECUTIVO)
      *           INTO :NRA-CONSECUTIVO
      *           FROM  UGDTNRA
      *          WHERE  NRA_TIPO_PRODUCTO = :NRA-TIPO-PRODUCTO
      *            AND  NRA_VARIABLE      = :NRA-VARIABLE
      *    END-EXEC
      *
      *    MOVE SQLCODE                     TO DB2-RETURN-CDE
      *                                        WVS-SQLCODE-ED
      *
      *    EVALUATE TRUE
      *        WHEN DB2-OK
      *        WHEN DB2-NOTFND
      *        WHEN DB2-NULL
      *             ADD 1                   TO NRA-CONSECUTIVO
      *             MOVE NRA-CONSECUTIVO    TO WS-CONSECUTIVO
      *        WHEN OTHER
      *             MOVE 'ERROR SELECT MAX UGDTNRA' TO
      *                                        SERR-DETALLE-ERROR(01:50)
      *             MOVE WVS-SQLCODE-ED     TO SERR-DETALLE-ERROR(51:10)
      *             PERFORM 2111-GRABA-SALIDA-ERROR
      *    END-EVALUATE
      *    .
      *COL11-F
      *----------------------------------------------------------------*
      *                   2211-MOVER-DATOS-UGDTNRA-INS                 *
      *----------------------------------------------------------------*
       2211-MOVER-DATOS-UGDTNRA-INS.
           INITIALIZE UGTCNRA
      *
           MOVE ENT-TIPO-PRODUCTO          TO NRA-TIPO-PRODUCTO         00000600
           MOVE ENT-VALIDA-VARIABLE        TO NRA-VARIABLE              00000800
      *
      *COL07-I
      *    PERFORM 2211-VALIDA-UGDTNRA
      *COL07-F
      *
           MOVE WS-CONSECUTIVO             TO NRA-CONSECUTIVO
           MOVE WSV-TIMESTAMP-INI(01:10)   TO NRA-FECHA-INI             00000900
           MOVE WC-FECHA-FIN               TO NRA-FECHA-FIN             00001000
      * VALIDA - BURO                   01
           MOVE ENT-RANGO-INI              TO NRA-RANGO-INI             00001100
           MOVE ENT-RANGO-FIN              TO NRA-RANGO-FIN             00001200
      *VALIDA DOM-NOMINA
           IF  ENT-VALIDA-VARIABLE   = '02'
               MOVE ENT-IND-CLIENTE        TO NRA-IND-DOM-NOMINA        00001300
           END-IF
      *VALIDA SITUACION LABORA
           IF ENT-VALIDA-VARIABLE    = '03'
              MOVE ENT-IND-CLIENTE         TO NRA-SITUA-LABORAL         00001400
           END-IF
      *VALIDA INGRESO-INI
           IF ENT-VALIDA-VARIABLE    = '04'
              MOVE WEMIN-ENT-MONTO-INI-9      TO WMIF-ENT-MONTO-REDFIN-9
              MOVE WEMIF-ENT-MONTO-INI-REDFIN TO NRA-MONTO-INICIAL
      *VALIDA INGRESO-FIN
              MOVE WEMIN-ENT-MONTO-FIN-9      TO WMIF-ENT-MONTO-REDFON-9
              MOVE WEMIF-ENT-MONTO-INI-REDFON TO NRA-MONTO-FINAL
           END-IF
      *VALIDA EL MONTO -FINANCIADO - INI
           IF ENT-VALIDA-VARIABLE    = '05'
              MOVE WEMIN-ENT-MONTO-INI-9      TO WMIF-ENT-MONTO-REDFIN-9
              MOVE WEMIF-ENT-MONTO-INI-REDFIN TO NRA-MONTO-INICIAL
      *VALIDA EL MONTO - FINANCIADO - FIN
              MOVE WEMIN-ENT-MONTO-FIN-9      TO WMIF-ENT-MONTO-REDFON-9
              MOVE WEMIF-ENT-MONTO-INI-REDFON TO NRA-MONTO-FINAL
           END-IF
      *VALIDA PLAZO DE OPERACION-INI-FIN
           IF ENT-VALIDA-VARIABLE    = '06'
              MOVE ENT-RANGO-INI              TO NRA-RANGO-INI          00001100
              MOVE ENT-RANGO-FIN              TO NRA-RANGO-FIN          00001200
           END-IF
      *VALIDA EDAD
           IF ENT-VALIDA-VARIABLE    = '07'
              MOVE ENT-RANGO-INI              TO NRA-RANGO-INI          00001100
              MOVE ENT-RANGO-FIN              TO NRA-RANGO-FIN          00001200
           END-IF
      *VALIDA SEGMENTO
           IF ENT-VALIDA-VARIABLE    = '08'
              MOVE WEMIN-ENT-MONTO-INI-9      TO WMIF-ENT-MONTO-REDFIN-9
              MOVE WEMIF-ENT-MONTO-INI-REDFIN TO NRA-SEGMENTO           00001700
           END-IF
      *VALIDA COLECTIVO
           IF ENT-VALIDA-VARIABLE    = '09'
              MOVE WEMIN-ENT-MONTO-INI-9      TO WMIF-ENT-MONTO-REDFIN-9
              MOVE WEMIF-ENT-MONTO-INI-REDFIN TO NRA-SEGMENTO           00001700
           END-IF
      *VALIDA GRUPO-RIESGO-INI
           IF ENT-VALIDA-VARIABLE    = '10'
              MOVE WEMIN-ENT-MONTO-INI-9      TO WMIF-ENT-MONTO-REDFIN-9
              MOVE WEMIF-ENT-MONTO-INI-REDFIN TO NRA-RANGO-RIESGO-INI   00001900
      *VALIDA GRUPO-RIESGO-FIN
              MOVE WEMIN-ENT-MONTO-FIN-9      TO WMIF-ENT-MONTO-REDFON-9
              MOVE WEMIF-ENT-MONTO-INI-REDFON TO NRA-RANGO-RIESGO-FIN   00002000
           END-IF
      *VALIDA TIPO DE VEHICULO N=NUEVO U=USADO
           IF ENT-VALIDA-VARIABLE    = '11'
              MOVE ENT-IND-CLIENTE            TO NRA-IND-ESTADO-VEH
           END-IF
      *VALIDA FINANCIACION-INI
           IF ENT-VALIDA-VARIABLE    = '12'
              MOVE WEMIN-ENT-MONTO-INI-9      TO WMIF-ENT-MONTO-REDFIN-9
              MOVE WEMIF-ENT-MONTO-INI-REDFIN TO NRA-MONTO-INICIAL
      *VALIDA FINANCIACION-INI
              MOVE WEMIN-ENT-MONTO-FIN-9      TO WMIF-ENT-MONTO-REDFON-9
              MOVE WEMIF-ENT-MONTO-INI-REDFON TO NRA-MONTO-FINAL
           END-IF
      *VALIDA GAMA DEL VEHICULO-INI
           IF ENT-VALIDA-VARIABLE    = '13'
              MOVE WEMIN-ENT-MONTO-INI-9      TO WMIF-ENT-MONTO-REDFIN-9
              MOVE WEMIF-ENT-MONTO-INI-REDFIN TO NRA-MONTO-INICIAL
      *VALIDA GAMA DEL VEHICULO-FIN
              MOVE WEMIN-ENT-MONTO-FIN-9      TO WMIF-ENT-MONTO-REDFON-9
              MOVE WEMIF-ENT-MONTO-INI-REDFON TO NRA-MONTO-FINAL
           END-IF
      *VALIDA TIPO DE VEHICULO P=PARTICULAR S=PUBLICO
           IF ENT-VALIDA-VARIABLE    = '14'
              MOVE ENT-IND-CLIENTE            TO NRA-IND-TIPO-VEH
           END-IF
      *CLIENTE VIP S/N
           IF ENT-VALIDA-VARIABLE    = '15'
              MOVE ENT-IND-CLIENTE         TO NRA-IND-CLIENTE-VIP       00001400
           END-IF
      *COL03-I
      *VALIDA COLECTIVO LIBRANZA
           IF ENT-VALIDA-VARIABLE    = '16'
              IF WEMIN-ENT-MONTO-INI-9 = CTE-NA
                 MOVE ZEROS            TO WEMIN-ENT-MONTO-INI-9
              END-IF
              MOVE WEMIN-ENT-MONTO-INI-9      TO WMIF-ENT-MONTO-REDFIN-9
              MOVE WEMIF-ENT-MONTO-INI-REDFIN TO NRA-SEGMENTO           00001700
           END-IF
      *VALIDA DESTINO LIBRANZA
           IF ENT-VALIDA-VARIABLE    = '17'
              IF WEMIN-ENT-MONTO-INI-9 = CTE-NA
                 MOVE ZEROS            TO WEMIN-ENT-MONTO-INI-9
              END-IF
              MOVE WEMIN-ENT-MONTO-INI-9      TO WMIF-ENT-MONTO-REDFIN-9
              MOVE WEMIF-ENT-MONTO-INI-REDFIN TO NRA-SEGMENTO           00001700
           END-IF
      *COL03-F
      *COL05-I
      *VALIDA VENTAS - INI Y MONTO DE OPERACION - INI
           IF ENT-VALIDA-VARIABLE    = '18' OR
              ENT-VALIDA-VARIABLE    = '23'
              MOVE WEMIN-ENT-MONTO-INI-9      TO WMIF-ENT-MONTO-REDFIN-9
              MOVE WEMIF-ENT-MONTO-INI-REDFIN TO NRA-MONTO-INICIAL
      *VALIDA VENTAS - FIN Y MONTO DE OPERACION - FIN
              MOVE WEMIN-ENT-MONTO-FIN-9      TO WMIF-ENT-MONTO-REDFON-9
              MOVE WEMIF-ENT-MONTO-INI-REDFON TO NRA-MONTO-FINAL
           END-IF
      *VALIDA TIPO-PERSONA
           IF ENT-VALIDA-VARIABLE   = '19'
              MOVE ENT-DATOS-COMER(2:1)   TO NRA-IND-CLIENTE-VIP        00001300
           END-IF
      *VALIDA CALF-RATING
           IF ENT-VALIDA-VARIABLE   = '20'
              MOVE ENT-DATOS-COMER(1:5)   TO NRA-RATING                 00001300
           END-IF
      *VALIDA RANG-RATING
           IF ENT-VALIDA-VARIABLE   = '21'
              MOVE ENT-DATOS-COMER(1:1)   TO NRA-RANGO-RATING           00001300
           END-IF
      *VALIDA GARANTIA
           IF ENT-VALIDA-VARIABLE   = '22'
              MOVE ENT-DATOS-COMER(1:1)   TO NRA-GARANTIA               00001300
           END-IF
      *COL05-F
      *
      *COL07-I
      *    MOVE WTL-LETRAS(WS-CSC)         TO NRA-CLAVE-ID
           MOVE WTL-LETRAS(WS-CONSECUTIVO) TO NRA-CLAVE-ID
      *COL07-I
           MOVE SPACES                     TO NRA-CLUSTER
           MOVE 'VS'                       TO NRA-ESTADO
           MOVE ZEROES                     TO NRA-TASA
           MOVE '0018'                     TO NRA-CENTRO-UMO
           MOVE 'UG4CRAR1'                 TO NRA-USERID-UMO
           MOVE 'J018'                     TO NRA-NETNAME-UMO

      *COL11-I
           PERFORM 2110-OBTENER-FECHA
           MOVE CURRENT-TIMESTAMP          TO NRA-TIMESTAMP
           PERFORM 2112-GRABA-SALIDA-UGDTNRA
           IF WS-CONSECUTIVO = CTEN-1
              PERFORM 2212-MOVER-VARIA-UGDTNRA-INS
           END-IF
           .
      *    EXEC SQL
      *      INSERT INTO UGDTNRA
      *        (NRA_TIPO_PRODUCTO,
      *         NRA_VARIABLE,
      *         NRA_CONSECUTIVO,
      *         NRA_FECHA_INI,
      *         NRA_FECHA_FIN,
      *         NRA_RANGO_INI,
      *         NRA_RANGO_FIN,
      *         NRA_IND_DOM_NOMINA,
      *         NRA_SITUA_LABORAL,
      *         NRA_MONTO_INICIAL,
      *         NRA_MONTO_FINAL,
      *         NRA_SEGMENTO,
      *         NRA_IND_CLIENTE_VIP,
      *         NRA_RANGO_RIESGO_INI,
      *         NRA_RANGO_RIESGO_FIN,
      *         NRA_IND_ESTADO_VEH,
      *         NRA_IND_TIPO_VEH,
      *         NRA_CLAVE_ID,
      *         NRA_CLUSTER,
      *         NRA_ESTADO,
      *         NRA_TASA,
      *         NRA_CENTRO_UMO,
      *         NRA_USERID_UMO,
      *         NRA_NETNAME_UMO,
      *COL05-I
      *         NRA_TIMESTAMP)
      *         NRA_TIMESTAMP,
      *         NRA_RATING,
      *         NRA_RANGO_RATING,
      *         NRA_GARANTIA,
      *         NRA_PORCENTA)
      *COL05-F
      *    VALUES (:NRA-TIPO-PRODUCTO,
      *        :NRA-VARIABLE,
      *        :NRA-CONSECUTIVO,
      *        :NRA-FECHA-INI,
      *        :NRA-FECHA-FIN,
      *        :NRA-RANGO-INI,
      *        :NRA-RANGO-FIN,
      *        :NRA-IND-DOM-NOMINA,
      *        :NRA-SITUA-LABORAL,
      *        :NRA-MONTO-INICIAL,
      *        :NRA-MONTO-FINAL,
      *        :NRA-SEGMENTO,
      *        :NRA-IND-CLIENTE-VIP,
      *        :NRA-RANGO-RIESGO-INI,
      *        :NRA-RANGO-RIESGO-FIN,
      *        :NRA-IND-ESTADO-VEH,
      *        :NRA-IND-TIPO-VEH,
      *        :NRA-CLAVE-ID,
      *        :NRA-CLUSTER,
      *        :NRA-ESTADO,
      *        :NRA-TASA,
      *        :NRA-CENTRO-UMO,
      *        :NRA-USERID-UMO,
      *        :NRA-NETNAME-UMO,
      *COL05-I
      *         CURRENT TIMESTAMP)
      *         CURRENT TIMESTAMP,
      *        :NRA-RATING,
      *        :NRA-RANGO-RATING,
      *        :NRA-GARANTIA,
      *        :NRA-PORCENTA)
      *COL05-F
      *    END-EXEC
      *    INITIALIZE                          DB2-RETURN-CDE
      *    MOVE ZEROS                       TO SQLCODE
      *    MOVE SQLCODE                     TO DB2-RETURN-CDE
      *                                        WVS-SQLCODE-ED
      *
      *    EVALUATE TRUE
      *        WHEN DB2-OK
      *             ADD 1                   TO WC-GRABADO-TABLA
      *             PERFORM 2211-GRABA-SALIDA
      *             MOVE  WC-GRABADO-TABLA  TO WS-PARM-COMMIT
      *        WHEN OTHER
      *COL07-I
      *             MOVE 'ERROR INSERT'     TO SERR-DETALLE-ERROR(01:50)
      *             MOVE  WVS-SQLCODE-ED    TO SERR-DETALLE-ERROR(51:10)
      *             MOVE 'ERROR INSERT'     TO SERR-DETALLE-ERROR(01:20)
      *             MOVE  WVS-SQLCODE-ED    TO SERR-DETALLE-ERROR(22:10)
      *COL07-F
      *             PERFORM 2111-GRABA-SALIDA-ERROR
      *             PERFORM 000500-HACER-COMMIT
      *    END-EVALUATE.                                                00161800
      *
      *                                                                 00169400
      ******************************************************************00152200
      *                   2211-VALIDA-UGDTNRA                           00152300
      ******************************************************************00152400
      *                                                                 00152500
      *2211-VALIDA-UGDTNRA.                                             00152600
      *                                                                 00152700
      *    MOVE ZEROS                           TO WS-CONTA-REGS        00094200
      *                                            WS-CSC
      *      EXEC SQL                                                   00094400
      *           SELECT COUNT(*)                                       00094500
      *           INTO   :WS-CONTA-REGS                                 00094600
      *           FROM   UGDTNRA                                        00094800
      *           WHERE NRA_TIPO_PRODUCTO = :NRA-TIPO-PRODUCTO  AND     00094900
      *                 NRA_VARIABLE      = :NRA-VARIABLE       AND     00094900
      *                 NRA_ESTADO        = 'VS'                        00094900
      *                                                                 00095000
      *      END-EXEC                                                   00095100
      *                                                                 00095200
      *    MOVE  SQLCODE                          TO DB2-RETURN-CDE     00095300
      *                                              WVS-SQLCODE-ED
      *                                                                 00095400
      *    IF DB2-OK                                                    00095500
      *       IF WS-CONTA-REGS > ZEROS                                  00095600
      *          MOVE WS-CONTA-REGS               TO WS-CSC
      *          ADD 1                            TO WS-CSC
      *       ELSE
      *          ADD 1                            TO WS-CSC
      *       END-IF                                                    00096000
      *    ELSE                                                         00096100
      *       IF DB2-NOTFND                                             00096200
      *          ADD 1                            TO WS-CSC
      *       ELSE                                                      00096400
      *         IF DB2-NODISP  OR DB2-ATRAPA                            00096500
      *            MOVE 'ERROR SELECT'     TO SERR-DETALLE-ERROR(01:50)
      *            MOVE  WVS-SQLCODE-ED    TO SERR-DETALLE-ERROR(51:10)
      *            PERFORM 2111-GRABA-SALIDA-ERROR
      *            PERFORM 000500-HACER-COMMIT
      *         ELSE                                                    00097300
      *            MOVE 'ERROR SELECT'     TO SERR-DETALLE-ERROR(01:50)
      *            MOVE  WVS-SQLCODE-ED    TO SERR-DETALLE-ERROR(51:10)
      *            PERFORM 2111-GRABA-SALIDA-ERROR
      *            PERFORM 000500-HACER-COMMIT
      *         END-IF                                                  00097800
      *       END-IF                                                    00097900
      *    END-IF.                                                      00098000
      *----------------------------------------------------------------*
      *  SE PROCEDE A CREAR EL REGISTRO EN LA UGDTNRA DE LAS VARIABLES *
      *  QUE APLICAN POR TIPO DE CARTERA                               *
      *----------------------------------------------------------------*
       2212-MOVER-VARIA-UGDTNRA-INS.
           INITIALIZE UGTCNRA
           ADD 1                           TO WS-CONSECUTIVO01
           MOVE ENT-TIPO-PRODUCTO          TO NRA-TIPO-PRODUCTO         00000600
           MOVE '99'                       TO NRA-VARIABLE              00000800
           MOVE WS-CONSECUTIVO01           TO NRA-CONSECUTIVO
           MOVE WSV-TIMESTAMP-INI(01:10)   TO NRA-FECHA-INI             00000900
           MOVE WC-FECHA-FIN               TO NRA-FECHA-FIN             00001000
           MOVE ZEROS                      TO NRA-SEGMENTO
                                              NRA-RANGO-INI             00001100
                                              NRA-RANGO-FIN             00001200
                                              NRA-MONTO-INICIAL
                                              NRA-MONTO-FINAL
                                              NRA-RANGO-RIESGO-INI
                                              NRA-RANGO-RIESGO-FIN
                                              NRA-MONTO-INICIAL
                                              NRA-MONTO-FINAL
                                              NRA-SEGMENTO
                                              NRA-TASA
           MOVE SPACES                     TO NRA-IND-DOM-NOMINA
                                              NRA-SITUA-LABORAL         00001400
                                              NRA-IND-ESTADO-VEH
                                              NRA-IND-TIPO-VEH
                                              NRA-IND-CLIENTE-VIP       00001400
                                              NRA-RATING                00001300
                                              NRA-RANGO-RATING          00001300
                                              NRA-GARANTIA              00001300
           MOVE ENT-VALIDA-VARIABLE        TO NRA-CLAVE-ID
                                              NRA-CLUSTER
           MOVE 'VS'                       TO NRA-ESTADO
           MOVE '0018'                     TO NRA-CENTRO-UMO
           MOVE 'UG4CRAR1'                 TO NRA-USERID-UMO
           MOVE 'J018'                     TO NRA-NETNAME-UMO

           MOVE CURRENT-TIMESTAMP          TO NRA-TIMESTAMP
           PERFORM 2112-GRABA-SALIDA-UGDTNRA
           .
      *COL11-F
      *
      ******************************************************************
      * GRABA SALIDA                                                   *
      ******************************************************************
       2211-GRABA-SALIDA.
      *
           INITIALIZE                          W-LINEA-DETALLE-1

           MOVE ENT-TIPO-PRODUCTO              TO WLD1-PRODUCTO
           MOVE ENT-VALIDA-VARIABLE            TO WLD1-VARIABLE
           MOVE WTD-DESCR(ENT-VALIDA-VARIABLE-9) TO WLD1-DESCRIPCION
           MOVE WS-CONSECUTIVO                 TO WLD1-CONSENCUTIVO
           MOVE ENT-RANGO-INI                  TO WLD1-RANGO-INI
           MOVE ENT-RANGO-FIN                  TO WLD1-RANGO-FIN
      * COL09-I
      *    MOVE WEMIN-ENT-MONTO-INI-9          TO WLD1-MONTO-INI
      *    MOVE WEMIN-ENT-MONTO-FIN-9          TO WLD1-MONTO-FIN
           MOVE W-ENT-MONTO-INI1               TO WLD1-MONTO-INI
           MOVE W-ENT-MONTO-FIN1               TO WLD1-MONTO-FIN
      * COL09-F
           MOVE ENT-IND-CLIENTE                TO WLD1-IND
           IF   ENT-IND-CLIENTE-9  = '1' OR '2' OR '3' OR '4'
                                      OR  '5'
      *COL12-I
                                      OR  '6'
      *COL12-F
                MOVE WTL-LABORAL(ENT-IND-CLIENTE-9) TO WLD1-NOMBRE
           END-IF
           MOVE WSV-TIMESTAMP-INI(01:10)       TO WLD1-FECHA-INI
      *    MOVE WTL-LETRAS(WS-CONSECUTIVO)     TO WLD1-CLAVE
      *COL07-I
      *    MOVE WTL-LETRAS(WS-CSC)             TO WLD1-CLAVE
           MOVE WTL-LETRAS(WS-CONSECUTIVO)     TO WLD1-CLAVE
      *COL07-F
      *COL05-I
           IF ENT-TIPO-PRODUCTO = 'C'
              MOVE ENT-DATOS-COMER             TO WLD1-DTOS-COMER
              IF ENT-VALIDA-VARIABLE   = '18' OR
                 ENT-VALIDA-VARIABLE   = '23'
                 MOVE WEMIF-ENT-MONTO-INI-REDFIN  TO WLD1-MONTO-INI
                 MOVE WEMIF-ENT-MONTO-INI-REDFON  TO WLD1-MONTO-FIN
              END-IF
           END-IF
      *COL05-F

           WRITE SAL-UGTCNRA      FROM W-LINEA-DETALLE-1

           IF VAR-ERROR = '00'
              ADD 1    TO   WC-GRABADO-SALIDA
              CONTINUE
           ELSE
              DISPLAY '**************************************'
              DISPLAY '*ERROR AL GRABAR ARHIVO DE SALIDA    *'
              DISPLAY '*------------------------------------*'
              DISPLAY '*ESTATUS DEL ARCHIVO : ' VAR-SALIDA
              DISPLAY '*------------------------------------*'
              STOP RUN
           END-IF.
      *----------------------------------------------------------------*
      *                  2211-VALIDA-GRUPO-RIESGOS                     *
      *----------------------------------------------------------------*
      *COL11-I
      *2211-VALIDA-GRUPO-RIESGOS.
      *
      *    MOVE WEMIN-ENT-MONTO-INI-9     TO WMIF-ENT-MONTO-REDFIN-9
      *    MOVE WEMIN-ENT-MONTO-FIN-9     TO WMIF-ENT-MONTO-REDFON-9
      *    MOVE NRA-RANGO-RIESGO-INI      TO WMIT-MONTO-INI
      *    MOVE NRA-RANGO-RIESGO-FIN      TO WMFT-MONTO-FIN
      *
      *    IF (WEMIF-ENT-MONTO-INI-REDFIN  = WMIT-MONTO-INI) AND
      *       (WEMIF-ENT-MONTO-INI-REDFON  = WMFT-MONTO-FIN)
      *       MOVE 'GRP.RIESGO INI Y GRP.RIESGO-FIN DUPLICADOS' TO
      *                                   SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *    ELSE
      *     IF (WEMIF-ENT-MONTO-INI-REDFIN <= WMFT-MONTO-FIN OR
      *         WEMIF-ENT-MONTO-INI-REDFIN  = WMIT-MONTO-INI OR
      *         WEMIF-ENT-MONTO-INI-REDFON  = WMFT-MONTO-FIN) AND
      *         WMFT-MONTO-FIN  > 0
      *         MOVE 'RANGO INVALIDO FUERA INTERVALO ' TO
      *                                   SERR-DETALLE-ERROR
      *        PERFORM 2111-GRABA-SALIDA-ERROR
      *     ELSE
      *COL07-I
      *         PERFORM 2211-SELECT-MAXTABLA-UGDTNRA
      *COL07-F
      *       PERFORM 2211-MOVER-DATOS-UGDTNRA-INS
      *     END-IF
      *    END-IF
      *    .
      *----------------------------------------------------------------*
      *                  2211-VALIDA-GRUPO-FETCH
      *----------------------------------------------------------------*
      *2211-VALIDA-GRUPO-FETCH.
      *
      *    INITIALIZE                       WMIT-MONTO-INI
      *                                     WMFT-MONTO-FIN
      *
      *    MOVE WEMIN-ENT-MONTO-INI-9     TO WMIF-ENT-MONTO-REDFIN-9
      *    MOVE WEMIN-ENT-MONTO-FIN-9     TO WMIF-ENT-MONTO-REDFON-9
      *    MOVE NRA-RANGO-RIESGO-INI      TO WMIT-MONTO-INI
      *    MOVE NRA-RANGO-RIESGO-FIN      TO WMFT-MONTO-FIN
      *
      *    IF (WEMIF-ENT-MONTO-INI-REDFIN  = WMIT-MONTO-INI) AND
      *       (WEMIF-ENT-MONTO-INI-REDFON  = WMFT-MONTO-FIN)
      *       MOVE 'RIEGO-INI Y RIESGO-FIN DUPLICADOS' TO
      *                                   SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *       SET WSF-SVA-FETCH      TO TRUE
      *    END-IF
      *    .
      *COL11-F
      *----------------------------------------------------------------*
      *                    22-VALIDA-GRUPO-RIESGOS                     *
      *----------------------------------------------------------------*
       22-VALIDA-GRUPO-RIESGOS.

           IF WEMIN-ENT-MONTO-INI-9   IS NOT NUMERIC
              SET NO-CORRECTO         TO TRUE
              MOVE SPACES             TO SERR-DETALLE-ERROR
              MOVE 'GRUPO DE RIESGO DEBE SER NUMERICO' TO
                                         SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           END-IF
      *
           IF WEMIN-ENT-MONTO-INI-9 <  ZEROES
              SET NO-CORRECTO          TO TRUE
              MOVE SPACES              TO SERR-DETALLE-ERROR
              MOVE 'GRUPO DE RIESGO DEBE SER MAYOR A 0' TO
                                          SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           END-IF
      *
           IF WEMIN-ENT-MONTO-FIN-9 IS NOT NUMERIC
              SET NO-CORRECTO       TO TRUE
              MOVE SPACES           TO SERR-DETALLE-ERROR
              MOVE 'GRUPO DE RIESGO DEBE SER NUMERICO' TO
                                       SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           END-IF

           IF WEMIN-ENT-MONTO-INI-9 = WEMIN-ENT-MONTO-FIN-9
              SET NO-CORRECTO       TO TRUE
              MOVE SPACES           TO SERR-DETALLE-ERROR
              MOVE 'INGRESO-INI NO DEBE SER IGUAL A INGRESO FIN' TO
                                       SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           END-IF
      *
           IF WEMIN-ENT-MONTO-INI-9  = ZEROES AND
              WEMIN-ENT-MONTO-FIN-9  = ZEROES
              CONTINUE
           ELSE
             IF (WEMIN-ENT-MONTO-INI-9  >= WEMIN-ENT-MONTO-FIN-9) OR
                (WEMIN-ENT-MONTO-FIN-9  <= ZEROES)
                SET NO-CORRECTO       TO TRUE
                MOVE SPACES           TO SERR-DETALLE-ERROR
                MOVE 'GRUPO RIESGO FINAL <= GRUPO RIESGO INI' TO
                                         SERR-DETALLE-ERROR
                PERFORM 2111-GRABA-SALIDA-ERROR
              END-IF
           END-IF
      *
      *COL11-I
            IF WEMIN-ENT-MONTO-INI-9  <= WS-GRUP-MONTO-INI
               AND WEMIN-ENT-MONTO-FIN-9 > ZEROS
               AND WS-GRUP-MONTO-INI > ZEROS
               AND SI-CORRECTO
               SET NO-CORRECTO        TO TRUE
               MOVE SPACES            TO SERR-DETALLE-ERROR
               MOVE 'GRUPO DE RIESGO INI MENOR ANTERIOR' TO
                                         SERR-DETALLE-ERROR
               PERFORM 2111-GRABA-SALIDA-ERROR
            ELSE
               MOVE WEMIN-ENT-MONTO-INI-9 TO WS-GRUP-MONTO-INI
            END-IF
            IF WEMIN-ENT-MONTO-FIN-9  <= WS-GRUP-MONTO-FIN
               AND SI-CORRECTO
               SET NO-CORRECTO        TO TRUE
               MOVE SPACES            TO SERR-DETALLE-ERROR
               MOVE 'GRUPO DE RIESGO FIN MENOR ANTERIOR' TO
                                         SERR-DETALLE-ERROR
               PERFORM 2111-GRABA-SALIDA-ERROR
            ELSE
               MOVE WEMIN-ENT-MONTO-FIN-9 TO WS-GRUP-MONTO-FIN
            END-IF
      *COL11-F
            IF SI-CORRECTO
               PERFORM 2211-CONSULTA-UGDTNRA
            END-IF.
      *----------------------------------------------------------------*
      *                    23-VALIDA-INGRESOS                          *
      *----------------------------------------------------------------*
       23-VALIDA-INGRESOS.

             IF WEMIN-ENT-MONTO-INI-9   IS NOT NUMERIC
                SET NO-CORRECTO         TO TRUE
                MOVE SPACES             TO SERR-DETALLE-ERROR
                MOVE 'INGRESOS INICIAL DEBE SER NUMERICO' TO
                                           SERR-DETALLE-ERROR
                PERFORM 2111-GRABA-SALIDA-ERROR
             END-IF
      *
             IF WEMIN-ENT-MONTO-INI-9  <  ZEROES
                SET NO-CORRECTO         TO TRUE
                MOVE SPACES             TO SERR-DETALLE-ERROR
                MOVE 'INGRESOS INICIAL DEBE SER MAYOR 0' TO
                                           SERR-DETALLE-ERROR
                PERFORM 2111-GRABA-SALIDA-ERROR
             END-IF
      *
             IF WEMIN-ENT-MONTO-FIN-9  IS NOT NUMERIC
                SET NO-CORRECTO        TO TRUE
                MOVE SPACES            TO SERR-DETALLE-ERROR
                MOVE 'INGRESO FINAL DEBE SER NUMERICO' TO
                                          SERR-DETALLE-ERROR
                PERFORM 2111-GRABA-SALIDA-ERROR
             END-IF

             IF WEMIN-ENT-MONTO-INI-9 =  WEMIN-ENT-MONTO-FIN-9
                SET NO-CORRECTO        TO TRUE
                MOVE SPACES            TO SERR-DETALLE-ERROR
                MOVE 'INGRESO INI NO DEBE  SER IGUAL INGRESO FIN' TO
                                          SERR-DETALLE-ERROR
                PERFORM 2111-GRABA-SALIDA-ERROR
             END-IF
      *
             IF WEMIN-ENT-MONTO-INI-9   = ZEROES AND
                WEMIN-ENT-MONTO-FIN-9   = ZEROES
                CONTINUE
             ELSE
               IF (WEMIN-ENT-MONTO-INI-9  >= WEMIN-ENT-MONTO-FIN-9) OR
                  (WEMIN-ENT-MONTO-FIN-9  <= ZEROES)
                  SET NO-CORRECTO        TO TRUE
                  MOVE SPACES            TO SERR-DETALLE-ERROR
                  MOVE 'INGRESO FINAL DEBE SER <= INGRESO INICIAL' TO
                                            SERR-DETALLE-ERROR
                  PERFORM 2111-GRABA-SALIDA-ERROR
               END-IF
           END-IF
      *COL11-I
           IF WEMIN-ENT-MONTO-INI-9   <= WS-MIN-MONTO-INI
              AND WEMIN-ENT-MONTO-INI-9 > ZEROS
              AND WS-MIN-MONTO-INI > ZEROS
              AND SI-CORRECTO
              SET NO-CORRECTO         TO TRUE
              MOVE SPACES             TO SERR-DETALLE-ERROR
              MOVE 'INGRESOS INICIAL MENOR ANTERIOR' TO
                                         SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           ELSE
              MOVE WEMIN-ENT-MONTO-INI-9 TO WS-MIN-MONTO-INI
           END-IF
           IF WEMIN-ENT-MONTO-FIN-9   <= WS-MAX-MONTO-FIN
              AND SI-CORRECTO
              SET NO-CORRECTO         TO TRUE
              MOVE SPACES             TO SERR-DETALLE-ERROR
              MOVE 'INGRESOS FINAL MENOR ANTERIOR' TO
                                         SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           ELSE
              MOVE WEMIN-ENT-MONTO-FIN-9 TO WS-MAX-MONTO-FIN
           END-IF
      *COL11-F
      * WS-MAX-MONTO-FIN
           IF SI-CORRECTO
               PERFORM 2211-CONSULTA-UGDTNRA
           END-IF.
      *----------------------------------------------------------------*
      *                    2211-VALIDA-INGRESO                         *
      *----------------------------------------------------------------*
      *COL11-I
      *2211-VALIDA-INGRESO.
      *
      *    MOVE WEMIN-ENT-MONTO-INI-9     TO WMIF-ENT-MONTO-REDFIN-9
      *    MOVE WEMIN-ENT-MONTO-FIN-9     TO WMIF-ENT-MONTO-REDFON-9
      *    MOVE NRA-MONTO-INICIAL         TO WMIT-MONTO-INI
      *    MOVE NRA-MONTO-FINAL           TO WMFT-MONTO-FIN
      *
      *    IF (WEMIF-ENT-MONTO-INI-REDFIN  = WMIT-MONTO-INI) AND
      *       (WEMIF-ENT-MONTO-INI-REDFON  = WMFT-MONTO-FIN)
      *        MOVE 'INGRESO-INI Y INGRESO FIN DUPLICADOS' TO
      *                                   SERR-DETALLE-ERROR
      *        PERFORM 2111-GRABA-SALIDA-ERROR
      *    ELSE
      *     IF (WEMIF-ENT-MONTO-INI-REDFIN <= WMFT-MONTO-FIN OR
      *         WEMIF-ENT-MONTO-INI-REDFIN  = WMIT-MONTO-INI OR
      *         WEMIF-ENT-MONTO-INI-REDFON  = WMFT-MONTO-FIN) AND
      *         WMFT-MONTO-FIN  > 0
      *         MOVE 'RANGO INVALIDO FUERA INTERVALO ' TO
      *                                   SERR-DETALLE-ERROR
      *        PERFORM 2111-GRABA-SALIDA-ERROR
      *     ELSE
      *COL07-I
      *         PERFORM 2211-SELECT-MAXTABLA-UGDTNRA
      *COL07-F
      *       PERFORM 2211-MOVER-DATOS-UGDTNRA-INS
      *     END-IF
      *    END-IF
      *    .
      *----------------------------------------------------------------*
      *                    2211-VALIDA-INGRESO-FETCH                   *
      *----------------------------------------------------------------*
      *2211-VALIDA-INGRESO-FETCH.
      *
      *    INITIALIZE                       WMIT-MONTO-INI
      *                                     WMFT-MONTO-FIN
      *
      *    MOVE WEMIN-ENT-MONTO-INI-9     TO WMIF-ENT-MONTO-REDFIN-9
      *    MOVE WEMIN-ENT-MONTO-FIN-9     TO WMIF-ENT-MONTO-REDFON-9
      *    MOVE NRA-MONTO-INICIAL         TO WMIT-MONTO-INI
      *    MOVE NRA-MONTO-FINAL           TO WMFT-MONTO-FIN
      *
      *    IF (WEMIF-ENT-MONTO-INI-REDFIN  = WMIT-MONTO-INI) AND
      *       (WEMIF-ENT-MONTO-INI-REDFON  = WMFT-MONTO-FIN)
      *       MOVE 'INGRESO-INI Y INGRESO FIN DUPLICADOS' TO
      *                                   SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *       SET  WSF-SVA-FETCH      TO TRUE
      *    END-IF
      *    .
      *COL11-F
      *----------------------------------------------------------------*
      *                    24-DOM-NOMINA                               *
      *----------------------------------------------------------------*
       24-DOM-NOMINA.

             IF ENT-IND-CLIENTE    NOT EQUAL 'S' AND 'N'
                SET NO-CORRECTO        TO TRUE
                MOVE SPACES            TO SERR-DETALLE-ERROR
                MOVE 'DOM.NOMINA DEBE SER S/N' TO
                                          SERR-DETALLE-ERROR
                PERFORM 2111-GRABA-SALIDA-ERROR
             END-IF
      *COL11-I
             IF ENT-IND-CLIENTE        EQUAL WS-IND-CLIENTE
                AND SI-CORRECTO
                SET NO-CORRECTO        TO TRUE
                MOVE SPACES            TO SERR-DETALLE-ERROR
                MOVE 'DOM.NOMINA DUPLICADO' TO
                                          SERR-DETALLE-ERROR
                PERFORM 2111-GRABA-SALIDA-ERROR
             ELSE
                MOVE ENT-IND-CLIENTE   TO WS-IND-CLIENTE
             END-IF
      *COL11-F

             IF SI-CORRECTO
                PERFORM 2211-CONSULTA-UGDTNRA
             END-IF
             .
      *----------------------------------------------------------------*
      *                  2211-VALIDA-DOM-NOMINA                        *
      *----------------------------------------------------------------*
      *COL11-I
      *2211-VALIDA-DOM-NOMINA.
      *
      *    IF ENT-IND-CLIENTE =  NRA-IND-DOM-NOMINA
      *       MOVE 'IND. CLIENTE = IND. CLIENTE TABLA S/N' TO
      *                                 SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *    ELSE
      *COL07-I
      *         PERFORM 2211-SELECT-MAXTABLA-UGDTNRA
      *COL07-F
      *       PERFORM 2211-MOVER-DATOS-UGDTNRA-INS
      *    END-IF
      *    .
      *----------------------------------------------------------------*
      *                  2211-VALIDA-DOM-NOMINA-FETCH                  *
      *----------------------------------------------------------------*
      *2211-VALIDA-DOM-NOMINA-FETCH.
      *
      *    IF ENT-IND-CLIENTE =  NRA-IND-DOM-NOMINA
      *       MOVE 'IND. CLIENTE = IND. CLIENTE TABLA S/N' TO
      *                                 SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *       SET WSF-SVA-FETCH      TO TRUE
      *    END-IF
      *    .
      *COL11-F
      *----------------------------------------------------------------*
      *                    25-VALIDA-CLIENTE SI ES VIP O NO            *
      *----------------------------------------------------------------*
       25-VALIDA-CLIENTE.

             IF ENT-IND-CLIENTE        IS NOT EQUAL 'S' AND 'N'         02670000
                SET NO-CORRECTO        TO TRUE
                MOVE SPACES            TO SERR-DETALLE-ERROR
                MOVE 'CLIENTE VIP DEBE SER S/N' TO
                                          SERR-DETALLE-ERROR
                PERFORM 2111-GRABA-SALIDA-ERROR
             END-IF
      *COL11-I
             IF ENT-IND-CLIENTE        EQUAL WS-VIP-CLIENTE
                AND SI-CORRECTO
                SET NO-CORRECTO        TO TRUE
                MOVE SPACES            TO SERR-DETALLE-ERROR
                MOVE 'CLIENTE VIP DUPLICADO' TO
                                          SERR-DETALLE-ERROR
                PERFORM 2111-GRABA-SALIDA-ERROR
             ELSE
                MOVE ENT-IND-CLIENTE   TO WS-VIP-CLIENTE
             END-IF
      *COL11-F

             IF SI-CORRECTO
                PERFORM 2211-CONSULTA-UGDTNRA
             END-IF
             .
      *----------------------------------------------------------------*
      *                  2211-VALIDA-CLIENTE-VIP-05                    *
      *----------------------------------------------------------------*
      *COL11-I
      *2211-VALIDA-CLIENTE-VIP-05.
      *
      *    IF ENT-IND-CLIENTE          =  NRA-IND-CLIENTE-VIP
      *       MOVE 'CLA-VIP INI CLA-VIP FIN DUPLICADO' TO
      *                                   SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *    ELSE
      *COL07-I
      *         PERFORM 2211-SELECT-MAXTABLA-UGDTNRA
      *COL07-F
      *       PERFORM 2211-MOVER-DATOS-UGDTNRA-INS
      *    END-IF
      *    .
      *----------------------------------------------------------------*
      *                  2211-VALIDA-CLI-VIP-05-FETCH                  *
      *----------------------------------------------------------------*
      *2211-VALIDA-CLI-VIP-05-FETCH.
      *
      *    IF ENT-IND-CLIENTE          =  NRA-IND-CLIENTE-VIP
      *       MOVE 'CLA-VIP INI CLA-VIP FIN DUPLICADO' TO
      *                                   SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *       SET WSF-SVA-FETCH      TO TRUE
      *    END-IF
      *    .
      *COL11-F
      *----------------------------------------------------------------*
      *                    26-MONTO-FINANCIADO                         *
      *----------------------------------------------------------------*
       26-MONTO-FINANCIADO.

           IF WEMIN-ENT-MONTO-INI-9   IS NOT NUMERIC
              SET NO-CORRECTO         TO TRUE
              MOVE SPACES             TO SERR-DETALLE-ERROR
              MOVE 'MONTO FINANCIADO INI DEBE SER NUMERICO' TO
                                         SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           END-IF

           IF WEMIN-ENT-MONTO-INI-9  <  ZEROES
              SET NO-CORRECTO         TO TRUE
              MOVE SPACES             TO SERR-DETALLE-ERROR
              MOVE 'MONTO FINANCIADO INI DEBE SER MAYOR 0' TO
                                         SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
            END-IF
      *
           IF WEMIN-ENT-MONTO-INI-9  = WEMIN-ENT-MONTO-FIN-9
              SET NO-CORRECTO        TO TRUE
              MOVE SPACES            TO SERR-DETALLE-ERROR
              MOVE 'MONTO INI NO DEBE SER IGUAL MONTO FIN' TO
                                        SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           END-IF

           IF WEMIN-ENT-MONTO-FIN-9  IS NOT NUMERIC
              SET NO-CORRECTO        TO TRUE
              MOVE SPACES            TO SERR-DETALLE-ERROR
              MOVE 'MONTO FINANCIADO FIN DEBE SER NUMERICO' TO
                                        SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           END-IF
      *
           IF WEMIN-ENT-MONTO-INI-9   = ZEROES AND
              WEMIN-ENT-MONTO-FIN-9   = ZEROES
              CONTINUE
           ELSE
             IF (WEMIN-ENT-MONTO-INI-9  >= WEMIN-ENT-MONTO-FIN-9) OR
                (WEMIN-ENT-MONTO-FIN-9  <= ZEROES)
                SET NO-CORRECTO        TO TRUE
                MOVE SPACES            TO SERR-DETALLE-ERROR
                MOVE 'MONTO FIN DEBE SER <= MONTO FIN INICIAL' TO
                                          SERR-DETALLE-ERROR
                PERFORM 2111-GRABA-SALIDA-ERROR
             END-IF
           END-IF
      *COL11-I
           IF WEMIN-ENT-MONTO-INI-9  <= WS-FINA-MONTO-INI
              AND WEMIN-ENT-MONTO-FIN-9 > ZEROS
              AND WS-FINA-MONTO-INI > ZEROS
              AND SI-CORRECTO
              SET NO-CORRECTO        TO TRUE
              MOVE SPACES            TO SERR-DETALLE-ERROR
              MOVE 'MONTO FINANCIADO INI MENOR ANTERIOR' TO
                                        SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           ELSE
              MOVE WEMIN-ENT-MONTO-INI-9 TO WS-FINA-MONTO-INI
           END-IF
           IF WEMIN-ENT-MONTO-FIN-9  <= WS-FINA-MONTO-FIN
              AND SI-CORRECTO
              SET NO-CORRECTO        TO TRUE
              MOVE SPACES            TO SERR-DETALLE-ERROR
              MOVE 'MONTO FINANCIADO FIN MENOR ANTERIOR' TO
                                        SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           ELSE
              MOVE WEMIN-ENT-MONTO-FIN-9 TO WS-FINA-MONTO-FIN
           END-IF
      *COL11-F
      *
           IF SI-CORRECTO
              PERFORM 2211-CONSULTA-UGDTNRA
           END-IF
           .
      *----------------------------------------------------------------*
      *                    2211-VALIDA-MONTO-FINANCIADO                *
      *----------------------------------------------------------------*
      *COL11-I
      *2211-VALIDA-MONTO-FINANCIADO.
      *
      *    MOVE WEMIN-ENT-MONTO-INI-9     TO WMIF-ENT-MONTO-REDFIN-9
      *    MOVE WEMIN-ENT-MONTO-FIN-9     TO WMIF-ENT-MONTO-REDFON-9
      *    MOVE NRA-MONTO-INICIAL         TO WMIT-MONTO-INI
      *    MOVE NRA-MONTO-FINAL           TO WMFT-MONTO-FIN
      *
      *    IF (WEMIF-ENT-MONTO-INI-REDFIN  = WMIT-MONTO-INI) AND
      *       (WEMIF-ENT-MONTO-INI-REDFON  = WMFT-MONTO-FIN)
      *       MOVE 'FINCI-INI Y FINCI-FIN DUPLICADOS' TO
      *                                    SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *    ELSE
      *     IF (WEMIF-ENT-MONTO-INI-REDFIN <= WMFT-MONTO-FIN OR
      *         WEMIF-ENT-MONTO-INI-REDFIN  = WMIT-MONTO-INI OR
      *         WEMIF-ENT-MONTO-INI-REDFON  = WMFT-MONTO-FIN) AND
      *         WMFT-MONTO-FIN > 0
      *         MOVE 'RANGO INVALIDO FUERA INTERVALO ' TO
      *                                    SERR-DETALLE-ERROR
      *         PERFORM 2111-GRABA-SALIDA-ERROR
      *     ELSE
      *COL07-I
      *         PERFORM 2211-SELECT-MAXTABLA-UGDTNRA
      *COL07-F
      *       PERFORM 2211-MOVER-DATOS-UGDTNRA-INS
      *     END-IF
      *    END-IF
      *    .
      *----------------------------------------------------------------*
      *                    2211-VALIDA-FINANCIADO-FETCH                *
      *----------------------------------------------------------------*
      *2211-VALIDA-FINANCIADO-FETCH.
      *
      *    INITIALIZE                       WMIT-MONTO-INI
      *                                     WMFT-MONTO-FIN
      *
      *
      *    MOVE WEMIN-ENT-MONTO-INI-9     TO WMIF-ENT-MONTO-REDFIN-9
      *    MOVE WEMIN-ENT-MONTO-FIN-9     TO WMIF-ENT-MONTO-REDFON-9
      *    MOVE NRA-MONTO-INICIAL         TO WMIT-MONTO-INI
      *    MOVE NRA-MONTO-FINAL           TO WMFT-MONTO-FIN
      *
      *    IF (WEMIF-ENT-MONTO-INI-REDFIN  = WMIT-MONTO-INI) AND
      *       (WEMIF-ENT-MONTO-INI-REDFON  = WMFT-MONTO-FIN)
      *       MOVE 'FINCI-INI Y FINCI-FIN DUPLICADOS' TO
      *                                    SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *       SET WSF-SVA-FETCH      TO TRUE
      *    END-IF
      *    .
      *----------------------------------------------------------------*
      *                    27-PLAZO-OPERACION                          *
      *----------------------------------------------------------------*
       27-PLAZO-OPERACION.

           IF ENT-RANGO-INI            IS NOT NUMERIC
              SET NO-CORRECTO          TO TRUE
              MOVE SPACES              TO SERR-DETALLE-ERROR
              MOVE 'PLAZO INICIAL DEBE SER NUMERICO' TO
                                          SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           END-IF
      *
           IF ENT-RANGO-INI           <  ZEROES
              SET NO-CORRECTO          TO TRUE
              MOVE SPACES              TO SERR-DETALLE-ERROR
              MOVE 'PLAZO INICIAL DEBE SER MAYOR A 0' TO
                                          SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           END-IF
      *
           IF ENT-RANGO-FIN           IS NOT NUMERIC
              SET NO-CORRECTO          TO TRUE
              MOVE SPACES              TO SERR-DETALLE-ERROR
              MOVE 'PLAZO FINAL DEBE SER NUMERICO' TO
                                          SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           END-IF

           IF ENT-RANGO-INI   = ENT-RANGO-FIN
              SET NO-CORRECTO          TO TRUE
              MOVE SPACES              TO SERR-DETALLE-ERROR
              MOVE 'PLAZO INI NO DEBE SER IGUAL A PLAZO FIN' TO
                                          SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           END-IF
      *
           IF ENT-RANGO-INI         = ZEROES  AND
              ENT-RANGO-FIN         = ZEROES
              CONTINUE
           ELSE
             IF (ENT-RANGO-INI     >= ENT-RANGO-FIN) OR
                (ENT-RANGO-FIN     <= 0)
                SET NO-CORRECTO       TO TRUE
                MOVE SPACES           TO SERR-DETALLE-ERROR
                MOVE 'PLAZO FINAL <=  PLAZO INICIAL' TO
                                          SERR-DETALLE-ERROR
                 PERFORM 2111-GRABA-SALIDA-ERROR
             END-IF
           END-IF
           IF ENT-RANGO-INI       <= WS-PLAZO-INI
              AND ENT-RANGO-INI > ZEROS
              SET NO-CORRECTO          TO TRUE
              MOVE SPACES              TO SERR-DETALLE-ERROR
              MOVE 'PLAZO INICIAL MEMOR PLAZO ANTERIOR' TO
                                          SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           ELSE
              MOVE ENT-RANGO-INI            TO WS-PLAZO-INI
           END-IF
           IF ENT-RANGO-FIN       <= WS-PLAZO-FIN
              SET NO-CORRECTO          TO TRUE
              MOVE SPACES              TO SERR-DETALLE-ERROR
              MOVE 'PLAZO FINAL MENOR PLAZO ANTERIRO' TO
                                          SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           ELSE
              MOVE ENT-RANGO-FIN            TO WS-PLAZO-FIN
           END-IF
      *COL11-F
      *
           IF SI-CORRECTO
              PERFORM 2211-CONSULTA-UGDTNRA
           END-IF
           .
      *----------------------------------------------------------------*
      *                    2211-VALIDA-PLAZO-OPERACION                 *
      *----------------------------------------------------------------*
      *COL11-I
      *2211-VALIDA-PLAZO-OPERACION.
      *
      *    IF ENT-RANGO-INI            =   NRA-RANGO-INI AND
      *       ENT-RANGO-FIN            =   NRA-RANGO-FIN
      *       MOVE 'PLAZO-INI Y PLAZO-FIN DUPLICADOS' TO
      *                                   SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *    ELSE
      *      IF (ENT-RANGO-INI   <=   NRA-RANGO-FIN OR
      *          ENT-RANGO-INI    =   NRA-RANGO-INI OR
      *          ENT-RANGO-FIN    =   NRA-RANGO-FIN) AND
      *          NRA-RANGO-FIN    > 0
      *          MOVE 'RANGO INVALIDO FUERA INTERVALO ' TO
      *                                     SERR-DETALLE-ERROR
      *          PERFORM 2111-GRABA-SALIDA-ERROR
      *      ELSE
      *COL07-I
      *         PERFORM 2211-SELECT-MAXTABLA-UGDTNRA
      *COL07-F
      *         PERFORM 2211-MOVER-DATOS-UGDTNRA-INS
      *      END-IF
      *    END-IF
      *    .
      *----------------------------------------------------------------*
      *                    2211-VALIDA-PLAZO-OPE-FETCH                 *
      *----------------------------------------------------------------*
      *2211-VALIDA-PLAZO-OPE-FETCH.
      *
      *    IF ENT-RANGO-INI            =   NRA-RANGO-INI AND
      *       ENT-RANGO-FIN            =   NRA-RANGO-FIN
      *       MOVE 'PLAZO-INI Y PLAZO-FIN DUPLICADOS' TO
      *                                   SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *       SET WSF-SVA-FETCH      TO TRUE
      *    END-IF
      *    .
      *COL11-F
      *----------------------------------------------------------------*
      *                    28-GAMA-VEHICULO                            *
      *----------------------------------------------------------------*
       28-GAMA-VEHICULO.

            IF WEMIN-ENT-MONTO-INI-9    IS NOT NUMERIC
               SET NO-CORRECTO          TO TRUE
               MOVE SPACES              TO SERR-DETALLE-ERROR
               MOVE 'GAMA VEH INICIAL DEBE SER NUMERICO' TO
                                           SERR-DETALLE-ERROR
               PERFORM 2111-GRABA-SALIDA-ERROR
            END-IF
      *
            IF WEMIN-ENT-MONTO-INI-9    < ZEROES
               SET NO-CORRECTO          TO TRUE
               MOVE SPACES              TO SERR-DETALLE-ERROR
               MOVE 'GAMA VEH INICIAL DEBE SER MAYOR A 0' TO
                                           SERR-DETALLE-ERROR
               PERFORM 2111-GRABA-SALIDA-ERROR
            END-IF
      *
            IF WEMIN-ENT-MONTO-FIN-9 IS NOT NUMERIC
               SET NO-CORRECTO       TO TRUE
               MOVE SPACES           TO SERR-DETALLE-ERROR
               MOVE 'GAMA VEH FINAL DEBE SER NUMERICO' TO
                                        SERR-DETALLE-ERROR
               PERFORM 2111-GRABA-SALIDA-ERROR
            END-IF
      *

            IF WEMIN-ENT-MONTO-INI-9 =  WEMIN-ENT-MONTO-FIN-9
               SET NO-CORRECTO       TO TRUE
               MOVE SPACES           TO SERR-DETALLE-ERROR
               MOVE 'GAMA VEH FINAL DEBE IGUAL GAMA VEH FIN' TO
                                        SERR-DETALLE-ERROR
               PERFORM 2111-GRABA-SALIDA-ERROR
            END-IF
      *
            IF WEMIN-ENT-MONTO-INI-9  = ZEROES AND
               WEMIN-ENT-MONTO-FIN-9  = ZEROES
               CONTINUE
            ELSE
              IF (WEMIN-ENT-MONTO-INI-9  >= WEMIN-ENT-MONTO-FIN-9) OR
                 (WEMIN-ENT-MONTO-FIN-9  <= ZEROES)
                 SET NO-CORRECTO       TO TRUE
                 MOVE SPACES           TO SERR-DETALLE-ERROR
                 MOVE 'GAMA VEH FIN <= GAMA VEH INI' TO
                                          SERR-DETALLE-ERROR
                 PERFORM 2111-GRABA-SALIDA-ERROR
              END-IF
            END-IF
      *COL11-I
            IF WEMIN-ENT-MONTO-INI-9  <= WS-GAMA-MONTO-INI
               AND WEMIN-ENT-MONTO-FIN-9 > ZEROS
               AND WS-GAMA-MONTO-INI > ZEROS
               AND SI-CORRECTO
               SET NO-CORRECTO        TO TRUE
               MOVE SPACES            TO SERR-DETALLE-ERROR
               MOVE 'GAMA VEH INI MENOR ANTERIOR' TO
                                         SERR-DETALLE-ERROR
               PERFORM 2111-GRABA-SALIDA-ERROR
            ELSE
               MOVE WEMIN-ENT-MONTO-INI-9 TO WS-GAMA-MONTO-INI
            END-IF
            IF WEMIN-ENT-MONTO-FIN-9  <= WS-GAMA-MONTO-FIN
               AND SI-CORRECTO
               SET NO-CORRECTO        TO TRUE
               MOVE SPACES            TO SERR-DETALLE-ERROR
               MOVE 'GAMA VEH FIN MENOR ANTERIOR' TO
                                         SERR-DETALLE-ERROR
               PERFORM 2111-GRABA-SALIDA-ERROR
            ELSE
               MOVE WEMIN-ENT-MONTO-FIN-9 TO WS-GAMA-MONTO-FIN
            END-IF
      *COL11-F
      *
            IF SI-CORRECTO
               PERFORM 2211-CONSULTA-UGDTNRA
            END-IF
            .
      *----------------------------------------------------------------*
      *                    2211-VALIDA-GAMA-VEHICULO                   *
      *----------------------------------------------------------------*
      *COL11-I
      *2211-VALIDA-GAMA-VEHICULO.
      *
      *    MOVE WEMIN-ENT-MONTO-INI-9     TO WMIF-ENT-MONTO-REDFIN-9
      *    MOVE WEMIN-ENT-MONTO-FIN-9     TO WMIF-ENT-MONTO-REDFON-9
      *    MOVE NRA-MONTO-INICIAL         TO WMIT-MONTO-INI
      *    MOVE NRA-MONTO-FINAL           TO WMFT-MONTO-FIN
      *    IF (WEMIF-ENT-MONTO-INI-REDFIN  = WMIT-MONTO-INI) AND
      *       (WEMIF-ENT-MONTO-INI-REDFON  = WMFT-MONTO-FIN)
      *       MOVE 'GAMA-INI Y GAMA-FIN DUPLICADOS' TO
      *                                    SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *    ELSE
      *     IF (WEMIF-ENT-MONTO-INI-REDFIN <= WMFT-MONTO-FIN OR
      *         WEMIF-ENT-MONTO-INI-REDFIN  = WMIT-MONTO-INI OR
      *         WEMIF-ENT-MONTO-INI-REDFON  = WMFT-MONTO-FIN) AND
      *         WMFT-MONTO-FIN > 0
      *         MOVE 'RANGO INVALIDO FUERA INTERVALO ' TO
      *                                    SERR-DETALLE-ERROR
      *         PERFORM 2111-GRABA-SALIDA-ERROR
      *     ELSE
      *COL07-I
      *         PERFORM 2211-SELECT-MAXTABLA-UGDTNRA
      *COL07-F
      *       PERFORM 2211-MOVER-DATOS-UGDTNRA-INS
      *     END-IF
      *    END-IF
      *    .
      *----------------------------------------------------------------*
      *                    2211-VALIDA-VEHICULO-FETCH                  *
      *----------------------------------------------------------------*
      *2211-VALIDA-VEHICULO-FETCH.
      *
      *    IF WEMIN-ENT-MONTO-INI-9     = NRA-MONTO-INICIAL  AND
      *       WEMIN-ENT-MONTO-FIN-9     = NRA-MONTO-FINAL
      *       MOVE 'GAMA-INI Y GAMA-FIN DUPLICADOS' TO
      *                                    SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *       SET WSF-SVA-FETCH      TO TRUE
      *    END-IF
      *    .
      *COL11-F
      *----------------------------------------------------------------*
      *                    29-TIPO-PART-PUBLICO                        *
      *----------------------------------------------------------------*
       29-TIPO-PART-PUBLICO.

            IF ENT-IND-CLIENTE         IS NOT EQUAL 'P' AND 'S'         02670000
               SET NO-CORRECTO         TO TRUE
               MOVE SPACES             TO SERR-DETALLE-ERROR
               MOVE 'TIPO DE VEHICULO DEBE SER P/S' TO
                                          SERR-DETALLE-ERROR
               PERFORM 2111-GRABA-SALIDA-ERROR
            END-IF

      *COL11-I
             IF ENT-IND-CLIENTE        EQUAL WS-TIP-VEHICULO
                AND SI-CORRECTO
                SET NO-CORRECTO        TO TRUE
                MOVE SPACES            TO SERR-DETALLE-ERROR
                MOVE 'TIPO DE VEHICULO DUPLICADO' TO
                                          SERR-DETALLE-ERROR
                PERFORM 2111-GRABA-SALIDA-ERROR
             ELSE
                MOVE ENT-IND-CLIENTE   TO WS-TIP-VEHICULO
             END-IF
      *COL11-F
            IF SI-CORRECTO
               PERFORM 2211-CONSULTA-UGDTNRA
            END-IF
            .
      *----------------------------------------------------------------*
      *                    2211-VALIDA-TIPO-USO-PART                   *
      *----------------------------------------------------------------*
      *COL11-I
      *2211-VALIDA-TIPO-USO-PART.
      *
      *    IF ENT-IND-CLIENTE          =  NRA-IND-TIPO-VEH
      *       MOVE 'TIP-USO-PART INI - TIP-USO-PART FIN' TO
      *                                   SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *    ELSE
      *COL07-I
      *         PERFORM 2211-SELECT-MAXTABLA-UGDTNRA
      *COL07-F
      *       PERFORM 2211-MOVER-DATOS-UGDTNRA-INS
      *    END-IF
      *    .
      *----------------------------------------------------------------*
      *                    2211-VALIDA-TIPO-USO-FETCH             *
      *----------------------------------------------------------------*
      *2211-VALIDA-TIPO-USO-FETCH.
      *
      *    IF ENT-IND-CLIENTE          =  NRA-IND-TIPO-VEH
      *       MOVE 'TIP-USO-PART INI - TIP-USO-PART FIN' TO
      *                                   SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *       SET WSF-SVA-FETCH      TO TRUE
      *    END-IF
      *    .
      *COL11-F
      *----------------------------------------------------------------*
      *                    30-TIPO-VEHICULO                            *
      *----------------------------------------------------------------*
       30-TIPO-VEHICULO.

             IF ENT-IND-CLIENTE        IS NOT EQUAL 'N' AND 'U'         02670000
                SET NO-CORRECTO        TO TRUE
                MOVE SPACES            TO SERR-DETALLE-ERROR
                MOVE 'TIPO DE VEHICULO DEBE SER N/U' TO
                                          SERR-DETALLE-ERROR
                PERFORM 2111-GRABA-SALIDA-ERROR
             END-IF
      *COL11-I
             IF ENT-IND-CLIENTE        EQUAL WS-ESTADO-VEHICULO
                AND SI-CORRECTO
                SET NO-CORRECTO        TO TRUE
                MOVE SPACES            TO SERR-DETALLE-ERROR
                MOVE 'TIPO ESTADO DE VEHICULO DUPLICADO' TO
                                          SERR-DETALLE-ERROR
                PERFORM 2111-GRABA-SALIDA-ERROR
             ELSE
                MOVE ENT-IND-CLIENTE   TO WS-ESTADO-VEHICULO
             END-IF
      *COL11-F

             IF SI-CORRECTO
                PERFORM 2211-CONSULTA-UGDTNRA
             END-IF
             .
      *----------------------------------------------------------------*
      *                    2211-VALIDA-ESTADO-VEHI-NUEVO               *
      *----------------------------------------------------------------*
      *COL11-I
      *2211-VALIDA-ESTADO-VEHI-NUEVO.
      *
      *    IF ENT-IND-CLIENTE         =  NRA-IND-ESTADO-VEH
      *       MOVE 'EST-VEH-INI Y EST-VEH-FIN DUPLICADO' TO
      *                                  SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *    ELSE
      *COL07-I
      *         PERFORM 2211-SELECT-MAXTABLA-UGDTNRA
      *COL07-F
      *       PERFORM 2211-MOVER-DATOS-UGDTNRA-INS
      *    END-IF
      *    .
      *----------------------------------------------------------------*
      *                    2211-VALIDA-VEHI-NUEVO-FETCH                *
      *----------------------------------------------------------------*
      *2211-VALIDA-VEHI-NUEVO-FETCH.
      *
      *    IF ENT-IND-CLIENTE         =  NRA-IND-ESTADO-VEH
      *       MOVE 'EST-VEH-INI Y EST-VEH-FIN DUPLICADO' TO
      *                                  SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *       SET WSF-SVA-FETCH      TO TRUE
      *    END-IF
      *    .
      *COL11-F
      *----------------------------------------------------------------*
      *                    31-FINANCIACION                             *
      *----------------------------------------------------------------*
       31-FINANCIACION.

            IF WEMIN-ENT-MONTO-INI-9   IS NOT NUMERIC
               SET NO-CORRECTO         TO TRUE
               MOVE SPACES             TO SERR-DETALLE-ERROR
               MOVE 'FINANCIACION % INICIO DEBE SER NUMERICO' TO
                                          SERR-DETALLE-ERROR
               PERFORM 2111-GRABA-SALIDA-ERROR
            END-IF
      *
            IF WEMIN-ENT-MONTO-INI-9   < ZEROES
               SET NO-CORRECTO         TO TRUE
               MOVE SPACES             TO SERR-DETALLE-ERROR
               MOVE 'FINANCIACION % FINAL DEBE SER MAYOR A 0' TO
                                          SERR-DETALLE-ERROR
               PERFORM 2111-GRABA-SALIDA-ERROR
            END-IF
      *
            IF WEMIN-ENT-MONTO-FIN-9  IS NOT NUMERIC
               SET NO-CORRECTO        TO TRUE
               MOVE SPACES            TO SERR-DETALLE-ERROR
               MOVE 'FINANCIACION % FINAL DEBE SER NUMERICO' TO
                                         SERR-DETALLE-ERROR
               PERFORM 2111-GRABA-SALIDA-ERROR
            END-IF
      *
            IF WEMIN-ENT-MONTO-FIN-9  =  ZEROES
               SET NO-CORRECTO        TO TRUE
               MOVE SPACES            TO SERR-DETALLE-ERROR
               MOVE 'FINANCIACION % FINAL  DEBE SER MAYOR A 0' TO
                                         SERR-DETALLE-ERROR
               PERFORM 2111-GRABA-SALIDA-ERROR
            END-IF
      *
            IF WEMIN-ENT-MONTO-INI-9 = ZEROES AND
               WEMIN-ENT-MONTO-FIN-9 = ZEROES
               CONTINUE
            ELSE
              IF (WEMIN-ENT-MONTO-INI-9  >= WEMIN-ENT-MONTO-FIN-9) OR
                 (WEMIN-ENT-MONTO-FIN-9  <= ZEROES)
                 SET NO-CORRECTO        TO TRUE
                 MOVE SPACES            TO SERR-DETALLE-ERROR
                 MOVE 'FINANCIACION % FINAL >= FINACIACION INICIAL' TO
                                           SERR-DETALLE-ERROR
                 PERFORM 2111-GRABA-SALIDA-ERROR
              END-IF
            END-IF
      *
            IF WEMIN-ENT-MONTO-INI-9  =  WEMIN-ENT-MONTO-FIN-9
               SET NO-CORRECTO        TO TRUE
               MOVE SPACES            TO SERR-DETALLE-ERROR
               MOVE 'FINAN. % INI NO DEBE SER = FINAN. % FIN'
                                      TO SERR-DETALLE-ERROR
               PERFORM 2111-GRABA-SALIDA-ERROR
            END-IF
      *
      *COL11-I
            IF WEMIN-ENT-MONTO-INI-9  <= WS-PORCFINA-MONTO-INI
               AND WEMIN-ENT-MONTO-FIN-9 > ZEROS
               AND WS-PORCFINA-MONTO-INI > ZEROS
               AND SI-CORRECTO
               SET NO-CORRECTO        TO TRUE
               MOVE SPACES            TO SERR-DETALLE-ERROR
               MOVE 'FINAN. % INI MENOR ANTERIOR' TO
                                         SERR-DETALLE-ERROR
               PERFORM 2111-GRABA-SALIDA-ERROR
            ELSE
               MOVE WEMIN-ENT-MONTO-INI-9 TO WS-PORCFINA-MONTO-INI
            END-IF
            IF WEMIN-ENT-MONTO-FIN-9  <= WS-PORCFINA-MONTO-FIN
               AND SI-CORRECTO
               SET NO-CORRECTO        TO TRUE
               MOVE SPACES            TO SERR-DETALLE-ERROR
               MOVE 'FINAN. % FIN MENOR ANTERIOR' TO
                                         SERR-DETALLE-ERROR
               PERFORM 2111-GRABA-SALIDA-ERROR
            ELSE
               MOVE WEMIN-ENT-MONTO-FIN-9 TO WS-PORCFINA-MONTO-FIN
            END-IF
      *COL11-F
            IF SI-CORRECTO
               PERFORM 2211-CONSULTA-UGDTNRA
            END-IF
            .
      *----------------------------------------------------------------*
      *                    2211-VALIDA-FINANCIACION                    *
      *----------------------------------------------------------------*
      *COL11-I
      *2211-VALIDA-FINANCIACION.
      *
      *    MOVE WEMIN-ENT-MONTO-INI-9     TO WMIF-ENT-MONTO-REDFIN-9
      *    MOVE WEMIN-ENT-MONTO-FIN-9     TO WMIF-ENT-MONTO-REDFON-9
      *    MOVE NRA-MONTO-INICIAL         TO WMIT-MONTO-INI
      *    MOVE NRA-MONTO-FINAL           TO WMFT-MONTO-FIN
      *
      *    IF (WEMIF-ENT-MONTO-INI-REDFIN  = WMIT-MONTO-INI) AND
      *       (WEMIF-ENT-MONTO-INI-REDFON  = WMFT-MONTO-FIN)
      *       MOVE 'FINANCIACION-INI FINANCIACION FIN DUPLI' TO
      *                                     SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *    ELSE
      *     IF (WEMIF-ENT-MONTO-INI-REDFIN <= WMFT-MONTO-FIN OR
      *         WEMIF-ENT-MONTO-INI-REDFIN =  WMIT-MONTO-INI OR
      *         WEMIF-ENT-MONTO-INI-REDFON =  WMFT-MONTO-FIN ) AND
      *         WMFT-MONTO-FIN             > 0
      *          MOVE 'RANGO INVALIDO FUERA INTERVALO ' TO
      *                                     SERR-DETALLE-ERROR
      *          PERFORM 2111-GRABA-SALIDA-ERROR
      *     ELSE
      *COL07-I
      *         PERFORM 2211-SELECT-MAXTABLA-UGDTNRA
      *COL07-F
      *       PERFORM 2211-MOVER-DATOS-UGDTNRA-INS
      *     END-IF
      *    END-IF
      *    .
      *----------------------------------------------------------------*
      *                    2211-VALIDA-FINANCIACION-FETCH              *
      *----------------------------------------------------------------*
      *2211-VALIDA-FINANCIACION-FETCH.
      *
      *    INITIALIZE                       WMIT-MONTO-INI
      *                                     WMFT-MONTO-FIN
      *
      *    MOVE WEMIN-ENT-MONTO-INI-9     TO WMIF-ENT-MONTO-REDFIN-9
      *    MOVE WEMIN-ENT-MONTO-FIN-9     TO WMIF-ENT-MONTO-REDFON-9
      *    MOVE NRA-MONTO-INICIAL         TO WMIT-MONTO-INI
      *    MOVE NRA-MONTO-FINAL           TO WMFT-MONTO-FIN
      *
      *    IF (WEMIF-ENT-MONTO-INI-REDFIN  = WMIT-MONTO-INI) AND
      *       (WEMIF-ENT-MONTO-INI-REDFON  = WMFT-MONTO-FIN)
      *       MOVE 'FINANCIACION-INI FINANCIACION FIN DUPLI' TO
      *                                     SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *       SET WSF-SVA-FETCH      TO TRUE
      *    END-IF
      *    .
      *COL11-F
      *----------------------------------------------------------------*
      *                    32-SEGMENTO                                 *
      *----------------------------------------------------------------*
       32-SEGMENTO.


            IF WEMIN-ENT-MONTO-INI-9 (1:5)  = 99999
               SET NO-CORRECTO         TO TRUE
            END-IF
            IF WEMIN-ENT-MONTO-INI-9   IS NOT NUMERIC
               SET NO-CORRECTO         TO TRUE
               MOVE SPACES             TO SERR-DETALLE-ERROR
               MOVE 'SEGMENTO INICIO DEBE SER NUMERICO' TO
                                          SERR-DETALLE-ERROR
               PERFORM 2111-GRABA-SALIDA-ERROR
            END-IF
      *
            IF WEMIN-ENT-MONTO-INI-9   < ZEROES
               SET NO-CORRECTO         TO TRUE
               MOVE SPACES             TO SERR-DETALLE-ERROR
               MOVE 'SEGMENTO DEBE SER MAYOR A 0' TO
                                          SERR-DETALLE-ERROR
               PERFORM 2111-GRABA-SALIDA-ERROR
            END-IF
      *COL11-I
            IF WEMIN-ENT-MONTO-INI-9  <= WS-SEGMENTO-INI
               AND WS-SEGMENTO-INI > ZEROS
               AND SI-CORRECTO
               SET NO-CORRECTO        TO TRUE
               MOVE SPACES            TO SERR-DETALLE-ERROR
               MOVE 'SEGMENTO INI MENOR ANTERIOR' TO
                                         SERR-DETALLE-ERROR
               PERFORM 2111-GRABA-SALIDA-ERROR
            ELSE
               MOVE WEMIN-ENT-MONTO-INI-9 TO WS-SEGMENTO-INI
            END-IF
      *COL11-F

            IF SI-CORRECTO
               PERFORM 2211-CONSULTA-UGDTNRA
            END-IF
           .

      *----------------------------------------------------------------*
      *                    2211-VALIDA-SEGMENTO                        *
      *----------------------------------------------------------------*
      *COL11-I
      *2211-VALIDA-SEGMENTO.
      *
      *    MOVE WEMIN-ENT-MONTO-INI-9     TO WMIF-ENT-MONTO-REDFIN-9
      *    MOVE NRA-SEGMENTO              TO WMIT-MONTO-INI
      *
      *    IF WEMIF-ENT-MONTO-INI-REDFIN  = WMIT-MONTO-INI
      *       MOVE 'SEGEMENTO INI Y SEGMENTO FIN DUPLICADO' TO
      *                                      SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *    ELSE
      *COL07-I
      *         PERFORM 2211-SELECT-MAXTABLA-UGDTNRA
      *COL07-F
      *       PERFORM 2211-MOVER-DATOS-UGDTNRA-INS
      *    END-IF
      *    .
      *----------------------------------------------------------------*
      *                    2211-VALIDA-SEGMENTO-FETCH                  *
      *----------------------------------------------------------------*
      *2211-VALIDA-SEGMENTO-FETCH.
      *
      *    INITIALIZE                       WMIT-MONTO-INI
      *
      *    MOVE WEMIN-ENT-MONTO-INI-9     TO WMIF-ENT-MONTO-REDFIN-9
      *    MOVE NRA-SEGMENTO              TO WMIT-MONTO-INI
      *
      *    IF WEMIF-ENT-MONTO-INI-REDFIN  = WMIT-MONTO-INI
      *       MOVE 'SEGEMENTO INI Y SEGMENTO FIN DUPLICADO' TO
      *                                      SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *       SET WSF-SVA-FETCH      TO TRUE
      *    END-IF
      *    .
      *COL11-F
      *----------------------------------------------------------------*
      *                    33-COLECTIVO                                *
      *----------------------------------------------------------------*
       33-COLECTIVO.

            IF WEMIN-ENT-MONTO-INI-9   = ZEROS
               SET NO-CORRECTO         TO TRUE
            ELSE
              IF WEMIN-ENT-MONTO-INI-9   IS NOT NUMERIC
                 SET NO-CORRECTO         TO TRUE
                 MOVE SPACES             TO SERR-DETALLE-ERROR
                 MOVE 'COLECTIVO MONTO-INI DEBE SER NUMERICO'
                                         TO SERR-DETALLE-ERROR
                 PERFORM 2111-GRABA-SALIDA-ERROR
              END-IF
      *
              IF WEMIN-ENT-MONTO-INI-9   < ZEROES
                 SET NO-CORRECTO         TO TRUE
                 MOVE SPACES             TO SERR-DETALLE-ERROR
                 MOVE 'COLECTIVO MONTO-INI DEBE SER MAYOR A 0'
                                         TO SERR-DETALLE-ERROR
                 PERFORM 2111-GRABA-SALIDA-ERROR
              END-IF
      *COL11-I
              IF WEMIN-ENT-MONTO-INI-9  <= WS-COLECTIVO-INI
                 AND WS-COLECTIVO-INI > ZEROS
                 AND SI-CORRECTO
                 SET NO-CORRECTO        TO TRUE
                 MOVE SPACES            TO SERR-DETALLE-ERROR
                 MOVE 'COLECTIVO INI MENOR ANTERIOR' TO
                                           SERR-DETALLE-ERROR
                 PERFORM 2111-GRABA-SALIDA-ERROR
              ELSE
                 MOVE WEMIN-ENT-MONTO-INI-9 TO WS-COLECTIVO-INI
              END-IF
      *COL11-F
              IF SI-CORRECTO
                 PERFORM 2211-CONSULTA-UGDTNRA
              END-IF
            END-IF
            .
      *----------------------------------------------------------------*
      *                    2211-VALIDA-COLECTIVO                       *
      *----------------------------------------------------------------*
      *COL11-I
      *2211-VALIDA-COLECTIVO.
      *
      *
      *    MOVE WEMIN-ENT-MONTO-INI-9     TO WMIF-ENT-MONTO-REDFIN-9
      *    MOVE NRA-SEGMENTO              TO WMIT-MONTO-INI
      *
      *    IF WEMIF-ENT-MONTO-INI-REDFIN  = WMIT-MONTO-INI
      *       MOVE 'COLECTIVO-INI Y COLECTIVO-FIN DUPLICADOS' TO
      *                                        SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *    ELSE
      *COL07-I
      *         PERFORM 2211-SELECT-MAXTABLA-UGDTNRA
      *COL07-F
      *       PERFORM 2211-MOVER-DATOS-UGDTNRA-INS
      *    END-IF
      *    .
      *----------------------------------------------------------------*
      *                    2211-VALIDA-COLECTIVO-FETCH                 *
      *----------------------------------------------------------------*
      *2211-VALIDA-COLECTIVO-FETCH.
      *
      *    INITIALIZE                       WMIT-MONTO-INI
      *
      *    MOVE WEMIN-ENT-MONTO-INI-9     TO WMIF-ENT-MONTO-REDFIN-9
      *    MOVE NRA-SEGMENTO              TO WMIT-MONTO-INI
      *
      *    IF WEMIF-ENT-MONTO-INI-REDFIN  = WMIT-MONTO-INI
      *       MOVE 'COLECTIVO-INI Y COLECTIVO-FIN DUPLICADOS' TO
      *                                        SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *       SET WSF-SVA-FETCH      TO TRUE
      *    END-IF
      *    .
      *COL11-F
      *----------------------------------------------------------------*
      *                    34-EDAD                                     *
      *----------------------------------------------------------------*
       34-EDAD.

            IF ENT-RANGO-INI          IS NOT NUMERIC
               SET NO-CORRECTO        TO TRUE
               MOVE SPACES            TO SERR-DETALLE-ERROR
               MOVE 'EDAD INICIO DEBE SER NUMERICO' TO
                                         SERR-DETALLE-ERROR
               PERFORM 2111-GRABA-SALIDA-ERROR
            END-IF
      *
            IF ENT-RANGO-INI           <  ZEROES
               SET NO-CORRECTO         TO TRUE
               MOVE SPACES             TO SERR-DETALLE-ERROR
               MOVE 'EDAD INICIO DEBE SER MAYOR A 0' TO
                                          SERR-DETALLE-ERROR
               PERFORM 2111-GRABA-SALIDA-ERROR
            END-IF
      *
            IF ENT-RANGO-FIN        IS NOT NUMERIC
               SET NO-CORRECTO      TO TRUE
               MOVE SPACES          TO SERR-DETALLE-ERROR
               MOVE 'EDAD FINAL DEBE SER NUMERICO' TO
                                       SERR-DETALLE-ERROR
               PERFORM 2111-GRABA-SALIDA-ERROR
            END-IF
      *
            IF ENT-RANGO-INI        =  ZEROES AND
               ENT-RANGO-FIN        =  ZEROES
               CONTINUE
            ELSE
              IF (ENT-RANGO-INI       >= ENT-RANGO-FIN) OR
                 (ENT-RANGO-FIN       <= 0)
                  SET NO-CORRECTO      TO TRUE
                  MOVE SPACES          TO SERR-DETALLE-ERROR
                  MOVE 'EDAD FIN <= EDAD INI' TO
                                          SERR-DETALLE-ERROR
                  PERFORM 2111-GRABA-SALIDA-ERROR
               END-IF
            END-IF

            IF ENT-RANGO-INI       =   ENT-RANGO-FIN
               SET NO-CORRECTO      TO TRUE
               MOVE SPACES          TO SERR-DETALLE-ERROR
               MOVE 'EDAD INI NO DEBE SER IGUAL EDAD FIN'
                                    TO SERR-DETALLE-ERROR
               PERFORM 2111-GRABA-SALIDA-ERROR
            END-IF
      *COL11-I
            IF ENT-RANGO-INI  <= WS-EDAD-INI
               AND WEMIN-ENT-MONTO-FIN-9 > ZEROS
               AND WS-EDAD-INI > ZEROS
               AND SI-CORRECTO
               SET NO-CORRECTO        TO TRUE
               MOVE SPACES            TO SERR-DETALLE-ERROR
               MOVE 'EDAD INI MENOR ANTERIOR' TO
                                         SERR-DETALLE-ERROR
               PERFORM 2111-GRABA-SALIDA-ERROR
            ELSE
               MOVE ENT-RANGO-INI     TO WS-EDAD-INI
            END-IF
            IF ENT-RANGO-FIN  <= WS-EDAD-FIN
               AND SI-CORRECTO
               SET NO-CORRECTO        TO TRUE
               MOVE SPACES            TO SERR-DETALLE-ERROR
               MOVE 'EDAD FIN MENOR ANTERIOR' TO
                                         SERR-DETALLE-ERROR
               PERFORM 2111-GRABA-SALIDA-ERROR
            ELSE
               MOVE ENT-RANGO-FIN     TO WS-EDAD-FIN
            END-IF
      *COL11-F
            IF SI-CORRECTO
               PERFORM 2211-CONSULTA-UGDTNRA
            END-IF
            .
      *----------------------------------------------------------------*
      *                    2211-VALIDA-EDAD                            *
      *----------------------------------------------------------------*
      *COL11-I
      *2211-VALIDA-EDAD.
      *
      *    IF ENT-RANGO-INI            =  NRA-RANGO-INI AND
      *       ENT-RANGO-FIN            =  NRA-RANGO-FIN
      *       MOVE 'EDAD-INI Y EDAD-FIN DUPLICADOS'  TO
      *                                  SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *    ELSE
      *      IF (ENT-RANGO-INI   <=   NRA-RANGO-FIN OR
      *          ENT-RANGO-INI    =   NRA-RANGO-INI OR
      *          ENT-RANGO-FIN    =   NRA-RANGO-FIN) AND
      *          NRA-RANGO-FIN    > 0
      *          MOVE 'RANGO INVALIDO FUERA INTERVALO ' TO
      *                                     SERR-DETALLE-ERROR
      *          PERFORM 2111-GRABA-SALIDA-ERROR
      *      ELSE
      *COL07-I
      *         PERFORM 2211-SELECT-MAXTABLA-UGDTNRA
      *COL07-F
      *          PERFORM 2211-MOVER-DATOS-UGDTNRA-INS
      *      END-IF
      *    END-IF
      *    .
      *----------------------------------------------------------------*
      *                    2211-VALIDA-EDAD-FETCH                      *
      *----------------------------------------------------------------*
      *2211-VALIDA-EDAD-FETCH.
      *
      *    IF ENT-RANGO-INI            =  NRA-RANGO-INI AND
      *       ENT-RANGO-FIN            =  NRA-RANGO-FIN
      *       MOVE 'EDAD-INI Y EDAD-FIN DUPLICADOS'  TO
      *                                  SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *       SET WSF-SVA-FETCH      TO TRUE
      *    END-IF
      *    .
      *COL11-F
      *----------------------------------------------------------------*
      *                    35-SITUACION-LABORAL                        *
      *----------------------------------------------------------------*
       35-SITUACION-LABORAL.

            IF ENT-IND-CLIENTE         IS NOT EQUAL '1' AND '2'         02670000
                                       AND '3' AND '4' AND '5'
      *COL12-I
                                       AND '6'
      *COL12-F
               SET NO-CORRECTO         TO TRUE
               MOVE SPACES             TO SERR-DETALLE-ERROR
               MOVE 'SITUACION/LABORAL DEBE SER 1,2,3,4,5'   TO
                                          SERR-DETALLE-ERROR(01:50)
               MOVE ENT-IND-CLIENTE    TO SERR-DETALLE-ERROR(51:10)
               PERFORM 2111-GRABA-SALIDA-ERROR
            END-IF
      *COL11-I
            IF ENT-IND-CLIENTE-9       <= WS-SIT-LABORAL                02670000
               AND WS-SIT-LABORAL > ZEROS
               AND SI-CORRECTO
               SET NO-CORRECTO         TO TRUE
               MOVE SPACES             TO SERR-DETALLE-ERROR
               MOVE 'SITUACION/LABORAL ERRADA O DUPLICADA'   TO
                                          SERR-DETALLE-ERROR(01:50)
               MOVE ENT-IND-CLIENTE    TO SERR-DETALLE-ERROR(51:10)
               PERFORM 2111-GRABA-SALIDA-ERROR
            ELSE
               MOVE ENT-IND-CLIENTE-9  TO WS-SIT-LABORAL
            END-IF
      *COL11-F
      *
            IF SI-CORRECTO
               PERFORM 2211-CONSULTA-UGDTNRA
            END-IF
            .
      *----------------------------------------------------------------*
      *                    2211-VALIDA-SITUACION-LABORAL               *
      *----------------------------------------------------------------*
      *COL11-I
      *2211-VALIDA-SITUACION-LABORAL.
      *
      *    IF ENT-IND-CLIENTE          =  NRA-SITUA-LABORAL
      *       MOVE 'IND-CLEINTE = SITUA-LABORAL DUPLICADO' TO
      *                                      SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *    ELSE
      *COL07-I
      *         PERFORM 2211-SELECT-MAXTABLA-UGDTNRA
      *COL07-F
      *       PERFORM 2211-MOVER-DATOS-UGDTNRA-INS
      *    END-IF
      *    .
      *----------------------------------------------------------------*
      *                    2211-VAL-SITUA-LABORAL-FETCH
      *----------------------------------------------------------------*
      *2211-VAL-SITUA-LABORAL-FETCH.
      *
      *    IF ENT-IND-CLIENTE          =  NRA-SITUA-LABORAL
      *       MOVE 'IND-CLEINTE = SITUA-LABORAL DUPLICADO' TO
      *                                      SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *       SET WSF-SVA-FETCH      TO TRUE
      *    END-IF
      *    .
      *COL11-F
      *COL03-I
      *----------------------------------------------------------------*
      *                    36-VALIDA-COLECTI-LIB                       *
      *----------------------------------------------------------------*
       36-VALIDA-COLECTI-LIB.

           SET IND-COLECTI TO 1
           SEARCH WTL-COLECTI
            AT END
              SET NO-CORRECTO         TO TRUE
              MOVE SPACES             TO SERR-DETALLE-ERROR
              MOVE 'VALOR COLECTIVO LIB NO EN UMTA-T37  '   TO
                                         SERR-DETALLE-ERROR(01:50)
              MOVE ENT-IND-CLIENTE    TO SERR-DETALLE-ERROR(51:10)
              PERFORM 2111-GRABA-SALIDA-ERROR
            WHEN W-COL-VALOR(IND-COLECTI) = ENT-MONTO-INI(1:3)
              CONTINUE
           END-SEARCH
      *
           IF SI-CORRECTO
              PERFORM 2211-CONSULTA-UGDTNRA
           END-IF
           .
      *----------------------------------------------------------------*
      *                    2211-VALIDA-COLECTI-LIB                     *
      *----------------------------------------------------------------*
      *COL11-I
      *2211-VALIDA-COLECTI-LIB.
      *
      *    MOVE WEMIN-ENT-MONTO-INI-9      TO WMIF-ENT-MONTO-REDFIN-9
      *    IF   WEMIF-ENT-MONTO-INI-REDFIN =  NRA-SEGMENTO
      *       MOVE 'COLECTIVO LIBRANZAS DUPLICADO' TO
      *                                      SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *    ELSE
      *COL07-I
      *         PERFORM 2211-SELECT-MAXTABLA-UGDTNRA
      *COL07-F
      *       PERFORM 2211-MOVER-DATOS-UGDTNRA-INS
      *    END-IF
      *    .
      *----------------------------------------------------------------*
      *                    2211-VALIDA-COLECTI-LIB-FETCH               *
      *----------------------------------------------------------------*
      *2211-VALIDA-COLECTI-LIB-FETCH.
      *
      *    MOVE WEMIN-ENT-MONTO-INI-9      TO WMIF-ENT-MONTO-REDFIN-9
      *    IF   WEMIF-ENT-MONTO-INI-REDFIN =  NRA-SEGMENTO
      *       MOVE 'COLECTIVO LIBRANZAS DUPLICADO' TO
      *                                      SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *       SET WSF-SVA-FETCH      TO TRUE
      *    END-IF
      *    .
      *COL11-F
      *----------------------------------------------------------------*
      *                    37-VALIDA-DESTINO-LIB                       *
      *----------------------------------------------------------------*
       37-VALIDA-DESTINO-LIB.

           SET IND-DESTINO TO 1
           SEARCH WTL-DESTINO
            AT END
              SET NO-CORRECTO         TO TRUE
              MOVE SPACES             TO SERR-DETALLE-ERROR
              MOVE 'VALOR DESTINO   LIB NO EN UMTA-T37  '   TO
                                         SERR-DETALLE-ERROR(01:50)
              MOVE ENT-IND-CLIENTE    TO SERR-DETALLE-ERROR(51:10)
              PERFORM 2111-GRABA-SALIDA-ERROR
            WHEN W-DES-VALOR(IND-DESTINO) = ENT-MONTO-INI(1:3)
              CONTINUE
           END-SEARCH
      *
           IF SI-CORRECTO
              PERFORM 2211-CONSULTA-UGDTNRA
           END-IF
           .
      *----------------------------------------------------------------*
      *                    2211-VALIDA-DESTINO-LIB                     *
      *----------------------------------------------------------------*
      *COL11-I
      *2211-VALIDA-DESTINO-LIB.
      *
      *    MOVE WEMIN-ENT-MONTO-INI-9      TO WMIF-ENT-MONTO-REDFIN-9
      *    IF   WEMIF-ENT-MONTO-INI-REDFIN =  NRA-SEGMENTO
      *       MOVE 'DESTINO LIBRANZAS DUPLICADO' TO
      *                                      SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *    ELSE
      *COL07-I
      *         PERFORM 2211-SELECT-MAXTABLA-UGDTNRA
      *COL07-F
      *       PERFORM 2211-MOVER-DATOS-UGDTNRA-INS
      *    END-IF
      *    .
      *----------------------------------------------------------------*
      *                    2211-VALIDA-DESTINO-LIB-FETCH
      *----------------------------------------------------------------*
      *2211-VALIDA-DESTINO-LIB-FETCH.
      *
      *    MOVE WEMIN-ENT-MONTO-INI-9      TO WMIF-ENT-MONTO-REDFIN-9
      *    IF   WEMIF-ENT-MONTO-INI-REDFIN =  NRA-MONTO-INICIAL
      *       MOVE 'DESTINO LIBRANZAS DUPLICADO' TO
      *                                      SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *       SET WSF-SVA-FETCH      TO TRUE
      *    END-IF
      *    .
      *COL11-F
      *COL03-F
      *COL05-I
      *----------------------------------------------------------------*
      *                   38-VALIDA-VENTAS-COMER                       *
      *----------------------------------------------------------------*
       38-VALIDA-VENTAS-COMER.

           IF WEMIN-ENT-MONTO-INI-9    IS NOT NUMERIC
              SET NO-CORRECTO          TO TRUE
              MOVE SPACES              TO SERR-DETALLE-ERROR
              MOVE 'VENTAS INICIAL DEBE SER NUMERICO' TO
                                          SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           END-IF
      *
           IF WEMIN-ENT-MONTO-INI-9    < ZEROES
              SET NO-CORRECTO          TO TRUE
              MOVE SPACES              TO SERR-DETALLE-ERROR
              MOVE 'VENTAS INICIAL DEBE SER MAYOR A 0' TO
                                          SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           END-IF
      *
           IF WEMIN-ENT-MONTO-FIN-9 IS NOT NUMERIC
              SET NO-CORRECTO       TO TRUE
              MOVE SPACES           TO SERR-DETALLE-ERROR
              MOVE 'VENTAS FINAL DEBE SER NUMERICO' TO
                                       SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           END-IF
      *
           IF WEMIN-ENT-MONTO-INI-9 =  WEMIN-ENT-MONTO-FIN-9
              SET NO-CORRECTO       TO TRUE
              MOVE SPACES           TO SERR-DETALLE-ERROR
              MOVE 'VENTAS INI IGUAL VENTAS FIN' TO
                                       SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           END-IF
      *
           IF WEMIN-ENT-MONTO-INI-9  = ZEROES AND
              WEMIN-ENT-MONTO-FIN-9  = ZEROES
              CONTINUE
           ELSE
              IF (WEMIN-ENT-MONTO-INI-9  >= WEMIN-ENT-MONTO-FIN-9) OR
                 (WEMIN-ENT-MONTO-FIN-9  <= ZEROES)
                 SET NO-CORRECTO       TO TRUE
                 MOVE SPACES           TO SERR-DETALLE-ERROR
                 MOVE 'VENTAS FIN <= VENTAS INI' TO
                                          SERR-DETALLE-ERROR
                 PERFORM 2111-GRABA-SALIDA-ERROR
              END-IF
           END-IF
      *
      *COL11-I
           IF WEMIN-ENT-MONTO-INI-9  <= WS-VENT-MONTO-INI
              AND WEMIN-ENT-MONTO-FIN-9 > ZEROS
              AND WS-VENT-MONTO-INI > ZEROS
              AND SI-CORRECTO
              SET NO-CORRECTO        TO TRUE
              MOVE SPACES            TO SERR-DETALLE-ERROR
              MOVE 'VENTAS INI MENOR ANTERIOR' TO
                                        SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           ELSE
              MOVE WEMIN-ENT-MONTO-INI-9 TO WS-VENT-MONTO-INI
           END-IF
           IF WEMIN-ENT-MONTO-FIN-9  <= WS-VENT-MONTO-FIN
              AND SI-CORRECTO
              SET NO-CORRECTO        TO TRUE
              MOVE SPACES            TO SERR-DETALLE-ERROR
              MOVE 'VENTAS FIN MENOR ANTERIOR' TO
                                        SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           ELSE
              MOVE WEMIN-ENT-MONTO-FIN-9 TO WS-VENT-MONTO-FIN
           END-IF
      *COL11-F
           IF SI-CORRECTO
              PERFORM 2211-CONSULTA-UGDTNRA
           END-IF.
      *
      *----------------------------------------------------------------*
      *                  39-VALIDA-TIPERS-COMER                        *
      *----------------------------------------------------------------*
       39-VALIDA-TIPERS-COMER.

           IF ENT-DATOS-COMER(1:2) IS NOT EQUAL 'PJ' AND 'PN'           02670000
              SET NO-CORRECTO         TO TRUE
              MOVE SPACES             TO SERR-DETALLE-ERROR
              MOVE 'TIPO PERSONA DEBE SER PJ/PN' TO
                                         SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           END-IF

      *COL11-I
           IF ENT-DATOS-COMER(1:2)   EQUAL WS-DATOS-COMER
              AND SI-CORRECTO
              SET NO-CORRECTO         TO TRUE
              MOVE SPACES             TO SERR-DETALLE-ERROR
              MOVE 'TIPO PERSONA DUPLICADO' TO
                                        SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           ELSE
              MOVE ENT-DATOS-COMER(1:2) TO WS-DATOS-COMER
           END-IF
      *COL11-F
           IF SI-CORRECTO
              PERFORM 2211-CONSULTA-UGDTNRA
           END-IF.
      *
      *----------------------------------------------------------------*
      *                  40-VALIDA-RATING-COMER                        *
      *----------------------------------------------------------------*
       40-VALIDA-RATING-COMER.

           IF ENT-DATOS-COMER(1:5) NOT EQUAL SPACES                     02670000
              MOVE ENT-DATOS-COMER(1:5)    TO WS-STRING
              MOVE CTEN-05                 TO WS-IND
              SET NO-NUMERICO              TO TRUE
              PERFORM VARYING WS-I FROM 1  BY 1 UNTIL WS-I > WS-IND
                  MOVE WS-STRING (WS-I:1)  TO WS-C
                  IF WS-N IS NUMERIC
                     MOVE WS-N             TO WS-NU(WS-I:1)
                     SET SI-NUMERICO       TO TRUE
                  END-IF
              END-PERFORM

              IF SI-NUMERICO AND WS-NU = ZEROES
                 SET NO-CORRECTO           TO TRUE
                 MOVE SPACES               TO SERR-DETALLE-ERROR
                 MOVE 'RATING DEBE SER ALFANUMERIC' TO
                                            SERR-DETALLE-ERROR
                 PERFORM 2111-GRABA-SALIDA-ERROR
              END-IF
           END-IF

           IF SI-CORRECTO
              PERFORM 2211-CONSULTA-UGDTNRA
           END-IF.
      *
      *----------------------------------------------------------------*
      *                 41-VALIDA-RANG-RATING-COMER                    *
      *----------------------------------------------------------------*
       41-VALIDA-RANG-RATING-COMER.

           IF ENT-DATOS-COMER(1:1) NOT EQUAL SPACES                     02670000
              IF ENT-DATOS-COMER(1:1) IS NOT NUMERIC
                 SET NO-CORRECTO         TO TRUE
                 MOVE SPACES             TO SERR-DETALLE-ERROR
                 MOVE 'IND.RANG RATING DEBE SER NUMERICO' TO
                                            SERR-DETALLE-ERROR
                 PERFORM 2111-GRABA-SALIDA-ERROR
              END-IF
           END-IF

           IF SI-CORRECTO
              PERFORM 2211-CONSULTA-UGDTNRA
           END-IF.
      *
      *----------------------------------------------------------------*
      *                  42-VALIDA-GARANTIA-COMER                      *
      *----------------------------------------------------------------*
       42-VALIDA-GARANTIA-COMER.

           IF ENT-DATOS-COMER(1:1)  NOT EQUAL 'S' AND 'N'
              SET NO-CORRECTO        TO TRUE
              MOVE SPACES            TO SERR-DETALLE-ERROR
              MOVE 'GARANTIA DEBE SER S/N' TO
                                        SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           END-IF

      *COL11-I
           IF ENT-DATOS-COMER(1:1)   EQUAL WS-GARANTIA
              AND SI-CORRECTO
              SET NO-CORRECTO           TO TRUE
              MOVE SPACES               TO SERR-DETALLE-ERROR
              MOVE 'GARANTIA DUPLICADO' TO
                                        SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           ELSE
              MOVE ENT-DATOS-COMER(1:1) TO WS-GARANTIA
           END-IF
      *COL11-F
           IF SI-CORRECTO
              PERFORM 2211-CONSULTA-UGDTNRA
           END-IF.
      *
      *----------------------------------------------------------------*
      *                   43-VALIDA-MONOPER-COMER                      *
      *----------------------------------------------------------------*
       43-VALIDA-MONOPER-COMER.

           IF WEMIN-ENT-MONTO-INI-9    IS NOT NUMERIC
              SET NO-CORRECTO          TO TRUE
              MOVE SPACES              TO SERR-DETALLE-ERROR
              MOVE 'MON-OPER INICIAL DEBE SER NUMERICO' TO
                                          SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           END-IF
      *
           IF WEMIN-ENT-MONTO-INI-9    < ZEROES
              SET NO-CORRECTO          TO TRUE
              MOVE SPACES              TO SERR-DETALLE-ERROR
              MOVE 'MON-OPER INICIAL DEBE SER MAYOR A 0' TO
                                          SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           END-IF
      *
           IF WEMIN-ENT-MONTO-FIN-9 IS NOT NUMERIC
              SET NO-CORRECTO       TO TRUE
              MOVE SPACES           TO SERR-DETALLE-ERROR
              MOVE 'MON-OPER FINAL DEBE SER NUMERICO' TO
                                       SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           END-IF
      *
           IF WEMIN-ENT-MONTO-INI-9 =  WEMIN-ENT-MONTO-FIN-9
              SET NO-CORRECTO       TO TRUE
              MOVE SPACES           TO SERR-DETALLE-ERROR
              MOVE 'MON-OPER INI IGUAL MON-OPER FIN' TO
                                       SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           END-IF
      *
           IF WEMIN-ENT-MONTO-INI-9  = ZEROES AND
              WEMIN-ENT-MONTO-FIN-9  = ZEROES
              CONTINUE
           ELSE
              IF (WEMIN-ENT-MONTO-INI-9  >= WEMIN-ENT-MONTO-FIN-9) OR
                 (WEMIN-ENT-MONTO-FIN-9  <= ZEROES)
                 SET NO-CORRECTO       TO TRUE
                 MOVE SPACES           TO SERR-DETALLE-ERROR
                 MOVE 'MON-OPER FIN <= MON-OPER INI' TO
                                          SERR-DETALLE-ERROR
                 PERFORM 2111-GRABA-SALIDA-ERROR
              END-IF
           END-IF
      *COL11-I
           IF WEMIN-ENT-MONTO-INI-9  <= WS-MONOPER-COMER-INI
              AND WEMIN-ENT-MONTO-FIN-9 > ZEROS
              AND WS-MONOPER-COMER-INI  > ZEROS
              AND SI-CORRECTO
              SET NO-CORRECTO        TO TRUE
              MOVE SPACES            TO SERR-DETALLE-ERROR
              MOVE 'MON-OPER COMER INI MENOR ANTERIOR' TO
                                        SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           ELSE
              MOVE WEMIN-ENT-MONTO-INI-9 TO WS-MONOPER-COMER-INI
           END-IF
           IF WEMIN-ENT-MONTO-FIN-9  <= WS-MONOPER-COMER-FIN
              AND SI-CORRECTO
              SET NO-CORRECTO        TO TRUE
              MOVE SPACES            TO SERR-DETALLE-ERROR
              MOVE 'MON-OPER COMER FIN MENOR ANTERIOR' TO
                                        SERR-DETALLE-ERROR
              PERFORM 2111-GRABA-SALIDA-ERROR
           ELSE
              MOVE WEMIN-ENT-MONTO-FIN-9 TO WS-MONOPER-COMER-FIN
           END-IF
      *COL11-F
      *
           IF SI-CORRECTO
              PERFORM 2211-CONSULTA-UGDTNRA
           END-IF.
      *
      *----------------------------------------------------------------*
      *                    2211-VALIDA-VENTAS-COMER                    *
      *----------------------------------------------------------------*
      *COL11-I
      *2211-VALIDA-VENTAS-COMER.
      *
      *    MOVE WEMIN-ENT-MONTO-INI-9     TO WMIF-ENT-MONTO-REDFIN-9
      *    MOVE WEMIN-ENT-MONTO-FIN-9     TO WMIF-ENT-MONTO-REDFON-9
      *    MOVE NRA-MONTO-INICIAL         TO WMIT-MONTO-INI
      *    MOVE NRA-MONTO-FINAL           TO WMFT-MONTO-FIN
      *
      *    IF (WEMIF-ENT-MONTO-INI-REDFIN  = WMIT-MONTO-INI) AND
      *       (WEMIF-ENT-MONTO-INI-REDFON  = WMFT-MONTO-FIN)
      *       MOVE 'VENTAS-INI Y VENTAS-FIN DUPLICADOS' TO
      *                                     SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *    ELSE
      *       IF (WEMIF-ENT-MONTO-INI-REDFIN <= WMFT-MONTO-FIN OR
      *           WEMIF-ENT-MONTO-INI-REDFIN  = WMIT-MONTO-INI OR
      *           WEMIF-ENT-MONTO-INI-REDFON  = WMFT-MONTO-FIN) AND
      *           WMFT-MONTO-FIN > 0
      *           MOVE 'RANGO VENTAS INVALIDO FUERA INTERVALO ' TO
      *                                     SERR-DETALLE-ERROR
      *           PERFORM 2111-GRABA-SALIDA-ERROR
      *       ELSE
      *COL07-I
      *         PERFORM 2211-SELECT-MAXTABLA-UGDTNRA
      *COL07-F
      *          PERFORM 2211-MOVER-DATOS-UGDTNRA-INS
      *       END-IF
      *    END-IF.
      *
      *----------------------------------------------------------------*
      *                    2211-VALIDA-TIPERS-COMER                    *
      *----------------------------------------------------------------*
      *2211-VALIDA-TIPERS-COMER.
      *
      *    MOVE ENT-DATOS-COMER(2:1)        TO WS-TIP-PERSON
      *
      *    IF WS-TIP-PERSON = NRA-IND-CLIENTE-VIP
      *       MOVE 'TIPO-PERSONA DUPLICADO' TO
      *                                   SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *    ELSE
      *COL07-I
      *         PERFORM 2211-SELECT-MAXTABLA-UGDTNRA
      *COL07-F
      *       PERFORM 2211-MOVER-DATOS-UGDTNRA-INS
      *    END-IF.
      *
      *----------------------------------------------------------------*
      *                    2211-VALIDA-RATING-COMER                    *
      *----------------------------------------------------------------*
      *2211-VALIDA-RATING-COMER.
      *
      *    IF ENT-DATOS-COMER(1:5) = NRA-RATING
      *       MOVE 'CALIF.RATING DUPLICADO'     TO SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *    ELSE
      *COL07-I
      *         PERFORM 2211-SELECT-MAXTABLA-UGDTNRA
      *COL07-F
      *       PERFORM 2211-MOVER-DATOS-UGDTNRA-INS
      *    END-IF.
      *
      *----------------------------------------------------------------*
      *                    2211-VALIDA-RANG-RATING-COMER               *
      *----------------------------------------------------------------*
      *2211-VALIDA-RANG-RATING-COMER.
      *
      *    IF ENT-DATOS-COMER(1:1) = NRA-RANGO-RATING
      *       MOVE 'RANGO CALIF.RATING DUPLICADO' TO
      *                                     SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *    ELSE
      *COL07-I
      *         PERFORM 2211-SELECT-MAXTABLA-UGDTNRA
      *COL07-F
      *       PERFORM 2211-MOVER-DATOS-UGDTNRA-INS
      *    END-IF.
      *
      *----------------------------------------------------------------*
      *                    2211-VALIDA-GARANTIA-COMER                  *
      *----------------------------------------------------------------*
      *2211-VALIDA-GARANTIA-COMER.
      *
      *    IF ENT-DATOS-COMER(1:1) = NRA-GARANTIA
      *       MOVE 'GARANTIA S/N DUPLICADO' TO
      *                                     SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *    ELSE
      *COL07-I
      *         PERFORM 2211-SELECT-MAXTABLA-UGDTNRA
      *COL07-F
      *       PERFORM 2211-MOVER-DATOS-UGDTNRA-INS
      *    END-IF.
      *
      *----------------------------------------------------------------*
      *                    2211-VALIDA-MONOPER-COMER                   *
      *----------------------------------------------------------------*
      *2211-VALIDA-MONOPER-COMER.
      *
      *    MOVE WEMIN-ENT-MONTO-INI-9     TO WMIF-ENT-MONTO-REDFIN-9
      *    MOVE WEMIN-ENT-MONTO-FIN-9     TO WMIF-ENT-MONTO-REDFON-9
      *    MOVE NRA-MONTO-INICIAL         TO WMIT-MONTO-INI
      *    MOVE NRA-MONTO-FINAL           TO WMFT-MONTO-FIN
      *
      *    IF (WEMIF-ENT-MONTO-INI-REDFIN  = WMIT-MONTO-INI) AND
      *       (WEMIF-ENT-MONTO-INI-REDFON  = WMFT-MONTO-FIN)
      *       MOVE 'MON.OPER-INI Y MON.OPER-FIN DUPLICADOS' TO
      *                                     SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *    ELSE
      *       IF (WEMIF-ENT-MONTO-INI-REDFIN <= WMFT-MONTO-FIN OR
      *           WEMIF-ENT-MONTO-INI-REDFIN  = WMIT-MONTO-INI OR
      *           WEMIF-ENT-MONTO-INI-REDFON  = WMFT-MONTO-FIN) AND
      *           WMFT-MONTO-FIN > 0
      *           MOVE 'RANGO MON.OPER INVALIDO FUERA INTERVALO ' TO
      *                                     SERR-DETALLE-ERROR
      *           PERFORM 2111-GRABA-SALIDA-ERROR
      *       ELSE
      *COL07-I
      *         PERFORM 2211-SELECT-MAXTABLA-UGDTNRA
      *COL07-F
      *          PERFORM 2211-MOVER-DATOS-UGDTNRA-INS
      *       END-IF
      *    END-IF.
      *
      *----------------------------------------------------------------*
      *                   2211-VALIDA-VENTAS-COMER-FETCH               *
      *----------------------------------------------------------------*
      *2211-VALIDA-VENTAS-COMER-FETCH.
      *
      *    INITIALIZE                       WMIT-MONTO-INI
      *                                     WMFT-MONTO-FIN
      *
      *    MOVE WEMIN-ENT-MONTO-INI-9     TO WMIF-ENT-MONTO-REDFIN-9
      *    MOVE WEMIN-ENT-MONTO-FIN-9     TO WMIF-ENT-MONTO-REDFON-9
      *    MOVE NRA-MONTO-INICIAL         TO WMIT-MONTO-INI
      *    MOVE NRA-MONTO-FINAL           TO WMFT-MONTO-FIN
      *
      *    IF (WEMIF-ENT-MONTO-INI-REDFIN  = WMIT-MONTO-INI) AND
      *       (WEMIF-ENT-MONTO-INI-REDFON  = WMFT-MONTO-FIN)
      *       MOVE 'VENTAS-INI VENTAS-FIN DUPLICADOS' TO
      *                                     SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *       SET WSF-SVA-FETCH      TO TRUE
      *    END-IF.
      *
      *----------------------------------------------------------------*
      *                 2211-VALIDA-TIPERS-COMER-FETCH                 *
      *----------------------------------------------------------------*
      *2211-VALIDA-TIPERS-COMER-FETCH.
      *
      *    MOVE ENT-DATOS-COMER(2:1)        TO WS-TIP-PERSON
      *
      *    IF WS-TIP-PERSON = NRA-IND-CLIENTE-VIP
      *       MOVE 'TIPO-PERSONA DUPLICADO' TO
      *                                   SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *       SET WSF-SVA-FETCH      TO TRUE
      *    END-IF.
      *
      *----------------------------------------------------------------*
      *                 2211-VALIDA-RATING-COMER-FETCH                 *
      *----------------------------------------------------------------*
      *2211-VALIDA-RATING-COMER-FETCH.
      *
      *    IF ENT-DATOS-COMER(1:5) = NRA-RATING
      *       MOVE 'CALIF.RATING DUPLICADO'     TO SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *       SET WSF-SVA-FETCH      TO TRUE
      *    END-IF.
      *
      *----------------------------------------------------------------*
      *                 2211-VALIDA-RANGRA-COMER-FETCH                 *
      *----------------------------------------------------------------*
      *2211-VALIDA-RANGRA-COMER-FETCH.
      *
      *    IF ENT-DATOS-COMER(1:1) = NRA-RANGO-RATING
      *       MOVE 'RANGO CALIF.RATING DUPLICADO' TO
      *                                     SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *       SET WSF-SVA-FETCH      TO TRUE
      *    END-IF.
      *
      *----------------------------------------------------------------*
      *                2211-VALIDA-GARANT-COMER-FETCH                  *
      *----------------------------------------------------------------*
      *2211-VALIDA-GARANT-COMER-FETCH.
      *
      *    IF ENT-DATOS-COMER(1:1) = NRA-GARANTIA
      *       MOVE 'GARANTIA S/N DUPLICADO' TO
      *                                     SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *       SET WSF-SVA-FETCH      TO TRUE
      *    END-IF.
      *
      *----------------------------------------------------------------*
      *                  2211-VALIDA-MONOPE-COMER-FETCH                *
      *----------------------------------------------------------------*
      *2211-VALIDA-MONOPE-COMER-FETCH.
      *
      *    INITIALIZE                       WMIT-MONTO-INI
      *                                     WMFT-MONTO-FIN
      *
      *    MOVE WEMIN-ENT-MONTO-INI-9     TO WMIF-ENT-MONTO-REDFIN-9
      *    MOVE WEMIN-ENT-MONTO-FIN-9     TO WMIF-ENT-MONTO-REDFON-9
      *    MOVE NRA-MONTO-INICIAL         TO WMIT-MONTO-INI
      *    MOVE NRA-MONTO-FINAL           TO WMFT-MONTO-FIN
      *
      *    IF (WEMIF-ENT-MONTO-INI-REDFIN  = WMIT-MONTO-INI) AND
      *       (WEMIF-ENT-MONTO-INI-REDFON  = WMFT-MONTO-FIN)
      *       MOVE 'MON.OPER-INI MON.OPER-FIN DUPLICADOS' TO
      *                                     SERR-DETALLE-ERROR
      *       PERFORM 2111-GRABA-SALIDA-ERROR
      *       SET WSF-SVA-FETCH      TO TRUE
      *    END-IF.
      *
      *COL05-F
      *---------------------------------------------------------------* 00101200
      *                    24-CURSOR-UGDTNRA                          * 00101300
      *---------------------------------------------------------------* 00101400
      *24-CURSOR-UGDTNRA.
      *
      *    INITIALIZE                     UGTCNRA
      *                                   DB2-RETURN-CDE
      *                                   WS-FETCH-FIN
      *                                   WS-VALIDA-INI
      *
      *    SET  WSF-NVA-FETCH          TO TRUE
      *    MOVE ENT-TIPO-PRODUCTO      TO NRA-TIPO-PRODUCTO
      *    MOVE ENT-VALIDA-VARIABLE    TO NRA-VARIABLE
      *    MOVE 'VS'                   TO NRA-ESTADO
      *
      *    PERFORM 25-ABRIR-CURSOR-NRA
      *    PERFORM 25-FETCH-CURSOR-NRA
      *            UNTIL WSF-SFI-FETCH   OR WSF-SVA-FETCH
      *    PERFORM 25-CERRAR-CURSOR-NRA.
      *---------------------------------------------------------------*
      *            ABRIR EL CURSOR DE LA UGDTNRA                      *
      *---------------------------------------------------------------*
      *25-ABRIR-CURSOR-NRA.
      *
      *
      *     EXEC SQL
      *       OPEN CURSOR-NRA
      *     END-EXEC
      *
      *     MOVE SQLCODE            TO DB2-RETURN-CDE
      *                                WVS-SQLCODE-ED
      *
      *     EVALUATE TRUE
      *         WHEN DB2-OK
      *              CONTINUE
      *         WHEN OTHER
      *              MOVE  'ERROR OPEN CURSOR UGDTNRA' TO               00100600
      *                                    SERR-DETALLE-ERROR(01:50)
      *              MOVE   WVS-SQLCODE-ED TO SERR-DETALLE-ERROR(51:10) 00100700
      *              PERFORM 2111-GRABA-SALIDA-ERROR                    00100900
      *     END-EVALUATE.
      *---------------------------------------------------------------*
      *         LEER CURSOR DE LA TABLA UGTCNRA                       *
      *---------------------------------------------------------------*
      *25-FETCH-CURSOR-NRA.
      *
      *
      *    INITIALIZE                           WS-FETCH
      *
      *    EXEC SQL
      *       FETCH CURSOR-NRA
      *       INTO  :NRA-TIPO-PRODUCTO,
      *             :NRA-VARIABLE,
      *             :NRA-CONSECUTIVO,
      *             :NRA-RANGO-INI,
      *             :NRA-RANGO-FIN,
      *             :NRA-IND-DOM-NOMINA,
      *             :NRA-SITUA-LABORAL,
      *             :NRA-MONTO-INICIAL,
      *             :NRA-MONTO-FINAL,
      *             :NRA-SEGMENTO,
      *             :NRA-IND-CLIENTE-VIP,
      *             :NRA-RANGO-RIESGO-INI,
      *             :NRA-RANGO-RIESGO-FIN,
      *             :NRA-IND-ESTADO-VEH,
      *             :NRA-IND-TIPO-VEH,
      *             :NRA-CLAVE-ID,
      *             :NRA-CLUSTER,
      *COL05-I
      *             :NRA-ESTADO
      *             :NRA-ESTADO,
      *             :NRA-RATING,
      *             :NRA-RANGO-RATING,
      *             :NRA-GARANTIA,
      *             :NRA-PORCENTA
      *COL05-F
      *    END-EXEC
      *
      *    MOVE SQLCODE               TO DB2-RETURN-CDE
      *                                  WVS-SQLCODE-ED
      *
      *    EVALUATE TRUE
      *         WHEN DB2-OK
      *              PERFORM 2211-VALIDA-ENT-FETCH
      *         WHEN DB2-NOTFND
      *              IF WSF-NVA-FETCH
      *COL07-I
      *                 MOVE NRA-CONSECUTIVO          TO WS-CONSECUTIVO
      *                 ADD 1                         TO WS-CONSECUTIVO
      *COL07-F
      *                 PERFORM 2211-VALIDA-DATOS-ENT-TABLA
      *              END-IF
      *              SET WSF-SFI-FETCH     TO TRUE
      *         WHEN OTHER
      *              MOVE 'ERROR FETCH'    TO SERR-DETALLE-ERROR(01:50)
      *              MOVE  WVS-SQLCODE-ED  TO SERR-DETALLE-ERROR(51:10)
      *              PERFORM 2111-GRABA-SALIDA-ERROR
      *    END-EVALUATE.                                                00161800
      *
      ******************************************************************
      *                     CERRAR EL CURSOR DE LA UGDTNRA             *
      ******************************************************************
      *25-CERRAR-CURSOR-NRA.
      *
      *
      *     EXEC SQL
      *          CLOSE CURSOR-NRA
      *     END-EXEC
      *
      *     MOVE SQLCODE            TO DB2-RETURN-CDE
      *                                WVS-SQLCODE-ED
      *     EVALUATE TRUE
      *         WHEN DB2-OK
      *              CONTINUE
      *         WHEN OTHER
      *              MOVE  'ERROR CLOSE CURSOR UGDTNRA' TO              00100600
      *                                       SERR-DETALLE-ERROR(01:50)
      *              MOVE   WVS-SQLCODE-ED  TO SERR-DETALLE-ERROR(51:10)00100700
      *              PERFORM 2111-GRABA-SALIDA-ERROR                    00100900
      *     END-EVALUATE.
      *                                                                 00169400
      *----------------------------------------------------------------*
      *                      000500-HACER-COMMIT                       *
      *----------------------------------------------------------------*
      *
      *000500-HACER-COMMIT.
      *
      *    EXEC SQL
      *         COMMIT
      *    END-EXEC
      *
      *    MOVE SQLCODE            TO   DB2-RETURN-CDE
      *                                 WVS-SQLCODE-ED
      *    EVALUATE TRUE
      *        WHEN DB2-OK
      *             CONTINUE
      *        WHEN OTHER
      *             MOVE  'ERROR EJECUTANDO COMMIT UG4CRAR1' TO         00100600
      *                                     SERR-DETALLE-ERROR(01:50)
      *             MOVE   WVS-SQLCODE-ED  TO SERR-DETALLE-ERROR(51:10) 00100700
      *             PERFORM 2111-GRABA-SALIDA-ERROR                     00100900
      *    END-EVALUATE.
      *COL11-F
      *----------------------------------------------------------------*
      *                        30000-FINAL                             *
      *----------------------------------------------------------------*
       30000-FINAL.
      *
           PERFORM 31000-CERRAR-ARCHIVOS
           PERFORM 32000-ESTADISTICAS
           STOP RUN.
      *
      *----------------------------------------------------------------*
      *                   31000-CERRAR-ARCHIVOS                        *
      *----------------------------------------------------------------*
       31000-CERRAR-ARCHIVOS.
      *
           CLOSE EUNIRAR
                 SALIDA
                 ERRORES
      *
           IF NOT ESTADO-OK
              DISPLAY 'ERROR CERRANDO ARCHIVO DE EUNIRAR'
                       VAR-ESTADO
              STOP RUN
           END-IF.
      *
      *----------------------------------------------------------------*
      *                     32000-ESTADISTICAS                         *
      *----------------------------------------------------------------*
       32000-ESTADISTICAS.
      *
           DISPLAY '**************************************************'
           DISPLAY '*        ESTADISTICAS DEL PROCESO                *'
           DISPLAY '*            PROGRAMA UG4CRAR1                   *'
           DISPLAY '**************************************************'
           DISPLAY 'REG. LEIDOS   ENTRADA   : ' WC-LEI-ENTRADA
           DISPLAY 'REG. GRABADOS TABLA NRA : ' WC-GRABADO-TABLA
           DISPLAY 'REG. GRABADOS SALIDA    : ' WC-GRABADO-SALIDA
COL11      DISPLAY 'REG. GRABADOS SUGDTNRA  : ' WC-GRABADO-SUGDTNRA
           DISPLAY 'REG. GRABADOS RECHAZOS  : ' WC-GRABADO-ERROR
           DISPLAY '**************************************************'.