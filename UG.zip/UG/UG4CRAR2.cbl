      ***************************************************************** 00000100
      * AUTHOR.   INETUM - CE56375                                    * 00000200
      *           06-07-2021                                          * 00000300
      *           PROGRAMA CARGAR TABLA UGDTNRA CON LOS DATOS DE      * 00000400
      *           ARCHIVO DE TASAS PREFERENCIAL POR CLUSTER           * 00000500
      *           GP17916-HUQA-CCSS-6856                              * 00000500
      ***************************************************************** 00000600
      * AUTOR    FECHA      MODIFICACION                              * 00000700
      *---------------------------------------------------------------* 00000800
      * CE56375  20-10-2021 SE REALIZA AJUSTE PARA CREAR CLUSTER CON  *
      * COL01               SEGMENTO 00000                            *
      *                     RSD INC000007679018                       *
      *---------------------------------------------------------------* 00000800
      * CE56375  08-11-2021 SE REALIZA AJUSTE PARA CORREGIR ELIMINACIO*
      * COL02               DE CLUSTER DADOS DE BAJA                  *
      *                     RSD INC000007720682                       *
      *---------------------------------------------------------------* 00000800
      * CE56375  01-21-2022 SE ADICIONA 2 COLUMNAS PARA INCLUIR CAMPOS*
      * COL03   INETUM SAS  COLECTIVO Y DESTINO MODELO RAR LIBRANZAS  *
      *SCRUM - SDA36560 - COLWSPREST-54 - COLWSPREST-383 OTORGAR TASAS*
      *PERSONALIZADAS LIBRANZAS                                       *
      *---------------------------------------------------------------* 00000800
      * C810846  14-03-2022 SE AJUSTA PARA INCLUIR LOS TIPOS DE OPERA-*
      * COL04               CION HS Y HV PARA PRICING HIPOTECARIO     *
      *                     CCSS-13169                                *
      *---------------------------------------------------------------* 00000800
      * C810908  29-03-2022 SE ADICIONAN NUEVAS COLUMNAS PARA INCLUIR *
      * DCP                 NUEVAS VARIABLES AL MODELO RAR PARA       *
      * COL05               CARTERA COMERCIAL.                        *
      *                     -RANGO PARA VENTAS                        *
      *                     -TIPO PERSONA                             *
      *                     -CALIFICACION DEL RIESGO - RATING         *
      *                     -RANGO CALIFICACION RATING                *
      *                     -IND GARANTIA                             *
      *                     -RANGO MONTO OPERACION                    *
      *                     -PORCENTAJE PERDIDA ESPERADA              *
      *                     -PORCENTAJE RORC                          *
      *                     -PORCENTAJE RAROEC                        *
      *                     -CAPITAL ECONOMICO                        *
      *                     GP-35771 COLWSCANAL-1036                  *
      *---------------------------------------------------------------* 00000800
      * C810908  01-12-2022 SE COMENTA SWITCH PARA QUE NO SE CARGUEN  *
      * DCP                 CLUSTER/VARIABLES SI ALGUNA VARIABLE DESDE*
      * COL06               EL ARCHIVO DE CARGA VIENE MAL INFORMADA   *
      *                     COLWSPREST-8416 HU-COLWSPREST-2043        *
      *---------------------------------------------------------------* 00000800
      * C810846  15-06-2023 SE AJUSTE SELECT Y UPDATE DE TABLA UGDTNRA*
      * GLADIADORES TEAM    SEGUN CAMBIO DE LLAVE DE TABLA UGDTNRA    *
      * COL07               COLWSPREST-15688.                         *
      *---------------------------------------------------------------* 00000800
      * C810846  31-07-2023 SE AJUSTA PARA DAR DE BAJA LOS CLUSTERS   *
      * COL08               ACTIVOS ES DECIR CON ESTADO VS            *
      * GLADIADORES TEAM    COLWSPREST-7249                           *
      *---------------------------------------------------------------* 00000800
      * REFERENCIA : COL09                                            * 00002393
      * REALIZO    : EDINSON CALENO - T016395 - ACCENTURE LTDA        * 00002394
      * FECHA      : 07/07/2024                                       * 00002395
      * SDA-FEATURE: SDA-41748 / COLONECAPN-38                        * 00002396
      * DESCRIPCION: CUOTA FIJA - TASA VARIABLE PARA CREDITOS DE      * 00002397
      *              CONSUMO Y VEHICULO                               * 00002398
      * METODOLOGIA  SE REALIZA AJUSTE PARA INCLUIR PARAMETRIA        * 00002399
      * TRADICIONAL: MEDIANTE T37 PARA VALIDACION DE CLUSTERS ACTIVOS * 00002400
      *              SE COMENTAN LINEAS DE CONSTANTES DE VALIDACION Y * 00002400
      *              SE AGREGA CAMPO INDICADOR DE CLUSTER ACTIVO      * 00002400
      *---------------------------------------------------------------* 00002403
      * REFERENCIA : COL10                                            * 00002393
      * REALIZO    : LUIS SANDON - C808648 - BBVA COLOMBIA            * 00002394
      * FECHA      : 01/02/2026                                       * 00002395
      * SDA-FEATURE: COLONEPRE1-16282                                 * 00002396
      * HU         : COLONEPRE1-16737                                 * 00002397
      * DESCRIPCION: SE AJUSTA PARA OPTIMIZAR EL PROCESO Y MEJORAR EL * 00002398
      *              CONSUMO DE CPU Y MEJORAR TIEMPOS DE RESPUESTA    * 00002399
      *---------------------------------------------------------------* 00002403
      * REFERENCIA : COL11                                            * 00002393
      * REALIZO    : JAYSON GABRIEL PINILLA SUAREZ - INETUM           * 00002394
      * FECHA      : 26/03/2026                                       * 00002395
      * SDA-FEATURE: COLONEPRE1-17080                                 * 00002396
      * DESCRIPCION: SE AJUSTA PARA INCLUIR SITUACION LABORAL 06 NICHO* 00002398
      *---------------------------------------------------------------* 00002403
      *****************************************************************
      *                                                                 00004400
       IDENTIFICATION DIVISION.                                         00004500
       PROGRAM-ID.    UG4CRAR2.                                         00004600
       ENVIRONMENT DIVISION.                                            00004700
       CONFIGURATION SECTION.                                           00004800
       INPUT-OUTPUT SECTION.                                            00004900
      *                                                                 00005000
      ***************************************************************** 00005100
      *                    F I L E   C O N T R O L                    * 00005200
      ***************************************************************** 00005300
      *                                                                 00005400
       FILE-CONTROL.                                                    00005500
      *                                                                 00005600
      ***************************************************************** 00005700
      *                   SELECT DEL ARCHIVO DE EUGDNRA               * 00005800
      ***************************************************************** 00005900
      *                                                                 00006000
            SELECT EUGDNRA ASSIGN TO EUGDNRA                            00006100
                   ORGANIZATION IS SEQUENTIAL                           00006200
                   FILE STATUS  IS W-ESTADO.                            00006300
      *                                                                 00006400
      *COL10-I
            SELECT EUGDTNRA ASSIGN TO EUGDTNRA                          00006100
                   ORGANIZATION IS SEQUENTIAL                           00006200
                   FILE STATUS  IS W-ESTADO.                            00006300
      *
            SELECT SUGDTNRA ASSIGN TO SUGDTNRA                          00006500
                   ORGANIZATION IS SEQUENTIAL                           00006600
                   FILE STATUS  IS W-ESTADO.                            00006700
      *COL10-F
      *                                                                 00006400
            SELECT SALIDA  ASSIGN TO SALIDA                             00006500
                   ORGANIZATION IS SEQUENTIAL                           00006600
                   FILE STATUS  IS W-ESTADO.                            00006700
      *                                                                 00006800
            SELECT ERRORES  ASSIGN TO ERRORES                           00006900
                   ORGANIZATION IS SEQUENTIAL                           00007000
                   FILE STATUS  IS W-ESTADO.                            00007100
      *                                                                 00007200
      ***************************************************************** 00007800
      *                  D A T A   D I V I S I O N                    * 00007900
      ***************************************************************** 00008000
      *                                                                 00008100
       DATA DIVISION.                                                   00008200
       FILE SECTION.                                                    00008300
      *                                                                 00008400
      ***************************************************************** 00008500
      *                  FD DEL ARCHIVO DE E1DQNRA                    * 00008600
      ***************************************************************** 00008700
      *                                                                 00008800
       FD  EUGDNRA RECORDING MODE IS F BLOCK CONTAINS 0.                00008900
       01  REG-EUGDNRA.                                                 00009000
           05 ENT-TIPO-PRODUCTO        PIC X(02).                       00009100
           05 ENT-BURO-INI             PIC 9(04).                       00009200
           05 ENT-BURO-FIN             PIC 9(04).                       00009300
           05 ENT-DOM-NOMINA           PIC X(01).                       00009400
           05 ENT-SIT-LABORAL          PIC X(01).                       00009400
           05 ENT-INGRESOS-INI         PIC X(10).                       00009400
           05 ENT-INGRESOS-FIN         PIC X(10).                       00009500
           05 ENT-MONFIN-INI           PIC X(10).
           05 ENT-MONFIN-FIN           PIC X(10).
           05 ENT-PLAZO-INI            PIC 9(04).
           05 ENT-PLAZO-FIN            PIC 9(04).
           05 ENT-EDAD-INI             PIC 9(04).
           05 ENT-EDAD-FIN             PIC 9(04).
           05 ENT-SEGMENTO             PIC 9(05).
           05 ENT-COLECTIVO            PIC 9(04).
           05 ENT-GRIESGO-INI          PIC X(10).
           05 ENT-GRIESGO-FIN          PIC X(10).
           05 ENT-ESTADO-VEH           PIC X(01).
           05 ENT-FINANC-INI           PIC X(10).
           05 ENT-FINANC-FIN           PIC X(10).
           05 ENT-GAMAVEH-INI          PIC X(10).
           05 ENT-GAMAVEH-FIN          PIC X(10).
           05 ENT-TIPOVEH              PIC X(01).
      *COL03-I
           05 ENT-CLTVLB               PIC 9(03).
           05 ENT-DESTLB               PIC 9(03).
      *COL03-F
      *COL05-I
           05 ENT-VENTAS-INI           PIC X(10).
           05 ENT-VENTAS-FIN           PIC X(10).
           05 ENT-TIPO-PERSONA         PIC X(02).
           05 ENT-RATING               PIC X(05).
           05 ENT-RANGO-RATING         PIC X(01).
           05 ENT-GARANTIA             PIC X(01).
           05 ENT-MON-OPER-INI         PIC X(10).
           05 ENT-MON-OPER-FIN         PIC X(10).
           05 ENT-PE                   PIC X(05).
           05 ENT-RORC                 PIC X(05).
           05 ENT-RAROEC               PIC X(05).
           05 ENT-CAP-ECON             PIC X(05).
      *COL05-F
           05 ENT-TASA                 PIC X(05).
           05 ENT-CLUSTER              PIC X(20).                       00015800
      *COL10-I                                                          00015800
      *COL09-I
      *    05 ENT-IND-ACTIVO           PIC X(1).                        00015800
      *COL09-F
      ***************************************************************** 00008500
      *                  FD DEL ARCHIVO DE EUGDTNRA                   * 00008600
      ***************************************************************** 00008700
      *                                                                 00008800
       FD  EUGDTNRA RECORDING MODE IS F BLOCK CONTAINS 0.               00008900
       01  REG-EUGDTNRA.                                                00009000
           10  ENRA-TIPO-PRODUCTO       PIC X(2).                       00000600
           10  ENRA-VARIABLE            PIC X(2).                       00000700
           10  ENRA-CONSECUTIVO         PIC S9(9)V USAGE COMP-3.
           10  ENRA-FECHA-INI           PIC X(10).                      00000800
           10  ENRA-FECHA-FIN           PIC X(10).                      00000900
           10  ENRA-RANGO-INI           PIC S9(4) USAGE COMP-3.         00001100
           10  ENRA-RANGO-FIN           PIC S9(4) USAGE COMP-3.         00001200
           10  ENRA-IND-DOM-NOMINA      PIC X(1).                       00001300
           10  ENRA-SITUA-LABORAL       PIC X(1).                       00001300
           10  ENRA-MONTO-INICIAL       PIC S9(5)V9(4) USAGE COMP-3.    00001400
           10  ENRA-MONTO-FINAL         PIC S9(5)V9(4) USAGE COMP-3.    00001500
           10  ENRA-SEGMENTO            PIC S9(5)      USAGE COMP-3.
           10  ENRA-IND-CLIENTE-VIP     PIC X(1).                       00001800
           10  ENRA-RANGO-RIESGO-INI    PIC S9(5)V9(4) USAGE COMP-3.    00001600
           10  ENRA-RANGO-RIESGO-FIN    PIC S9(5)V9(4) USAGE COMP-3.    00001700
           10  ENRA-IND-ESTADO-VEH      PIC X(1).                       00001900
           10  ENRA-IND-TIPO-VEH        PIC X(1).                       00001900
           10  ENRA-CLAVE-ID            PIC X(25).                      00001900
           10  ENRA-CLUSTER             PIC X(25).                      00001900
           10  ENRA-ESTADO              PIC X(2).                       00001900
           10  ENRA-TASA                PIC S9(3)V9(4) USAGE COMP-3.    00001900
           10  ENRA-CENTRO-UMO          PIC X(4).                       00002100
           10  ENRA-USERID-UMO          PIC X(8).                       00002200
           10  ENRA-NETNAME-UMO         PIC X(4).                       00002300
           10  ENRA-TIMESTAMP           PIC X(26).                      00002400
           10  ENRA-RATING              PIC X(5).
           10  ENRA-RANGO-RATING        PIC X(1).
           10  ENRA-GARANTIA            PIC X(1).
           10  ENRA-PORCENTA            PIC S9(2)V9(2) USAGE COMP-3.
           10  ENRA-FILLER              PIC X(829).
      ***************************************************************** 00015900
      *                  FD DEL ARCHIVO DE SALIDA SUGDTNRA            * 00016000
      ***************************************************************** 00016100
      *                                                                 00016200
       FD  SUGDTNRA RECORDING MODE IS F                                 00016300
                     LABEL RECORDS ARE STANDARD                         00016400
                     BLOCK CONTAINS 0 RECORDS                           00016500
                     DATA RECORD IS REG-SUGDTNRA.                       00016600
       01  REG-SUGDTNRA                     PIC X(1000).
      *                                                                 00015800
      *COL10-F                                                          00015800
      ***************************************************************** 00015900
      *                  FD DEL ARCHIVO DE SALIDA                     * 00016000
      ***************************************************************** 00016100
      *                                                                 00016200
       FD  SALIDA RECORDING MODE IS F                                   00016300
                     LABEL RECORDS ARE STANDARD                         00016400
                     BLOCK CONTAINS 0 RECORDS                           00016500
                     DATA RECORD IS REG-SAL.                            00016600
      *COL05-I
      *01  REG-SAL                          PIC X(280).                 00016700
       01  REG-SAL                          PIC X(420).
      *COL05-F
      *                                                                 00016800
      ***************************************************************** 00016900
      *              FD DEL ARCHIVO DE SALIDA ERRORES                 * 00017000
      ***************************************************************** 00017100
      *                                                                 00017200
       FD  ERRORES RECORDING MODE IS F                                  00017300
                     LABEL RECORDS ARE STANDARD                         00017400
                     BLOCK CONTAINS 0 RECORDS                           00017500
                     DATA RECORD IS REG-SAL.                            00017600
      *COL05-I
      *01  REG-ERR                          PIC X(280).                 00017700
       01  REG-ERR                          PIC X(420).
      *COL05-F
      *                                                                 00017800
      ***************************************************************** 00019000
      *                   WORKING STORAGE SECTION                     * 00019100
      ***************************************************************** 00019200
      *                                                                 00019300
       WORKING-STORAGE SECTION.                                         00019400
      *                                                                 00019500
      ***************************************************************** 00019600
      *                  A R E A S   D E   T R A B A J O              * 00019700
      ***************************************************************** 00019800
      *                                                               * 00019900
      ***************************************************************** 00020000
      *                      INCLUDE DEL SQLCA                        * 00020100
      ***************************************************************** 00020200
      *                                                                 00020300
           EXEC SQL                                                     00020400
                INCLUDE SQLCA                                           00020500
           END-EXEC.                                                    00020600
      *                                                                 00020700
      ***************************************************************** 00020800
      *                  AREA DE LA TABLA DB2 UGDTNRA                 * 00020900
      ***************************************************************** 00021000
      *                                                                 00021100
           EXEC SQL                                                     00021200
                INCLUDE UGGTNRA                                         00021300
           END-EXEC.                                                    00021400
      *                                                                 00021500
           EXEC SQL                                                     00021600
                INCLUDE UGTCNRA                                         00021700
           END-EXEC.                                                    00021800
      *
      *COL03-I                                                          00082700
      ***************************************************************** 00020800
      *                  AREA DE LA TABLA DB2 UGDTT37                 * 00020900
      ***************************************************************** 00021000
           EXEC SQL                                                     00082800
             INCLUDE UGGTT37                                            00082900
           END-EXEC                                                     00083000
      *                                                                 00083100
           EXEC SQL                                                     00083200
             INCLUDE UGTCT37                                            00083300
           END-EXEC                                                     00083400
      *COL03-F                                                          00083500
      ***************************************************************** 00023200
      *                           SWITCHES                            * 00023300
      ***************************************************************** 00023400
      *                                                                 00023500
       01 EST-SALIDA                   PIC XX    VALUE '00'.            00023600
      *                                                                 00023700
      ***************************************************************** 00023800
      *                       VARIABLES DE TRABAJO                    * 00023900
      ***************************************************************** 00024000
      *                                                                 00024100
       01 WS-VARIABLES.                                                 00024200
          05 WS-PARM-COMMIT               PIC 9(04).
      *COL01-I
          05 WS-PARM-TIPO                 PIC X(02).
      *COL01-F
          05 WS-CONT-COMMIT               PIC 9(04).
          05 WS-VARIABLE                  PIC X(02).
      *COL05-I
      *   05 WS-CLAVEID                   PIC X(20) VALUE SPACES.
      *   05 WS-CERO                      PIC X(20) VALUE SPACES.
          05 WS-CLAVEID                   PIC X(35) VALUE SPACES.
          05 WS-CERO                      PIC X(35) VALUE SPACES.
      *COL05-F
          05 WS-C                         PIC X(01).
          05 WS-CN REDEFINES WS-C.
             10 WS-N                      PIC 9(01).
          05 WS-I                         PIC 9(02) VALUE ZEROS.
          05 WS-IND                       PIC 9(02) VALUE ZEROS.
          05 WS-STRING                    PIC X(10) VALUE SPACES.
          05 WS-CONTA-REGS                PIC S9(6) COMP.
          05 WS-RANGO-INI                 PIC 9(04).
          05 WS-RANGO-FIN                 PIC 9(04).
          05 WS-MONTO-INI                 PIC S9(05)V9(04).
          05 WS-MONTO-FIN                 PIC S9(05)V9(04).
          05 WS-SEGMCOLE                  PIC 9(05) VALUE ZEROS.
      *COL03-I
          05 WS-SECT37                    PIC X(04) VALUE SPACES.
          05 WS-ELMT37                    PIC X(03) VALUE SPACES.
          05 WS-T37-RESTO                 PIC X(20) VALUE SPACES.
      *COL03-F
      *COL05-I
          05 WS-PE                        PIC S9(02)V9(02) VALUE ZEROS.
          05 WS-RORC                      PIC S9(02)V9(02) VALUE ZEROS.
          05 WS-RAROEC                    PIC S9(02)V9(02) VALUE ZEROS.
          05 WS-CAPITAL-ECON              PIC S9(02)V9(02) VALUE ZEROS.
          05 WS-TIPOPER                   PIC X(01) VALUE SPACES.
          05 WS-NUMERO3                   PIC S9(2)V9(2) VALUE ZEROS.   00033600
          05 WS-NU                        PIC 9(05).
      *COL05-F
      *COL07-I
           05 WS-FECHA-INI                PIC X(10) VALUE SPACES.
      *COL07-I
      *COL08-I
          05 WS-CLUSTER                   PIC X(20).                    00015800
          05 WS-TPROD-AUX                 PIC X(02).                    00015800
          05 WS-CONSEC-T.
             10 WS-CONSEC-A               PIC 9(05).
             10 WS-CONSEC-B               PIC 9(04).
          05 WS-CONSEC-R REDEFINES WS-CONSEC-T PIC S9(9).
      *COL08-F
      *COL10-I
          05 WS-TIPO-PRODUCTO             PIC X(02).                    00015800
          05 WS-VAR-CLUSTER               PIC X(01).                    00015800
          05 WS-LLAVE01.
             10 WS01-TIPO-PRODUCTO        PIC X(2).
             10 WS01-VARIABLE             PIC X(2).
             10 WS01-RANGO-INI            PIC S9(4) USAGE COMP-3.
             10 WS01-RANGO-FIN            PIC S9(4) USAGE COMP-3.
          05 WS-LLAVE02.
             10 WS02-TIPO-PRODUCTO        PIC X(2).
             10 WS02-VARIABLE             PIC X(2).
             10 WS02-AUX                  PIC X(1).
          05 WS-LLAVE03.
             10 WS03-TIPO-PRODUCTO        PIC X(2).
             10 WS03-VARIABLE             PIC X(2).
             10 WS03-MONTO-INICIAL  PIC S9(5)V9(4) USAGE COMP-3.
             10 WS03-MONTO-FINAL    PIC S9(5)V9(4) USAGE COMP-3.
          05 WS-LLAVE04.
             10 WS04-TIPO-PRODUCTO        PIC X(2).
             10 WS04-VARIABLE             PIC X(2).
             10 WS04-SEGMENTO             PIC S9(5) USAGE COMP-3.
          05 WS-LLAVE05.
             10 WS05-TIPO-PRODUCTO        PIC X(2).
             10 WS05-VARIABLE             PIC X(2).
             10 WS05-RATING               PIC X(5).
          05 CURRENT-TIMESTAMP            pic x(26).
      *COL10-F
      *
          05 WS-CONTADORES.                                             00033600
      *COL08-I
      *      10 CONT-CSC                  PIC S9(6) COMP.               00033700
             10 CONT-CSC                  PIC S9(9) COMP.               00033700
      *COL08-F
      *COL10-I
             10 CONT-TNRA                 PIC 9(09) VALUE ZEROES.       00033700
             10 CONT-TNRA01               PIC 9(09) VALUE ZEROES.       00033700
             10 CONT-TNRA02               PIC 9(09) VALUE ZEROES.       00033700
             10 CONT-TNRA03               PIC 9(09) VALUE ZEROES.       00033700
             10 CONT-TNRA04               PIC 9(09) VALUE ZEROES.       00033700
             10 CONT-TNRA05               PIC 9(09) VALUE ZEROES.       00033700
             10 CONT-TNRA06               PIC 9(09) VALUE ZEROES.       00033700
             10 CONT-TNRA07               PIC 9(09) VALUE ZEROES.       00033700
             10 CONT-TNRA08               PIC 9(09) VALUE ZEROES.       00033700
             10 CONT-TNRA09               PIC 9(09) VALUE ZEROES.       00033700
             10 CONT-TNRA10               PIC 9(09) VALUE ZEROES.       00033700
             10 CONT-TNRA11               PIC 9(09) VALUE ZEROES.       00033700
             10 CONT-TNRA12               PIC 9(09) VALUE ZEROES.       00033700
             10 CONT-COUNTER              PIC 9(09) VALUE ZEROES.       00033700
             10 CONT-SUGDTNRA             PIC 9(09) VALUE ZEROES.       00034000
      *COL10-F
             10 CONT-NRA                  PIC 9(09) VALUE ZEROES.       00033700
             10 CONT-GRABADOS             PIC 9(09) VALUE ZEROES.       00033800
             10 CONT-ACTUALIZA            PIC 9(09) VALUE ZEROES.       00034000
             10 CONT-ERRORES              PIC 9(09) VALUE ZEROES.       00034000
             10 CONT-BORRADOS             PIC 9(09) VALUE ZEROES.       00034000
      * COL03-I
             10 CONT-UPDATE               PIC 9(09) VALUE ZEROES.       00034000
      * COL03-F
                                                                        00035200
          05 WS-NUMERO5                   PIC S9(5)V9(4) VALUE ZEROS.   00033600
          05 WS-NUMERO2                   PIC S9(2)V9(2) VALUE ZEROS.   00033600
                                                                        00034000
      *                                                                 00038000
       01 WS-FECHAS.                                                    00038100
          03 WS-FHGRE1                    PIC X(10)  VALUE SPACES.      00038200
          03 WS-FHGRE2                    PIC X(10)  VALUE SPACES.      00038300
          03 W-FECHA-HOY.                                               00038400
              05 W-ANO-HOY                PIC 9(02).                    00038500
              05 W-MES-HOY                PIC 9(02).                    00038600
              05 W-DIA-HOY                PIC 9(02).                    00038700
          03 W-FECHA-DIS.                                               00038800
              05 W-ANO-DIS                PIC 9(04).                    00038900
              05 FILLER                   PIC X(01) VALUE '-'.          00039000
              05 W-MES-DIS                PIC 9(02).                    00039100
              05 FILLER                   PIC X(01) VALUE '-'.          00039200
              05 W-DIA-DIS                PIC 9(02).                    00039300
          03 W-FECHA-DIA.                                               00038800
              05 W-ANO-DIA                PIC 9(04).                    00038900
              05 FILLER                   PIC X(01) VALUE '-'.          00039000
              05 W-MES-DIA                PIC 9(02).                    00039100
              05 FILLER                   PIC X(01) VALUE '-'.          00039200
              05 W-DIA-DIA                PIC 9(02).                    00039300
      *                                                                 00039400
          03 W-HORA-HOY.                                                00039500
              05 W-HH-HOY                 PIC  9(02).                   00039600
              05 W-MM-HOY                 PIC  9(02).                   00039700
              05 W-SS-HOY                 PIC  9(02).                   00039800
              05 W-MS-HOY                 PIC  9(02).                   00039900
           03 W-HORA-DIS.                                               00040000
              05 W-HH-DIS                 PIC  9(02).                   00040100
              05 FILLER                   PIC  X(01) VALUE ':'.         00040200
              05 W-MM-DIS                 PIC  9(02).                   00040300
              05 FILLER                   PIC  X(01) VALUE ':'.         00040400
              05 W-SS-DIS                 PIC  9(02).                   00040500
              05 FILLER                   PIC  X(01) VALUE ':'.         00040600
              05 W-MS-DIS                 PIC  9(02).                   00040700
      *COL10-I                                                          00033560
      *----------------------------------------------------------------*00033570
      *               VARIABLES DE TABLAS                              *00033580
      *----------------------------------------------------------------*00033590
       01  W-TABLA-NRA01.                                               00033591
           05 TAB-RANGO          OCCURS 1 TO 100 TIMES                  00033592
                                 DEPENDING ON CONT-TNRA01
                                 ASCENDING KEY IS RNRA-LLAVE            00033593
                                 INDEXED BY INDNRA01.                   00033594
              10 RNRA-LLAVE.                                            00033595
                 15 RNRA-TIPO-PRODUCTO       PIC X(2).                  00033596
                 15 RNRA-VARIABLE            PIC X(2).                  00033597
                 15 RNRA-RANGO-INI           PIC S9(4) USAGE COMP-3.    00033597
                 15 RNRA-RANGO-FIN           PIC S9(4) USAGE COMP-3.    00033597
              10 RNRA-CLAVE-ID               PIC X(1).                  00033598
       01  W-TABLA-NRA02.                                               00033591
           05 TAB-NOMINA         OCCURS 1 TO 100 TIMES                  00033592
                                 DEPENDING ON CONT-TNRA02
                                 ASCENDING KEY IS NNRA-LLAVE            00033593
                                 INDEXED BY INDNRA02.                   00033594
              10 NNRA-LLAVE.                                            00033595
                 15 NNRA-TIPO-PRODUCTO       PIC X(2).                  00033596
                 15 NNRA-VARIABLE            PIC X(2).                  00033597
                 15 NNRA-IND-DOM-NOMINA      PIC X(1).                  00033597
              10 NNRA-CLAVE-ID               PIC X(1).                  00033598
       01  W-TABLA-NRA03.                                               00033591
           05 TAB-LABORAL        OCCURS 1 TO 100 TIMES                  00033592
                                 DEPENDING ON CONT-TNRA03
                                 ASCENDING KEY IS LNRA-LLAVE            00033593
                                 INDEXED BY INDNRA03.                   00033594
              10 LNRA-LLAVE.                                            00033595
                 15 LNRA-TIPO-PRODUCTO       PIC X(2).                  00033596
                 15 LNRA-VARIABLE            PIC X(2).                  00033597
                 15 LNRA-SITUA-LABORAL       PIC X(1).                  00033597
              10 LNRA-CLAVE-ID               PIC X(1).                  00033598
       01  W-TABLA-NRA04.                                               00033591
           05 TAB-MONTO          OCCURS 1 TO 100 TIMES                  00033592
                                 DEPENDING ON CONT-TNRA04
                                 ASCENDING KEY IS MNRA-LLAVE            00033593
                                 INDEXED BY INDNRA04.                   00033594
              10 MNRA-LLAVE.                                            00033595
                 15 MNRA-TIPO-PRODUCTO       PIC X(2).                  00033596
                 15 MNRA-VARIABLE            PIC X(2).                  00033597
                 15 MNRA-MONTO-INICIAL  PIC S9(5)V9(4) USAGE COMP-3.    00033597
                 15 MNRA-MONTO-FINAL    PIC S9(5)V9(4) USAGE COMP-3.    00033597
              10 MNRA-CLAVE-ID               PIC X(1).                  00033598
       01  W-TABLA-NRA05.                                               00033591
           05 TAB-SEGMENTO       OCCURS 1 TO 100 TIMES                  00033592
                                 DEPENDING ON CONT-TNRA05
                                 ASCENDING KEY IS SNRA-LLAVE            00033593
                                 INDEXED BY INDNRA05.                   00033594
              10 SNRA-LLAVE.                                            00033595
                 15 SNRA-TIPO-PRODUCTO       PIC X(2).                  00033596
                 15 SNRA-VARIABLE            PIC X(2).                  00033597
                 15 SNRA-SEGMENTO            PIC S9(5) USAGE COMP-3.    00033597
              10 SNRA-CLAVE-ID               PIC X(1).                  00033598
       01  W-TABLA-NRA06.                                               00033591
           05 TAB-VIP            OCCURS 1 TO 100 TIMES                  00033592
                                 DEPENDING ON CONT-TNRA06
                                 ASCENDING KEY IS VNRA-LLAVE            00033593
                                 INDEXED BY INDNRA06.                   00033594
              10 VNRA-LLAVE.                                            00033595
                 15 VNRA-TIPO-PRODUCTO       PIC X(2).                  00033596
                 15 VNRA-VARIABLE            PIC X(2).                  00033597
                 15 VNRA-IND-CLIENTE-VIP     PIC X(1).                  00033597
              10 VNRA-CLAVE-ID               PIC X(1).                  00033598
       01  W-TABLA-NRA07.                                               00033591
           05 TAB-RIESGO         OCCURS 1 TO 100 TIMES                  00033592
                                 DEPENDING ON CONT-TNRA07
                                 ASCENDING KEY IS BNRA-LLAVE            00033593
                                 INDEXED BY INDNRA07.                   00033594
              10 BNRA-LLAVE.                                            00033595
                 15 BNRA-TIPO-PRODUCTO       PIC X(2).                  00033596
                 15 BNRA-VARIABLE            PIC X(2).                  00033597
                 15 BNRA-RANGO-RIESGO-INI PIC S9(5)V9(4) USAGE COMP-3.  00033597
                 15 BNRA-RANGO-RIESGO-FIN PIC S9(5)V9(4) USAGE COMP-3.  00033597
              10 BNRA-CLAVE-ID               PIC X(1).                  00033598
       01  W-TABLA-NRA08.                                               00033591
           05 TAB-ESTADO-VEH     OCCURS 1 TO 100 TIMES                  00033592
                                 DEPENDING ON CONT-TNRA08
                                 ASCENDING KEY IS XNRA-LLAVE            00033593
                                 INDEXED BY INDNRA08.                   00033594
              10 XNRA-LLAVE.                                            00033595
                 15 XNRA-TIPO-PRODUCTO       PIC X(2).                  00033596
                 15 XNRA-VARIABLE            PIC X(2).                  00033597
                 15 XNRA-IND-ESTADO-VEH      PIC X(1).                  00033597
              10 XNRA-CLAVE-ID               PIC X(1).                  00033598
       01  W-TABLA-NRA09.                                               00033591
           05 TAB-TIPO-VEH       OCCURS 1 TO 100 TIMES                  00033592
                                 DEPENDING ON CONT-TNRA09
                                 ASCENDING KEY IS TNRA-LLAVE            00033593
                                 INDEXED BY INDNRA09.                   00033594
              10 TNRA-LLAVE.                                            00033595
                 15 TNRA-TIPO-PRODUCTO       PIC X(2).                  00033596
                 15 TNRA-VARIABLE            PIC X(2).                  00033597
                 15 TNRA-IND-TIPO-VEH        PIC X(1).                  00033597
              10 TNRA-CLAVE-ID               PIC X(1).                  00033598
       01  W-TABLA-NRA10.                                               00033591
           05 TAB-RATING         OCCURS 1 TO 100 TIMES                  00033592
                                 DEPENDING ON CONT-TNRA10
                                 ASCENDING KEY IS GNRA-LLAVE            00033593
                                 INDEXED BY INDNRA10.                   00033594
              10 GNRA-LLAVE.                                            00033595
                 15 GNRA-TIPO-PRODUCTO       PIC X(2).                  00033596
                 15 GNRA-VARIABLE            PIC X(2).                  00033597
                 15 GNRA-RATING              PIC X(5).                  00033597
              10 GNRA-CLAVE-ID               PIC X(1).                  00033598
       01  W-TABLA-NRA11.                                               00033591
           05 TAB-RANGO-RATING   OCCURS 1 TO 100 TIMES                  00033592
                                 DEPENDING ON CONT-TNRA11
                                 ASCENDING KEY IS HNRA-LLAVE            00033593
                                 INDEXED BY INDNRA11.                   00033594
              10 HNRA-LLAVE.                                            00033595
                 15 HNRA-TIPO-PRODUCTO       PIC X(2).                  00033596
                 15 HNRA-VARIABLE            PIC X(2).                  00033597
                 15 HNRA-RANGO-RATING        PIC X(1).                  00033597
              10 HNRA-CLAVE-ID               PIC X(1).                  00033598
       01  W-TABLA-NRA12.                                               00033591
           05 TAB-GARANTIA       OCCURS 1 TO 100 TIMES                  00033592
                                 DEPENDING ON CONT-TNRA12
                                 ASCENDING KEY IS ANRA-LLAVE            00033593
                                 INDEXED BY INDNRA12.                   00033594
              10 ANRA-LLAVE.                                            00033595
                 15 ANRA-TIPO-PRODUCTO       PIC X(2).                  00033596
                 15 ANRA-VARIABLE            PIC X(2).                  00033597
                 15 ANRA-GARANTIA            PIC X(1).                  00033597
              10 ANRA-CLAVE-ID               PIC X(1).                  00033598
      *COL10-F                                                          00033599
      *****************************************************************
      *                           CONSTANTES                          *
      *****************************************************************
      *
       01 CONSTANTES.
      *****************************************************************
          05 CTE-TITULO-0                 PIC X(68)
                VALUE 'RESULTADO CARGA TASA PREF....'.
          05 CTE-VS                       PIC XX    VALUE 'VS'.
          05 CTE-BA                       PIC XX    VALUE 'BA'.
          05 CTE-00                       PIC XX    VALUE '00'.
          05 CTE-01                       PIC X(02) VALUE '01'.
          05 CTE-02                       PIC X(02) VALUE '02'.
          05 CTE-03                       PIC X(02) VALUE '03'.
          05 CTE-04                       PIC X(02) VALUE '04'.
          05 CTE-05                       PIC X(02) VALUE '05'.
          05 CTE-06                       PIC X(02) VALUE '06'.
          05 CTE-07                       PIC X(02) VALUE '07'.
          05 CTE-08                       PIC X(02) VALUE '08'.
          05 CTE-09                       PIC X(02) VALUE '09'.
          05 CTE-10                       PIC X(02) VALUE '10'.
          05 CTEN-10                      PIC 9(02) VALUE 10.
          05 CTEN-05                      PIC 9(02) VALUE 05.
          05 CTE-11                       PIC X(02) VALUE '11'.
          05 CTE-12                       PIC X(02) VALUE '12'.
          05 CTE-13                       PIC X(02) VALUE '13'.
          05 CTE-14                       PIC X(02) VALUE '14'.
          05 CTE-15                       PIC X(02) VALUE '15'.
      *COL03-I
          05 CTE-16                       PIC X(02) VALUE '16'.
          05 CTE-17                       PIC X(02) VALUE '17'.
          05 CTE-9965                     PIC X(04) VALUE '9965'.
          05 CTE-9966                     PIC X(04) VALUE '9966'.
          05 CTE-ERR-COLECTIVO            PIC X(18) VALUE
             'ERROR EN COLECTIVO'.
          05 CTE-ERR-DESTINO              PIC X(18) VALUE
             'ERROR EN DESTINO  '.
      *COL03-F
      *COL05-I
          05 CTE-18                       PIC X(02) VALUE '18'.
          05 CTE-19                       PIC X(02) VALUE '19'.
          05 CTE-20                       PIC X(02) VALUE '20'.
          05 CTE-21                       PIC X(02) VALUE '21'.
          05 CTE-22                       PIC X(02) VALUE '22'.
          05 CTE-23                       PIC X(02) VALUE '23'.
      *COL05-F
          05 CTE-90                       PIC X(02) VALUE '90'.

          05 CTE-FECFIN                   PIC X(10) VALUE '2099-12-30'.
          05 CTE-RETURNCDE                PIC 99    VALUE 12.
          05 CTE-ERROR-WRITE-CONTROL      PIC X(38) VALUE
              ' ERROR ESCRIBIENDO EL ARCHIVO CONTROL '.
      *                                                                 00040800
       01 WS-SWITCHES.                                                  00040900
          05 DB2-RETURN-CDE               PIC S9(9) COMP.               00041000
      *CUANDO REALIZAS UNA CONSULTA Y ENCUENTRA DATOS.
             88 DB2-OK                         VALUE +0.
      *CUANDO REALIZAS UNA CONSULTA Y NO ENCUENTRA DATOS.
             88 DB2-NOTFND                     VALUE +100.
      *CUANDO QUIERES EL MAXIMO Y NO ENCUENTRA REGISTRO REGRESA NULOS.
             88 DB2-NULL                       VALUE -305.
      *CUANDO REALIZAS UN INSERT O ACTUALIZAR UN REGISTRO Y YA EXISTE.
             88 DB2-DUPL                       VALUE -803.
      *CUANDO REALIZAS UN UPDATE O SELECT Y EXISTE MAS DE UN REGISTRO.
             88 DB2-VARIOS                     VALUE -811.
      *CUANDO LA TABALA ESTA OCUPADA EN ELGUN PROCESO O POR UN USUARIO.
             88 DB2-NODISP                     VALUE -911.              00041400
      *CUANDO REALIZAS UN UPDATE O INSERT Y ESTAN OCUPANDO LA TABLA.
             88 DB2-ATRAPA                     VALUE -904.              00041500
      *                                                                 00041600
         05 W-ESTADO                      PIC X(02) VALUE '00'.         00041700
             88 STATUS-OK                      VALUE '00'.              00041800
             88 STATUS-10                      VALUE '10'.              00041900
             88 STATUS-97                      VALUE '97'.              00042000
      *COL10-I
         05 SW-TNRA                       PIC X(01) VALUE 'N'.          00042100
             88 SI-FIN-TNRA                    VALUE 'S'.               00042200
             88 NO-FIN-TNRA                    VALUE 'N'.               00042300
         05 SW-VAR-01                     PIC X(01) VALUE 'N'.          00042100
             88 SI-VAR-01                      VALUE 'S'.               00042200
             88 NO-VAR-01                      VALUE 'N'.               00042300
         05 SW-VAR-02                     PIC X(01) VALUE 'N'.          00042100
             88 SI-VAR-02                      VALUE 'S'.               00042200
             88 NO-VAR-02                      VALUE 'N'.               00042300
         05 SW-VAR-03                     PIC X(01) VALUE 'N'.          00042100
             88 SI-VAR-03                      VALUE 'S'.               00042200
             88 NO-VAR-03                      VALUE 'N'.               00042300
         05 SW-VAR-04                     PIC X(01) VALUE 'N'.          00042100
             88 SI-VAR-04                      VALUE 'S'.               00042200
             88 NO-VAR-04                      VALUE 'N'.               00042300
         05 SW-VAR-05                     PIC X(01) VALUE 'N'.          00042100
             88 SI-VAR-05                      VALUE 'S'.               00042200
             88 NO-VAR-05                      VALUE 'N'.               00042300
         05 SW-VAR-06                     PIC X(01) VALUE 'N'.          00042100
             88 SI-VAR-06                      VALUE 'S'.               00042200
             88 NO-VAR-06                      VALUE 'N'.               00042300
         05 SW-VAR-07                     PIC X(01) VALUE 'N'.          00042100
             88 SI-VAR-07                      VALUE 'S'.               00042200
             88 NO-VAR-07                      VALUE 'N'.               00042300
         05 SW-VAR-08                     PIC X(01) VALUE 'N'.          00042100
             88 SI-VAR-08                      VALUE 'S'.               00042200
             88 NO-VAR-08                      VALUE 'N'.               00042300
         05 SW-VAR-09                     PIC X(01) VALUE 'N'.          00042100
             88 SI-VAR-09                      VALUE 'S'.               00042200
             88 NO-VAR-09                      VALUE 'N'.               00042300
         05 SW-VAR-10                     PIC X(01) VALUE 'N'.          00042100
             88 SI-VAR-10                      VALUE 'S'.               00042200
             88 NO-VAR-10                      VALUE 'N'.               00042300
         05 SW-VAR-11                     PIC X(01) VALUE 'N'.          00042100
             88 SI-VAR-11                      VALUE 'S'.               00042200
             88 NO-VAR-11                      VALUE 'N'.               00042300
         05 SW-VAR-12                     PIC X(01) VALUE 'N'.          00042100
             88 SI-VAR-12                      VALUE 'S'.               00042200
             88 NO-VAR-12                      VALUE 'N'.               00042300
         05 SW-VAR-13                     PIC X(01) VALUE 'N'.          00042100
             88 SI-VAR-13                      VALUE 'S'.               00042200
             88 NO-VAR-13                      VALUE 'N'.               00042300
         05 SW-VAR-14                     PIC X(01) VALUE 'N'.          00042100
             88 SI-VAR-14                      VALUE 'S'.               00042200
             88 NO-VAR-14                      VALUE 'N'.               00042300
         05 SW-VAR-15                     PIC X(01) VALUE 'N'.          00042100
             88 SI-VAR-15                      VALUE 'S'.               00042200
             88 NO-VAR-15                      VALUE 'N'.               00042300
         05 SW-VAR-16                     PIC X(01) VALUE 'N'.          00042100
             88 SI-VAR-16                      VALUE 'S'.               00042200
             88 NO-VAR-16                      VALUE 'N'.               00042300
         05 SW-VAR-17                     PIC X(01) VALUE 'N'.          00042100
             88 SI-VAR-17                      VALUE 'S'.               00042200
             88 NO-VAR-17                      VALUE 'N'.               00042300
         05 SW-VAR-18                     PIC X(01) VALUE 'N'.          00042100
             88 SI-VAR-18                      VALUE 'S'.               00042200
             88 NO-VAR-18                      VALUE 'N'.               00042300
         05 SW-VAR-19                     PIC X(01) VALUE 'N'.          00042100
             88 SI-VAR-19                      VALUE 'S'.               00042200
             88 NO-VAR-19                      VALUE 'N'.               00042300
         05 SW-VAR-20                     PIC X(01) VALUE 'N'.          00042100
             88 SI-VAR-20                      VALUE 'S'.               00042200
             88 NO-VAR-20                      VALUE 'N'.               00042300
         05 SW-VAR-21                     PIC X(01) VALUE 'N'.          00042100
             88 SI-VAR-21                      VALUE 'S'.               00042200
             88 NO-VAR-21                      VALUE 'N'.               00042300
         05 SW-VAR-22                     PIC X(01) VALUE 'N'.          00042100
             88 SI-VAR-22                      VALUE 'S'.               00042200
             88 NO-VAR-22                      VALUE 'N'.               00042300
         05 SW-VAR-23                     PIC X(01) VALUE 'N'.          00042100
             88 SI-VAR-23                      VALUE 'S'.               00042200
             88 NO-VAR-23                      VALUE 'N'.               00042300
      *COL10-F
         05 SW-NRA                        PIC X(01) VALUE 'N'.          00042100
             88 SI-FIN-NRA                     VALUE 'S'.               00042200
             88 NO-FIN-NRA                     VALUE 'N'.               00042300
         05 SW-EXIS-NRA                   PIC X(01) VALUE 'N'.          00042400
             88 SI-EXIS-NRA                    VALUE 'S'.               00042500
             88 NO-EXIS-NRA                    VALUE 'N'.               00042600
         05 SW-FIN-CURSOR                 PIC X(01) VALUE 'N'.
             88 SI-FIN-CURSOR                  VALUE 'S'.
             88 NO-FIN-CURSOR                  VALUE 'N'.
      * COL03-I
         05 SW-FIN-CURSO1                 PIC X(01) VALUE 'N'.
             88 SI-FIN-CURSO1                  VALUE 'S'.
             88 NO-FIN-CURSO1                  VALUE 'N'.
      * COL03-F
      *COL02-I
         05 SW-MODI-VAR                   PIC X(01) VALUE 'N'.          00042400
             88 SI-MODI-VAR                    VALUE 'S'.               00042500
             88 NO-MODI-VAR                    VALUE 'N'.               00042600
      *COL02-F
      *COL03-I
          05 SW-SECT37                    PIC X VALUE 'S'.              00092200
             88 SW-SECT37-OK                    VALUE 'S'.              00092300
             88 SW-SECT37-ERROR                 VALUE 'N'.              00092400
      *COL03-F
         05 CTE-TIPPRO-H                  PIC X(02) VALUE 'H '.         00041700
         05 CTE-TIPPRO-L                  PIC X(02) VALUE 'L '.         00041700
         05 CTE-TIPPRO-N                  PIC X(02) VALUE 'N '.         00041700
         05 CTE-TIPPRO-V                  PIC X(02) VALUE 'V '.         00041700
         05 CTE-TIPPRO-VC                 PIC X(02) VALUE 'VC'.         00041700
         05 CTE-TIPPRO-NC                 PIC X(02) VALUE 'NC'.         00041700
         05 CTE-TIPPRO-HC                 PIC X(02) VALUE 'HC'.         00041700
         05 CTE-TIPPRO-HU                 PIC X(02) VALUE 'HU'.         00041700
         05 SW-CORRECTO                   PIC X(01)   VALUE 'S'.
             88 SI-CORRECTO                    VALUE 'S'.
             88 NO-CORRECTO                    VALUE 'N'.
         05 SW-NUMERICO                   PIC X(01)   VALUE 'S'.
             88 SI-NUMERICO                    VALUE 'S'.
             88 NO-NUMERICO                    VALUE 'N'.
      ***************************************************************** 00043300
      *                    AUXILIARES DE REGISTRO SALIDA              * 00043400
      ***************************************************************** 00043500
      *                                                                 00043600
       01 REG-ENCABE.                                                   00043700
          05 ENC-TIPPRO                     PIC X(06)                   00043800
                                            VALUE 'TIPPRO'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ENC-BURINI                     PIC X(06)                   00043800
                                            VALUE 'BR-IN'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ENC-BURFIN                     PIC X(06)                   00043800
                                            VALUE 'BR-FI'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ENC-DOMNOM                     PIC X(03)                   00043800
                                            VALUE 'DNM'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ENC-SITLAB                     PIC X(03)                   00043800
                                            VALUE 'SLA'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ENC-INGINI                     PIC X(10)                   00043800
                                            VALUE 'IGR-INI '.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ENC-INGFIN                     PIC X(10)                   00043800
                                            VALUE 'IGR-FIN '.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ENC-MONINI                     PIC X(10)                   00043800
                                            VALUE 'MON-INI '.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ENC-MONFIN                     PIC X(10)                   00043800
                                            VALUE 'MON-FIN '.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ENC-PLAINI                     PIC X(06)                   00043800
                                            VALUE 'PZ-IN '.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ENC-PLAFIN                     PIC X(06)                   00043800
                                            VALUE 'PZ-FI'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ENC-EDAINI                     PIC X(06)                   00043800
                                            VALUE 'ED-IN '.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ENC-EDAFIN                     PIC X(06)                   00043800
                                            VALUE 'ED-FI'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ENC-SEGMEN                     PIC X(05)                   00043800
                                            VALUE 'SEGME'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ENC-COLECT                     PIC X(04)                   00043800
                                            VALUE 'CLTV'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ENC-GRIINI                     PIC X(10)                   00043800
                                            VALUE 'GRI-INI '.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ENC-GRIFIN                     PIC X(10)                   00043800
                                            VALUE 'GRI-FIN '.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ENC-ESTVEH                     PIC X(06)                   00043800
                                            VALUE 'ES-VH'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ENC-PFIINI                     PIC X(10)                   00043800
                                            VALUE '%FN-INI '.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ENC-PFIFIN                     PIC X(10)                   00043800
                                            VALUE '%FN-FIN '.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ENC-GAMINI                     PIC X(10)                   00043800
                                            VALUE 'GAM-INI '.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ENC-GAMFIN                     PIC X(10)                   00043800
                                            VALUE 'GAM-FIN '.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ENC-TIPVEH                     PIC X(06)                   00043800
                                            VALUE 'TP-VH'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
      *COL03-I
          05 ENC-CLTVLB                     PIC X(06)                   00043800
                                            VALUE 'CLTVLB'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ENC-DESTLB                     PIC X(06)                   00043800
                                            VALUE 'DESTLB'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
      *COL03-F
      *COL05-I
          05 ENC-VENTINI                    PIC X(10)
                                            VALUE 'VENTAS-INI'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ENC-VENTFIN                    PIC X(10)
                                            VALUE 'VENTAS-FIN'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ENC-TIPPERSO                   PIC X(07)
                                            VALUE 'TIP-PER'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ENC-RATING                     PIC X(06)
                                            VALUE 'RATING'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ENC-RANRATING                  PIC X(07)
                                            VALUE 'RANG-RA'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ENC-GARANTIA                   PIC X(05)
                                            VALUE 'GARAN'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ENC-MONOPERINI                 PIC X(10)
                                            VALUE 'MONOPE-INI'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ENC-MONOPERFIN                 PIC X(10)
                                            VALUE 'MONOPE-FIN'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ENC-PE                         PIC X(06)
                                            VALUE 'PERDES'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ENC-RORC                       PIC X(05)
                                            VALUE 'RORC '.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ENC-RAROEC                     PIC X(06)
                                            VALUE 'RAROEC'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ENC-CAPECON                    PIC X(06)
                                            VALUE 'CAPECO'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
      *COL05-F
          05 ENC-TASA                       PIC X(05)                   00043800
                                            VALUE 'TASA'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ENC-CLUSTE                     PIC X(20)                   00043800
                                            VALUE 'CLUSTER'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
      *COL05-I
      *   05 ENC-CLUSID                     PIC X(20)                   00043800
          05 ENC-CLUSID                     PIC X(35)                   00043800
                                            VALUE 'CLUSTID'.
      *COL05-F

       01 REG-SALIDA.                                                   00043700
          05 FILLER                         PIC X(02) VALUE SPACES.     00043900
          05 SAL-TIPPRO                     PIC X(04).                  00043800
          05 FILLER                         PIC X(02) VALUE '|'.        00043900
          05 SAL-BURINI                     PIC ZZZ9B.                  00043800
          05 FILLER                         PIC X(02) VALUE '|'.        00043900
          05 SAL-BURFIN                     PIC ZZZ9B.                  00043800
          05 FILLER                         PIC X(02) VALUE '|'.        00043900
          05 SAL-DOMNOM                     PIC X(02).                  00043800
          05 FILLER                         PIC X(02) VALUE '|'.        00043900
          05 SAL-SITLAB                     PIC X(02).                  00043800
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 SAL-INGINI                     PIC ZZZZ9.9999.             00043800
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 SAL-INGFIN                     PIC ZZZZ9.9999.             00043800
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 SAL-MONINI                     PIC ZZZZ9.9999.             00043800
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 SAL-MONFIN                     PIC ZZZZ9.9999.             00043800
          05 FILLER                         PIC X(02) VALUE '|'.        00043900
          05 SAL-PLAINI                     PIC ZZZ9B.                  00043800
          05 FILLER                         PIC X(02) VALUE '|'.        00043900
          05 SAL-PLAFIN                     PIC ZZZ9B.                  00043800
          05 FILLER                         PIC X(02) VALUE '|'.        00043900
          05 SAL-EDAINI                     PIC ZZZ9B.                  00043800
          05 FILLER                         PIC X(02) VALUE '|'.        00043900
          05 SAL-EDAFIN                     PIC ZZZ9B.                  00043800
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 SAL-SEGMEN                     PIC ZZZZ9.                  00043800
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 SAL-COLECT                     PIC ZZZ9.                   00043800
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 SAL-GRIINI                     PIC ZZZZ9.9999.             00043800
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 SAL-GRIFIN                     PIC ZZZZ9.9999.             00043800
          05 FILLER                         PIC X(03) VALUE '|'.        00043900
          05 SAL-ESTVEH                     PIC X(04).                  00043800
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 SAL-PFIINI                     PIC ZZZZ9.9999.             00043800
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 SAL-PFIFIN                     PIC ZZZZ9.9999.             00043800
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 SAL-GAMINI                     PIC ZZZZ9.9999.             00043800
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 SAL-GAMFIN                     PIC ZZZZ9.9999.             00043800
          05 FILLER                         PIC X(03) VALUE '|'.        00043900
          05 SAL-TIPVEH                     PIC X(04).                  00043800
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
      *COL03-I
          05 FILLER                         PIC X(02) VALUE SPACES.     00043900
          05 SAL-CLTVLB                     PIC X(04).                  00043800
          05 FILLER                         PIC X(03) VALUE '|'.        00043900
          05 SAL-DESTLB                     PIC X(04).                  00043800
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
      *COL03-F
      *COL05-I
          05 SAL-VENTINI                    PIC ZZZZ9.9999.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 SAL-VENTFIN                    PIC ZZZZ9.9999.
          05 FILLER                         PIC X(03) VALUE '|'.        00043900
          05 SAL-TIPPERSO                   PIC X(05).
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 SAL-RATING                     PIC X(06).
          05 FILLER                         PIC X(03) VALUE '|'.        00043900
          05 SAL-RANRATING                  PIC X(05).
          05 FILLER                         PIC X(03) VALUE '|'.        00043900
          05 SAL-GARANTIA                   PIC X(03).
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 SAL-MONOPERINI                 PIC ZZZZ9.9999.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 SAL-MONOPERFIN                 PIC ZZZZ9.9999.
          05 FILLER                         PIC X(02) VALUE '|'.        00043900
          05 SAL-PE                         PIC Z9.99.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 SAL-RORC                       PIC Z9.99.
          05 FILLER                         PIC X(02) VALUE '|'.        00043900
          05 SAL-RAROEC                     PIC Z9.99.
          05 FILLER                         PIC X(02) VALUE '|'.        00043900
          05 SAL-CAPECON                    PIC Z9.99.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
      *COL05-F
          05 SAL-TASA                       PIC Z9.99.                  00043800
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 SAL-CLUSTE                     PIC X(20).                  00043800
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
      *COL05-I
      *   05 SAL-CLUSID                     PIC X(20).                  00043800
          05 SAL-CLUSID                     PIC X(35).                  00043800
      *COL05-F
      *                                                                 00044100
      ***************************************************************** 00044200
      *                    AUXILIARES DE REGISTRO ERRORES              *00044300
      ***************************************************************** 00044400
      *                                                                 00044500
       01 ENC-ERRORES.                                                  00044600
          05 EER-TIPPRO                     PIC X(06)                   00043800
                                            VALUE 'TIPPRO'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 EER-BURINI                     PIC X(06)                   00043800
                                            VALUE 'BR-IN '.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 EER-BURFIN                     PIC X(06)                   00043800
                                            VALUE 'BR-FI'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 EER-DOMNOM                     PIC X(03)                   00043800
                                            VALUE 'DNM'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 EER-SITLAB                     PIC X(03)                   00043800
                                            VALUE 'SLA'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 EER-INGINI                     PIC X(10)                   00043800
                                            VALUE 'IGR-INI '.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 EER-INGFIN                     PIC X(10)                   00043800
                                            VALUE 'IGR-FIN '.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 EER-MONINI                     PIC X(10)                   00043800
                                            VALUE 'MON-INI '.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 EER-MONFIN                     PIC X(10)                   00043800
                                            VALUE 'MON-FIN '.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 EER-PLAINI                     PIC X(06)                   00043800
                                            VALUE 'PZ-IN '.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 EER-PLAFIN                     PIC X(06)                   00043800
                                            VALUE 'PZ-FI'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 EER-EDAINI                     PIC X(06)                   00043800
                                            VALUE 'ED-IN '.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 EER-EDAFIN                     PIC X(06)                   00043800
                                            VALUE 'ED-FI'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 EER-SEGMEN                     PIC X(05)                   00043800
                                            VALUE 'SEGME'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 EER-COLECT                     PIC X(04)                   00043800
                                            VALUE 'CLTV'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 EER-GRIINI                     PIC X(10)                   00043800
                                            VALUE 'GRI-INI '.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 EER-GRIFIN                     PIC X(10)                   00043800
                                            VALUE 'GRI-FIN '.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 EER-ESTVEH                     PIC X(06)                   00043800
                                            VALUE 'ES-VH'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 EER-PFIINI                     PIC X(10)                   00043800
                                            VALUE '%FI-INI '.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 EER-PFIFIN                     PIC X(10)                   00043800
                                            VALUE '%FI-FIN '.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 EER-GAMINI                     PIC X(10)                   00043800
                                            VALUE 'GAM-INI '.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 EER-GAMFIN                     PIC X(10)                   00043800
                                            VALUE 'GAM-FIN '.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 EER-TIPVEH                     PIC X(06)                   00043800
                                            VALUE 'TP-VH'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
      *COL03-I
          05 EER-CLTVLB                     PIC X(06)                   00043800
                                            VALUE 'CLTVLB'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 EER-DESTLB                     PIC X(06)                   00043800
                                            VALUE 'DESTLB'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
      *COL03-F
      *COL05-I
          05 EER-VENTINI                    PIC X(10)
                                            VALUE 'VENTAS-INI'.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 EER-VENTFIN                    PIC X(10)
                                            VALUE 'VENTAS-FIN'.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 EER-TIPPERSO                   PIC X(07)
                                            VALUE 'TIP-PER'.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 EER-RATING                     PIC X(06)
                                            VALUE 'RATING'.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 EER-RANRATING                  PIC X(07)
                                            VALUE 'RANG-RA'.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 EER-GARANTIA                   PIC X(05)
                                            VALUE 'GARAN'.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 EER-MONOPERINI                 PIC X(10)
                                            VALUE 'MONOPE-INI'.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 EER-MONOPERFIN                 PIC X(10)
                                            VALUE 'MONOPE-FIN'.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 EER-PE                         PIC X(06)
                                            VALUE 'PERDES'.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 EER-RORC                       PIC X(05)
                                            VALUE 'RORC '.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 EER-RAROEC                     PIC X(06)
                                            VALUE 'RAROEC'.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 EER-CAPECON                    PIC X(06)
                                            VALUE 'CAPECO'.
          05 FILLER                         PIC X(01) VALUE '|'.
      *COL05-F
          05 EER-TASA                       PIC X(05)                   00043800
                                            VALUE 'TASA'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 EER-CLUSTE                     PIC X(20)                   00043800
                                            VALUE 'CLUSTER'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 EER-DETALL                     PIC X(36)                   00043800
                                            VALUE 'DETALLE'.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 EER-TABLA                      PIC X(08)                   00043800
                                            VALUE 'TABLA '.
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 EER-SQL                        PIC X(08)                   00043800
                                            VALUE 'ERR SQL'.


       01 REG-ERRORES.                                                  00044600
          05 FILLER                         PIC X(02) VALUE SPACES.     00043900
          05 ERR-TIPPRO                     PIC X(04).                  00043800
          05 FILLER                         PIC X(02) VALUE '|'.        00043900
          05 ERR-BURINI                     PIC ZZZ9B.                  00043800
          05 FILLER                         PIC X(02) VALUE '|'.        00043900
          05 ERR-BURFIN                     PIC ZZZ9B.                  00043800
          05 FILLER                         PIC X(02) VALUE '|'.        00043900
          05 ERR-DOMNOM                     PIC X(02).                  00043800
          05 FILLER                         PIC X(02) VALUE '|'.        00043900
          05 ERR-SITLAB                     PIC X(02).                  00043800
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ERR-INGINI                     PIC ZZZZ9.9999.             00043800
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ERR-INGFIN                     PIC ZZZZ9.9999.             00043800
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ERR-MONINI                     PIC ZZZZ9.9999.             00043800
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ERR-MONFIN                     PIC ZZZZ9.9999.             00043800
          05 FILLER                         PIC X(02) VALUE '|'.        00043900
          05 ERR-PLAINI                     PIC ZZZ9B.                  00043800
          05 FILLER                         PIC X(02) VALUE '|'.        00043900
          05 ERR-PLAFIN                     PIC ZZZ9B.                  00043800
          05 FILLER                         PIC X(02) VALUE '|'.        00043900
          05 ERR-EDAINI                     PIC ZZZ9B.                  00043800
          05 FILLER                         PIC X(02) VALUE '|'.        00043900
          05 ERR-EDAFIN                     PIC ZZZ9B.                  00043800
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ERR-SEGMEN                     PIC ZZZZ9.                  00043800
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ERR-COLECT                     PIC ZZZ9.                   00043800
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ERR-GRIINI                     PIC ZZZZ9.9999.             00043800
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ERR-GRIFIN                     PIC ZZZZ9.9999.             00043800
          05 FILLER                         PIC X(03) VALUE '|'.        00043900
          05 ERR-ESTVEH                     PIC X(04).                  00043800
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ERR-PFIINI                     PIC ZZZZ9.9999.             00043800
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ERR-PFIFIN                     PIC ZZZZ9.9999.             00043800
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ERR-GAMINI                     PIC ZZZZ9.9999.             00043800
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ERR-GAMFIN                     PIC ZZZZ9.9999.             00043800
          05 FILLER                         PIC X(03) VALUE '|'.        00043900
          05 ERR-TIPVEH                     PIC X(04).                  00043800
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
      *COL03-I
          05 FILLER                         PIC X(02) VALUE SPACES.     00043900
          05 ERR-CLTVLB                     PIC X(04).                  00043800
          05 FILLER                         PIC X(03) VALUE '|'.        00043900
          05 ERR-DESTLB                     PIC X(04).                  00043800
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
      *COL03-F
      *COL05-I
          05 ERR-VENTINI                    PIC ZZZZ9.9999.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 ERR-VENTFIN                    PIC ZZZZ9.9999.
          05 FILLER                         PIC X(03) VALUE '|'.
          05 ERR-TIPPERSO                   PIC X(05).
          05 FILLER                         PIC X(01) VALUE '|'.
          05 ERR-RATING                     PIC X(06).
          05 FILLER                         PIC X(03) VALUE '|'.
          05 ERR-RANRATING                  PIC X(05).
          05 FILLER                         PIC X(03) VALUE '|'.
          05 ERR-GARANTIA                   PIC X(03).
          05 FILLER                         PIC X(01) VALUE '|'.
          05 ERR-MONOPERINI                 PIC ZZZZ9.9999.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 ERR-MONOPERFIN                 PIC ZZZZ9.9999.
          05 FILLER                         PIC X(02) VALUE '|'.
          05 ERR-PE                         PIC Z9.99.
          05 FILLER                         PIC X(01) VALUE '|'.
          05 ERR-RORC                       PIC Z9.99.
          05 FILLER                         PIC X(02) VALUE '|'.
          05 ERR-RAROEC                     PIC Z9.99.
          05 FILLER                         PIC X(02) VALUE '|'.
          05 ERR-CAPECON                    PIC Z9.99.
          05 FILLER                         PIC X(01) VALUE '|'.
      *COL05-F
          05 ERR-TASA                       PIC Z9.99.                  00043800
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ERR-CLUSTE                     PIC X(20).                  00043800
          05 FILLER                         PIC X(01) VALUE '|'.        00043900
          05 ERR-DETALLE                    PIC X(36).                  00043800
          05 FILLER                         PIC X(01) VALUE '|'.        00045200
          05 ERR-TABLERR                    PIC X(08).                  00045300
          05 FILLER                         PIC X(01) VALUE '|'.        00045400
          05 ERR-SQLCODE                    PIC 9(03).                  00045700
      *                                                                 00050600
      ******************************************************************00039700
      * DECLARAR CURSOR DE LA TABLA UGDTNRA                            *00039800
      ******************************************************************00039900
           EXEC SQL                                                     00040000
              DECLARE  CURSOR-NRA CURSOR FOR                            00040100
               SELECT  NRA_TIPO_PRODUCTO,
                       NRA_VARIABLE,
                       NRA_CONSECUTIVO,
      *COL07-I
                       NRA_FECHA_INI,
      *COL07-F
                       NRA_RANGO_INI,
                       NRA_RANGO_FIN,
                       NRA_IND_DOM_NOMINA,
                       NRA_SITUA_LABORAL,
                       NRA_MONTO_INICIAL,
                       NRA_MONTO_FINAL,
                       NRA_SEGMENTO,
                       NRA_IND_CLIENTE_VIP,
                       NRA_RANGO_RIESGO_INI,
                       NRA_RANGO_RIESGO_FIN,
                       NRA_IND_ESTADO_VEH,
                       NRA_IND_TIPO_VEH,
                       NRA_CLAVE_ID,
                       NRA_CLUSTER,
      *COL05-I
      *                NRA_ESTADO
                       NRA_ESTADO,
                       NRA_RATING,
                       NRA_RANGO_RATING,
                       NRA_GARANTIA,
                       NRA_PORCENTA
      *COL05-F

               FROM  UGDTNRA
               WHERE NRA_TIPO_PRODUCTO = :NRA-TIPO-PRODUCTO AND
                     NRA_VARIABLE      = :NRA-VARIABLE AND
                     NRA_ESTADO        = :CTE-VS
            END-EXEC.
      *
      * -------------------------------------------------------------- *
      * COL03-I
           EXEC SQL                                                     00040000
              DECLARE  CURSOR-NR1 CURSOR FOR                            00040100
               SELECT  NRA_TIPO_PRODUCTO,
                       NRA_VARIABLE,
                       NRA_CONSECUTIVO,
                       NRA_CLAVE_ID
               FROM  UGDTNRA
               WHERE NRA_VARIABLE      = :CTE-90 AND
                     NRA_ESTADO        = :CTE-VS
            END-EXEC.
      *
      * COL03-F
      ******************************************************************00064300
      *                   L I N K A G E   S E C T I O N                *00064400
      ******************************************************************00064500
      *                                                                 00064600
       LINKAGE SECTION.                                                 00064700
          01 REG-PARM.                                                  00064800
             05 LK-PARM-LONG   PIC X(02).                               00064900
             05 LK-PARM-FECDIA PIC X(10).
      *COL02-I
             05 LK-FILLER      PIC X(01).                               00064900
             05 LK-PARM-TIPO   PIC X(02).
             05 LK-FILLER      PIC X(01).                               00064900
             05 LK-PARM-COMMIT PIC X(04).                               00065000
      *COL02-F
      *                                                                 00065100
      ******************************************************************00065200
      *                P R O C E D U R E   D I V I S I O N             *00065300
      ******************************************************************00065400
      *                                                                 00065500
       PROCEDURE DIVISION USING REG-PARM.                               00065600
      *                                                                 00065700
                                                                        00065900
           PERFORM 1-INICIO-PROGRAMA.                                   00066100
      *                                                                 00066200
      * COL03-I
      *COL10-I
      *     IF WS-PARM-TIPO = '01'
      *        PERFORM 9999-UPDATECLUSTER
      *     END-IF
      *COL10-F
      * COL03-F
           PERFORM 2-PROCESO-PROGRAMA UNTIL SI-FIN-NRA.                 00066300
      *                                                                 00066400
COL10 *    PERFORM 000500-HACER-COMMIT                                  00066500
      *                                                                 00066600
           PERFORM 3-FINAL.                                             00066700
      *                                                                 00066800
           STOP RUN.                                                    00066900
      *                                                                 00067000
      *                                                                 00070300
      ******************************************************************00070400
      *                       1-INICIO-PROGRAMA                        *00070500
      ******************************************************************00070600
      *                                                                 00070700
       1-INICIO-PROGRAMA.                                               00070800
      *                                                                 00070900
           MOVE 0                             TO CONT-NRA               00071000
                                                 CONT-GRABADOS          00071100
                                                 CONT-ACTUALIZA         00071100
                                                 CONT-ERRORES           00071200
                                                 CONT-BORRADOS
      *COL08-I
           MOVE ZEROS                         TO CONT-CSC
           MOVE SPACES                        TO WS-TPROD-AUX
COL10                                            WS-TIPO-PRODUCTO
      *COL08-F
           SET NO-EXIS-NRA                    TO TRUE                   00072400
           SET NO-FIN-NRA                     TO TRUE                   00072400
           SET SI-CORRECTO                    TO TRUE                   00072400
      *                                                                 00072500
           MOVE LK-PARM-FECDIA                TO W-FECHA-DIA            00072600
           MOVE LK-PARM-COMMIT                TO WS-PARM-COMMIT         00072600
      *COL02-I
           MOVE LK-PARM-TIPO                  TO WS-PARM-TIPO           00072600
      *COL02-F
           PERFORM 11-ABRIR-ARCHIVOS                                    00072700
           PERFORM 12-CARGAR-FECHA                                      00072800
      *COL10-I
           PERFORM 1A-LEER-EUGDTNRA                                     00072900
      *COL10-F
           PERFORM 13-LEER-EUGDNRA.                                     00072900
      *                                                                 00073000
      ******************************************************************00073100
      *                       11-ABRIR-ARCHIVOS                         00073200
      ******************************************************************00073300
      *                                                                 00073400
       11-ABRIR-ARCHIVOS.                                               00073500
      *                                                                 00073600
           OPEN INPUT EUGDNRA                                           00073700
           IF (W-ESTADO NOT = '00' AND NOT = '97')                      00073800
              DISPLAY ' ERROR ABRIENDO EL ARCHIVO EUGDNRA ' W-ESTADO    00073900
              MOVE 12 TO RETURN-CODE                                    00074000
              PERFORM 3-FINAL                                           00074100
           END-IF                                                       00074200
      *COL10-I
           OPEN INPUT EUGDTNRA                                          00073700
           IF (W-ESTADO NOT = '00' AND NOT = '97')                      00073800
              CLOSE EUGDNRA
              DISPLAY ' ERROR ABRIENDO EL ARCHIVO EUGDTNRA ' W-ESTADO   00073900
              MOVE 12 TO RETURN-CODE                                    00074000
              PERFORM 3-FINAL                                           00074100
           END-IF                                                       00074200
      *
           OPEN OUTPUT SUGDTNRA                                         00074300
           IF (W-ESTADO NOT = '00' AND NOT = '97')                      00074400
              CLOSE EUGDNRA EUGDTNRA
              DISPLAY ' ERROR ABRIENDO SUGDTNRA' W-ESTADO               00074500
              MOVE 12 TO RETURN-CODE                                    00074600
              PERFORM 3-FINAL                                           00074700
           END-IF                                                       00074800
      *COL10-F
           OPEN OUTPUT SALIDA                                           00074300
           IF (W-ESTADO NOT = '00' AND NOT = '97')                      00074400
              DISPLAY ' ERROR ABRIENDO ERRORES' W-ESTADO                00074500
              MOVE 12 TO RETURN-CODE                                    00074600
              PERFORM 3-FINAL                                           00074700
           END-IF                                                       00074800
           OPEN OUTPUT ERRORES                                          00074900
           IF (W-ESTADO NOT = '00' AND NOT = '97')                      00075000
              DISPLAY ' ERROR ABRIENDO ERRORES' W-ESTADO                00075100
              MOVE 12 TO RETURN-CODE                                    00075200
              PERFORM 3-FINAL                                           00075300
           END-IF                                                       00075400
           PERFORM 14-ESC-ENCAB-SALIDA
           PERFORM 15-ESC-ENCAB-ERROR.
      *                                                                 00073600
      *                                                                 00076390
      ******************************************************************00076400
      *                       12-CARGAR-FECHA                           00076500
      ******************************************************************00076600
      *                                                                 00076700
       12-CARGAR-FECHA.                                                 00076800
      *                                                                 00076900
           ACCEPT W-FECHA-HOY                    FROM  DATE             00077000
           MOVE   W-ANO-HOY                      TO W-ANO-DIS           00077100
           MOVE   W-MES-HOY                      TO W-MES-DIS           00077200
           MOVE   W-DIA-HOY                      TO W-DIA-DIS           00077300
           IF W-ANO-HOY > 90                                            00077400
              MOVE '19'                          TO W-FECHA-DIS(1:2)    00077500
           ELSE                                                         00077600
              MOVE '20'                          TO W-FECHA-DIS(1:2)    00077700
           END-IF.                                                      00077800
      *                                                                 00077900
      *---------- Carga La Hora Del Sistema ----------*                 00078100
           ACCEPT W-HORA-HOY FROM TIME                                  00078200
           MOVE W-HH-HOY        TO W-HH-DIS                             00078300
           MOVE W-MM-HOY        TO W-MM-DIS                             00078400
           MOVE W-SS-HOY        TO W-SS-DIS                             00078500
           MOVE W-MS-HOY        TO W-MS-DIS.                            00078600
      *                                                                 00078700
      ******************************************************************00078800
      *                      13-LEER-EUGDNRA                            00078900
      ******************************************************************00079000
      *                                                                 00079100
       13-LEER-EUGDNRA.                                                 00079200
                                                                        00079300
           READ EUGDNRA                                                 00079400
             AT END SET SI-FIN-NRA               TO TRUE                00079500
           END-READ                                                     00079600
                                                                        00079700
           IF STATUS-OK                                                 00079800
              ADD 1                              TO CONT-NRA            00079900
                                                    WS-CONT-COMMIT      00080000
              PERFORM  23-MOVER-DATA
           ELSE                                                         00082000
              IF STATUS-10                                              00082100
                 SET SI-FIN-NRA TO TRUE                                 00082200
              ELSE                                                      00082300
                 DISPLAY 'ERROR LEYENDO EUGDNRA' W-ESTADO               00082400
                 MOVE 12 TO RETURN-CODE                                 00082500
                 PERFORM 3-FINAL                                        00082600
              END-IF                                                    00082700
           END-IF.                                                      00082800
      *                                                                 00078700
      *COL10-I                                                          00078700
      ******************************************************************00078800
      *                      1A-LEER-EUGDTNRA                           00078900
      ******************************************************************00079000
      *                                                                 00079100
       1A-LEER-EUGDTNRA.                                                00079200
                                                                        00079300
           READ EUGDTNRA                                                00079400
             AT END SET SI-FIN-TNRA              TO TRUE                00079500
           END-READ                                                     00079600
                                                                        00079700
           IF STATUS-OK                                                 00079800
              ADD 1                              TO CONT-TNRA           00079900
           ELSE                                                         00082000
              IF STATUS-10                                              00082100
                 SET SI-FIN-TNRA                 TO TRUE                00082200
              ELSE                                                      00082300
                 DISPLAY 'ERROR LEYENDO EUGDTNRA' W-ESTADO              00082400
                 MOVE 12 TO RETURN-CODE                                 00082500
                 PERFORM 3-FINAL                                        00082600
              END-IF                                                    00082700
           END-IF.                                                      00082800
      *                                                                 00078700
      ******************************************************************00078800
      *                      14-ESC-ENCAB-SALIDA                        00078900
      ******************************************************************00079000
      *                                                                 00079100
       14-ESC-ENCAB-SALIDA.                                             00079200
      *                                                                 00078700
           WRITE REG-SAL  FROM  REG-ENCABE  END-WRITE
           MOVE  ALL  '-'     TO  ENC-TIPPRO
                                  ENC-BURINI
                                  ENC-BURFIN
                                  ENC-SITLAB
                                  ENC-DOMNOM
                                  ENC-INGINI
                                  ENC-INGFIN
                                  ENC-MONINI
                                  ENC-MONFIN
                                  ENC-PLAINI
                                  ENC-PLAFIN
                                  ENC-EDAINI
                                  ENC-EDAFIN
                                  ENC-SEGMEN
                                  ENC-COLECT
                                  ENC-GRIINI
                                  ENC-GRIFIN
                                  ENC-ESTVEH
                                  ENC-PFIINI
                                  ENC-PFIINI
                                  ENC-GAMINI
                                  ENC-GAMFIN
                                  ENC-TIPVEH
      *COL03-I
                                  ENC-CLTVLB
                                  ENC-DESTLB
      *COL03-F
      *COL05-I
                                  ENC-VENTINI
                                  ENC-VENTFIN
                                  ENC-TIPPERSO
                                  ENC-RATING
                                  ENC-RANRATING
                                  ENC-GARANTIA
                                  ENC-MONOPERINI
                                  ENC-MONOPERFIN
                                  ENC-PE
                                  ENC-RORC
                                  ENC-RAROEC
                                  ENC-CAPECON
      *COL05-F
                                  ENC-TASA
                                  ENC-CLUSTE
                                  ENC-CLUSID
           WRITE REG-SAL  FROM  REG-ENCABE  END-WRITE.
      *                                                                 00078700
      ******************************************************************00078800
      *                      15-ESC-ENCAB-ERROR                         00078900
      ******************************************************************00079000
      *                                                                 00079100
       15-ESC-ENCAB-ERROR.                                              00079200
      *                                                                 00082900
           WRITE REG-ERR  FROM  ENC-ERRORES END-WRITE
           MOVE  ALL  '-'     TO  EER-TIPPRO
                                  EER-BURINI
                                  EER-BURFIN
                                  EER-SITLAB
                                  EER-DOMNOM
                                  EER-INGINI
                                  EER-INGFIN
                                  EER-MONINI
                                  EER-MONFIN
                                  EER-PLAINI
                                  EER-PLAFIN
                                  EER-EDAINI
                                  EER-EDAFIN
                                  EER-SEGMEN
                                  EER-COLECT
                                  EER-GRIINI
                                  EER-GRIFIN
                                  EER-ESTVEH
                                  EER-PFIINI
                                  EER-PFIFIN
                                  EER-GAMINI
                                  EER-GAMFIN
                                  EER-TIPVEH
      *COL03-I
                                  ERR-CLTVLB
                                  ERR-DESTLB
      *COL03-F
      *COL05-I
                                  EER-VENTINI
                                  EER-VENTFIN
                                  EER-TIPPERSO
                                  EER-RATING
                                  EER-RANRATING
                                  EER-GARANTIA
                                  EER-MONOPERINI
                                  EER-MONOPERFIN
                                  EER-PE
                                  EER-RORC
                                  EER-RAROEC
                                  EER-CAPECON
      *COL05-F
                                  EER-TASA
                                  EER-CLUSTE
                                  EER-DETALL
                                  EER-TABLA
                                  EER-SQL
           WRITE REG-ERR  FROM  ENC-ERRORES END-WRITE.
      *                                                                 00083000
      ******************************************************************00083000
      *                       2-PROCESO-PROGRAMA                       *00083100
      ******************************************************************00083200
      *                                                                 00083300
       2-PROCESO-PROGRAMA.                                              00083400
      *                                                                 00083500
      *COL02-I
      *COL10-I
      *    SET NO-MODI-VAR                TO TRUE
      *    EVALUATE WS-PARM-TIPO
      *       WHEN '01'  SET NO-MODI-VAR  TO TRUE
      *       WHEN '02'  SET SI-MODI-VAR  TO TRUE
      *    END-EVALUATE
      *COL02-F
      *COL08-I
      *    MOVE FUNCTION UPPER-CASE(ENT-CLUSTER) TO WS-CLUSTER
      *    MOVE WS-CLUSTER                       TO ENT-CLUSTER
      *    IF NOT SI-MODI-VAR
      *COL08-F
      *COL08-I
      *    ELSE
      *SE INFORMA LA VARIABLE A DAR DE BAJA
      *      MOVE ENT-TIPO-PERSONA        TO WS-VARIABLE
      *      MOVE ENT-SEGMENTO            TO WS-CONSEC-A
      *      MOVE ENT-COLECTIVO           TO WS-CONSEC-B
      *      MOVE ZEROS                   TO CONT-CSC
      *      MOVE WS-CONSEC-R             TO CONT-CSC
      *      MOVE ENT-INGRESOS-INI        TO WS-FECHA-INI
      *      PERFORM 26-UPDATE-UGDTNRA-VAR
      *    END-IF
      *COL08-F
      *    IF WS-CONT-COMMIT = WS-PARM-COMMIT                               0008
      *       PERFORM 000500-HACER-COMMIT                                   0008
      *       MOVE ZEROS TO WS-CONT-COMMIT                                  0008
      *    END-IF                                                           0008
           IF WS-TIPO-PRODUCTO NOT EQUAL ENT-TIPO-PRODUCTO
              MOVE ENT-TIPO-PRODUCTO        TO WS-TIPO-PRODUCTO
              PERFORM 14-INITIALIZE-TABLA                               00072900
              PERFORM 1B-CARGA-TABLA UNTIL (SI-FIN-TNRA OR
                    ENRA-TIPO-PRODUCTO NOT EQUAL ENT-TIPO-PRODUCTO)
           END-IF
           PERFORM 20-VALIDA-RENGLON
      *COL10-F
           PERFORM 13-LEER-EUGDNRA.                                     00087400
      *                                                                 00087500
      *                                                                 00174700
      ******************************************************************00174900
      *                 999999-ROLLBACK.                               *00175000
      *    SI ABENDA DESPUES DE HABER HECHO OPERACIONES DE UPDATE,     *00175100
      *    INSERT O DELETE, RECONSTRUYE LAS TABLASA LA SITUACION       *00175200
      *    ANTERIOR A LA EJECUCION DEL PROGRAMA.                       *00175300
      ******************************************************************00175400
      *COL10-I
      *999999-ROLLBACK.                                                 00175500
      *                                                                 00175600
      *          EXEC SQL                                               00175700
      *                  ROLLBACK                                       00175800
      *          END-EXEC.                                              00175900
      *                                                                 00176000
      *    MOVE SQLCODE                            TO DB2-RETURN-CDE    00176100
      *                                                                 00176200
      *    IF DB2-OK                                                    00176300
      *       DISPLAY 'ROLLBACK EJECUTADO CORRECTAMENTE'                00176400
      *       SUBTRACT 1                         FROM CONT-GRABADOS     00176500
      *       CONTINUE                                                  00176600
      *    ELSE                                                         00176700
      *       DISPLAY 'ERROR EJECUTANDO COMMIT ROLLBACK'                00176800
      *       PERFORM 999999-ROLLBACK                                   00176900
      *    END-IF.                                                      00177000
      *                                                                 00177100
      *----------------------------------------------------------------*00177200
      *                      000500-HACER-COMMIT                       *00177300
      *----------------------------------------------------------------*00177400
      *                                                                 00177500
      *000500-HACER-COMMIT.                                             00177600
      *                                                                 00177700
      *    EXEC SQL                                                     00177800
      *         COMMIT                                                  00177900
      *    END-EXEC                                                     00178000
      *                                                                 00178100
      *    MOVE SQLCODE            TO   DB2-RETURN-CDE                  00178200
      *    IF DB2-OK                                                    00178300
      *       CONTINUE                                                  00178400
      *    ELSE                                                         00178500
      *       DISPLAY 'ERROR EJECUTANDO COMMIT UG4CRAR2'                00178600
      *    END-IF.                                                      00178800
      *COL10-F
      *                                                                 00178900
      ******************************************************************00179000
      *                   20-VALIDA-RENGLON                             00179100
      ******************************************************************00179200
      *                                                                 00179300
       20-VALIDA-RENGLON.                                               00178900
      *                                                                 00178900
           SET SI-CORRECTO  TO TRUE                                     00178900
      *COL10-I
           MOVE ZEROS               TO WS-CLAVEID
           IF SI-VAR-01
              PERFORM 21-VALIDA-BURO
              MOVE WS-VAR-CLUSTER   TO WS-CLAVEID(1:1)
           END-IF
           IF SI-VAR-02
              PERFORM 21-VALIDA-NOMINA
              MOVE WS-VAR-CLUSTER   TO WS-CLAVEID(2:1)
           END-IF
           IF SI-VAR-03
              PERFORM 21-VALIDA-SITU-LAB
              MOVE WS-VAR-CLUSTER   TO WS-CLAVEID(3:1)
           END-IF
           IF SI-VAR-04
              PERFORM 21-VALIDA-INGRESOS
              MOVE WS-VAR-CLUSTER   TO WS-CLAVEID(4:1)
           END-IF
           IF SI-VAR-05
              PERFORM 21-VALIDA-MONTO
              MOVE WS-VAR-CLUSTER   TO WS-CLAVEID(5:1)
           END-IF
           IF SI-VAR-06
              PERFORM 21-VALIDA-PLAZO
              MOVE WS-VAR-CLUSTER   TO WS-CLAVEID(6:1)
           END-IF
           IF SI-VAR-07
              PERFORM 21-VALIDA-EDAD
              MOVE WS-VAR-CLUSTER   TO WS-CLAVEID(7:1)
           END-IF
           IF SI-VAR-08
              PERFORM 21-VALIDA-SEGMENTO
              MOVE WS-VAR-CLUSTER   TO WS-CLAVEID(8:1)
           END-IF
           IF SI-VAR-09
              PERFORM 21-VALIDA-COLECTIVO
              MOVE WS-VAR-CLUSTER   TO WS-CLAVEID(9:1)
           END-IF
           IF SI-VAR-10
              PERFORM 21-VALIDA-GR-RIESGO
              MOVE WS-VAR-CLUSTER   TO WS-CLAVEID(10:1)
           END-IF
           IF SI-VAR-11
              PERFORM 21-VALIDA-ESTA-VEH
              MOVE WS-VAR-CLUSTER   TO WS-CLAVEID(11:1)
           END-IF
           IF SI-VAR-12
              PERFORM 21-VALIDA-PORC-FINANC
              MOVE WS-VAR-CLUSTER   TO WS-CLAVEID(12:1)
           END-IF
           IF SI-VAR-13
              PERFORM 21-VALIDA-GAMA-VEH
              MOVE WS-VAR-CLUSTER   TO WS-CLAVEID(13:1)
           END-IF
           IF SI-VAR-14
              PERFORM 21-VALIDA-TIPO-VEH
              MOVE WS-VAR-CLUSTER   TO WS-CLAVEID(14:1)
           END-IF
      *    PERFORM 21-VALIDA-BURO
      *    PERFORM 21-VALIDA-NOMINA
      *    PERFORM 21-VALIDA-SITU-LAB
      *    PERFORM 21-VALIDA-INGRESOS
      *    PERFORM 21-VALIDA-MONTO
      *    PERFORM 21-VALIDA-PLAZO
      *    PERFORM 21-VALIDA-EDAD
      *    PERFORM 21-VALIDA-SEGMENTO
      *    PERFORM 21-VALIDA-COLECTIVO
      *    PERFORM 21-VALIDA-GR-RIESGO
      *    PERFORM 21-VALIDA-ESTA-VEH
      *    PERFORM 21-VALIDA-PORC-FINANC
      *    PERFORM 21-VALIDA-GAMA-VEH
      *    PERFORM 21-VALIDA-TIPO-VEH
      *COL10-F
      *COL03-I
           IF ENT-CLTVLB = ZEROS OR ENT-CLTVLB = SPACES OR
              ENT-CLTVLB = 099
              MOVE 99 TO ENT-CLTVLB
           END-IF
           IF ENT-DESTLB = ZEROS OR ENT-DESTLB = SPACES OR
              ENT-DESTLB = 099
              MOVE 99 TO ENT-DESTLB
           END-IF
      *COL10-I
           IF SI-VAR-16
              PERFORM 21-VALIDA-COLECTIVO-LB
              MOVE WS-VAR-CLUSTER   TO WS-CLAVEID(16:1)
           END-IF
           IF SI-VAR-17
              PERFORM 21-VALIDA-DESTINO-LB
              MOVE WS-VAR-CLUSTER   TO WS-CLAVEID(17:1)
           END-IF
      *    PERFORM 21-VALIDA-COLECTIVO-LB
      *    PERFORM 21-VALIDA-DESTINO-LB
      *COL10-F
      *COL03-F
      *COL05-I
           IF ENT-TIPO-PRODUCTO = 'C'
      *COL10-I
              IF SI-VAR-18
                 PERFORM 21-VALIDA-VENTAS-COMER
                 MOVE WS-VAR-CLUSTER   TO WS-CLAVEID(18:1)
              END-IF
              IF SI-VAR-19
                 PERFORM 21-VALIDA-TIP-PER-COMER
                 MOVE WS-VAR-CLUSTER   TO WS-CLAVEID(19:1)
              END-IF
              IF SI-VAR-20
                 PERFORM 21-VALIDA-RATING-COMER
                 MOVE WS-VAR-CLUSTER   TO WS-CLAVEID(20:1)
              END-IF
              IF SI-VAR-21
                 PERFORM 21-VALIDA-RANG-RATIN-COMER
                 MOVE WS-VAR-CLUSTER   TO WS-CLAVEID(21:1)
              END-IF
              IF SI-VAR-22
                 PERFORM 21-VALIDA-GARANTIA-COMER
                 MOVE WS-VAR-CLUSTER   TO WS-CLAVEID(22:1)
              END-IF
              IF SI-VAR-23
                 PERFORM 21-VALIDA-MON-OPER-COMER
                 MOVE WS-VAR-CLUSTER   TO WS-CLAVEID(23:1)
              END-IF
      *       PERFORM 21-VALIDA-VENTAS-COMER
      *       PERFORM 21-VALIDA-TIP-PER-COMER
      *       PERFORM 21-VALIDA-RATING-COMER
      *       PERFORM 21-VALIDA-RANG-RATIN-COMER
      *       PERFORM 21-VALIDA-GARANTIA-COMER
      *       PERFORM 21-VALIDA-MON-OPER-COMER
      *COL10-F
           END-IF
      *COL05-F
           PERFORM 22-VALIDA-DATOS
           IF NO-CORRECTO
              CONTINUE
           ELSE
      *COL03-I
      *       MOVE WS-CLAVEID (1:15)        TO SAL-CLUSID
      *COL05-I
      *       MOVE WS-CLAVEID (1:17)        TO SAL-CLUSID
              MOVE WS-CLAVEID (1:23)        TO SAL-CLUSID
      *COL05-F
      *COL03-F
              SET NO-EXIS-NRA               TO TRUE
              MOVE CTE-90                   TO WS-VARIABLE
      *COL10-I
              PERFORM 27-INSERT-UGDTNRA
      *       PERFORM 24-CURSOR-UGDTNRA
      *       IF SI-EXIS-NRA
      *          PERFORM 26-UPDATE-UGDTNRA
      *       ELSE
      *COL02-I
      *          IF NO-MODI-VAR AND ENT-CLUSTER (1:2) NOT EQUAL CTE-BA
      *COL02-F
      *COL08-I
      *          MOVE ZEROS                 TO CONT-CSC
      *COL08-F
      *          MOVE CTE-90                TO WS-VARIABLE
      *COL08-I
      *          PERFORM 28-VALIDA-UGDTNRA
      *COL08-F
      *          PERFORM 27-INSERT-UGDTNRA
      *COL02-I
      *          END-IF
      *COL02-F
      *       END-IF
      *COL10-F
           END-IF.
      *
      *----------------------------------------------------------------*
      *                    21-VALIDA-BURO                              *
      *----------------------------------------------------------------*
      *
       21-VALIDA-BURO.

      *COL05-I
      *COL06-I
      *      SET SI-CORRECTO                TO TRUE                     00178900
      *COL06-F
      *COL05-F
             MOVE SPACES                    TO ERR-DETALLE
             IF ENT-BURO-INI  IS NOT NUMERIC
                SET NO-CORRECTO             TO TRUE
                MOVE 'BURO INICIAL DEBE SER NUMERICO'
                                            TO ERR-DETALLE
                PERFORM 30-ESCRIBIR-RECHAZOS
             END-IF

             IF ENT-BURO-INI         < 0
                SET NO-CORRECTO             TO TRUE
                MOVE 'BURO INICIAL DEBE SER MAYOR A 0'
                                            TO ERR-DETALLE
                PERFORM 30-ESCRIBIR-RECHAZOS
             END-IF

             IF ENT-BURO-FIN         IS NOT NUMERIC
                SET NO-CORRECTO             TO TRUE
                MOVE 'BURO FINAL DEBE SER NUMERICO'
                                            TO ERR-DETALLE
                PERFORM 30-ESCRIBIR-RECHAZOS
             END-IF

             IF ENT-BURO-INI = ZEROS AND
                ENT-BURO-FIN = ZEROS
                CONTINUE
             ELSE
               IF (ENT-BURO-INI        >= ENT-BURO-FIN) OR
                  (ENT-BURO-FIN        <= 0)
                  SET NO-CORRECTO             TO TRUE
                  MOVE 'BURO FINAL <= BURO INICIAL '
                                              TO ERR-DETALLE
                  PERFORM 30-ESCRIBIR-RECHAZOS
               END-IF
             END-IF
             IF SI-CORRECTO
                MOVE ENT-BURO-INI           TO WS-RANGO-INI
                MOVE ENT-BURO-FIN           TO WS-RANGO-FIN
                MOVE CTE-01                 TO WS-VARIABLE
                PERFORM 24-CURSOR-UGDTNRA
             END-IF.
      *
      *----------------------------------------------------------------*
      *                    21-VALIDA-NOMINA                            *
      *----------------------------------------------------------------*
      *
       21-VALIDA-NOMINA.

      *COL05-I
      *COL06-I
      *      SET SI-CORRECTO                TO TRUE                     00178900
      *COL06-F
      *COL05-F
             MOVE SPACES                    TO ERR-DETALLE
             IF ENT-DOM-NOMINA       NOT EQUAL 'S' AND 'N' AND ' '
                SET NO-CORRECTO             TO TRUE
                MOVE 'DOMICILIA NOMINA DEBE SER S/N'
                                            TO ERR-DETALLE
                PERFORM 30-ESCRIBIR-RECHAZOS
             ELSE
                MOVE CTE-02                 TO WS-VARIABLE
                PERFORM 24-CURSOR-UGDTNRA
             END-IF.
      *
      *----------------------------------------------------------------*
      *                    21-VALIDA-SITU-LAB                          *
      *----------------------------------------------------------------*
      *
       21-VALIDA-SITU-LAB.

      *COL05-I
      *COL06-I
      *      SET SI-CORRECTO                TO TRUE                     00178900
      *COL06-F
      *COL05-F
             MOVE SPACES                    TO ERR-DETALLE
             IF ENT-SIT-LABORAL      NOT EQUAL '1' AND '2' AND '3'
                                                 AND '4' AND '5'
      *COL11-I
                                                 AND '6'
      *COL11-F
                                                 AND ' '
                SET NO-CORRECTO             TO TRUE
      *COL11-I
      *         MOVE 'SITUACION LABORAL DEBE SER 1/2/3/4/5'
                MOVE 'SITUACION LABO. DEBE SER 1/2/3/4/5/6'
      *COL11-F
                                            TO ERR-DETALLE
                PERFORM 30-ESCRIBIR-RECHAZOS
             ELSE
                MOVE CTE-03                 TO WS-VARIABLE
                PERFORM 24-CURSOR-UGDTNRA
             END-IF.
      *
      *----------------------------------------------------------------*
      *                    21-VALIDA-INGRESOS                          *
      *----------------------------------------------------------------*
      *
       21-VALIDA-INGRESOS.

      *COL05-I
      *COL06-I
      *      SET SI-CORRECTO                TO TRUE                     00178900
      *COL06-F
      *COL05-F
             MOVE SPACES                    TO ERR-DETALLE
                                               WS-STRING
             MOVE ZEROS                     TO WS-NUMERO5
             MOVE ENT-INGRESOS-INI          TO WS-STRING
             MOVE CTEN-10                   TO WS-IND
             PERFORM 22-VALIDA-STRING
             IF SI-NUMERICO
                MOVE ENT-INGRESOS-FIN       TO WS-STRING
                PERFORM 22-VALIDA-STRING
             ELSE
                STRING 'INGRS_INI INVALIDO ' DELIMITED BY SIZE
                        WS-STRING         DELIMITED BY SIZE
                                          INTO ERR-DETALLE
                END-STRING
                PERFORM 30-ESCRIBIR-RECHAZOS
             END-IF
             IF SI-NUMERICO
               COMPUTE
                 WS-NUMERO5 = FUNCTION NUMVAL (ENT-INGRESOS-INI)
               END-COMPUTE
               MOVE WS-NUMERO5             TO WS-MONTO-INI
                                              SAL-INGINI
                                              ERR-INGINI
               COMPUTE
                 WS-NUMERO5 = FUNCTION NUMVAL (ENT-INGRESOS-FIN)
               END-COMPUTE
               MOVE WS-NUMERO5             TO WS-MONTO-FIN
                                              SAL-INGFIN
                                              ERR-INGFIN
               IF WS-MONTO-INI         IS NOT NUMERIC
                  SET NO-CORRECTO             TO TRUE
                  MOVE 'INGRESO INICIAL DEBE SER NUMERICO'
                                              TO ERR-DETALLE
                  PERFORM 30-ESCRIBIR-RECHAZOS
               END-IF

               IF WS-MONTO-INI         < ZEROS
                  SET NO-CORRECTO             TO TRUE
                  MOVE 'INGRESO INICIAL DEBE SER MAYOR A 0'
                                              TO ERR-DETALLE
                  PERFORM 30-ESCRIBIR-RECHAZOS
               END-IF

               IF WS-MONTO-FIN         IS NOT NUMERIC
                  SET NO-CORRECTO             TO TRUE
                  MOVE 'INGRESO FINAL DEBE SER NUMERICO'
                                              TO ERR-DETALLE
                  PERFORM 30-ESCRIBIR-RECHAZOS
               END-IF

               IF WS-MONTO-INI  = ZEROS AND
                  WS-MONTO-FIN  = ZEROS
                  CONTINUE
               ELSE
                 IF (WS-MONTO-INI         >= WS-MONTO-FIN) OR
                    (WS-NUMERO5           <= ZEROS)
                    SET NO-CORRECTO             TO TRUE
                    MOVE 'INGRESO FINAL <= INGRESO INICIAL   '
                                                TO ERR-DETALLE
                    PERFORM 30-ESCRIBIR-RECHAZOS
                 END-IF
               END-IF
               IF SI-CORRECTO
                  MOVE CTE-04                 TO WS-VARIABLE
                  PERFORM 24-CURSOR-UGDTNRA
               END-IF
             ELSE
                STRING 'INGRS_FIN INVALIDO ' DELIMITED BY SIZE
                        WS-STRING         DELIMITED BY SIZE
                                          INTO ERR-DETALLE
                END-STRING
                PERFORM 30-ESCRIBIR-RECHAZOS
             END-IF.
      *
      *----------------------------------------------------------------*
      *                    21-VALIDA-MONTO                             *
      *----------------------------------------------------------------*
      *
       21-VALIDA-MONTO.

      *COL05-I
      *COL06-I
      *      SET SI-CORRECTO                TO TRUE                     00178900
      *COL06-F
      *COL05-F
             MOVE SPACES                    TO ERR-DETALLE
                                               WS-STRING
             MOVE ENT-MONFIN-INI            TO WS-STRING
             MOVE CTEN-10                   TO WS-IND
             PERFORM 22-VALIDA-STRING
             IF SI-NUMERICO
                MOVE ENT-MONFIN-FIN         TO WS-STRING
                PERFORM 22-VALIDA-STRING
             ELSE
                STRING 'MONTO_INI INVALIDO ' DELIMITED BY SIZE
                        WS-STRING         DELIMITED BY SIZE
                                          INTO ERR-DETALLE
                END-STRING
                PERFORM 30-ESCRIBIR-RECHAZOS
             END-IF
             IF SI-NUMERICO
               COMPUTE
                 WS-NUMERO5 = FUNCTION NUMVAL (ENT-MONFIN-INI)
               END-COMPUTE
               MOVE WS-NUMERO5                TO WS-MONTO-INI
                                                 SAL-MONINI
                                                 ERR-MONINI
               COMPUTE
                 WS-NUMERO5 = FUNCTION NUMVAL (ENT-MONFIN-FIN)
               END-COMPUTE
               MOVE WS-NUMERO5                TO WS-MONTO-FIN
                                                 SAL-MONFIN
                                                 ERR-MONFIN
               IF WS-MONTO-INI         IS NOT NUMERIC
                  SET NO-CORRECTO             TO TRUE
                  MOVE 'MONTO INICIAL DEBE SER NUMERICO'
                                              TO ERR-DETALLE
                  PERFORM 30-ESCRIBIR-RECHAZOS
               END-IF

               IF WS-MONTO-INI         < ZEROS
                  SET NO-CORRECTO             TO TRUE
                  MOVE 'MONTO INICIAL DEBE SER MAYOR A 0'
                                              TO ERR-DETALLE
                  PERFORM 30-ESCRIBIR-RECHAZOS
               END-IF

               IF WS-MONTO-FIN         IS NOT NUMERIC
                  SET NO-CORRECTO             TO TRUE
                  MOVE 'MONTO FINAL DEBE SER NUMERICO'
                                              TO ERR-DETALLE
                  PERFORM 30-ESCRIBIR-RECHAZOS
               END-IF

               IF WS-MONTO-INI  = ZEROS AND
                  WS-MONTO-FIN  = ZEROS
                  CONTINUE
               ELSE
                 IF (WS-MONTO-INI         >= WS-MONTO-FIN) OR
                    (WS-NUMERO5           <= ZEROS)
                    SET NO-CORRECTO             TO TRUE
                    MOVE 'MONTO FINAL <= MONTO INICIAL '
                                                TO ERR-DETALLE
                    PERFORM 30-ESCRIBIR-RECHAZOS
                 END-IF
               END-IF
               IF SI-CORRECTO
                  MOVE CTE-05                 TO WS-VARIABLE
                  PERFORM 24-CURSOR-UGDTNRA
               END-IF
             ELSE
                STRING 'MONTO_FIN INVALIDO ' DELIMITED BY SIZE
                        WS-STRING         DELIMITED BY SIZE
                                          INTO ERR-DETALLE
                END-STRING
                PERFORM 30-ESCRIBIR-RECHAZOS
             END-IF.
      *
      *----------------------------------------------------------------*
      *                    21-VALIDA-PLAZO                             *
      *----------------------------------------------------------------*
      *
       21-VALIDA-PLAZO.

      *COL05-I
      *COL06-I
      *      SET SI-CORRECTO                TO TRUE                     00178900
      *COL06-F
      *COL05-F
             MOVE SPACES                    TO ERR-DETALLE
             IF ENT-PLAZO-INI        IS NOT NUMERIC
                SET NO-CORRECTO             TO TRUE
                MOVE 'PLAZO INICIAL DEBE SER NUMERICO'
                                            TO ERR-DETALLE
                PERFORM 30-ESCRIBIR-RECHAZOS
             END-IF

             IF ENT-PLAZO-INI        < ZEROS
                SET NO-CORRECTO              TO TRUE
                MOVE 'PLAZO INICIAL DEBE SER MAYOR A 0'
                                             TO ERR-DETALLE
                PERFORM 30-ESCRIBIR-RECHAZOS
             END-IF

             IF ENT-PLAZO-FIN        IS NOT NUMERIC
                SET NO-CORRECTO             TO TRUE
                MOVE 'PLAZO FINAL DEBE SER NUMERICO'
                                            TO ERR-DETALLE
                PERFORM 30-ESCRIBIR-RECHAZOS
             END-IF

             IF ENT-PLAZO-INI = ZEROS AND
                ENT-PLAZO-FIN = ZEROS
                CONTINUE
             ELSE
               IF (ENT-PLAZO-INI       >= ENT-PLAZO-FIN) OR
                  (ENT-PLAZO-FIN       <= 0)
                  SET NO-CORRECTO             TO TRUE
                  MOVE 'PLAZO FINAL <= PLAZO INICIAL '
                                              TO ERR-DETALLE
                  PERFORM 30-ESCRIBIR-RECHAZOS
               END-IF
             END-IF
             IF SI-CORRECTO
                MOVE ENT-PLAZO-INI          TO WS-RANGO-INI
                MOVE ENT-PLAZO-FIN          TO WS-RANGO-FIN
                MOVE CTE-06                 TO WS-VARIABLE
                PERFORM 24-CURSOR-UGDTNRA
             END-IF.
      *
      *----------------------------------------------------------------*
      *                    21-VALIDA-EDAD                              *
      *----------------------------------------------------------------*
      *
       21-VALIDA-EDAD.

      *COL05-I
      *COL06-I
      *      SET SI-CORRECTO                TO TRUE                     00178900
      *COL06-F
      *COL05-F
             MOVE SPACES                    TO ERR-DETALLE
             IF ENT-EDAD-INI         IS NOT NUMERIC
                SET NO-CORRECTO             TO TRUE
                MOVE 'EDAD INICIAL DEBE SER NUMERICO'
                                            TO ERR-DETALLE
                PERFORM 30-ESCRIBIR-RECHAZOS
             END-IF

             IF ENT-EDAD-INI         < ZEROS
                SET NO-CORRECTO              TO TRUE
                MOVE 'EDAD INICIAL DEBE SER MAYOR A 0'
                                             TO ERR-DETALLE
                PERFORM 30-ESCRIBIR-RECHAZOS
             END-IF

             IF ENT-EDAD-FIN         IS NOT NUMERIC
                SET NO-CORRECTO             TO TRUE
                MOVE 'EDAD FINAL DEBE SER NUMERICO'
                                            TO ERR-DETALLE
                PERFORM 30-ESCRIBIR-RECHAZOS
             END-IF

             IF ENT-EDAD-INI = ZEROS AND
                ENT-EDAD-FIN = ZEROS
                CONTINUE
             ELSE
               IF (ENT-EDAD-INI        >= ENT-EDAD-FIN) OR
                  (ENT-EDAD-FIN        <= 0)
                  SET NO-CORRECTO             TO TRUE
                  MOVE 'EDAD FINAL <= EDAD INICIAL '
                                              TO ERR-DETALLE
                  PERFORM 30-ESCRIBIR-RECHAZOS
               END-IF
             END-IF
             IF SI-CORRECTO
                MOVE ENT-EDAD-INI           TO WS-RANGO-INI
                MOVE ENT-EDAD-FIN           TO WS-RANGO-FIN
                MOVE CTE-07                 TO WS-VARIABLE
                PERFORM 24-CURSOR-UGDTNRA
             END-IF.
      *
      *----------------------------------------------------------------*
      *                    21-VALIDA-SEGMENTO                          *
      *----------------------------------------------------------------*
      *
       21-VALIDA-SEGMENTO.

      *COL05-I
      *COL06-I
      *      SET SI-CORRECTO                TO TRUE                     00178900
      *COL06-F
      *COL05-F
             MOVE SPACES                    TO ERR-DETALLE
             IF ENT-SEGMENTO         IS NOT NUMERIC
                SET NO-CORRECTO             TO TRUE
                MOVE 'SEGMENTO DEBE SER NUMERICO'
                                            TO ERR-DETALLE
                PERFORM 30-ESCRIBIR-RECHAZOS
             END-IF

             IF ENT-SEGMENTO         < ZEROS
                SET NO-CORRECTO             TO TRUE
                MOVE 'SEGMENTO DEBE SER MAYOR A 0'
                                            TO ERR-DETALLE
                PERFORM 30-ESCRIBIR-RECHAZOS
             END-IF
      *COL01-I
      *      IF SI-CORRECTO AND ENT-SEGMENTO > 0
             IF SI-CORRECTO AND ENT-SEGMENTO NOT EQUAL 99999
      *COL01-F
                MOVE ENT-SEGMENTO           TO WS-SEGMCOLE
                MOVE CTE-08                 TO WS-VARIABLE
                PERFORM 24-CURSOR-UGDTNRA
             END-IF.

      *
      *----------------------------------------------------------------*
      *                    21-VALIDA-COLECTIVO                         *
      *----------------------------------------------------------------*
      *
       21-VALIDA-COLECTIVO.

      *COL05-I
      *COL06-I
      *      SET SI-CORRECTO                TO TRUE                     00178900
      *COL06-F
      *COL05-F
             MOVE SPACES                    TO ERR-DETALLE
             IF ENT-COLECTIVO        IS NOT NUMERIC
                SET NO-CORRECTO             TO TRUE
                MOVE 'COLECTIVO DEBE SER NUMERICO'
                                            TO ERR-DETALLE
                PERFORM 30-ESCRIBIR-RECHAZOS
             END-IF

             IF ENT-COLECTIVO        < ZEROS
                SET NO-CORRECTO             TO TRUE
                MOVE 'COLECTIVO DEBE SER MAYOR A 0'
                                            TO ERR-DETALLE
                PERFORM 30-ESCRIBIR-RECHAZOS
             END-IF
             IF SI-CORRECTO AND ENT-COLECTIVO > 0
                MOVE ENT-COLECTIVO          TO WS-SEGMCOLE
                MOVE CTE-09                 TO WS-VARIABLE
                PERFORM 24-CURSOR-UGDTNRA
             END-IF.

      *
      *----------------------------------------------------------------*
      *                    21-VALIDA-GR-RIESGO                         *
      *----------------------------------------------------------------*
      *
       21-VALIDA-GR-RIESGO.

      *COL05-I
      *COL06-I
      *      SET SI-CORRECTO                TO TRUE                     00178900
      *COL06-F
      *COL05-F
             MOVE SPACES                    TO ERR-DETALLE  WS-STRING
             MOVE ENT-GRIESGO-INI           TO WS-STRING
             MOVE CTEN-10                   TO WS-IND
             PERFORM 22-VALIDA-STRING
             IF SI-NUMERICO
                MOVE ENT-GRIESGO-FIN        TO WS-STRING
                PERFORM 22-VALIDA-STRING
             ELSE
                STRING 'GRSGO_INI INVALIDO ' DELIMITED BY SIZE
                        WS-STRING         DELIMITED BY SIZE
                                          INTO ERR-DETALLE
                END-STRING
                PERFORM 30-ESCRIBIR-RECHAZOS
             END-IF
             IF SI-NUMERICO
               COMPUTE
                 WS-NUMERO5 = FUNCTION NUMVAL (ENT-GRIESGO-INI)
               END-COMPUTE
               MOVE WS-NUMERO5                TO WS-MONTO-INI
                                                 SAL-GRIINI
                                                 ERR-GRIINI
               COMPUTE
                 WS-NUMERO5 = FUNCTION NUMVAL (ENT-GRIESGO-FIN)
               END-COMPUTE
               MOVE WS-NUMERO5                TO WS-MONTO-FIN
                                                 SAL-GRIFIN
                                                 ERR-GRIFIN
               IF WS-MONTO-INI         IS NOT NUMERIC
                  SET NO-CORRECTO             TO TRUE
                  MOVE 'GR.RIESGO INICIAL DEBE SER NUMERICO'
                                              TO ERR-DETALLE
                  PERFORM 30-ESCRIBIR-RECHAZOS
               END-IF

               IF WS-MONTO-INI         < ZEROS
                  SET NO-CORRECTO             TO TRUE
                  MOVE 'GR.RIESGO INICIAL DEBE SER MAYOR A 0'
                                              TO ERR-DETALLE
                  PERFORM 30-ESCRIBIR-RECHAZOS
               END-IF

               IF WS-MONTO-FIN         IS NOT NUMERIC
                  SET NO-CORRECTO             TO TRUE
                  MOVE 'GR.RIESGO FINAL DEBE SER NUMERICO'
                                              TO ERR-DETALLE
                  PERFORM 30-ESCRIBIR-RECHAZOS
               END-IF

               IF WS-MONTO-INI = ZEROS AND
                  WS-MONTO-FIN = ZEROS
                  CONTINUE
               ELSE
                 IF (WS-MONTO-INI         >= WS-MONTO-FIN) OR
                    (WS-NUMERO5           <= ZEROS)
                    SET NO-CORRECTO             TO TRUE
                    MOVE 'GR.RIESGO FINAL <= GR.RIESGO INICIAL '
                                                TO ERR-DETALLE
                    PERFORM 30-ESCRIBIR-RECHAZOS
                 END-IF
               END-IF
               IF SI-CORRECTO
                  MOVE CTE-10                 TO WS-VARIABLE
                  PERFORM 24-CURSOR-UGDTNRA
               END-IF
             ELSE
                STRING 'GRSGO_FIN INVALIDO ' DELIMITED BY SIZE
                        WS-STRING         DELIMITED BY SIZE
                                          INTO ERR-DETALLE
                END-STRING
             END-IF.
      *
      *----------------------------------------------------------------*
      *                    21-VALIDA-ESTA-VEH                          *
      *----------------------------------------------------------------*
      *
       21-VALIDA-ESTA-VEH.

      *COL05-I
      *COL06-I
      *      SET SI-CORRECTO                TO TRUE                     00178900
      *COL06-F
      *COL05-F
             MOVE SPACES                    TO ERR-DETALLE
             IF ENT-ESTADO-VEH       NOT EQUAL 'N' AND 'U' AND ' '
                SET NO-CORRECTO             TO TRUE
                MOVE 'ESTADO VEHICULO DEBE SER N/U'
                                            TO ERR-DETALLE
                PERFORM 30-ESCRIBIR-RECHAZOS
             ELSE
                MOVE CTE-11                 TO WS-VARIABLE
                PERFORM 24-CURSOR-UGDTNRA
             END-IF.
      *
      *----------------------------------------------------------------*
      *                    21-VALIDA-PORC-FINANC                       *
      *----------------------------------------------------------------*
      *
       21-VALIDA-PORC-FINANC.

      *COL05-I
      *COL06-I
      *      SET SI-CORRECTO                TO TRUE                     00178900
      *COL06-F
      *COL05-F
             MOVE SPACES                    TO ERR-DETALLE WS-STRING
             MOVE ENT-FINANC-INI            TO WS-STRING
             MOVE CTEN-10                   TO WS-IND
             PERFORM 22-VALIDA-STRING
             IF SI-NUMERICO
                MOVE ENT-FINANC-FIN         TO WS-STRING
                PERFORM 22-VALIDA-STRING
             ELSE
                STRING '%FINC_INI INVALIDO ' DELIMITED BY SIZE
                        WS-STRING         DELIMITED BY SIZE
                                          INTO ERR-DETALLE
                END-STRING
                PERFORM 30-ESCRIBIR-RECHAZOS
             END-IF
             IF SI-NUMERICO
               COMPUTE
                 WS-NUMERO5 = FUNCTION NUMVAL (ENT-FINANC-INI)
               END-COMPUTE
               MOVE WS-NUMERO5                TO WS-MONTO-INI
                                                 SAL-PFIINI
                                                 ERR-PFIINI
               COMPUTE
                 WS-NUMERO5 = FUNCTION NUMVAL (ENT-FINANC-FIN)
               END-COMPUTE
               MOVE WS-NUMERO5                TO WS-MONTO-FIN
                                                 SAL-PFIFIN
                                                 ERR-PFIFIN
               IF WS-MONTO-INI         IS NOT NUMERIC
                  SET NO-CORRECTO             TO TRUE
                  MOVE '% FINANC INICIAL DEBE SER NUMERICO'
                                              TO ERR-DETALLE
                  PERFORM 30-ESCRIBIR-RECHAZOS
               END-IF

               IF WS-MONTO-INI         < ZEROS
                  SET NO-CORRECTO             TO TRUE
                  MOVE '% FINANC INICIAL DEBE SER MAYOR A 0'
                                              TO ERR-DETALLE
                  PERFORM 30-ESCRIBIR-RECHAZOS
               END-IF

               IF WS-MONTO-FIN         IS NOT NUMERIC
                  SET NO-CORRECTO             TO TRUE
                  MOVE '% FINANC FINAL DEBE SER NUMERICO'
                                              TO ERR-DETALLE
                  PERFORM 30-ESCRIBIR-RECHAZOS
               END-IF

               IF WS-MONTO-INI = ZEROS AND
                  WS-MONTO-FIN = ZEROS
                  CONTINUE
               ELSE
                 IF (WS-MONTO-INI         >= WS-MONTO-FIN) OR
                    (WS-NUMERO5           <= ZEROS)
                    SET NO-CORRECTO             TO TRUE
                    MOVE '% FINANC FINAL <= % FINANC INICIAL '
                                                TO ERR-DETALLE
                    PERFORM 30-ESCRIBIR-RECHAZOS
                 END-IF
               END-IF
               IF SI-CORRECTO
                  MOVE CTE-12                 TO WS-VARIABLE
                  PERFORM 24-CURSOR-UGDTNRA
               END-IF
             ELSE
                STRING '%FINC_FIN INVALIDO ' DELIMITED BY SIZE
                        WS-STRING         DELIMITED BY SIZE
                                          INTO ERR-DETALLE
                END-STRING
                PERFORM 30-ESCRIBIR-RECHAZOS
             END-IF.
      *
      *----------------------------------------------------------------*
      *                    21-VALIDA-GAMA-VEH                          *
      *----------------------------------------------------------------*
      *
       21-VALIDA-GAMA-VEH.

      *COL05-I
      *COL06-I
      *      SET SI-CORRECTO                TO TRUE                     00178900
      *COL06-F
      *COL05-F
             MOVE SPACES                    TO ERR-DETALLE WS-STRING
             MOVE ENT-GAMAVEH-INI           TO WS-STRING
             MOVE CTEN-10                   TO WS-IND
             PERFORM 22-VALIDA-STRING
             IF SI-NUMERICO
                MOVE ENT-GAMAVEH-FIN        TO WS-STRING
                PERFORM 22-VALIDA-STRING
             ELSE
                STRING 'GAMA_INI INVALIDO ' DELIMITED BY SIZE
                        WS-STRING         DELIMITED BY SIZE
                                          INTO ERR-DETALLE
                END-STRING
                PERFORM 30-ESCRIBIR-RECHAZOS
             END-IF
             IF SI-NUMERICO
               COMPUTE
                 WS-NUMERO5 = FUNCTION NUMVAL (ENT-GAMAVEH-INI)
               END-COMPUTE
               MOVE WS-NUMERO5                 TO WS-MONTO-INI
                                                  SAL-GAMINI
                                                  ERR-GAMINI
               COMPUTE
                 WS-NUMERO5 = FUNCTION NUMVAL (ENT-GAMAVEH-FIN)
               END-COMPUTE
               MOVE WS-NUMERO5                 TO WS-MONTO-FIN
                                                  SAL-GAMFIN
                                                  ERR-GAMFIN
               IF WS-MONTO-INI         IS NOT NUMERIC
                  SET NO-CORRECTO             TO TRUE
                  MOVE 'GAMA VEH INICIAL DEBE SER NUMERICO'
                                              TO ERR-DETALLE
                  PERFORM 30-ESCRIBIR-RECHAZOS
               END-IF

               IF WS-MONTO-INI         < ZEROS
                  SET NO-CORRECTO             TO TRUE
                  MOVE 'GAMA VEH INICIAL DEBE SER MAYOR A 0'
                                              TO ERR-DETALLE
                  PERFORM 30-ESCRIBIR-RECHAZOS
               END-IF

               IF WS-MONTO-FIN         IS NOT NUMERIC
                  SET NO-CORRECTO             TO TRUE
                  MOVE 'GAMA VEH FINAL DEBE SER NUMERICO'
                                              TO ERR-DETALLE
                  PERFORM 30-ESCRIBIR-RECHAZOS
               END-IF

               IF WS-MONTO-INI = ZEROS AND
                  WS-MONTO-FIN = ZEROS
                  CONTINUE
               ELSE
                 IF (WS-MONTO-INI         >= WS-MONTO-FIN) OR
                    (WS-NUMERO5           <= ZEROS)
                    SET NO-CORRECTO             TO TRUE
                    MOVE 'GAMA VEH FINAL <= GAMA VEH INICIAL '
                                                TO ERR-DETALLE
                    PERFORM 30-ESCRIBIR-RECHAZOS
                 END-IF
               END-IF
               IF SI-CORRECTO
                  MOVE CTE-13                 TO WS-VARIABLE
                  PERFORM 24-CURSOR-UGDTNRA
               END-IF
             ELSE
                STRING 'GAMA_FIN INVALIDO ' DELIMITED BY SIZE
                        WS-STRING         DELIMITED BY SIZE
                                          INTO ERR-DETALLE
                END-STRING
                PERFORM 30-ESCRIBIR-RECHAZOS
             END-IF.
      *
      *----------------------------------------------------------------*
      *                    21-VALIDA-TIPO-VEH                          *
      *----------------------------------------------------------------*
      *
       21-VALIDA-TIPO-VEH.

      *COL05-I
      *COL06-I
      *      SET SI-CORRECTO                TO TRUE                     00178900
      *COL06-F
      *COL05-F
             MOVE SPACES                    TO ERR-DETALLE
             IF ENT-TIPOVEH          NOT EQUAL 'P' AND 'S' AND ' '
                SET NO-CORRECTO             TO TRUE
                MOVE 'TIPO VEHICULO DEBE SER P/S'
                                            TO ERR-DETALLE
                PERFORM 30-ESCRIBIR-RECHAZOS
             ELSE
                MOVE CTE-14                 TO WS-VARIABLE
                PERFORM 24-CURSOR-UGDTNRA
             END-IF.
      *
      *COL03-I
      *----------------------------------------------------------------*
      *                    21-VALIDA-COLECTIVO-LB                      *
      *----------------------------------------------------------------*
      *
       21-VALIDA-COLECTIVO-LB.
      *COL05-I
      *COL06-I
      *      SET SI-CORRECTO                TO TRUE                     00178900
      *COL06-F
      *COL05-F
             MOVE SPACES                    TO ERR-DETALLE
             IF ENT-CLTVLB           IS NOT NUMERIC
                SET NO-CORRECTO             TO TRUE
                MOVE 'COLECTIVO DEBE SER NUMERICO'
                                            TO ERR-DETALLE
                PERFORM 30-ESCRIBIR-RECHAZOS
             ELSE
               MOVE CTE-9965          TO  WS-SECT37
               MOVE ENT-CLTVLB        TO  WS-ELMT37
               PERFORM 22-VALIDA-T37
               IF SW-SECT37-ERROR
                  SET NO-CORRECTO             TO TRUE
                  STRING CTE-ERR-COLECTIVO '-'  ENT-CLTVLB
                        ' SECCION ' CTE-9965 DELIMITED BY SIZE
                              INTO ERR-DETALLE
                  END-STRING
                  PERFORM 30-ESCRIBIR-RECHAZOS
               END-IF
               IF SI-CORRECTO AND ENT-CLTVLB > 0
                  MOVE ENT-CLTVLB             TO WS-SEGMCOLE
                  MOVE CTE-16                 TO WS-VARIABLE
                  PERFORM 24-CURSOR-UGDTNRA
               END-IF
             END-IF.
      *
      *----------------------------------------------------------------*
      *                    21-VALIDA-DESTINO-LB                        *
      *----------------------------------------------------------------*
      *
       21-VALIDA-DESTINO-LB.
      *COL05-I
      *COL06-I
      *      SET SI-CORRECTO                TO TRUE                     00178900
      *COL06-F
      *COL05-F
             MOVE SPACES                    TO ERR-DETALLE
             IF ENT-DESTLB           IS NOT NUMERIC
                SET NO-CORRECTO             TO TRUE
                MOVE 'DESTINO DEBE SER NUMERICO'
                                            TO ERR-DETALLE
                PERFORM 30-ESCRIBIR-RECHAZOS
             ELSE
               MOVE CTE-9966          TO  WS-SECT37
               MOVE ENT-DESTLB        TO  WS-ELMT37
               PERFORM 22-VALIDA-T37
               IF SW-SECT37-ERROR
                  SET NO-CORRECTO             TO TRUE
                  STRING CTE-ERR-DESTINO  '-'  ENT-CLTVLB
                              ' SECCION ' CTE-9966 DELIMITED BY SIZE
                              INTO ERR-DETALLE
                  END-STRING
                  PERFORM 30-ESCRIBIR-RECHAZOS
               END-IF
               IF SI-CORRECTO AND ENT-DESTLB > 0
                  MOVE ENT-DESTLB             TO WS-SEGMCOLE
                  MOVE CTE-17                 TO WS-VARIABLE
                  PERFORM 24-CURSOR-UGDTNRA
               END-IF
             END-IF.
      *
      ******************************************************************00425220
      *                  22-VALIDA-T37                                 *00425230
      *    SE ACCEDE A LA TABLA UGDTT37 SECCION 9965, 9966 PARA VALIDAR*00425240
      *    CONVENIOS Y DESTINO PARA ALTA MASIVA.                       *00425250
      ******************************************************************00425260
       22-VALIDA-T37.                                                   00425270
      *                                                                 00425280
            MOVE SPACES                       TO WS-T37-RESTO           00425290
            INITIALIZE UGTCT37                                          00425291
            MOVE WS-SECT37                    TO T37-SECCION            00425292
            MOVE WS-ELMT37(2:2)               TO T37-ELEMENTO(1:2)      00425293
            SET SW-SECT37-ERROR               TO TRUE
      *                                                                 00425295
            EXEC SQL                                                    00425296
                 SELECT RESTO                                           00425297
                 INTO  :T37-RESTO                                       00425298
                 FROM UGDTT37                                           00425299
                WHERE SECCION  = :T37-SECCION  AND                      00425300
                      ELEMENTO = :T37-ELEMENTO                          00425301
            END-EXEC.                                                   00425302
      *                                                                 00425303
            MOVE SQLCODE                      TO DB2-RETURN-CDE         00425304
      *                                                                 00425305
            IF DB2-OK                                                   00425306
               SET SW-SECT37-OK               TO TRUE
               MOVE T37-RESTO                 TO WS-T37-RESTO           00425307
            ELSE                                                        00425308
               IF DB2-NOTFND                                            00425309
                  CONTINUE                                              00425310
               ELSE                                                     00425311
                  MOVE  'ERROR SELECT UGDTNRA'  TO ERR-DETALLE
                  MOVE  SQLCODE                 TO ERR-SQLCODE
                  MOVE 'UGDTNRA'                TO ERR-TABLERR
                  PERFORM 30-ESCRIBIR-RECHAZOS
               END-IF                                                   00425318
            END-IF.                                                     00425319
      *COL03-F
      *COL05-I
      *----------------------------------------------------------------*
      *                  21-VALIDA-VENTAS-COMER                        *
      *----------------------------------------------------------------*
      *
       21-VALIDA-VENTAS-COMER.

      *COL06-I
      *    SET SI-CORRECTO                  TO TRUE                     00178900
      *COL06-F
           MOVE SPACES                      TO ERR-DETALLE
                                               WS-STRING
           MOVE ZEROS                       TO WS-NUMERO5

           MOVE ENT-VENTAS-INI              TO WS-STRING
           MOVE CTEN-10                     TO WS-IND
           PERFORM 22-VALIDA-STRING
           IF SI-NUMERICO
              COMPUTE
                 WS-NUMERO5 = FUNCTION NUMVAL (ENT-VENTAS-INI)
              END-COMPUTE
              MOVE WS-NUMERO5               TO WS-MONTO-INI
                                               SAL-VENTINI
                                               ERR-VENTINI
              IF WS-MONTO-INI < ZEROS
                 SET NO-CORRECTO            TO TRUE
                 MOVE 'VENTAS INICIAL DEBE SER MAYOR A 0'
                                            TO ERR-DETALLE
                 PERFORM 30-ESCRIBIR-RECHAZOS
              END-IF
           ELSE
              SET NO-CORRECTO               TO TRUE
              STRING 'VENTAS_INI DEBE SER NUMERICO:' DELIMITED BY SIZE
                      WS-STRING                      DELIMITED BY SIZE
                                                     INTO ERR-DETALLE
              END-STRING
              PERFORM 30-ESCRIBIR-RECHAZOS
           END-IF

           MOVE ENT-VENTAS-FIN              TO WS-STRING
           PERFORM 22-VALIDA-STRING
           IF SI-NUMERICO
              COMPUTE
                 WS-NUMERO5 = FUNCTION NUMVAL (ENT-VENTAS-FIN)
              END-COMPUTE
              MOVE WS-NUMERO5               TO WS-MONTO-FIN
                                               SAL-VENTFIN
                                               ERR-VENTFIN

              IF WS-MONTO-INI  = ZEROS AND
                 WS-MONTO-FIN  = ZEROS
                 CONTINUE
              ELSE
                 IF (WS-MONTO-INI >= WS-MONTO-FIN) OR
                    (WS-NUMERO5   <= ZEROS)
                    SET NO-CORRECTO         TO TRUE
                    MOVE 'VENTA FINAL <= VENTA INICIAL   '
                                            TO ERR-DETALLE
                    PERFORM 30-ESCRIBIR-RECHAZOS
                 END-IF
              END-IF

              IF SI-CORRECTO
                 MOVE CTE-18                TO WS-VARIABLE
                 PERFORM 24-CURSOR-UGDTNRA
              END-IF
           ELSE
              STRING 'VENTAS_FIN DEBE SER NUMERICO:'
                                            DELIMITED BY SIZE
                      WS-STRING             DELIMITED BY SIZE
                                            INTO ERR-DETALLE
              END-STRING
              PERFORM 30-ESCRIBIR-RECHAZOS
           END-IF.
      *
      *----------------------------------------------------------------*
      *                  21-VALIDA-TIP-PER-COMER                       *
      *----------------------------------------------------------------*
      *
       21-VALIDA-TIP-PER-COMER.

      *COL06-I
      *    SET SI-CORRECTO                  TO TRUE                     00178900
      *COL06-F
           MOVE SPACES                      TO ERR-DETALLE
           MOVE ENT-TIPO-PERSONA(2:1)       TO WS-TIPOPER

           IF ENT-TIPO-PERSONA NOT EQUAL 'PJ' AND 'PN' AND ' '
              SET NO-CORRECTO               TO TRUE
              MOVE 'TIPO PERSONA DEBE SER PJ/PN'
                                            TO ERR-DETALLE
              PERFORM 30-ESCRIBIR-RECHAZOS
           ELSE
              MOVE CTE-19                   TO WS-VARIABLE
              PERFORM 24-CURSOR-UGDTNRA
           END-IF.
      *
      *----------------------------------------------------------------*
      *                  21-VALIDA-RATING-COMER                        *
      *----------------------------------------------------------------*
      *
       21-VALIDA-RATING-COMER.

      *COL06-I
      *    SET SI-CORRECTO                  TO TRUE                     00178900
      *COL06-F
           MOVE SPACES                      TO ERR-DETALLE
                                               WS-STRING

           IF ENT-RATING NOT EQUAL SPACES                               02670000
              MOVE ENT-RATING              TO WS-STRING
              MOVE CTEN-05                 TO WS-IND
              SET NO-NUMERICO              TO TRUE
              PERFORM VARYING WS-I FROM 1  BY 1 UNTIL WS-I > WS-IND
                  MOVE WS-STRING (WS-I:1)  TO WS-C
                  IF WS-N IS NUMERIC
                     MOVE WS-N             TO WS-NU(WS-I:1)
                     SET SI-NUMERICO       TO TRUE
                  END-IF
              END-PERFORM

              IF SI-NUMERICO AND WS-NU = ZEROES
                 SET NO-CORRECTO            TO TRUE
                 MOVE 'RATING DEBE SER ALFANUMERIC' TO
                                            ERR-DETALLE
                 PERFORM 30-ESCRIBIR-RECHAZOS
              ELSE
                 MOVE CTE-20                TO WS-VARIABLE
                 PERFORM 24-CURSOR-UGDTNRA
              END-IF
           END-IF.
      *
      *----------------------------------------------------------------*
      *                 21-VALIDA-RANG-RATIN-COMER                     *
      *----------------------------------------------------------------*
      *
       21-VALIDA-RANG-RATIN-COMER.

      *COL06-I
      *    SET SI-CORRECTO                  TO TRUE                     00178900
      *COL06-F
           MOVE SPACES                      TO ERR-DETALLE

           IF ENT-RANGO-RATING NOT EQUAL SPACES
              IF ENT-RANGO-RATING IS NOT NUMERIC
                 SET NO-CORRECTO            TO TRUE
                 MOVE 'IND.RANG RATING DEBE SER NUMERICO'
                                            TO ERR-DETALLE
                 PERFORM 30-ESCRIBIR-RECHAZOS
              ELSE
                 MOVE CTE-21                TO WS-VARIABLE
                 PERFORM 24-CURSOR-UGDTNRA
              END-IF
           END-IF.
      *
      *----------------------------------------------------------------*
      *                 21-VALIDA-GARANTIA-COMER                       *
      *----------------------------------------------------------------*
      *
       21-VALIDA-GARANTIA-COMER.

      *COL06-I
      *    SET SI-CORRECTO                  TO TRUE                     00178900
      *COL06-F
           MOVE SPACES                      TO ERR-DETALLE

           IF ENT-GARANTIA NOT EQUAL 'S' AND 'N' AND ' '
              SET NO-CORRECTO               TO TRUE
              MOVE 'GARANTIA DEBE SER S/N'
                                            TO ERR-DETALLE
              PERFORM 30-ESCRIBIR-RECHAZOS
           ELSE
              MOVE CTE-22                   TO WS-VARIABLE
              PERFORM 24-CURSOR-UGDTNRA
           END-IF.
      *
      *----------------------------------------------------------------*
      *                  21-VALIDA-MON-OPER-COMER                      *
      *----------------------------------------------------------------*
      *
       21-VALIDA-MON-OPER-COMER.

      *COL06-I
      *    SET SI-CORRECTO                  TO TRUE                     00178900
      *COL06-F
           MOVE SPACES                      TO ERR-DETALLE
                                               WS-STRING
           MOVE ZEROS                       TO WS-NUMERO5

           MOVE ENT-MON-OPER-INI            TO WS-STRING
           MOVE CTEN-10                     TO WS-IND
           PERFORM 22-VALIDA-STRING
           IF SI-NUMERICO
              COMPUTE
                 WS-NUMERO5 = FUNCTION NUMVAL (ENT-MON-OPER-INI)
              END-COMPUTE
              MOVE WS-NUMERO5               TO WS-MONTO-INI
                                               SAL-MONOPERINI
                                               ERR-MONOPERINI
              IF WS-MONTO-INI < ZEROS
                 SET NO-CORRECTO            TO TRUE
                 MOVE 'MONOPER INICIAL DEBE SER MAYOR A 0'
                                            TO ERR-DETALLE
                 PERFORM 30-ESCRIBIR-RECHAZOS
              END-IF
           ELSE
              SET NO-CORRECTO               TO TRUE
              STRING 'MONOPER_INI DEBE SER NUMERICO:' DELIMITED BY SIZE
                      WS-STRING                       DELIMITED BY SIZE
                                                      INTO ERR-DETALLE
              END-STRING
              PERFORM 30-ESCRIBIR-RECHAZOS
           END-IF

           MOVE ENT-MON-OPER-FIN            TO WS-STRING
           PERFORM 22-VALIDA-STRING
           IF SI-NUMERICO
              COMPUTE
                 WS-NUMERO5 = FUNCTION NUMVAL (ENT-MON-OPER-FIN)
              END-COMPUTE
              MOVE WS-NUMERO5               TO WS-MONTO-FIN
                                               SAL-MONOPERFIN
                                               ERR-MONOPERFIN

              IF WS-MONTO-INI  = ZEROS AND
                 WS-MONTO-FIN  = ZEROS
                 CONTINUE
              ELSE
                 IF (WS-MONTO-INI >= WS-MONTO-FIN) OR
                    (WS-NUMERO5   <= ZEROS)
                    SET NO-CORRECTO         TO TRUE
                    MOVE 'MONOPER FINAL <= VENTA INICIAL   '
                                            TO ERR-DETALLE
                    PERFORM 30-ESCRIBIR-RECHAZOS
                 END-IF
              END-IF

              IF SI-CORRECTO
                 MOVE CTE-23                TO WS-VARIABLE
                 PERFORM 24-CURSOR-UGDTNRA
              END-IF
           ELSE
              STRING 'MONOPER_FIN DEBE SER NUMERICO:'
                                             DELIMITED BY SIZE
                      WS-STRING              DELIMITED BY SIZE
                                             INTO ERR-DETALLE
              END-STRING
              PERFORM 30-ESCRIBIR-RECHAZOS
           END-IF.
      *
      *----------------------------------------------------------------*
      *                  21-VALIDA-PE-COMER                            *
      *----------------------------------------------------------------*
      *
       21-VALIDA-PE-COMER.

      *COL06-I
      *    SET SI-CORRECTO                  TO TRUE                     00178900
      *COL06-F
           MOVE SPACES                      TO ERR-DETALLE
                                               WS-STRING
           MOVE ZEROS                       TO WS-NUMERO3
           MOVE ENT-PE                      TO WS-STRING
           MOVE CTEN-05                     TO WS-IND

           PERFORM 22-VALIDA-STRING
           IF SI-NUMERICO
              COMPUTE
                 WS-NUMERO3 = FUNCTION NUMVAL (ENT-PE)
              END-COMPUTE
              MOVE WS-NUMERO3               TO SAL-PE
                                               ERR-PE
                                               WS-PE
              IF WS-NUMERO3 IS NOT NUMERIC
                 SET NO-CORRECTO            TO TRUE
                 MOVE 'P.E DEBE SER NUMERICO'
                                            TO ERR-DETALLE
                 PERFORM 30-ESCRIBIR-RECHAZOS
              END-IF

              IF WS-NUMERO3 <= ZEROS
                 SET NO-CORRECTO            TO TRUE
                 MOVE 'P.E DEBE SER MAYOR A 0'
                                            TO ERR-DETALLE
                 PERFORM 30-ESCRIBIR-RECHAZOS
              END-IF
           ELSE
              STRING 'P.E INVALIDA ' DELIMITED BY SIZE
                      WS-STRING      DELIMITED BY SIZE
                                     INTO ERR-DETALLE
              END-STRING
              PERFORM 30-ESCRIBIR-RECHAZOS
           END-IF.
      *
      *----------------------------------------------------------------*
      *                  21-VALIDA-RORC-COMER                          *
      *----------------------------------------------------------------*
      *
       21-VALIDA-RORC-COMER.

      *COL06-I
      *    SET SI-CORRECTO                  TO TRUE                     00178900
      *COL06-F
           MOVE SPACES                      TO ERR-DETALLE
                                               WS-STRING
           MOVE ZEROS                       TO WS-NUMERO3
           MOVE ENT-RORC                    TO WS-STRING
           MOVE CTEN-05                     TO WS-IND

           PERFORM 22-VALIDA-STRING
           IF SI-NUMERICO
              COMPUTE
                 WS-NUMERO3 = FUNCTION NUMVAL (ENT-RORC)
              END-COMPUTE
              MOVE WS-NUMERO3               TO SAL-RORC
                                               ERR-RORC
                                               WS-RORC
              IF WS-NUMERO3 IS NOT NUMERIC
                 SET NO-CORRECTO            TO TRUE
                 MOVE 'RORC DEBE SER NUMERICO'
                                            TO ERR-DETALLE
                 PERFORM 30-ESCRIBIR-RECHAZOS
              END-IF

              IF WS-NUMERO3 <= ZEROS
                 SET NO-CORRECTO            TO TRUE
                 MOVE 'RORC DEBE SER MAYOR A 0'
                                            TO ERR-DETALLE
                 PERFORM 30-ESCRIBIR-RECHAZOS
              END-IF
           ELSE
              STRING 'RORC INVALIDA ' DELIMITED BY SIZE
                      WS-STRING       DELIMITED BY SIZE
                                      INTO ERR-DETALLE
              END-STRING
              PERFORM 30-ESCRIBIR-RECHAZOS
           END-IF.
      *
      *----------------------------------------------------------------*
      *                  21-VALIDA-RAROEC-COMER                        *
      *----------------------------------------------------------------*
      *
       21-VALIDA-RAROEC-COMER.

      *COL06-I
      *    SET SI-CORRECTO                  TO TRUE                     00178900
      *COL06-F
           MOVE SPACES                      TO ERR-DETALLE
                                               WS-STRING
           MOVE ZEROS                       TO WS-NUMERO3
           MOVE ENT-RAROEC                  TO WS-STRING
           MOVE CTEN-05                     TO WS-IND

           PERFORM 22-VALIDA-STRING
           IF SI-NUMERICO
              COMPUTE
                 WS-NUMERO3 = FUNCTION NUMVAL (ENT-RAROEC)
              END-COMPUTE
              MOVE WS-NUMERO3               TO SAL-RAROEC
                                               ERR-RAROEC
                                               WS-RAROEC
              IF WS-NUMERO3 IS NOT NUMERIC
                 SET NO-CORRECTO            TO TRUE
                 MOVE 'RAROEC DEBE SER NUMERICO'
                                            TO ERR-DETALLE
                 PERFORM 30-ESCRIBIR-RECHAZOS
              END-IF
      *COL06-I
      *       IF WS-NUMERO3 <= ZEROS
      *          SET NO-CORRECTO            TO TRUE
      *          MOVE 'RAROEC DEBE SER MAYOR A 0'
      *                                     TO ERR-DETALLE
      *          PERFORM 30-ESCRIBIR-RECHAZOS
      *       END-IF
      *COL06-F
           ELSE
              STRING 'RAROEC INVALIDA ' DELIMITED BY SIZE
                      WS-STRING       DELIMITED BY SIZE
                                      INTO ERR-DETALLE
              END-STRING
              PERFORM 30-ESCRIBIR-RECHAZOS
           END-IF.
      *
      *----------------------------------------------------------------*
      *                 21-VALIDA-CAP-ECON-COMER                       *
      *----------------------------------------------------------------*
      *
       21-VALIDA-CAP-ECON-COMER.

      *COL06-I
      *    SET SI-CORRECTO                  TO TRUE                     00178900
      *COL06-F
           MOVE SPACES                      TO ERR-DETALLE
                                               WS-STRING
           MOVE ZEROS                       TO WS-NUMERO3
           MOVE ENT-CAP-ECON                TO WS-STRING
           MOVE CTEN-05                     TO WS-IND

           PERFORM 22-VALIDA-STRING
           IF SI-NUMERICO
              COMPUTE
                 WS-NUMERO3 = FUNCTION NUMVAL (ENT-CAP-ECON)
              END-COMPUTE
              MOVE WS-NUMERO3               TO SAL-CAPECON
                                               ERR-CAPECON
                                               WS-CAPITAL-ECON
              IF WS-NUMERO3 IS NOT NUMERIC
                 SET NO-CORRECTO            TO TRUE
                 MOVE 'CAP ECONO DEBE SER NUMERICO'
                                            TO ERR-DETALLE
                 PERFORM 30-ESCRIBIR-RECHAZOS
              END-IF

              IF WS-NUMERO3 <= ZEROS
                 SET NO-CORRECTO            TO TRUE
                 MOVE 'CAP ECONO DEBE SER MAYOR A 0'
                                            TO ERR-DETALLE
                 PERFORM 30-ESCRIBIR-RECHAZOS
              END-IF
           ELSE
              STRING 'CAPI ECONO INVALIDA ' DELIMITED BY SIZE
                      WS-STRING             DELIMITED BY SIZE
                                            INTO ERR-DETALLE
              END-STRING
              PERFORM 30-ESCRIBIR-RECHAZOS
           END-IF.
      *
      *COL05-F
      *----------------------------------------------------------------*
      *                    22-VALIDA-DATOS                             *
      *----------------------------------------------------------------*
      *
       22-VALIDA-DATOS.

             INITIALIZE  WS-NUMERO2  ERR-DETALLE
      *COL09-I
      *      IF ENT-TIPO-PRODUCTO  NOT EQUAL 'H' AND 'L' AND 'N'
      *                            AND 'VC' AND 'V' AND 'NC' AND 'HC'
      *                            AND 'HU' AND 'HK'
      *COL03-I
      *COL05-I
      *                            AND 'Z'
      *                            AND 'Z'  AND 'C'
      *COL05-F
      *COL03-F
      *COL04-I
      *                            AND 'HS' AND 'HV'
      *COL04-F
      *COL10-I
      *      IF ENT-IND-ACTIVO     NOT EQUAL 'B'
      *COL09-F
      *         SET NO-CORRECTO              TO TRUE
      *         MOVE 'TIPO PRODUCTO INVALIDO '
      *                                      TO ERR-DETALLE
      *         PERFORM 30-ESCRIBIR-RECHAZOS
      *      END-IF
      *COL10-F
             MOVE SPACES                   TO WS-STRING
             MOVE ENT-TASA                 TO WS-STRING
             MOVE CTEN-05                  TO WS-IND
             PERFORM 22-VALIDA-STRING
             IF SI-NUMERICO
               COMPUTE
                 WS-NUMERO2 = FUNCTION NUMVAL (ENT-TASA)
               END-COMPUTE
               MOVE WS-NUMERO2             TO SAL-TASA
                                              ERR-TASA
               IF WS-NUMERO2           IS NOT NUMERIC
                  SET NO-CORRECTO             TO TRUE
                  MOVE 'TASA DEBE SER NUMERICO'
                                              TO ERR-DETALLE
                  PERFORM 30-ESCRIBIR-RECHAZOS
               END-IF

               IF WS-NUMERO2           < ZEROS
                  SET NO-CORRECTO             TO TRUE
                  MOVE 'TASA DEBE SER MAYOR A 0'
                                              TO ERR-DETALLE
                  PERFORM 30-ESCRIBIR-RECHAZOS
               END-IF
             ELSE
                STRING 'TASA INVALIDA ' DELIMITED BY SIZE
                        WS-STRING         DELIMITED BY SIZE
                                          INTO ERR-DETALLE
                END-STRING
                PERFORM 30-ESCRIBIR-RECHAZOS
             END-IF
             IF ENT-CLUSTER              EQUAL SPACES
                SET NO-CORRECTO             TO TRUE
                MOVE 'CLUSTER NO DEBE SER VACIO '
                                            TO ERR-DETALLE
                PERFORM 30-ESCRIBIR-RECHAZOS
             END-IF
      *COL05-I
             IF ENT-TIPO-PRODUCTO = 'C'
                PERFORM 21-VALIDA-PE-COMER
                PERFORM 21-VALIDA-RORC-COMER
                PERFORM 21-VALIDA-RAROEC-COMER
                PERFORM 21-VALIDA-CAP-ECON-COMER
             END-IF
      *COL05-F
             IF WS-CLAVEID  = WS-CERO AND
                ENT-CLUSTER (1:2) NOT EQUAL CTE-BA
                SET NO-CORRECTO             TO TRUE
                STRING 'CLUSTER VRS.CEROS ' DELIMITED BY SIZE
      *COL05-I
      *                 WS-CERO (1:15)    DELIMITED BY SIZE
                        WS-CERO (1:23)    DELIMITED BY SIZE
      *COL05-F
                                          INTO ERR-DETALLE
                END-STRING
                PERFORM 30-ESCRIBIR-RECHAZOS
             END-IF.
      *
      *----------------------------------------------------------------*
      *                    22-VALIDA-STRING                            *
      *----------------------------------------------------------------*
      *
       22-VALIDA-STRING.
             SET SI-NUMERICO             TO TRUE
             PERFORM VARYING WS-I FROM 1  BY 1 UNTIL WS-I > WS-IND
                  IF (WS-STRING (WS-I:1)  = '.') AND
                     (WS-I = 3 OR 6)
                     CONTINUE
                  ELSE
                     MOVE WS-STRING (WS-I:1) TO WS-C
                     IF WS-N             IS NOT NUMERIC
                        SET NO-NUMERICO  TO TRUE
                     END-IF
                  END-IF
             END-PERFORM.

      *
      *----------------------------------------------------------------*
      *                    23-MOVER-DATA                               *
      *----------------------------------------------------------------*
      *
       23-MOVER-DATA.
           INITIALIZE REG-ERRORES REG-SALIDA WS-CLAVEID
           MOVE ALL '0'                     TO WS-CLAVEID
                                               WS-CERO
           MOVE ENT-TIPO-PRODUCTO           TO SAL-TIPPRO
           MOVE ENT-BURO-INI                TO SAL-BURINI
           MOVE ENT-BURO-FIN                TO SAL-BURFIN
           MOVE ENT-DOM-NOMINA              TO SAL-DOMNOM
           MOVE ENT-SIT-LABORAL             TO SAL-SITLAB
           MOVE ENT-PLAZO-INI               TO SAL-PLAINI
           MOVE ENT-PLAZO-FIN               TO SAL-PLAFIN
           MOVE ENT-EDAD-INI                TO SAL-EDAINI
           MOVE ENT-EDAD-FIN                TO SAL-EDAFIN
           MOVE ENT-SEGMENTO                TO SAL-SEGMEN
           MOVE ENT-COLECTIVO               TO SAL-COLECT
           MOVE ENT-ESTADO-VEH              TO SAL-ESTVEH
           MOVE ENT-TIPOVEH                 TO SAL-TIPVEH
      *COL05-I
           MOVE ENT-TIPO-PERSONA            TO SAL-TIPPERSO
           MOVE ENT-RATING                  TO SAL-RATING
           MOVE ENT-RANGO-RATING            TO SAL-RANRATING
           MOVE ENT-GARANTIA                TO SAL-GARANTIA
      *COL05-F
           MOVE ENT-CLUSTER                 TO SAL-CLUSTE
      *COL03-I
           MOVE ENT-CLTVLB                  TO SAL-CLTVLB
           MOVE ENT-DESTLB                  TO SAL-DESTLB
           MOVE SAL-CLTVLB                  TO ERR-CLTVLB
           MOVE SAL-DESTLB                  TO ERR-DESTLB
      *COL03-F
           MOVE SAL-TIPPRO                  TO ERR-TIPPRO
           MOVE SAL-BURINI                  TO ERR-BURINI
           MOVE SAL-BURFIN                  TO ERR-BURFIN
           MOVE SAL-DOMNOM                  TO ERR-DOMNOM
           MOVE SAL-SITLAB                  TO ERR-SITLAB
           MOVE SAL-PLAINI                  TO ERR-PLAINI
           MOVE SAL-PLAFIN                  TO ERR-PLAFIN
           MOVE SAL-EDAINI                  TO ERR-EDAINI
           MOVE SAL-EDAFIN                  TO ERR-EDAFIN
           MOVE SAL-SEGMEN                  TO ERR-SEGMEN
           MOVE SAL-COLECT                  TO ERR-COLECT
           MOVE SAL-ESTVEH                  TO ERR-ESTVEH
           MOVE SAL-TIPVEH                  TO ERR-TIPVEH
      *COL05-I
           MOVE SAL-TIPPERSO                TO ERR-TIPPERSO
           MOVE SAL-RATING                  TO ERR-RATING
           MOVE SAL-RANRATING               TO ERR-RANRATING
           MOVE SAL-GARANTIA                TO ERR-GARANTIA
      *COL05-F
           MOVE SAL-CLUSTE                  TO ERR-CLUSTE.

      *                                                                 00087500
      ***************************************************************** 00101200
      *                    24-CURSOR-UGDTNRA                          * 00101300
      *---------------------------------------------------------------* 00101400
       24-CURSOR-UGDTNRA.
      *
      *COL10-I
           MOVE '0'                               TO WS-VAR-CLUSTER
           EVALUATE WS-VARIABLE
              WHEN CTE-01
              WHEN CTE-06
              WHEN CTE-07
                MOVE ENT-TIPO-PRODUCTO            TO WS01-TIPO-PRODUCTO
                MOVE WS-VARIABLE                  TO WS01-VARIABLE
                MOVE WS-RANGO-INI                 TO WS01-RANGO-INI
                MOVE WS-RANGO-FIN                 TO WS01-RANGO-FIN
                SET INDNRA01                      TO  1                      000
                SEARCH ALL TAB-RANGO                                         000
                  AT END
                     MOVE '0'                     TO WS-VAR-CLUSTER
                  WHEN RNRA-LLAVE(INDNRA01) = WS-LLAVE01                     000
                     MOVE RNRA-CLAVE-ID(INDNRA01) TO WS-VAR-CLUSTER          000
                END-SEARCH                                                   000
              WHEN CTE-04
              WHEN CTE-05
              WHEN CTE-10
              WHEN CTE-12
              WHEN CTE-13
              WHEN CTE-18
              WHEN CTE-23
                MOVE ENT-TIPO-PRODUCTO            TO WS03-TIPO-PRODUCTO
                MOVE WS-VARIABLE                  TO WS03-VARIABLE
                MOVE WS-MONTO-INI                 TO WS03-MONTO-INICIAL
                MOVE WS-MONTO-FIN                 TO WS03-MONTO-FINAL
                SET INDNRA04                      TO  1                      000
                SEARCH ALL TAB-MONTO                                         000
                  AT END
                     MOVE '0'                     TO WS-VAR-CLUSTER
                  WHEN MNRA-LLAVE(INDNRA04) = WS-LLAVE03                     000
                     MOVE MNRA-CLAVE-ID(INDNRA04) TO WS-VAR-CLUSTER          000
                END-SEARCH                                                   000
              WHEN CTE-02
                MOVE ENT-TIPO-PRODUCTO            TO WS02-TIPO-PRODUCTO
                MOVE WS-VARIABLE                  TO WS02-VARIABLE
                MOVE ENT-DOM-NOMINA               TO WS02-AUX
                SET INDNRA02                      TO  1                      000
                SEARCH ALL TAB-NOMINA                                        000
                  AT END
                     MOVE '0'                     TO WS-VAR-CLUSTER
                  WHEN NNRA-LLAVE(INDNRA02) = WS-LLAVE02                     000
                     MOVE NNRA-CLAVE-ID(INDNRA02) TO WS-VAR-CLUSTER          000
                END-SEARCH                                                   000
              WHEN CTE-14
                MOVE ENT-TIPO-PRODUCTO            TO WS02-TIPO-PRODUCTO
                MOVE WS-VARIABLE                  TO WS02-VARIABLE
                MOVE ENT-TIPOVEH                  TO WS02-AUX
                SET INDNRA09                      TO  1                      000
                SEARCH ALL TAB-TIPO-VEH                                      000
                  AT END
                     MOVE '0'                     TO WS-VAR-CLUSTER
                  WHEN TNRA-LLAVE(INDNRA09) = WS-LLAVE02                     000
                     MOVE TNRA-CLAVE-ID(INDNRA09) TO WS-VAR-CLUSTER          000
                END-SEARCH                                                   000
              WHEN CTE-11
                MOVE ENT-TIPO-PRODUCTO            TO WS02-TIPO-PRODUCTO
                MOVE WS-VARIABLE                  TO WS02-VARIABLE
                MOVE ENT-ESTADO-VEH               TO WS02-AUX
                SET INDNRA08                      TO  1                      000
                SEARCH ALL TAB-ESTADO-VEH                                    000
                  AT END
                     MOVE '0'                     TO WS-VAR-CLUSTER
                  WHEN XNRA-LLAVE(INDNRA08) = WS-LLAVE02                     000
                     MOVE XNRA-CLAVE-ID(INDNRA08) TO WS-VAR-CLUSTER          000
                END-SEARCH                                                   000
              WHEN CTE-08
              WHEN CTE-09
              WHEN CTE-16
              WHEN CTE-17
                MOVE ENT-TIPO-PRODUCTO            TO WS04-TIPO-PRODUCTO
                MOVE WS-VARIABLE                  TO WS04-VARIABLE
                MOVE WS-SEGMCOLE                  TO WS04-SEGMENTO
                SET INDNRA05                      TO  1                      000
                SEARCH ALL TAB-SEGMENTO                                      000
                  AT END
                     MOVE '0'                     TO WS-VAR-CLUSTER
                  WHEN SNRA-LLAVE(INDNRA05) = WS-LLAVE04                     000
                     MOVE SNRA-CLAVE-ID(INDNRA05) TO WS-VAR-CLUSTER          000
                END-SEARCH                                                   000
              WHEN CTE-03
                MOVE ENT-TIPO-PRODUCTO            TO WS02-TIPO-PRODUCTO
                MOVE WS-VARIABLE                  TO WS02-VARIABLE
                MOVE ENT-SIT-LABORAL              TO WS02-AUX
                SET INDNRA03                      TO  1                      000
                SEARCH ALL TAB-LABORAL                                       000
                  AT END
                     MOVE '0'                     TO WS-VAR-CLUSTER
                  WHEN LNRA-LLAVE(INDNRA03) = WS-LLAVE02                     000
                     MOVE LNRA-CLAVE-ID(INDNRA03) TO WS-VAR-CLUSTER          000
                END-SEARCH                                                   000
              WHEN CTE-19
                MOVE ENT-TIPO-PRODUCTO            TO WS02-TIPO-PRODUCTO
                MOVE WS-VARIABLE                  TO WS02-VARIABLE
                MOVE WS-TIPOPER                   TO WS02-AUX
                SET INDNRA06                      TO  1                      000
                SEARCH ALL TAB-VIP                                           000
                  AT END
                     MOVE '0'                     TO WS-VAR-CLUSTER
                  WHEN VNRA-LLAVE(INDNRA06) = WS-LLAVE02                     000
                     MOVE VNRA-CLAVE-ID(INDNRA06) TO WS-VAR-CLUSTER          000
                END-SEARCH                                                   000
              WHEN CTE-20
                MOVE ENT-TIPO-PRODUCTO            TO WS05-TIPO-PRODUCTO
                MOVE WS-VARIABLE                  TO WS05-VARIABLE
                MOVE ENT-RATING                   TO WS05-RATING
                SET INDNRA10                      TO  1                      000
                SEARCH ALL TAB-RATING                                        000
                  AT END
                     MOVE '0'                     TO WS-VAR-CLUSTER
                  WHEN GNRA-LLAVE(INDNRA10) = WS-LLAVE05                     000
                     MOVE GNRA-CLAVE-ID(INDNRA10) TO WS-VAR-CLUSTER          000
                END-SEARCH                                                   000
              WHEN CTE-21
                MOVE ENT-TIPO-PRODUCTO            TO WS02-TIPO-PRODUCTO
                MOVE WS-VARIABLE                  TO WS02-VARIABLE
                MOVE ENT-RANGO-RATING             TO WS02-AUX
                SET INDNRA11                      TO  1                      000
                SEARCH ALL TAB-RANGO-RATING                                  000
                  AT END
                     MOVE '0'                     TO WS-VAR-CLUSTER
                  WHEN HNRA-LLAVE(INDNRA11) = WS-LLAVE02                     000
                     MOVE HNRA-CLAVE-ID(INDNRA11) TO WS-VAR-CLUSTER          000
                END-SEARCH                                                   000
              WHEN CTE-22
                MOVE ENT-TIPO-PRODUCTO            TO WS02-TIPO-PRODUCTO
                MOVE WS-VARIABLE                  TO WS02-VARIABLE
                MOVE ENT-GARANTIA                 TO WS02-AUX
                SET INDNRA12                      TO  1                      000
                SEARCH ALL TAB-GARANTIA                                      000
                  AT END
                     MOVE '0'                     TO WS-VAR-CLUSTER
                  WHEN ANRA-LLAVE(INDNRA12) = WS-LLAVE02                     000
                     MOVE ANRA-CLAVE-ID(INDNRA12) TO WS-VAR-CLUSTER          000
                END-SEARCH                                                   000
           END-EVALUATE
           .
      *    MOVE SPACES                 TO ERR-DETALLE
      *    MOVE ENT-TIPO-PRODUCTO      TO NRA-TIPO-PRODUCTO
      *    MOVE WS-VARIABLE            TO NRA-VARIABLE
      *    MOVE 0001                   TO NRA-CONSECUTIVO
      *    MOVE CTE-VS                 TO NRA-ESTADO
      *    SET NO-FIN-CURSOR           TO TRUE
      *    PERFORM 25-ABRIR-CURSOR-NRA
      *    PERFORM 25-FETCH-CURSOR-NRA UNTIL SI-FIN-CURSOR
      *    PERFORM 25-CERRAR-CURSOR-NRA.
      *****************************************************************
      *            ABRIR EL CURSOR DE LA UGDTNRA
      *****************************************************************
      *25-ABRIR-CURSOR-NRA.
      *
      *       EXEC SQL
      *         OPEN CURSOR-NRA
      *       END-EXEC
      *
      *       MOVE SQLCODE            TO DB2-RETURN-CDE
      *       IF DB2-OK
      *         CONTINUE
      *       ELSE
      *         MOVE  'ERROR OPEN CURSOR '           TO ERR-DETALLE     00100600
      *         MOVE  SQLCODE                        TO ERR-SQLCODE     00100700
      *         MOVE 'UGDTNRA'                       TO ERR-TABLERR     00100800
      *         PERFORM 30-ESCRIBIR-RECHAZOS                            00100900
      *       END-IF.
      *****************************************************************
      *         LEER CURSOR DE LA TABLA UGTCNRA
      *****************************************************************
      *25-FETCH-CURSOR-NRA.
      *
      *COL07-I
      *    INITIALIZE WS-FECHA-INI
      *COL07-F
      *      EXEC SQL
      *       FETCH CURSOR-NRA
      *       INTO  :NRA-TIPO-PRODUCTO,
      *             :NRA-VARIABLE,
      *             :NRA-CONSECUTIVO,
      *COL07-I
      *             :NRA-FECHA-INI,
      *COL07-F
      *             :NRA-RANGO-INI,
      *             :NRA-RANGO-FIN,
      *             :NRA-IND-DOM-NOMINA,
      *             :NRA-SITUA-LABORAL,
      *             :NRA-MONTO-INICIAL,
      *             :NRA-MONTO-FINAL,
      *             :NRA-SEGMENTO,
      *             :NRA-IND-CLIENTE-VIP,
      *             :NRA-RANGO-RIESGO-INI,
      *             :NRA-RANGO-RIESGO-FIN,
      *             :NRA-IND-ESTADO-VEH,
      *             :NRA-IND-TIPO-VEH,
      *             :NRA-CLAVE-ID,
      *             :NRA-CLUSTER,
      *COL05-I
      *             :NRA-ESTADO
      *             :NRA-ESTADO,
      *             :NRA-RATING,
      *             :NRA-RANGO-RATING,
      *             :NRA-GARANTIA,
      *             :NRA-PORCENTA
      *COL05-F
      *      END-EXEC
      *     MOVE SQLCODE             TO DB2-RETURN-CDE
      *     IF DB2-OK
      *        COMPUTE
      *           WS-IND = FUNCTION NUMVAL(WS-VARIABLE)
      *        END-COMPUTE
      *        EVALUATE NRA-VARIABLE
      *         WHEN CTE-01
      *         WHEN CTE-06
      *         WHEN CTE-07
      *           IF NRA-RANGO-INI       = WS-RANGO-INI       AND
      *              NRA-RANGO-FIN       = WS-RANGO-FIN                 00164500
      *              MOVE NRA-CLAVE-ID  TO WS-CLAVEID(WS-IND:1)
      *              SET SI-FIN-CURSOR  TO TRUE
      *              IF ENT-CLUSTER (1:2) = CTE-BA
      *COL02-I
      *                 AND SI-MODI-VAR
      *COL02-F
      *                 MOVE NRA-CONSECUTIVO TO CONT-CSC
      *COL07-I
      *                 MOVE NRA-FECHA-INI   TO WS-FECHA-INI
      *COL07-F
      *                 PERFORM 26-UPDATE-UGDTNRA-VAR
      *              END-IF
      *           END-IF
      *         WHEN CTE-04
      *         WHEN CTE-05
      *         WHEN CTE-10
      *         WHEN CTE-12
      *         WHEN CTE-13
      *COL05-I
      *         WHEN CTE-18
      *         WHEN CTE-23
      *COL05-F
      *           IF NRA-MONTO-INICIAL   = WS-MONTO-INI       AND
      *              NRA-MONTO-FINAL     = WS-MONTO-FIN                 00164500
      *              MOVE NRA-CLAVE-ID  TO WS-CLAVEID(WS-IND:1)
      *              SET SI-FIN-CURSOR  TO TRUE
      *              IF ENT-CLUSTER (1:2) = CTE-BA
      *COL02-I
      *                 AND SI-MODI-VAR
      *COL02-F
      *                 MOVE NRA-CONSECUTIVO TO CONT-CSC
      *COL07-I
      *                 MOVE NRA-FECHA-INI   TO WS-FECHA-INI
      *COL07-F
      *                 PERFORM 26-UPDATE-UGDTNRA-VAR
      *              END-IF
      *           END-IF
      *         WHEN CTE-02
      *           IF NRA-IND-DOM-NOMINA  = ENT-DOM-NOMINA
      *              MOVE NRA-CLAVE-ID  TO WS-CLAVEID(WS-IND:1)         00164500
      *              SET SI-FIN-CURSOR  TO TRUE
      *              IF ENT-CLUSTER (1:2) = CTE-BA
      *COL02-I
      *                 AND SI-MODI-VAR
      *COL02-F
      *                 MOVE NRA-CONSECUTIVO TO CONT-CSC
      *COL07-I
      *                 MOVE NRA-FECHA-INI   TO WS-FECHA-INI
      *COL07-F
      *                 PERFORM 26-UPDATE-UGDTNRA-VAR
      *              END-IF
      *           END-IF
      *         WHEN CTE-14
      *           IF NRA-IND-TIPO-VEH    = ENT-TIPOVEH
      *              MOVE NRA-CLAVE-ID  TO WS-CLAVEID(WS-IND:1)         00164500
      *              SET SI-FIN-CURSOR  TO TRUE
      *              IF ENT-CLUSTER (1:2) = CTE-BA
      *COL02-I
      *                 AND SI-MODI-VAR
      *COL02-F
      *                 MOVE NRA-CONSECUTIVO TO CONT-CSC
      *COL07-I
      *                 MOVE NRA-FECHA-INI   TO WS-FECHA-INI
      *COL07-F
      *                 PERFORM 26-UPDATE-UGDTNRA-VAR
      *              END-IF
      *           END-IF
      *         WHEN CTE-11
      *           IF NRA-IND-ESTADO-VEH  = ENT-ESTADO-VEH
      *              MOVE NRA-CLAVE-ID  TO WS-CLAVEID(WS-IND:1)         00164500
      *              SET SI-FIN-CURSOR  TO TRUE
      *              IF ENT-CLUSTER (1:2) = CTE-BA
      *COL02-I
      *                 AND SI-MODI-VAR
      *COL02-F
      *                 MOVE NRA-CONSECUTIVO TO CONT-CSC
      *COL07-I
      *                 MOVE NRA-FECHA-INI   TO WS-FECHA-INI
      *COL07-F
      *                 PERFORM 26-UPDATE-UGDTNRA-VAR
      *              END-IF
      *           END-IF
      *         WHEN CTE-08
      *         WHEN CTE-09
      *COL03-I
      *         WHEN CTE-16
      *         WHEN CTE-17
      *COL03-F
      *           IF NRA-SEGMENTO        = WS-SEGMCOLE
      *              MOVE NRA-CLAVE-ID  TO WS-CLAVEID(WS-IND:1)         00164500
      *              SET SI-FIN-CURSOR  TO TRUE
      *              IF ENT-CLUSTER (1:2) = CTE-BA
      *COL02-I
      *                 AND SI-MODI-VAR
      *COL02-F
      *                 MOVE NRA-CONSECUTIVO TO CONT-CSC
      *COL07-I
      *                 MOVE NRA-FECHA-INI   TO WS-FECHA-INI
      *COL07-F
      *                 PERFORM 26-UPDATE-UGDTNRA-VAR
      *              END-IF
      *           END-IF
      *         WHEN CTE-03
      *           IF NRA-SITUA-LABORAL   = ENT-SIT-LABORAL
      *              MOVE NRA-CLAVE-ID  TO WS-CLAVEID(WS-IND:1)         00164500
      *              SET SI-FIN-CURSOR  TO TRUE
      *              IF ENT-CLUSTER (1:2) = CTE-BA
      *COL02-I
      *                 AND SI-MODI-VAR
      *COL02-F
      *                 MOVE NRA-CONSECUTIVO TO CONT-CSC
      *COL07-I
      *                 MOVE NRA-FECHA-INI   TO WS-FECHA-INI
      *COL07-F
      *                 PERFORM 26-UPDATE-UGDTNRA-VAR
      *              END-IF
      *           END-IF
      *         WHEN CTE-90
      * COL03-I
      *           IF NRA-CLAVE-ID (1:15)  = WS-CLAVEID (1:15)
      *COL05-I
      *           IF NRA-CLAVE-ID (1:17)  = WS-CLAVEID (1:17)
      *           IF NRA-CLAVE-ID (1:23)  = WS-CLAVEID (1:23)
      *COL05-F
      * COL03-F
      *              MOVE NRA-CONSECUTIVO           TO CONT-CSC
      *COL07-I
      *              MOVE NRA-FECHA-INI             TO WS-FECHA-INI
      *COL07-F
      *              SET SI-FIN-CURSOR              TO TRUE
      *              SET SI-EXIS-NRA                TO TRUE
      *           END-IF
      *COL05-I
      *         WHEN CTE-19
      *           IF NRA-IND-CLIENTE-VIP = WS-TIPOPER
      *              MOVE NRA-CLAVE-ID  TO WS-CLAVEID(WS-IND:1)         00164500
      *              SET SI-FIN-CURSOR  TO TRUE
      *              IF ENT-CLUSTER (1:2) = CTE-BA
      *                 AND SI-MODI-VAR
      *                 MOVE NRA-CONSECUTIVO TO CONT-CSC
      *COL07-I
      *                 MOVE NRA-FECHA-INI   TO WS-FECHA-INI
      *COL07-F
      *                 PERFORM 26-UPDATE-UGDTNRA-VAR
      *              END-IF
      *           END-IF
      *         WHEN CTE-20
      *           IF NRA-RATING = ENT-RATING
      *              MOVE NRA-CLAVE-ID  TO WS-CLAVEID(WS-IND:1)         00164500
      *              SET SI-FIN-CURSOR  TO TRUE
      *              IF ENT-CLUSTER (1:2) = CTE-BA
      *                 AND SI-MODI-VAR
      *                 MOVE NRA-CONSECUTIVO TO CONT-CSC
      *COL07-I
      *                 MOVE NRA-FECHA-INI   TO WS-FECHA-INI
      *COL07-F
      *                 PERFORM 26-UPDATE-UGDTNRA-VAR
      *              END-IF
      *           END-IF
      *         WHEN CTE-21
      *           IF NRA-RANGO-RATING = ENT-RANGO-RATING
      *              MOVE NRA-CLAVE-ID  TO WS-CLAVEID(WS-IND:1)         00164500
      *              SET SI-FIN-CURSOR  TO TRUE
      *              IF ENT-CLUSTER (1:2) = CTE-BA
      *                 AND SI-MODI-VAR
      *                 MOVE NRA-CONSECUTIVO TO CONT-CSC
      *COL07-I
      *                 MOVE NRA-FECHA-INI   TO WS-FECHA-INI
      *COL07-F
      *                 PERFORM 26-UPDATE-UGDTNRA-VAR
      *              END-IF
      *           END-IF
      *         WHEN CTE-22
      *           IF NRA-GARANTIA = ENT-GARANTIA
      *              MOVE NRA-CLAVE-ID  TO WS-CLAVEID(WS-IND:1)         00164500
      *              SET SI-FIN-CURSOR  TO TRUE
      *              IF ENT-CLUSTER (1:2) = CTE-BA
      *                 AND SI-MODI-VAR
      *                 MOVE NRA-CONSECUTIVO TO CONT-CSC
      *COL07-I
      *                 MOVE NRA-FECHA-INI   TO WS-FECHA-INI
      *COL07-F
      *                 PERFORM 26-UPDATE-UGDTNRA-VAR
      *              END-IF
      *           END-IF
      *COL05-F
      *         WHEN OTHER
      *              SET SI-FIN-CURSOR              TO TRUE
      *        END-EVALUATE
      *     ELSE
      *      IF  DB2-NOTFND
      *          SET SI-FIN-CURSOR                   TO TRUE
      *      ELSE
      *         MOVE  'ERROR FETCH CURSOR '          TO ERR-DETALLE     00100600
      *         MOVE  SQLCODE                        TO ERR-SQLCODE     00100700
      *         MOVE 'UGDTNRA'                       TO ERR-TABLERR     00100800
      *         PERFORM 30-ESCRIBIR-RECHAZOS                            00100900
      *         SET SI-FIN-CURSOR                    TO TRUE
      *      END-IF
      *     END-IF.
      *
      ******************************************************************
      *                     CERRAR EL CURSOR DE LA UGDTTDF             *
      ******************************************************************
      *25-CERRAR-CURSOR-NRA.
      *
      *     EXEC SQL
      *          CLOSE CURSOR-NRA
      *     END-EXEC
      *     MOVE SQLCODE            TO DB2-RETURN-CDE
      *     IF DB2-OK
      *          CONTINUE
      *     ELSE
      *         MOVE  'ERROR CLOSE CURSOR '          TO ERR-DETALLE     00100600
      *         MOVE  SQLCODE                        TO ERR-SQLCODE     00100700
      *         MOVE 'UGDTNRA'                       TO ERR-TABLERR     00100800
      *         PERFORM 30-ESCRIBIR-RECHAZOS                            00100900
      *     END-IF.
      *                                                                 00169400
      ******************************************************************00152200
      *                     26-UPDATE-UGDTNRA                           00152300
      ******************************************************************00152400
      *                                                                 00152500
      *26-UPDATE-UGDTNRA.                                               00152600
      *                                                                 00152700
      *    INITIALIZE UGTCNRA ERR-DETALLE
      *    MOVE ENT-TIPO-PRODUCTO               TO NRA-TIPO-PRODUCTO
      *    MOVE CTE-90                          TO NRA-VARIABLE
      *    MOVE CONT-CSC                        TO NRA-CONSECUTIVO
      *COL07-I
      *    MOVE WS-FECHA-INI                    TO NRA-FECHA-INI
      *COL07-F
      *COL03-I
      *    MOVE WS-CLAVEID (1:15)               TO NRA-CLAVE-ID
      *COL05-I
      *    MOVE WS-CLAVEID (1:17)               TO NRA-CLAVE-ID
      *    MOVE WS-CLAVEID (1:23)               TO NRA-CLAVE-ID
      *    MOVE WS-PE                           TO NRA-PORCENTA
      *    MOVE WS-RORC                         TO NRA-RANGO-RIESGO-INI
      *    MOVE WS-RAROEC                       TO NRA-RANGO-RIESGO-FIN
      *    MOVE WS-CAPITAL-ECON                 TO NRA-MONTO-INICIAL
      *COL05-F
      *COL03-F
      *    MOVE WS-NUMERO2                      TO NRA-TASA
      *    MOVE '0013'                          TO NRA-CENTRO-UMO       154200
      *    MOVE 'UG4CRAR2'                      TO NRA-USERID-UMO       154300
      *    MOVE 'RAR2'                          TO NRA-NETNAME-UMO      154400
      *    MOVE CTE-VS                          TO NRA-ESTADO
      *    IF ENT-CLUSTER (1:2) = CTE-BA
      *       MOVE W-FECHA-DIS                  TO NRA-FECHA-FIN
      *       MOVE CTE-BA                       TO NRA-ESTADO
      *    ELSE
      *       MOVE ENT-CLUSTER                  TO NRA-CLUSTER
      *       MOVE CTE-FECFIN                   TO NRA-FECHA-FIN
      *    END-IF
      *
      *    EXEC SQL                                                     1546
      *         UPDATE UGDTNRA                                          1547
      *         SET NRA_TASA        = :NRA-TASA,
      *             NRA_CENTRO_UMO  = :NRA-CENTRO-UMO,
      *             NRA_CLAVE_ID    = :NRA-CLAVE-ID,
      *             NRA_NETNAME_UMO = :NRA-NETNAME-UMO,
      *             NRA_USERID_UMO  = :NRA-USERID-UMO,
      *             NRA_FECHA_FIN   = :NRA-FECHA-FIN,
      *             NRA_ESTADO      = :NRA-ESTADO,
      *             NRA_TIMESTAMP   = CURRENT TIMESTAMP
      *       WHERE NRA_TIPO_PRODUCTO = :NRA-TIPO-PRODUCTO AND          1034
      *             NRA_VARIABLE      = :NRA-VARIABLE      AND
      *             NRA_CONSECUTIVO   = :NRA-CONSECUTIVO
      *COL07-I
      *         AND NRA_FECHA_INI     = :NRA-FECHA-INI
      *COL07-F
      *    END-EXEC                                                     1612
      *    MOVE SQLCODE                            TO DB2-RETURN-CDE    00161400
      *    IF DB2-OK                                                    00161500
      *       ADD  1                               TO CONT-ACTUALIZA    00161600
      *       PERFORM 31-ESCRIBIR-ACEPTADOS
      *    ELSE                                                         00161800
      *         IF DB2-NODISP  OR DB2-ATRAPA                            00162000
      *             DISPLAY 'ERROR UPDATE UGDTNRA ' SQLCODE             00162100
      *             DISPLAY ' UGDTNRA NO DISPONIBLE'                    00162200
      *             PERFORM 3-FINAL                                     00162400
      *             PERFORM 000500-HACER-COMMIT                         00162500
      *             STOP RUN                                            00162700
      *           ELSE                                                  00162800
      *             MOVE 'ERROR UPDATE UGDTNRA'          TO ERR-DETALLE 00163100
      *             MOVE SQLCODE                         TO ERR-SQLCODE 00163200
      *             MOVE 'UGDTNRA'                       TO ERR-TABLERR 00163300
      *             PERFORM 30-ESCRIBIR-RECHAZOS                        00163400
      *        END-IF                                                   00163500
      *    END-IF.                                                      00163700
      *                                                                 00169400
      ******************************************************************00152200
      *                     26-UPDATE-UGDTNRA-VAR                       00152300
      *                     ACTUALIZA BAJA POR VARIABLE                 00152300
      ******************************************************************00152400
      *                                                                 00152500
      *26-UPDATE-UGDTNRA-VAR.                                           00152600
      *                                                                 00152700
      *    INITIALIZE UGTCNRA ERR-DETALLE
      *    MOVE ENT-TIPO-PRODUCTO               TO NRA-TIPO-PRODUCTO
      *    MOVE WS-VARIABLE                     TO NRA-VARIABLE
      *    MOVE CONT-CSC                        TO NRA-CONSECUTIVO
      *COL07-I
      *    MOVE WS-FECHA-INI                    TO NRA-FECHA-INI
      *COL07-F
      *    MOVE '0013'                          TO NRA-CENTRO-UMO       154200
      *    MOVE 'UG4CRAR2'                      TO NRA-USERID-UMO       154300
      *    MOVE 'RAR2'                          TO NRA-NETNAME-UMO      154400
      *    MOVE W-FECHA-DIS                     TO NRA-FECHA-FIN
      *    MOVE CTE-BA                          TO NRA-ESTADO
      *
      *    EXEC SQL                                                     1546
      *         UPDATE UGDTNRA                                          1547
      *         SET
      *             NRA_CENTRO_UMO  = :NRA-CENTRO-UMO,
      *             NRA_NETNAME_UMO = :NRA-NETNAME-UMO,
      *             NRA_USERID_UMO  = :NRA-USERID-UMO,
      *             NRA_FECHA_FIN   = :NRA-FECHA-FIN,
      *             NRA_ESTADO      = :NRA-ESTADO,
      *             NRA_TIMESTAMP   = CURRENT TIMESTAMP
      *       WHERE NRA_TIPO_PRODUCTO = :NRA-TIPO-PRODUCTO AND          1034
      *             NRA_VARIABLE      = :NRA-VARIABLE      AND
      *             NRA_CONSECUTIVO   = :NRA-CONSECUTIVO
      *COL07-I
      *         AND NRA_FECHA_INI     = :NRA-FECHA-INI
      *COL07-F
      *    END-EXEC                                                     1612
      *    MOVE SQLCODE                            TO DB2-RETURN-CDE    00161400
      *    IF DB2-OK                                                    00161500
      *       ADD  1                               TO CONT-ACTUALIZA    00161600
      *       PERFORM 31-ESCRIBIR-ACEPTADOS
      *    ELSE                                                         00161800
      *         IF DB2-NODISP  OR DB2-ATRAPA                            00162000
      *             DISPLAY 'ERROR UPDATE UGDTNRA2' SQLCODE             00162100
      *             DISPLAY ' UGDTNRA NO DISPONIBLE'                    00162200
      *             PERFORM 3-FINAL                                     00162400
      *             PERFORM 000500-HACER-COMMIT                         00162500
      *             STOP RUN                                            00162700
      *           ELSE                                                  00162800
      *             MOVE 'ERROR UPDATE UGDTNRA'          TO ERR-DETALLE 00163100
      *             MOVE SQLCODE                         TO ERR-SQLCODE 00163200
      *             MOVE 'UGDTNRA'                       TO ERR-TABLERR 00163300
      *             PERFORM 30-ESCRIBIR-RECHAZOS                        00163400
      *        END-IF                                                   00163500
      *    END-IF.                                                      00163700
      *COL10-F
      *                                                                 00169400
      ******************************************************************00152200
      *                     27-INSERT-UGDTNRA                           00152300
      ******************************************************************00152400
      *                                                                 00152500
       27-INSERT-UGDTNRA.                                               00152600
      *                                                                 00152700
           INITIALIZE UGTCNRA ERR-DETALLE
      *COL08-I
           IF ENT-TIPO-PRODUCTO NOT EQUAL WS-TPROD-AUX
             MOVE 1                             TO CONT-CSC
             MOVE ENT-TIPO-PRODUCTO             TO WS-TPROD-AUX
           ELSE
             ADD 1                              TO CONT-CSC
           END-IF
      *COL08-F
           MOVE ENT-TIPO-PRODUCTO               TO NRA-TIPO-PRODUCTO
           MOVE CTE-90                          TO NRA-VARIABLE
           MOVE CONT-CSC                        TO NRA-CONSECUTIVO
           MOVE ENT-CLUSTER                     TO NRA-CLUSTER
      *COL03-I
      *    MOVE WS-CLAVEID(1:15)                TO NRA-CLAVE-ID
      *COL05-I
      *    MOVE WS-CLAVEID(1:17)                TO NRA-CLAVE-ID
           MOVE WS-CLAVEID(1:23)                TO NRA-CLAVE-ID
           MOVE WS-PE                           TO NRA-PORCENTA
           MOVE WS-RORC                         TO NRA-RANGO-RIESGO-INI
           MOVE WS-RAROEC                       TO NRA-RANGO-RIESGO-FIN
           MOVE WS-CAPITAL-ECON                 TO NRA-MONTO-INICIAL
      *COL05-F
      *COL03-F
           MOVE WS-NUMERO2                      TO NRA-TASA
           MOVE '0013'                          TO NRA-CENTRO-UMO       154200
           MOVE 'UG4CRAR2'                      TO NRA-USERID-UMO       154300
           MOVE 'RAR2'                          TO NRA-NETNAME-UMO      154400
           MOVE W-FECHA-DIS                     TO NRA-FECHA-INI
           MOVE CTE-FECFIN                      TO NRA-FECHA-FIN
           MOVE CTE-VS                          TO NRA-ESTADO
      *COL10-I
           PERFORM 15-OBTENER-FECHA
           MOVE CURRENT-TIMESTAMP               TO NRA-TIMESTAMP
           ADD  1                               TO CONT-GRABADOS        00161600
           PERFORM 30-ESCRIBIR-SUGDTNRA
           PERFORM 31-ESCRIBIR-ACEPTADOS
           .
      *    EXEC SQL
      *           INSERT INTO UGDTNRA
      *             (NRA_TIPO_PRODUCTO,
      *              NRA_VARIABLE,
      *              NRA_CONSECUTIVO,
      *              NRA_FECHA_INI,
      *              NRA_FECHA_FIN,
      *              NRA_RANGO_INI,
      *              NRA_RANGO_FIN,
      *              NRA_IND_DOM_NOMINA,
      *              NRA_SITUA_LABORAL,
      *              NRA_MONTO_INICIAL,
      *              NRA_MONTO_FINAL,
      *              NRA_SEGMENTO,
      *              NRA_IND_CLIENTE_VIP,
      *              NRA_RANGO_RIESGO_INI,
      *              NRA_RANGO_RIESGO_FIN,
      *              NRA_IND_ESTADO_VEH,
      *              NRA_IND_TIPO_VEH,
      *              NRA_CLAVE_ID,
      *              NRA_CLUSTER,
      *              NRA_ESTADO,
      *              NRA_TASA,
      *              NRA_CENTRO_UMO,
      *              NRA_USERID_UMO,
      *              NRA_NETNAME_UMO,
      *COL05-I
      *              NRA_TIMESTAMP)
      *              NRA_TIMESTAMP,
      *              NRA_RATING,
      *              NRA_RANGO_RATING,
      *              NRA_GARANTIA,
      *              NRA_PORCENTA)
      *COL05-F
      *         VALUES (:NRA-TIPO-PRODUCTO,
      *             :NRA-VARIABLE,
      *             :NRA-CONSECUTIVO,
      *             :NRA-FECHA-INI,
      *             :NRA-FECHA-FIN,
      *             :NRA-RANGO-INI,
      *             :NRA-RANGO-FIN,
      *             :NRA-IND-DOM-NOMINA,
      *             :NRA-SITUA-LABORAL,
      *             :NRA-MONTO-INICIAL,
      *             :NRA-MONTO-FINAL,
      *             :NRA-SEGMENTO,
      *             :NRA-IND-CLIENTE-VIP,
      *             :NRA-RANGO-RIESGO-INI,
      *             :NRA-RANGO-RIESGO-FIN,
      *             :NRA-IND-ESTADO-VEH,
      *             :NRA-IND-TIPO-VEH,
      *             :NRA-CLAVE-ID,
      *             :NRA-CLUSTER,
      *             :NRA-ESTADO,
      *             :NRA-TASA,
      *             :NRA-CENTRO-UMO,
      *             :NRA-USERID-UMO,
      *             :NRA-NETNAME-UMO,
      *COL05-I
      *              CURRENT TIMESTAMP)
      *              CURRENT TIMESTAMP,
      *             :NRA-RATING,
      *             :NRA-RANGO-RATING,
      *             :NRA-GARANTIA,
      *             :NRA-PORCENTA)
      *COL05-F
      *    END-EXEC
      *    MOVE SQLCODE                            TO DB2-RETURN-CDE    00161400
      *    IF DB2-OK                                                    00161500
      *       ADD  1                               TO CONT-GRABADOS     00161600
      *       PERFORM 31-ESCRIBIR-ACEPTADOS
      *    ELSE                                                         00161800
      *         IF DB2-NODISP  OR DB2-ATRAPA                            00162000
      *             DISPLAY 'ERROR INSERT UGDTNRA ' SQLCODE             00162100
      *             DISPLAY ' UGDTNRA NO DISPONIBLE'                    00162200
      *             PERFORM 3-FINAL                                     00162400
      *             PERFORM 000500-HACER-COMMIT                         00162500
      *             STOP RUN                                            00162700
      *           ELSE                                                  00162800
      *             MOVE 'ERROR INSERT UGDTNRA'          TO ERR-DETALLE 00163100
      *             MOVE SQLCODE                         TO ERR-SQLCODE 00163200
      *             MOVE 'UGDTNRA'                       TO ERR-TABLERR 00163300
      *             PERFORM 30-ESCRIBIR-RECHAZOS                        00163400
      *        END-IF                                                   00163500
      *    END-IF.                                                      00163700
      *                                                                 00169400
      ******************************************************************00152200
      *                     28-VALIDA-UGDTNRA                           00152300
      ******************************************************************00152400
      *                                                                 00152500
      *28-VALIDA-UGDTNRA.                                               00152600
      *                                                                 00152700
      *    INITIALIZE UGTCNRA ERR-DETALLE
      *    MOVE ENT-TIPO-PRODUCTO               TO NRA-TIPO-PRODUCTO
      *    MOVE WS-VARIABLE                     TO NRA-VARIABLE
      *    MOVE ZEROS                           TO WS-CONTA-REGS        00094200
      *    SET NO-EXIS-NRA                      TO TRUE                 00094300
      *      EXEC SQL                                                   00094400
      *           SELECT COUNT(*)                                       00094500
      *           INTO   :WS-CONTA-REGS                                 00094600
      *           FROM   UGDTNRA                                        00094800
      *           WHERE NRA_TIPO_PRODUCTO = :NRA-TIPO-PRODUCTO  AND     00094900
      *                 NRA_VARIABLE      = :NRA-VARIABLE               00094900
      *                                                                 00095000
      *      END-EXEC                                                   00095100
      *                                                                 00095200
      *    MOVE  SQLCODE                          TO DB2-RETURN-CDE     00095300
      *                                                                 00095400
      *    IF DB2-OK                                                    00095500
      *       IF WS-CONTA-REGS > ZEROS                                  00095600
      *          MOVE WS-CONTA-REGS               TO CONT-CSC
      *          ADD 1                            TO CONT-CSC
      *          SET SI-EXIS-NRA                  TO TRUE               00072400
      *       ELSE
      *COL01-I
      *          MOVE  'NO EXISTE EN UGDTNRA'     TO ERR-DETALLE        97400
      *          MOVE  SQLCODE                    TO ERR-SQLCODE        97500
      *          MOVE 'UGDTNRA'                   TO ERR-TABLERR        97600
      *          PERFORM 30-ESCRIBIR-RECHAZOS                           97700
      *COL01-F
      *          ADD 1                            TO CONT-CSC
      *          SET NO-EXIS-NRA                  TO TRUE               00072400
      *       END-IF                                                    00096000
      *    ELSE                                                         00096100
      *       IF DB2-NOTFND                                             00096200
      *          ADD 1                            TO CONT-CSC
      *          SET NO-EXIS-NRA                  TO TRUE               00072400
      *       ELSE                                                      00096400
      *         IF DB2-NODISP  OR DB2-ATRAPA                            00096500
      *          DISPLAY 'ERROR UPDATE UGDTNRA ' SQLCODE                00096600
      *          DISPLAY 'UGDTNRA NO DISPONIBLE'                        00096700
      *          PERFORM 3-FINAL                                        00096900
      *          PERFORM 000500-HACER-COMMIT                            00097000
      *          STOP RUN                                               00097200
      *         ELSE                                                    00097300
      *             MOVE  'ERROR SELECT UGDTNRA'  TO ERR-DETALLE        00097400
      *             MOVE  SQLCODE                 TO ERR-SQLCODE        00097500
      *             MOVE 'UGDTNRA'                TO ERR-TABLERR        00097600
      *             PERFORM 30-ESCRIBIR-RECHAZOS                        00097700
      *         END-IF                                                  00097800
      *       END-IF                                                    00097900
      *    END-IF.                                                      00098000
      ******************************************************************00179000
      *                   30-ESCRIBIR-RECHAZOS                          00179100
      ******************************************************************00179200
      *                                                                 00179300
      *
       30-ESCRIBIR-SUGDTNRA.                                            00179400
      *                                                                 00179500
           ADD 1                                   TO CONT-SUGDTNRA     00179800
           WRITE REG-SUGDTNRA   FROM UGTCNRA  END-WRITE.                00179900
           IF W-ESTADO NOT EQUAL CTE-00
              DISPLAY 'ERROR ESCRIBIENDO SUGDTNRA: ' W-ESTADO
              MOVE CTE-RETURNCDE TO RETURN-CODE
              PERFORM 3-FINAL
              STOP RUN
           END-IF.                                                      00191400
      *                                                                 00180100
      *COL10-F
      *                                                                 00178900
      ******************************************************************00179000
      *                   30-ESCRIBIR-RECHAZOS                          00179100
      ******************************************************************00179200
      *                                                                 00179300
      *
       30-ESCRIBIR-RECHAZOS.                                            00179400
      *                                                                 00179500
           ADD 1                                   TO CONT-ERRORES      00179800
           WRITE REG-ERR   FROM   REG-ERRORES END-WRITE.                00179900
           IF W-ESTADO NOT EQUAL CTE-00
              DISPLAY CTE-ERROR-WRITE-CONTROL W-ESTADO
              MOVE CTE-RETURNCDE TO RETURN-CODE
              PERFORM 3-FINAL
              STOP RUN
           END-IF.                                                      00191400
                                                                        00180000
      *                                                                 00180100
      ******************************************************************00180200
      *                      31-ESCRIBIR-ACEPTADOS                      00180300
      ******************************************************************00180400
      *                                                                 00180500
       31-ESCRIBIR-ACEPTADOS.                                           00180600
      *                                                                 00180700
           WRITE REG-SAL  FROM  REG-SALIDA  END-WRITE.                  00180900
           IF W-ESTADO NOT EQUAL CTE-00
              DISPLAY CTE-ERROR-WRITE-CONTROL W-ESTADO
              MOVE CTE-RETURNCDE TO RETURN-CODE
              PERFORM 3-FINAL
              STOP RUN
           END-IF.                                                      00191400
      *                                                                 00191400
      ******************************************************************00191500
      *                              3-FINAL                           *00191600
      ******************************************************************00191700
      *                                                                 00191800
       3-FINAL.                                                         00191900
           DISPLAY '************FINAL DEL PROGRAMA UG2CRAR2*********'   00195100
COL02      DISPLAY 'PAR. TIPO         :' WS-PARM-TIPO                   00195200
COL10      DISPLAY 'REG. LEIDOS UNRA  :' CONT-TNRA                      00195200
           DISPLAY 'REG. LEIDOS       :' CONT-NRA                       00195200
           DISPLAY 'REG. GRABADOS     :' CONT-GRABADOS                  00195300
COL10      DISPLAY 'REG. ESCRITOS UNRA  :' CONT-TNRA                    00195200
           DISPLAY 'REG. ACTUALIZADOS :' CONT-ACTUALIZA                 00195300
           DISPLAY 'REG. ERRORES      :' CONT-ERRORES                   00195500
      * COL03-I
           DISPLAY 'UPDATE ID CLUSTER :' CONT-UPDATE
           DISPLAY '************************************************'   00195100
      * COL03-F
      *COL08-I
           IF CONT-ERRORES > 0
             MOVE 04            TO RETURN-CODE
           END-IF
      *COL08-F
           CLOSE  EUGDNRA                                               00195900
COL10             EUGDTNRA                                              00195900
COL10             SUGDTNRA                                              00195900
                  SALIDA                                                00196000
                  ERRORES                                               00196100
COL10      STOP RUN.
      * -------------------------------------------------------------- *
      * COL03-I
      *COL10-I
      *9999-UPDATECLUSTER.
      *    SET NO-FIN-CURSO1    TO TRUE
      *    MOVE CTE-90          TO NRA-VARIABLE
      *    MOVE 0001            TO NRA-CONSECUTIVO
      *    MOVE CTE-VS          TO NRA-ESTADO
      *    INITIALIZE           NRA-CLAVE-ID
      *    PERFORM 9999-ABRECURSOR-NR1
      *    PERFORM 9999-FECHCURSOR-NR1 UNTIL SI-FIN-CURSO1
      *    PERFORM 9999-CLOSCURSOR-NR1
      *    .
      * -------------------------------------------------------------- *
      *9999-ABRECURSOR-NR1.
      *
      *       EXEC SQL
      *         OPEN CURSOR-NR1
      *       END-EXEC
      *
      *       MOVE SQLCODE            TO DB2-RETURN-CDE
      *       IF DB2-OK
      *         CONTINUE
      *       ELSE
      *         MOVE  'ERROR OPEN CURSOR '           TO ERR-DETALLE     00100600
      *         MOVE  SQLCODE                        TO ERR-SQLCODE     00100700
      *         MOVE 'UGDTNRA'                       TO ERR-TABLERR     00100800
      *         PERFORM 30-ESCRIBIR-RECHAZOS                            00100900
      *       END-IF.
      *    .
      * -------------------------------------------------------------- *
      *9999-FECHCURSOR-NR1.
      *
      *      EXEC SQL
      *       FETCH CURSOR-NR1
      *       INTO  :NRA-TIPO-PRODUCTO,
      *             :NRA-VARIABLE,
      *             :NRA-CONSECUTIVO,
      *             :NRA-CLAVE-ID
      *      END-EXEC
      *     MOVE SQLCODE             TO DB2-RETURN-CDE
      *     IF DB2-OK
      *        ADD 1            TO CONT-NRA
      *        IF NRA-CLAVE-ID (16:2)  = SPACES
      *           PERFORM 9999-GRABA-CONVDEST
      *        END-IF
      *     ELSE
      *        IF DB2-NOTFND
      *           SET SI-FIN-CURSO1           TO TRUE
      *        ELSE
      *           MOVE  'ERROR FETCH CURSOR1' TO ERR-DETALLE            00100600
      *           MOVE  SQLCODE               TO ERR-SQLCODE            00100700
      *           MOVE 'UGDTNRA'              TO ERR-TABLERR            00100800
      *           PERFORM 30-ESCRIBIR-RECHAZOS                          00100900
      *           SET SI-FIN-CURSOR           TO TRUE
      *        END-IF
      *     END-IF
      *    .
      * -------------------------------------------------------------- *
      *9999-CLOSCURSOR-NR1.
      *
      *     EXEC SQL
      *          CLOSE CURSOR-NR1
      *     END-EXEC
      *     MOVE SQLCODE            TO DB2-RETURN-CDE
      *     IF DB2-OK
      *          CONTINUE
      *     ELSE
      *         MOVE  'ERROR CLOSE CURSOR1'          TO ERR-DETALLE     00100600
      *         MOVE  SQLCODE                        TO ERR-SQLCODE     00100700
      *         MOVE 'UGDTNRA'                       TO ERR-TABLERR     00100800
      *         PERFORM 30-ESCRIBIR-RECHAZOS                            00100900
      *     END-IF.
      * -------------------------------------------------------------- *
      *9999-GRABA-CONVDEST.
      *    MOVE ZEROS           TO NRA-CLAVE-ID (16:2)
      *    EXEC SQL                                                     1546
      *         UPDATE UGDTNRA                                          1547
      *         SET NRA_CLAVE_ID    = :NRA-CLAVE-ID
      *       WHERE NRA_TIPO_PRODUCTO = :NRA-TIPO-PRODUCTO AND
      *             NRA_VARIABLE      = :NRA-VARIABLE      AND
      *             NRA_CONSECUTIVO   = :NRA-CONSECUTIVO
      *    END-EXEC                                                     1612
      *    MOVE SQLCODE                            TO DB2-RETURN-CDE    00161400
      *    IF DB2-OK                                                    00161500
      *       ADD 1             TO CONT-UPDATE
      *    ELSE                                                         00161800
      *         IF DB2-NODISP  OR DB2-ATRAPA                            00162000
      *             DISPLAY 'ERROR UPDATE UGDTNRA ' SQLCODE             00162100
      *             DISPLAY ' UGDTNRA NO DISPONIBLE'                    00162200
      *             PERFORM 3-FINAL                                     00162400
      *             PERFORM 000500-HACER-COMMIT                         00162500
      *             STOP RUN                                            00162700
      *           ELSE                                                  00162800
      *             MOVE 'ERROR UPDATE UGDTNRA'          TO ERR-DETALLE 00163100
      *             MOVE SQLCODE                         TO ERR-SQLCODE 00163200
      *             MOVE 'UGDTNRA'                       TO ERR-TABLERR 00163300
      *             PERFORM 30-ESCRIBIR-RECHAZOS                        00163400
      *        END-IF                                                   00163500
      *    END-IF.                                                      00163700
      * COL03-F
      * -------------------------------------------------------------- *
      *                  SE CARGAN LAS TABLAS DE MEMORIA               *
      * -------------------------------------------------------------- *
        1B-CARGA-TABLA.
      *
           EVALUATE ENRA-VARIABLE
              WHEN CTE-01
                SET SI-VAR-01       TO TRUE
              WHEN CTE-02
                SET SI-VAR-02       TO TRUE
              WHEN CTE-03
                SET SI-VAR-03       TO TRUE
              WHEN CTE-04
                SET SI-VAR-04       TO TRUE
              WHEN CTE-05
                SET SI-VAR-05       TO TRUE
              WHEN CTE-06
                SET SI-VAR-06       TO TRUE
              WHEN CTE-07
                SET SI-VAR-07       TO TRUE
              WHEN CTE-08
                SET SI-VAR-08       TO TRUE
              WHEN CTE-09
                SET SI-VAR-09       TO TRUE
              WHEN CTE-10
                SET SI-VAR-10       TO TRUE
              WHEN CTE-11
                SET SI-VAR-11       TO TRUE
              WHEN CTE-12
                SET SI-VAR-12       TO TRUE
              WHEN CTE-13
                SET SI-VAR-13       TO TRUE
              WHEN CTE-14
                SET SI-VAR-14       TO TRUE
              WHEN CTE-15
                SET SI-VAR-15       TO TRUE
              WHEN CTE-16
                SET SI-VAR-16       TO TRUE
              WHEN CTE-17
                SET SI-VAR-17       TO TRUE
              WHEN CTE-18
                SET SI-VAR-18       TO TRUE
              WHEN CTE-19
                SET SI-VAR-19       TO TRUE
              WHEN CTE-20
                SET SI-VAR-20       TO TRUE
              WHEN CTE-21
                SET SI-VAR-21       TO TRUE
              WHEN CTE-22
                SET SI-VAR-22       TO TRUE
              WHEN CTE-23
                SET SI-VAR-23       TO TRUE
           END-EVALUATE
           EVALUATE ENRA-VARIABLE
              WHEN CTE-01
              WHEN CTE-06
              WHEN CTE-07
                ADD 1               TO CONT-TNRA01
                SET INDNRA01        TO CONT-TNRA01
                MOVE ENRA-TIPO-PRODUCTO
                                    TO RNRA-TIPO-PRODUCTO(CONT-TNRA01)
                MOVE ENRA-VARIABLE  TO RNRA-VARIABLE(CONT-TNRA01)
                MOVE ENRA-RANGO-INI TO RNRA-RANGO-INI(CONT-TNRA01)
                MOVE ENRA-RANGO-FIN TO RNRA-RANGO-FIN(CONT-TNRA01)
                MOVE ENRA-CLAVE-ID  TO RNRA-CLAVE-ID(CONT-TNRA01)
              WHEN CTE-04
              WHEN CTE-05
              WHEN CTE-10
              WHEN CTE-12
              WHEN CTE-13
              WHEN CTE-18
              WHEN CTE-23
                ADD 1               TO CONT-TNRA04
                SET INDNRA04        TO CONT-TNRA04
                MOVE ENRA-TIPO-PRODUCTO
                                    TO MNRA-TIPO-PRODUCTO(CONT-TNRA04)
                MOVE ENRA-VARIABLE  TO MNRA-VARIABLE(CONT-TNRA04)
                MOVE ENRA-MONTO-INICIAL
                                    TO MNRA-MONTO-INICIAL(CONT-TNRA04)
                MOVE ENRA-MONTO-FINAL TO MNRA-MONTO-FINAL(CONT-TNRA04)
                MOVE ENRA-CLAVE-ID  TO MNRA-CLAVE-ID(CONT-TNRA04)
              WHEN CTE-02
                ADD 1               TO CONT-TNRA02
                SET INDNRA02        TO CONT-TNRA02
                MOVE ENRA-TIPO-PRODUCTO
                                    TO NNRA-TIPO-PRODUCTO(CONT-TNRA02)
                MOVE ENRA-VARIABLE  TO NNRA-VARIABLE(CONT-TNRA02)
                MOVE ENRA-IND-DOM-NOMINA
                                    TO NNRA-IND-DOM-NOMINA(CONT-TNRA02)
                MOVE ENRA-CLAVE-ID  TO NNRA-CLAVE-ID(CONT-TNRA02)
              WHEN CTE-14
                ADD 1               TO CONT-TNRA09
                SET INDNRA09        TO CONT-TNRA09
                MOVE ENRA-TIPO-PRODUCTO
                                    TO TNRA-TIPO-PRODUCTO(CONT-TNRA09)
                MOVE ENRA-VARIABLE  TO TNRA-VARIABLE(CONT-TNRA09)
                MOVE ENRA-IND-TIPO-VEH
                                    TO TNRA-IND-TIPO-VEH(CONT-TNRA09)
                MOVE ENRA-CLAVE-ID  TO TNRA-CLAVE-ID(CONT-TNRA09)
              WHEN CTE-11
                ADD 1               TO CONT-TNRA08
                SET INDNRA08        TO CONT-TNRA08
                MOVE ENRA-TIPO-PRODUCTO
                                    TO XNRA-TIPO-PRODUCTO(CONT-TNRA08)
                MOVE ENRA-VARIABLE  TO XNRA-VARIABLE(CONT-TNRA08)
                MOVE ENRA-IND-ESTADO-VEH
                                    TO XNRA-IND-ESTADO-VEH(CONT-TNRA08)
                MOVE ENRA-CLAVE-ID  TO XNRA-CLAVE-ID(CONT-TNRA08)
              WHEN CTE-08
              WHEN CTE-09
              WHEN CTE-16
              WHEN CTE-17
                ADD 1               TO CONT-TNRA05
                SET INDNRA05        TO CONT-TNRA05
                MOVE ENRA-TIPO-PRODUCTO
                                    TO SNRA-TIPO-PRODUCTO(CONT-TNRA05)
                MOVE ENRA-VARIABLE  TO SNRA-VARIABLE(CONT-TNRA05)
                MOVE ENRA-SEGMENTO  TO SNRA-SEGMENTO(CONT-TNRA05)
                MOVE ENRA-CLAVE-ID  TO SNRA-CLAVE-ID(CONT-TNRA05)
              WHEN CTE-03
                ADD 1               TO CONT-TNRA03
                SET INDNRA03        TO CONT-TNRA03
                MOVE ENRA-TIPO-PRODUCTO
                                    TO LNRA-TIPO-PRODUCTO(CONT-TNRA03)
                MOVE ENRA-VARIABLE  TO LNRA-VARIABLE(CONT-TNRA03)
                MOVE ENRA-SITUA-LABORAL
                                    TO LNRA-SITUA-LABORAL(CONT-TNRA03)
                MOVE ENRA-CLAVE-ID  TO LNRA-CLAVE-ID(CONT-TNRA03)
              WHEN CTE-19
                ADD 1               TO CONT-TNRA06
                SET INDNRA06        TO CONT-TNRA06
                MOVE ENRA-TIPO-PRODUCTO
                                    TO VNRA-TIPO-PRODUCTO(CONT-TNRA06)
                MOVE ENRA-VARIABLE  TO VNRA-VARIABLE(CONT-TNRA06)
                MOVE ENRA-IND-CLIENTE-VIP
                                    TO VNRA-IND-CLIENTE-VIP(CONT-TNRA06)
                MOVE ENRA-CLAVE-ID  TO VNRA-CLAVE-ID(CONT-TNRA06)
              WHEN CTE-20
                ADD 1               TO CONT-TNRA10
                SET INDNRA10        TO CONT-TNRA10
                MOVE ENRA-TIPO-PRODUCTO
                                    TO GNRA-TIPO-PRODUCTO(CONT-TNRA10)
                MOVE ENRA-VARIABLE  TO GNRA-VARIABLE(CONT-TNRA10)
                MOVE ENRA-RATING    TO GNRA-RATING(CONT-TNRA10)
                MOVE ENRA-CLAVE-ID  TO GNRA-CLAVE-ID(CONT-TNRA10)
              WHEN CTE-21
                ADD 1               TO CONT-TNRA11
                SET INDNRA11        TO CONT-TNRA11
                MOVE ENRA-TIPO-PRODUCTO
                                    TO HNRA-TIPO-PRODUCTO(CONT-TNRA11)
                MOVE ENRA-VARIABLE  TO HNRA-VARIABLE(CONT-TNRA11)
                MOVE ENRA-RANGO-RATING
                                    TO HNRA-RANGO-RATING(CONT-TNRA11)
                MOVE ENRA-CLAVE-ID  TO HNRA-CLAVE-ID(CONT-TNRA11)
              WHEN CTE-22
                ADD 1               TO CONT-TNRA12
                SET INDNRA12        TO CONT-TNRA12
                MOVE ENRA-TIPO-PRODUCTO
                                    TO ANRA-TIPO-PRODUCTO(CONT-TNRA12)
                MOVE ENRA-VARIABLE  TO ANRA-VARIABLE(CONT-TNRA12)
                MOVE ENRA-GARANTIA  TO ANRA-GARANTIA(CONT-TNRA12)
                MOVE ENRA-CLAVE-ID  TO ANRA-CLAVE-ID(CONT-TNRA12)
           END-EVALUATE
           PERFORM 1A-LEER-EUGDTNRA                                     00088991
           .
      *
      * -------------------------------------------------------------- *
      *             SE INICIALIZAN LAS TABLAS DE MEMORIA               *
      * -------------------------------------------------------------- *
        14-INITIALIZE-TABLA.
           MOVE ZEROS              TO CONT-COUNTER
                                      CONT-TNRA01
                                      CONT-TNRA02
                                      CONT-TNRA03
                                      CONT-TNRA04
                                      CONT-TNRA05
                                      CONT-TNRA06
                                      CONT-TNRA07
                                      CONT-TNRA08
                                      CONT-TNRA09
                                      CONT-TNRA10
                                      CONT-TNRA11
                                      CONT-TNRA12
           SET NO-VAR-01           TO TRUE
           SET NO-VAR-02           TO TRUE
           SET NO-VAR-03           TO TRUE
           SET NO-VAR-04           TO TRUE
           SET NO-VAR-05           TO TRUE
           SET NO-VAR-06           TO TRUE
           SET NO-VAR-07           TO TRUE
           SET NO-VAR-08           TO TRUE
           SET NO-VAR-09           TO TRUE
           SET NO-VAR-10           TO TRUE
           SET NO-VAR-11           TO TRUE
           SET NO-VAR-12           TO TRUE
           SET NO-VAR-13           TO TRUE
           SET NO-VAR-14           TO TRUE
           SET NO-VAR-15           TO TRUE
           SET NO-VAR-16           TO TRUE
           SET NO-VAR-17           TO TRUE
           SET NO-VAR-18           TO TRUE
           SET NO-VAR-19           TO TRUE
           SET NO-VAR-20           TO TRUE
           SET NO-VAR-21           TO TRUE
           SET NO-VAR-22           TO TRUE
           SET NO-VAR-23           TO TRUE
           PERFORM VARYING CONT-COUNTER FROM 1 BY 1
                                             UNTIL CONT-COUNTER > 100
              MOVE ZEROS         TO RNRA-RANGO-INI(CONT-COUNTER)
                                    RNRA-RANGO-FIN(CONT-COUNTER)
                                    MNRA-MONTO-INICIAL(CONT-COUNTER)
                                    MNRA-MONTO-FINAL(CONT-COUNTER)
                                    SNRA-SEGMENTO(CONT-COUNTER)
                                    BNRA-RANGO-RIESGO-INI(CONT-COUNTER)
                                    BNRA-RANGO-RIESGO-FIN(CONT-COUNTER)
              MOVE SPACES        TO NNRA-LLAVE(CONT-COUNTER)
                                    LNRA-LLAVE(CONT-COUNTER)
                                    VNRA-LLAVE(CONT-COUNTER)
                                    XNRA-LLAVE(CONT-COUNTER)
                                    TNRA-LLAVE(CONT-COUNTER)
                                    GNRA-LLAVE(CONT-COUNTER)
                                    HNRA-LLAVE(CONT-COUNTER)
                                    ANRA-LLAVE(CONT-COUNTER)
                                    RNRA-TIPO-PRODUCTO(CONT-COUNTER)
                                    RNRA-VARIABLE(CONT-COUNTER)
                                    RNRA-CLAVE-ID(CONT-COUNTER)
                                    NNRA-CLAVE-ID(CONT-COUNTER)
                                    LNRA-CLAVE-ID(CONT-COUNTER)
                                    MNRA-TIPO-PRODUCTO(CONT-COUNTER)
                                    MNRA-VARIABLE(CONT-COUNTER)
                                    MNRA-CLAVE-ID(CONT-COUNTER)
                                    SNRA-TIPO-PRODUCTO(CONT-COUNTER)
                                    SNRA-VARIABLE(CONT-COUNTER)
                                    SNRA-CLAVE-ID(CONT-COUNTER)
                                    VNRA-CLAVE-ID(CONT-COUNTER)
                                    BNRA-TIPO-PRODUCTO(CONT-COUNTER)
                                    BNRA-VARIABLE(CONT-COUNTER)
                                    BNRA-CLAVE-ID(CONT-COUNTER)
                                    XNRA-CLAVE-ID(CONT-COUNTER)
                                    TNRA-CLAVE-ID(CONT-COUNTER)
                                    GNRA-CLAVE-ID(CONT-COUNTER)
                                    HNRA-CLAVE-ID(CONT-COUNTER)
                                    ANRA-CLAVE-ID(CONT-COUNTER)
           END-PERFORM
           .
      *
      * -------------------------------------------------------------- *
      *             SE OBTIENE LA TIMESTAP PARA LA UGDTNRA             *
      * -------------------------------------------------------------- *
       15-OBTENER-FECHA.
           EXEC SQL
              SET :CURRENT-TIMESTAMP = CURRENT TIMESTAMP
           END-EXEC
           .
      *COL10-F
      * -------------------------------------------------------------- *