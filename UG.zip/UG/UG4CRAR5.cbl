      *----------------------------------------------------------------*
      *                    IDENTIFICATION DIVISION                     *
      *----------------------------------------------------------------*
       IDENTIFICATION DIVISION.

       PROGRAM-ID.      UG4CRAR5.
       AUTHOR.          JORGE BUITRAGO.
       DATE-WRITTEN.    11/11/2022.
       DATE-COMPILED.   11/11/2022.
      *----------------------------------------------------------------*
      *REALIZO    : INETUM COLOMBIA                                    *
      * SCRUM - SDA36560 - PLAN REPORTERIA TASA RAR-COLWSPREST-15693   *
      *DESCRIPCION: GENERACION REPORTE TASA RAR MENSUAL                *
      *----------------------------------------------------------------*
      * --------------------  LOG DE MODIFICACIONES  ----------------- *
      * ------- ------- ---------------------------------------------- *
      *  AUTOR   FECHA          DESCRIPCION                            *
      *  ------ ------- ---------------------------------------------- *
      * COL01   18/12/2023 CE59519 GLADIADORES COLONEPRE1-4            *
      * - SE INCORPORA CONTROL PARA VALIDAR QUE EL REPORTE NO SE QUEDE *
      *   SIN TIPO DE CARTERA.                                         *
      * - SE INCORPORA AJUSTE PARA EVITAR QUE SE PIERDA EL CANAL DE    *
      *   ORIGEN POR DONDE SE REALIZA LA TRANSACCION.                  *
      *----------------------------------------------------------------*
      *                      ENVIRONMENT DIVISION                      *
      *----------------------------------------------------------------*
       ENVIRONMENT DIVISION.

       CONFIGURATION SECTION.

       SOURCE-COMPUTER.  IBM-3090.
       OBJECT-COMPUTER.  IBM-3090.

       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
      *--------------------DEFINICION DE ENTRADA-----------------------*
           SELECT TASAULOG ASSIGN TO TASAULOG
                           FILE STATUS IS WS-ESTADO.
      *
      *--------------------DEFINICION DE SALIDAS-----------------------*
           SELECT ACUMULAD  ASSIGN TO ACUMULAD
                            FILE STATUS IS WS-ESTADO.
      *
           SELECT S2SINSEG  ASSIGN TO S2SINSEG
                            FILE STATUS IS WS-ESTADO.
      *
      *
      *----------------------------------------------------------------*
      *                  DATA DIVISION                                 *
      *----------------------------------------------------------------*
       DATA DIVISION.
       FILE SECTION.
      *-------------FILE DESCRIPTION DE ARCHIVO DE ENTRADA-------------*
       FD TASAULOG RECORDING MODE IS F BLOCK CONTAINS 0.
       01 REG-TASAULOG          PIC X(760).

      *
      * ------------ ARCHIVO ACUMULADO MENSUAL         --------------- *
       FD ACUMULAD RECORDING MODE IS F BLOCK CONTAINS 0.
       01 REG-GEN                      PIC X(570).
      *
      * -------------------------------------------------------------- *
       FD S2SINSEG RECORDING MODE IS F BLOCK CONTAINS 0.
       01 REG-S2SINSEG                 PIC X(262).
      *
      *----------------------------------------------------------------*
      *                  WORKING-STORAGE SECTION                       *
      *----------------------------------------------------------------*
       WORKING-STORAGE SECTION.
      *-----VARIABLE PARA EL ESTADO DE APERTURA, LECTURA Y CIERRE------*
       01 FILE-STATUS.
          05 WS-ESTADO                 PIC XX VALUE SPACES.
      *
      *----------------------------------------------------------------*
      *               AREAS DE ENLACE Y COPYS DE FICHERO               *
      *----------------------------------------------------------------*
           EXEC SQL INCLUDE SQLCA   END-EXEC.
      *-----------------------DCL TABLA DE FECHAS----------------------*
           EXEC SQL INCLUDE UGGTPRC END-EXEC.
      *----------------------COPY TABLA DE FECHAS----------------------*
           EXEC SQL INCLUDE UGTCPRC END-EXEC.
      *
      *
      *----------------------------------------------------------------*
      *                           VARIABLES                            *
      *----------------------------------------------------------------*
       01 WS-TASAULOG.
          05 ENT1-ENTIOFI       PIC X(08).
          05 ENT1-CUENTA        PIC X(10).
          05 ENT1-TIMESTAMP     PIC X(26).
          05 ENT1-CODIGO        PIC X(04).
          05 ENT1-FECMOV        PIC X(10).
          05 ENT1-CONSOPE       PIC X(07).
          05 ENT1-FECANT        PIC X(10).
          05 ENT1-IMPANT        PIC -ZZZZZZZZZZZZ9,99.
          05 ENT1-CARANT        PIC X(30).
          05 ENT1-TASA-ANT      PIC -ZZ9,99999.
          05 ENT1-FECNUE        PIC X(10).
          05 ENT1-IMPNUE        PIC -ZZZZZZZZZZZZ9,99.
          05 ENT1-CARNUE        PIC X(30).
          05 ENT1-TASA-NUE      PIC -ZZ9,99999.
          05 ENT1-TABLA         PIC X(07).
          05 ENT1-COLUMNA       PIC X(15).
          05 ENT1-DESCRIPCION.
             10 ENT1-MODELO     PIC X(16).
             10 FILLER          PIC X(01).
             10 ENT1-TASA       PIC X(09).
             10 FILLER          PIC X(01).
             10 ENT1-TCARTE     PIC X(21).
             10 FILLER          PIC X(01).
             10 ENT1-TCLUST     PIC X(30).
             10 FILLER          PIC X(01).
          05 ENT1-ENTIDAD-UMO   PIC X(04).
          05 ENT1-CENTRO-UMO    PIC X(04).
          05 ENT1-USERID-UMO    PIC X(08).
          05 ENT1-NETNAME-UMO   PIC X(08).
          05 REG-SALIDA1-MRARUDIF.
             10 ENT1-TASA-POLITICA          PIC -Z99.99999.
             10 ENT1-TASA-USURA             PIC -Z99.99999.
             10 ENT1-TASA-FORMALIZA         PIC -Z99.99999.
             10 ENT1-TOTAL-BONIFICA         PIC -999.99999.
             10 ENT1-TASA-PREFEREN          PIC -999.99999.
             10 ENT1-BONIFICA-BURO          PIC -9999.9999.
             10 ENT1-VLR-BURO               PIC 9(05).
             10 ENT1-BONIFICA-GRUPO         PIC -9999.9999.
             10 ENT1-VLR-GRUPO              PIC 9(02).
             10 ENT1-BONIFICA-INGR          PIC -9999.9999.
             10 ENT1-VLR-INGRESOS           PIC -Z,ZZZ,ZZZ,ZZZ,ZZ9.99.
             10 ENT1-BONIFICA-NOMINA        PIC -9999.9999.
             10 ENT1-VLR-NOMINA             PIC X(01).
          05 SAL1-MOTOS.
             10 ENT1-DSC-MONTO              PIC -9999.9999.
             10 ENT1-MONTO-FINA             PIC -Z,ZZZ,ZZZ,ZZZ,ZZ9.99.
             10 ENT1-DSC-PLAZO-MES          PIC -9999.9999.
             10 ENT1-PLAZO-MES              PIC X(4).
          05 SAL1-UGDTRVE.
             10 ENT1-DSC-GAMA-VEH           PIC -9999.9999.
             10 ENT1-GAMA-VEH               PIC 99999.9999.
             10 ENT1-DSC-TIPO-VEH           PIC -9999.9999.
             10 ENT1-TIPO-VEH               PIC X(10).
             10 ENT1-DSC-ESTD-VEH           PIC -9999.9999.
             10 ENT1-ESTADO-VEH             PIC X(10).
          05 SAL1-UGDTRAR2.
             10 ENT1-DSC-PORC-FINA          PIC -9999.9999.
             10 ENT1-PORC-FINA              PIC 9.9999.
             10 ENT1-DSC-SEGMENTO           PIC -9999.9999.
             10 ENT1-SEGMENTO               PIC 9(5).
             10 ENT1-DSC-COLECTIVO          PIC -9999.9999.
             10 ENT1-COLECTIVO              PIC 9(5).
             10 ENT1-DSC-EDAD               PIC -9999.9999.
             10 ENT1-EDAD                   PIC 9(2).
             10 ENT1-DSC-SITU-LABO          PIC -9999.9999.
             10 ENT1-SITU-LABO              PIC X(20).
             10 ENT1-TIPO-CARTERA           PIC X(20).
             10 FILLER                      PIC X(01).
             10 ENT1-CLUSTER                PIC X(19).
             10 ENT1-CANAL                  PIC X(05).
             10 ENT1-DESTINOLIB             PIC X(02).
             10 ENT1-COLECTILIB             PIC X(02).
             10 ENT1-CLIENTEVIP             PIC X(01).
             10 ENT1-VALORIESGO             PIC X(10).
          05 SAL1-UGDTMAE2.
             10 ENT1-SUBPRO                 PIC X(04).
             10 ENT1-PLAZOMAE               PIC X(04).
             10 ENT-IMPCONCE                PIC S9(13)V99.
             10 ENT1-FECCREACION            PIC X(10).
             10 ENT1-FECDESEMBOL            PIC X(10).
             10 ENT1-FECAPROBACI            PIC X(10).
             10 ENT1-SITPRES                PIC X(01).
             10 ENT1-TIPOCREDITO            PIC X(01).
             10 ENT1-MAECLIENTE             PIC X(08).
       01 WS-VARIABLES.
      * COL01-I
      * -------------------------------------------------------------- *
      * WORKING DE LA TABLA MCDTT37 PARA OBTENER SECCION UMTA          *
      * --------------------------------------------------------------**
        02 AREA-URMPCT37.                                               00006400
          05 URMPCT37-INPUT.                                            00006400
             10 URMPCT37-I-SECCION              PIC  X(004).            00006410
             10 URMPCT37-I-ELEMENTO             PIC  X(022).            00006420
          05 URMPCT37-OUTPUT.                                           00006430
             10 URMPCT37-OUTPUT-RETURN.                                 00006440
                15 URMPCT37-O-COD-RETURN        PIC X(02).              00006450
                15 URMPCT37-O-DES-RETURN        PIC X(200).             00006460
             10 URMPCT37-OUTPUT-DATA.                                   00006470
                15 URMPCT37-O-RESTO             PIC  X(250).            00006480
                15 URMPCT37-O-ENTIDAD-UMO       PIC  X(004).            00006490
                15 URMPCT37-O-CENTRO-UMO        PIC  X(004).            00006491
                15 URMPCT37-O-USERID-UMO        PIC  X(008).            00006492
                15 URMPCT37-O-NETNAME-UMO       PIC  X(008).            00006493
                15 URMPCT37-O-TIMESTAMP         PIC  X(026).            00006494
      *
      * COL01-F
          05 WS-EDITADO                  PIC -----99999.
          05 WS-CONT                     PIC 9(04).
          05 WS-INDSTRING                PIC 9(02).
          05 WS-CARACTER                 PIC X(01).
          05 WS-PERIODO                  PIC X(04).
          05 PARM-AMBIENTE               PIC X(1).
          05 PARM-NUM-ARCH               PIC X(1).
          05 WS-ERR-SELECT               PIC X(03)  VALUE SPACES.
          05 WS-IND                      PIC X(01).
          05 WS-MES                      PIC 9(02).
          05 WS-ERROR                    PIC S9(3)  VALUE +540.
          05 WS-FECHA-OPER               PIC X(10)  VALUE SPACES.
          05 REG-SINSEG                  PIC X(262) VALUE SPACES.
          05 REG-SINSEG-E                PIC X(262) VALUE SPACES.
          05 WS-OFICINA-ANT              PIC X(04)  VALUE SPACES.
          05 WS-TERRITORIAL-ANT          PIC X(04)  VALUE SPACES.
          05 AUX-ARCHIVOS                PIC 9(02)  VALUE ZEROS.
          05 PARM-NUM-ARCH-AUX           PIC 9(1)   VALUE ZEROS.
          05 PARM-NUM-ARCH-ANT           PIC 9(1)   VALUE ZEROS.
       01 AREA-LINKAGE.
          05 CODERR                      PIC X(07)  VALUE SPACES.
          05 SQLCA-LINK                  PIC X(136) VALUE SPACES.
          05 PGRNAME-LINK                PIC X(08)  VALUE SPACES.
          05 OBJETO-LINK                 PIC X(08)  VALUE SPACES.
          05 SENTENCIA-LINK              PIC X(08)  VALUE SPACES.

       01 FECHAS.
          05 W-FECHA-HOY.
             10 W-ANO-HOY                  PIC 9(04).
             10 W-MES-HOY                  PIC 9(02).
             10 W-DIA-HOY                  PIC 9(02).
          05 W-FECHA-DISPLAY.
             10 W-ANO-DIS                  PIC 9(04).
             10 FILLER                     PIC X(01) VALUE '-'.
             10 W-MES-DIS                  PIC 9(02).
             10 FILLER                     PIC X(01) VALUE '-'.
             10 W-DIA-DIS                  PIC 9(02).
      *
      *-----------------VARIABLES DE CONTROL DEL DB2-------------------*
          05 DB2-RETURN-CDE              PIC S9(9) COMP.
             88 DB2-OK                   VALUE +0.
             88 DB2-NOTFND               VALUE +100.
             88 DB2-DUPREC               VALUE -803.
             88 DB2-DOBLE                VALUE -811.
          05 WS-SQLCODE                  PIC ---9  VALUE ZERO.
      *
      *----------------------------------------------------------------*
      *                           CONTADORES                           *
      *----------------------------------------------------------------*
       01 WS-CONTADORES.
          05 WSA-REG-LEIDOS-E1           PIC 9(08) VALUE ZEROS.
          05 WSA-REG-ESCRITOS-S1         PIC 9(08) VALUE ZEROS.
          05 WSA-REG-ESCRITOS-S2         PIC 9(08) VALUE ZEROS.
          05 PASO-NUMERO                 PIC 9(02) VALUE ZEROS.
          05 OFI-TER-CONT                PIC 9(02) VALUE ZEROS.
      *
      *----------------------------------------------------------------*
      *                            CONSTANTES                          *
      *----------------------------------------------------------------*
      *-----------VARIABLES Y CONSTANTES PARA ARMADO DE JCL------------*
       01 WS-CONSTANTES.
          05 CON-911            PIC 9(03)  VALUE 911.
          05 CON-913            PIC 9(03)  VALUE 913.
          05 CON-2021           PIC X(04)  VALUE '2021'.
          05 WC-PROGRAMA        PIC X(08) VALUE 'UG4CRAR5'.
          05 CTE-ESPECIALES         PIC X(32) VALUE
             'Ã?¿=)(/&%$Ñ"]¡°|*   _~+!¢:¬°<>}{'.
      * COL01-I
          05 CTA-UR9CCT37       PIC X(08) VALUE 'UR9CCT37'.
      * COL01-F
       01 REG-TITULO.
          05 FILLER             PIC X(08) VALUE 'ENTIOFI'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(10) VALUE 'CUENTA'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(26) VALUE 'FECHA ACTUALIZACION'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(04) VALUE 'COD'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(10) VALUE 'FEC MOVIM '.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(07) VALUE 'CONSOPE'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(10) VALUE 'FECANT'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(17) VALUE 'IMPANT'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(08) VALUE 'CARANT'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(10) VALUE 'TASA-ANT'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(10) VALUE 'FECNUE '.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(17) VALUE 'IMPNUE'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(30) VALUE 'CARNUE'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(10) VALUE 'TASA-NUE'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(07) VALUE 'TRANSAC'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(15) VALUE 'COLUMNA'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(16) VALUE '  MODELO   '.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(09) VALUE 'TASAS '.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(21) VALUE ' TIPO CARTERA'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(30) VALUE ' CLUSTER   '.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(04) VALUE 'ENTI'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(04) VALUE 'UMO'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(08) VALUE 'USERID'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(08) VALUE 'NETNAME'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(10) VALUE 'TASA-POLIT'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(10) VALUE 'TASA-USURA'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(10) VALUE 'TASA-FORMA'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(10) VALUE 'TOT-BONIFI'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(10) VALUE 'TASA-PREFE'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(10) VALUE 'BONIF-BURO'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(05) VALUE 'BURO '.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(10) VALUE 'BONI-GRUPO'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(02) VALUE 'VG'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(10) VALUE 'BON-INGRES'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(21) VALUE 'VALOR INGRESOS'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(10) VALUE 'BON-NOMINA'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(01) VALUE 'N'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(10) VALUE 'DSC-MONTO'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(21) VALUE 'MONTO-FINANCIACION'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(10) VALUE 'DSC-PLAZO'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(04) VALUE 'PLAZ'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(10) VALUE 'DSC-GAMAV'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(10) VALUE 'GAMA-VEH '.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(10) VALUE 'DSC-TIPO '.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(10) VALUE 'TIPO-VEH '.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(10) VALUE 'DSC-ESTD '.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(10) VALUE 'EST-VEHIC'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(10) VALUE 'DSC-PORCF'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(06) VALUE 'PORCFI'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(10) VALUE 'DSC-SEGMEN'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(05) VALUE 'SEGME'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(10) VALUE 'DSC-COLECT'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(05) VALUE 'COLEC'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(10) VALUE 'DSC-EDAD  '.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(02) VALUE 'ED'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(10) VALUE 'DSC-SITU-L'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(20) VALUE 'SITUACION LABORAL'.
          05 FILLER             PIC X(01) VALUE ';'.
       01 REG-TITUL1.
          05 FILLER             PIC X(08) VALUE 'ENTIOFI'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(10) VALUE 'CUENTA'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(26) VALUE 'FECHA ACTUALIZACION'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(40) VALUE 'ESTADO PRESTAMO'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(06) VALUE 'SUBPRO'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(14) VALUE 'FECHA CREACION'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(16) VALUE 'FECHA APROBACION'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(16) VALUE 'FECHA DESEMBOLSO'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(17) VALUE 'FECHA ASIGNA TASA'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(08) VALUE 'CLIENTE '.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(11) VALUE 'TRANSACCION'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(05) VALUE 'CANAL'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(07) VALUE 'USERID '.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(21) VALUE 'TIPO CARTERA'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(30) VALUE 'CLUSTER APLICADO '.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(13) VALUE 'TASA POLITICA'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(13) VALUE 'TASA USURA   '.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(13) VALUE 'TASA FORMALIZ'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(13) VALUE 'TASA RAR     '.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(13) VALUE '01 BURO      '.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(13) VALUE '02 IND NOMINA'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(20) VALUE '03 SITUACION LABORAL'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(21) VALUE '04 INGRESOS SMLV  '.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(21) VALUE '05 MONTO FINANCIADO'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(12) VALUE '06 IND PLAZO'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(13) VALUE '07 IND EDAD  '.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(13) VALUE '08 SEGMENTO  '.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(12) VALUE '09 COLECTIVO'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(15) VALUE '10 GRUPO RIESGO'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(13) VALUE '11 EST VEHICU'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(17) VALUE '12 % FINANCIACION'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(13) VALUE '13 GAM VEHICU'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(13) VALUE '14 TIPO USO  '.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(13) VALUE '15 CLIENT VIP'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(13) VALUE '16 LIB COLECT'.
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER             PIC X(13) VALUE '17 LIB DESTIN'.
          05 FILLER             PIC X(01) VALUE ';'.
       01 REG-REGISTRO.
          05 SAL1-ENTIOFI       PIC X(08).
          05 FILLER             PIC X(01) VALUE ';'.
          05 SAL1-CUENTA        PIC X(10).
          05 FILLER             PIC X(01) VALUE ';'.
          05 SAL1-TIMESTAMP     PIC X(26).
          05 FILLER             PIC X(01) VALUE ';'.
          05 SAL1-CODIGO        PIC X(04).
          05 FILLER             PIC X(01) VALUE ';'.
          05 SAL1-FECMOV        PIC X(10).
          05 FILLER             PIC X(01) VALUE ';'.
          05 SAL1-CONSOPE       PIC X(07).
          05 FILLER             PIC X(01) VALUE ';'.
          05 SAL1-FECANT        PIC X(10).
          05 FILLER             PIC X(01) VALUE ';'.
          05 SAL1-IMPANT        PIC -ZZZZZZZZZZZZ9,99.
          05 FILLER             PIC X(01) VALUE ';'.
          05 SAL1-CARANT        PIC X(08).
          05 FILLER             PIC X(01) VALUE ';'.
          05 SAL1-TASA-ANT      PIC -ZZ9,99999.
          05 FILLER             PIC X(01) VALUE ';'.
          05 SAL1-FECNUE        PIC X(10).
          05 FILLER             PIC X(01) VALUE ';'.
          05 SAL1-IMPNUE        PIC -ZZZZZZZZZZZZ9,99.
          05 FILLER             PIC X(01) VALUE ';'.
          05 SAL1-CARNUE        PIC X(30).
          05 FILLER             PIC X(01) VALUE ';'.
          05 SAL1-TASA-NUE      PIC -ZZ9,99999.
          05 FILLER             PIC X(01) VALUE ';'.
          05 SAL1-TABLA         PIC X(07).
          05 FILLER             PIC X(01) VALUE ';'.
          05 SAL1-COLUMNA       PIC X(15).
          05 FILLER             PIC X(01) VALUE ';'.
          05 SAL1-DESCRIPCION.
             10 SAL1-MODELO     PIC X(16).
             10 FILLER          PIC X(01) VALUE ';'.
             10 SAL1-TASA       PIC X(09).
             10 FILLER          PIC X(01) VALUE ';'.
             10 SAL1-TCARTE     PIC X(21).
             10 FILLER          PIC X(01) VALUE ';'.
             10 SAL1-TCLUST     PIC X(30).
          05 FILLER             PIC X(01) VALUE ';'.
          05 SAL1-ENTIDAD-UMO   PIC X(04).
          05 FILLER             PIC X(01) VALUE ';'.
          05 SAL1-CENTRO-UMO    PIC X(04).
          05 FILLER             PIC X(01) VALUE ';'.
          05 SAL1-USERID-UMO    PIC X(08).
          05 FILLER             PIC X(01) VALUE ';'.
          05 SAL1-NETNAME-UMO   PIC X(08).
          05 FILLER             PIC X(01) VALUE ';'.
          05 SAL1-TASA-POLITICA          PIC -Z99.99999.
          05 FILLER                      PIC X(01) VALUE ';'.
          05 SAL1-TASA-USURA             PIC -ZZ9.99999.
          05 FILLER                      PIC X(01) VALUE ';'.
          05 SAL1-TASA-FORMALIZA         PIC -ZZ9.99999.
          05 FILLER                      PIC X(01) VALUE ';'.
          05 SAL1-TOTAL-BONIFICA         PIC -999.99999.
          05 FILLER                      PIC X(01) VALUE ';'.
          05 SAL1-TASA-PREFEREN          PIC -Z99.99999.
          05 FILLER                      PIC X(01) VALUE ';'.
          05 SAL1-BONIFICA-BURO          PIC -9999.9999.
          05 FILLER                      PIC X(01) VALUE ';'.
          05 SAL1-VLR-BURO               PIC ZZ999.
          05 FILLER                      PIC X(01) VALUE ';'.
          05 SAL1-BONIFICA-GRUPO         PIC -9999.9999.
          05 FILLER                      PIC X(01) VALUE ';'.
          05 SAL1-VLR-GRUPO              PIC X(10).
          05 FILLER                      PIC X(01) VALUE ';'.
          05 SAL1-BONIFICA-INGR          PIC -9999.9999.
          05 FILLER                      PIC X(01) VALUE ';'.
          05 SAL1-VLR-INGRESOS           PIC -Z,ZZZ,ZZZ,ZZZ,ZZ9.99.
          05 FILLER                      PIC X(01) VALUE ';'.
          05 SAL1-BONIFICA-NOMINA        PIC -9999.9999.
          05 FILLER                      PIC X(01) VALUE ';'.
          05 SAL1-VLR-NOMINA             PIC X(01).
          05 FILLER                      PIC X(01) VALUE ';'.
          05 SAL1-MOTOS.
             10 SAL1-DSC-MONTO              PIC -9999.9999.
             10 FILLER                      PIC X(01) VALUE ';'.
             10 SAL1-MONTO-FINA             PIC -Z,ZZZ,ZZZ,ZZZ,ZZ9.99.
             10 FILLER                      PIC X(01) VALUE ';'.
             10 SAL1-DSC-PLAZO-MES          PIC -9999.9999.
             10 FILLER                      PIC X(01) VALUE ';'.
             10 SAL1-PLAZO-MES              PIC X(4).
             10 FILLER                      PIC X(01) VALUE ';'.
          05 SAL1-UGDTRVE.
             10 SAL1-DSC-GAMA-VEH           PIC -9999.9999.
             10 FILLER                      PIC X(01) VALUE ';'.
             10 SAL1-GAMA-VEH               PIC 99999.9999.
             10 FILLER                      PIC X(01) VALUE ';'.
             10 SAL1-DSC-TIPO-VEH           PIC -9999.9999.
             10 FILLER                      PIC X(01) VALUE ';'.
             10 SAL1-TIPO-VEH               PIC X(10).
             10 FILLER                      PIC X(01) VALUE ';'.
             10 SAL1-DSC-ESTD-VEH           PIC -9999.9999.
             10 FILLER                      PIC X(01) VALUE ';'.
             10 SAL1-ESTADO-VEH             PIC X(10).
             10 FILLER                      PIC X(01) VALUE ';'.
          05 SAL1-UGDTRAR2.
             10 SAL1-DSC-PORC-FINA          PIC -9999.9999.
             10 FILLER                      PIC X(01) VALUE ';'.
             10 SAL1-PORC-FINA              PIC 9.9999.
             10 FILLER                      PIC X(01) VALUE ';'.
             10 SAL1-DSC-SEGMENTO           PIC -9999.9999.
             10 FILLER                      PIC X(01) VALUE ';'.
             10 SAL1-SEGMENTO               PIC 9(5).
             10 FILLER                      PIC X(01) VALUE ';'.
             10 SAL1-DSC-COLECTIVO          PIC -9999.9999.
             10 FILLER                      PIC X(01) VALUE ';'.
             10 SAL1-COLECTIVO              PIC 9(4).
             10 FILLER                      PIC X(01) VALUE ';'.
             10 SAL1-DSC-EDAD               PIC -9999.9999.
             10 FILLER                      PIC X(01) VALUE ';'.
             10 SAL1-EDAD                   PIC 9(2).
             10 FILLER                      PIC X(01) VALUE ';'.
             10 SAL1-DSC-SITU-LABO          PIC -9999.9999.
             10 FILLER                      PIC X(01) VALUE ';'.
             10 SAL1-SITU-LABO              PIC X(20).
             10 FILLER                      PIC X(01) VALUE ';'.
             10 FILLER                      PIC X(45).
      *----------------------------------------------------------------*
       01 REG-REGISTR2.
          05 SAL2-ENTIOFI       PIC X(08).
          05 FILLER             PIC X(01) VALUE ';'.
          05 SAL2-CUENTA        PIC X(10).
          05 FILLER             PIC X(01) VALUE ';'.
          05 SAL2-TIMESTAMP     PIC X(26).
          05 FILLER             PIC X(01) VALUE ';'.
          05 SAL2-SITPRES       PIC X(40).
          05 FILLER             PIC X(01) VALUE ';'.
          05 SAL2-SUBPRO        PIC X(06).
          05 FILLER             PIC X(01) VALUE ';'.
          05 SAL2-FECREACION    PIC X(14).
          05 FILLER             PIC X(01) VALUE ';'.
          05 SAL2-FECAPROBAC    PIC X(16).
          05 FILLER             PIC X(01) VALUE ';'.
          05 SAL2-FECDESEMBO    PIC X(16).
          05 FILLER             PIC X(01) VALUE ';'.
          05 SAL2-FECMOV        PIC X(17).
          05 FILLER             PIC X(01) VALUE ';'.
          05 SAL2-CARANT        PIC X(08).
          05 FILLER             PIC X(01) VALUE ';'.
          05 SAL2-TABLA         PIC X(11).
          05 FILLER             PIC X(01) VALUE ';'.
          05 SAL2-COLUMNA       PIC X(05).
          05 FILLER             PIC X(01) VALUE ';'.
          05 SAL2-USERID-UMO    PIC X(07).
          05 FILLER             PIC X(01) VALUE ';'.
          05 SAL2-DESCRIPCION.
             10 SAL2-TCARTE     PIC X(21).
             10 FILLER          PIC X(01) VALUE ';'.
             10 SAL2-TCLUST     PIC X(30).
          05 FILLER             PIC X(01) VALUE ';'.
          05 FILLER                      PIC X(03) VALUE SPACES.
      * TASA APLICADAS A LA OFERTA
          05 SAL2-TASA-POLITICA          PIC -Z99.99999.
          05 FILLER                      PIC X(01) VALUE ';'.
          05 FILLER                      PIC X(03) VALUE SPACES.
          05 SAL2-TASA-USURA             PIC -ZZ9.99999.
          05 FILLER                      PIC X(01) VALUE ';'.
          05 FILLER                      PIC X(03) VALUE SPACES.
          05 SAL2-TASA-FORMALIZA         PIC -ZZ9.99999.
          05 FILLER                      PIC X(01) VALUE ';'.
          05 FILLER                      PIC X(03) VALUE SPACES.
          05 SAL2-TASA-PREFEREN          PIC X(10).
          05 FILLER                      PIC X(01) VALUE ';'.
          05 FILLER                      PIC X(08) VALUE SPACES.
          05 SAL2-VLR-BURO               PIC ZZ999.
          05 FILLER                      PIC X(01) VALUE ';'.
          05 FILLER                      PIC X(12) VALUE SPACES.
          05 SAL2-VLR-NOMINA             PIC X(01).
          05 FILLER                      PIC X(01) VALUE ';'.
          05 SAL2-SITU-LABO              PIC X(20).
          05 FILLER                      PIC X(01) VALUE ';'.
          05 SAL2-VLR-INGRESOS           PIC -Z,ZZZ,ZZZ,ZZZ,ZZ9.99.
          05 FILLER                      PIC X(01) VALUE ';'.
          05 SAL2-MOTOS.
             10 SAL2-MONTO-FINA          PIC -Z,ZZZ,ZZZ,ZZZ,ZZ9.99.
             10 FILLER                   PIC X(01) VALUE ';'.
             10 FILLER                   PIC X(08) VALUE SPACES.
             10 SAL2-PLAZO-MES           PIC X(4).
             10 FILLER                   PIC X(01) VALUE ';'.
             10 FILLER                   PIC X(11) VALUE SPACES.
             10 SAL2-EDAD                PIC 9(2).
             10 FILLER                   PIC X(01) VALUE ';'.
             10 FILLER                   PIC X(08) VALUE SPACES.
             10 SAL2-SEGMENTO            PIC 9(5).
             10 FILLER                   PIC X(01) VALUE ';'.
             10 FILLER                   PIC X(08) VALUE SPACES.
             10 SAL2-COLECTIVO           PIC 9(4).
             10 FILLER                   PIC X(01) VALUE ';'.
             10 FILLER                   PIC X(05) VALUE SPACES.
             10 SAL2-VLR-GRUPO           PIC X(10).
             10 FILLER                   PIC X(01) VALUE ';'.
      * VARIABLES APLICABLES A VEHICULO
          05 SAL2-UGDTRVE.
             10 FILLER                      PIC X(03) VALUE SPACES.
             10 SAL2-ESTADO-VEH             PIC X(10).
             10 FILLER                      PIC X(01) VALUE ';'.
             10 FILLER                      PIC X(07) VALUE SPACES.
             10 SAL2-PORC-FINA              PIC X(10).
             10 FILLER                      PIC X(01) VALUE ';'.
             10 FILLER                      PIC X(03) VALUE SPACES.
             10 SAL2-GAMA-VEH               PIC X(10).
             10 FILLER                      PIC X(01) VALUE ';'.
             10 FILLER                      PIC X(03) VALUE SPACES.
             10 SAL2-TIPO-VEH               PIC X(10).
             10 FILLER                      PIC X(01) VALUE ';'.
          05 SAL2-UGDTRAR2.
             10 SAL2-CLIENTEVIP             PIC X(13).
             10 FILLER                      PIC X(01) VALUE ';'.
             10 SAL2-COLECTLIBR             PIC X(13).
             10 FILLER                      PIC X(01) VALUE ';'.
             10 SAL2-DESTINLIBR             PIC X(13).
             10 FILLER                      PIC X(01) VALUE ';'.
             10 FILLER                      PIC X(45).
      *----------------------------------------------------------------*

      *----------------------------------------------------------------*
       01 WS-REG-IN2.
         03 WS-REG-IN2-P1                PIC X(32) VALUE
            '     INCLUDE COND=(206,4,CH,EQ,C'.
         03 WS-INC2-COMILLA7             PIC X(1)  VALUE "'".
         03 WS-REG-TERR                  PIC X(4).
         03 WS-INC2-COMILLA2             PIC X(1)  VALUE "'".
         03 WS-REG-IN2-P2                PIC X(1)  VALUE
            ')'.
      *----------------------------------------------------------------*
      *                            SWITCHES                            *
      *----------------------------------------------------------------*
      *-------SWITCH PARA EL CONTROL DE CADA ARCHIVO DE ENTRADA--------*
        01 SWITCHES.
           05 SW-FIN-TASAULOG            PIC X VALUE 'N'.
              88 SW-FIN-TASAULOG-S             VALUE 'S'.
              88 SW-FIN-TASAULOG-N             VALUE 'N'.
      *
      *----------------------------------------------------------------*
      *                         LINKAGE SECTION                        *
      *----------------------------------------------------------------*
       LINKAGE SECTION.
      *-------------PARÁMETROS QUE INGRESAN POR CONTROL-M--------------*
       01 PARM.
          03 PARM-L             PIC X(06).
      *
      ******************************************************************
      *                       PROCEDURE DIVISION                       *
      ******************************************************************
      *--------------------ESTRUCTURA DEL PROGRAMA---------------------*
       PROCEDURE DIVISION USING PARM.
      *
            PERFORM 100000-INICIO-PROCESO.
            PERFORM 200000-PROCESO-PRINCIPAL UNTIL SW-FIN-TASAULOG-S.
            PERFORM 300000-FIN-PROCESO.
            STOP RUN.
      *
      ******************************************************************
      *                    100000-INICIO-PROCESO                       *
      ******************************************************************
       100000-INICIO-PROCESO.
            INITIALIZE WS-VARIABLES
                       WS-CONTADORES.
            MOVE PARM-L(3:)     TO WS-PERIODO
            PERFORM 100100-OBTENER-FECHA-CONT.
            PERFORM 100200-ABRIR-ARCHIVOS.
      *
      ******************************************************************
      *                     100100-OBTENER-FECHA-CONT                  *
      ******************************************************************
       100100-OBTENER-FECHA-CONT.
           ACCEPT W-FECHA-HOY   FROM DATE YYYYMMDD.
           MOVE W-ANO-HOY       TO W-ANO-DIS
           MOVE W-MES-HOY       TO W-MES-DIS
           MOVE W-DIA-HOY       TO W-DIA-DIS
           MOVE W-FECHA-DISPLAY TO WS-FECHA-OPER.
      *
      ******************************************************************
      *                  100200-ABRIR-ARCHIVOS                         *
      ******************************************************************
       100200-ABRIR-ARCHIVOS.
           INITIALIZE           WS-ESTADO
           OPEN INPUT TASAULOG
           IF WS-ESTADO NOT = ZEROS
              DISPLAY 'ERROR ABRIENDO EL ARCHIVO TASAULOG '
              DISPLAY 'ESTADO MARCADO ... '  WS-ESTADO
              MOVE 12                     TO RETURN-CODE
              STOP RUN
           END-IF
      *--------------------ABRIR ARCHIVOS DE SALIDA--------------------*
           OPEN OUTPUT ACUMULAD
           IF WS-ESTADO NOT = ZEROS
              DISPLAY 'ERROR GRABANDO EL ARCHIVO ACUMULAD SEP. '
              DISPLAY 'ESTADO MARCADO ... '  WS-ESTADO
              MOVE 12                     TO RETURN-CODE
              PERFORM 300000-FIN-PROCESO
           END-IF
           IF WS-ESTADO NOT = ZEROS
              DISPLAY 'ERROR ABRIENDO EL ARCHIVO ACUMULAD '
              DISPLAY 'ESTADO MARCADO ... '  WS-ESTADO
              CLOSE TASAULOG
              MOVE 12                     TO RETURN-CODE
              STOP RUN
           END-IF.
      *
           OPEN OUTPUT S2SINSEG
           IF WS-PERIODO  < CON-2021
              WRITE REG-GEN FROM REG-TITULO
           ELSE
              WRITE REG-GEN FROM REG-TITUL1
           END-IF
           IF WS-ESTADO NOT = ZEROS
              DISPLAY 'ERROR ABRIENDO EL ARCHIVO MENSULES '
              DISPLAY 'ESTADO MARCADO ... '  WS-ESTADO
              CLOSE TASAULOG ACUMULAD
              MOVE 12                     TO RETURN-CODE
              STOP RUN
           END-IF.
      *
      * -------------------------------------------------------------- *
      *                  200000-PROCESO-PRINCIPAL                      *
      * -------------------------------------------------------------- *
       200000-PROCESO-PRINCIPAL.
           PERFORM 200100-LEER-ARCHIVOS.
      *
      * -------------------------------------------------------------- *
      *                    200100-LEER-ARCHIVOS                        *
      * -------------------------------------------------------------- *
       200100-LEER-ARCHIVOS.
      *
           PERFORM 200110-LEER-TASAULOG UNTIL SW-FIN-TASAULOG-S.
      *
      * -------------------------------------------------------------- *
      *                    200110-LEER-TASAULOG                        *
      * -------------------------------------------------------------- *
       200110-LEER-TASAULOG.
      *
           READ TASAULOG        AT END
                 SET SW-FIN-TASAULOG-S    TO TRUE
              NOT AT END
                 PERFORM 99999-CARACTESPE
                 MOVE REG-TASAULOG  TO WS-TASAULOG
                 SET SW-FIN-TASAULOG-N    TO TRUE
                 PERFORM 999999-MUEVEDATA
                 IF ENT1-FECMOV(1:4) >= PARM-L
                    IF WS-PERIODO >= CON-2021
                       INITIALIZE        REG-REGISTRO
                       MOVE REG-REGISTR2 TO REG-REGISTRO
                    END-IF
                    WRITE REG-GEN FROM REG-REGISTRO
                    IF WS-ESTADO NOT = ZEROS
                      DISPLAY 'ERROR GRABANDO EL ARCHIVO ACUMULAD SEP. '
                      DISPLAY 'ESTADO MARCADO ... '  WS-ESTADO
                      MOVE 12                     TO RETURN-CODE
                      PERFORM 300000-FIN-PROCESO
                      STOP RUN
                    ELSE
                      ADD 1              TO WSA-REG-ESCRITOS-S1
                    END-IF
                 END-IF
           END-READ.
      *
      * -------------------------------------------------------------- *
      *                300000-FIN-PROCESO                              *
      * -------------------------------------------------------------- *
       300000-FIN-PROCESO.
      *
           CLOSE TASAULOG ACUMULAD S2SINSEG
      *--------------------ESTADISTICAS DEL PROCESO--------------------*
           DISPLAY ' ----------------------------------------------'
           DISPLAY '       RESUMEN DEL PROGRAMA (UG4CRAR5)'
           DISPLAY ' ----------------------------------------------'
           DISPLAY ' FECHA PROCESAMIENTO        : ' WS-FECHA-OPER
           DISPLAY ' REG. PROCESADOS ' PARM-L ' : ' WSA-REG-ESCRITOS-S1.
           DISPLAY ' ----------------------------------------------'.
      *
      * -------------------------------------------------------------- *
      *                        999999-MUEVEDATA
      * -------------------------------------------------------------- *
       999999-MUEVEDATA.
           INITIALIZE           SAL1-TASA-POLITICA
                                SAL2-FECREACION
                                SAL2-FECAPROBAC
                                SAL2-FECDESEMBO
           MOVE ENT1-CLIENTEVIP TO SAL2-CLIENTEVIP
           MOVE ENT1-DESTINOLIB TO SAL2-DESTINLIBR
           MOVE ENT1-COLECTILIB TO SAL2-COLECTLIBR
           IF SAL2-CLIENTEVIP   = SPACES OR LOW-VALUES
              MOVE 'N/A            ' TO SAL2-CLIENTEVIP
           END-IF
           IF SAL2-COLECTLIBR(1:2) IS NOT NUMERIC
              MOVE 'N/A            ' TO SAL2-COLECTLIBR
           END-IF
           IF SAL2-DESTINLIBR(1:2) IS NOT NUMERIC
              MOVE 'N/A            ' TO SAL2-DESTINLIBR
           END-IF
           IF ENT1-VLR-NOMINA   = SPACES OR LOW-VALUES
              MOVE 'N/A            ' TO ENT1-VLR-NOMINA
           END-IF
           IF ENT1-SITU-LABO    = SPACES OR LOW-VALUES
              MOVE 'SIN INFORMACION' TO ENT1-SITU-LABO
           END-IF
           IF ENT1-CLUSTER      = SPACES OR LOW-VALUES
              MOVE ' N/A           ' TO ENT1-CLUSTER
           END-IF
           IF (ENT1-COLUMNA NOT = SPACES AND
              ENT1-COLUMNA NOT = LOW-VALUES)
              MOVE ENT1-CANAL   TO ENT1-COLUMNA
           END-IF
      * COL01-I
      *    IF ENT1-TIPO-CARTERA = SPACES OR LOW-VALUES
      *       MOVE 'N/A'     TO ENT1-COLUMNA
      *    END-IF
      * COL01-F
           IF ENT1-TIPO-CARTERA = SPACES OR LOW-VALUES
              PERFORM 99999-VALIDATIPCART
           END-IF
           IF ENT1-FECAPROBACI  = '0001-01-01'
              MOVE SPACES       TO ENT1-FECAPROBACI
           END-IF
           IF ENT1-FECDESEMBOL  = '0001-01-01'
              MOVE SPACES       TO ENT1-FECDESEMBOL
           END-IF
           IF ENT1-PLAZO-MES NOT = ENT1-PLAZOMAE(2:3)
              MOVE ENT1-PLAZOMAE(2:3) TO ENT1-PLAZO-MES
           END-IF
           PERFORM 99999-VALIDASITPRES
           MOVE ENT1-SUBPRO      TO SAL2-SUBPRO
           MOVE ENT1-FECCREACION TO SAL2-FECREACION
           MOVE ENT1-FECAPROBACI TO SAL2-FECAPROBAC
           MOVE ENT1-FECDESEMBOL TO SAL2-FECDESEMBO
      *
      *    INFORMACION MAESTRA DE PRESTAMOS
      *
           MOVE ENT1-ENTIOFI       TO SAL1-ENTIOFI     SAL2-ENTIOFI
           MOVE ENT1-CUENTA        TO SAL1-CUENTA      SAL2-CUENTA
           MOVE ENT1-TIMESTAMP     TO SAL1-TIMESTAMP   SAL2-TIMESTAMP
           MOVE ENT1-CODIGO        TO SAL1-CODIGO
           MOVE ENT1-FECMOV        TO SAL1-FECMOV      SAL2-FECMOV
           MOVE ENT1-CONSOPE       TO SAL1-CONSOPE
           MOVE ENT1-FECANT        TO SAL1-FECANT
           MOVE ENT1-IMPANT        TO SAL1-IMPANT
           MOVE ENT1-CARANT        TO SAL1-CARANT
           MOVE ENT1-CARANT(1:8)   TO SAL2-CARANT
           MOVE ENT1-TASA-ANT      TO SAL1-TASA-ANT
           MOVE ENT1-FECNUE        TO SAL1-FECNUE
           MOVE ENT1-IMPNUE        TO SAL1-IMPNUE
           MOVE ENT1-CARNUE        TO SAL1-CARNUE
           MOVE ENT1-TASA-NUE      TO SAL1-TASA-NUE
           MOVE ENT1-TABLA         TO SAL1-TABLA       SAL2-TABLA
           MOVE ENT1-COLUMNA       TO SAL1-COLUMNA     SAL2-COLUMNA
           MOVE ENT1-MODELO        TO SAL1-MODELO
           MOVE ENT1-TASA          TO SAL1-TASA
           MOVE ENT1-TCARTE        TO SAL1-TCARTE      SAL2-TCARTE
           MOVE ENT1-TCLUST        TO SAL1-TCLUST      SAL2-TCLUST
           MOVE ENT1-ENTIDAD-UMO   TO SAL1-ENTIDAD-UMO
           MOVE ENT1-CENTRO-UMO    TO SAL1-CENTRO-UMO
           MOVE ENT1-USERID-UMO    TO SAL1-USERID-UMO  SAL2-USERID-UMO
           MOVE ENT1-NETNAME-UMO   TO SAL1-NETNAME-UMO
      *
      * INFORMACION DE TASAS
      *
           MOVE ENT1-TASA-POLITICA  TO SAL1-TASA-POLITICA
                                       SAL2-TASA-POLITICA
           MOVE ENT1-TASA-USURA     TO SAL1-TASA-USURA
                                       SAL2-TASA-USURA
           MOVE ENT1-TASA-FORMALIZA TO SAL1-TASA-FORMALIZA
                                       SAL2-TASA-FORMALIZA
           MOVE ENT1-TOTAL-BONIFICA TO SAL1-TOTAL-BONIFICA
           MOVE ENT1-TASA-PREFEREN  TO SAL1-TASA-PREFEREN
           MOVE ENT1-TASA-NUE       TO SAL2-TASA-PREFEREN
      *
      * VARIABLES DEL MODELO PRINCING
      *
           MOVE ENT1-BONIFICA-BURO  TO SAL1-BONIFICA-BURO
           MOVE ENT1-VLR-BURO       TO SAL1-VLR-BURO
                                       SAL2-VLR-BURO
           MOVE ENT1-BONIFICA-GRUPO TO SAL1-BONIFICA-GRUPO
           IF ENT1-VALORIESGO(1:5)  IS NOT NUMERIC
              MOVE 'N/A'            TO ENT1-VALORIESGO
           END-IF
           MOVE ENT1-VALORIESGO      TO SAL1-VLR-GRUPO
                                        SAL2-VLR-GRUPO
           MOVE ENT1-VLR-INGRESOS    TO SAL1-VLR-INGRESOS
                                        SAL2-VLR-INGRESOS
           MOVE ENT1-VLR-NOMINA      TO SAL1-VLR-NOMINA
                                        SAL2-VLR-NOMINA

           MOVE ENT-IMPCONCE         TO ENT1-MONTO-FINA
           MOVE ENT1-MONTO-FINA      TO SAL1-MONTO-FINA
                                        SAL2-MONTO-FINA
           MOVE ENT1-DSC-PLAZO-MES   TO SAL1-DSC-PLAZO-MES
           MOVE ENT1-PLAZO-MES       TO SAL1-PLAZO-MES
                                        SAL2-PLAZO-MES
           MOVE ENT1-DSC-GAMA-VEH    TO SAL1-DSC-GAMA-VEH
           MOVE ENT1-GAMA-VEH        TO SAL1-GAMA-VEH
                                        SAL2-GAMA-VEH
           MOVE ENT1-DSC-TIPO-VEH    TO SAL1-DSC-TIPO-VEH
           MOVE ENT1-TIPO-VEH        TO SAL1-TIPO-VEH
                                        SAL2-TIPO-VEH
           MOVE ENT1-DSC-ESTD-VEH    TO SAL1-DSC-ESTD-VEH
           MOVE ENT1-ESTADO-VEH      TO SAL1-ESTADO-VEH
                                        SAL2-ESTADO-VEH
           MOVE ENT1-DSC-PORC-FINA   TO SAL1-DSC-PORC-FINA
           MOVE ENT1-PORC-FINA       TO SAL1-PORC-FINA
                                        SAL2-PORC-FINA
           MOVE ENT1-DSC-SEGMENTO    TO SAL1-DSC-SEGMENTO
           MOVE ENT1-SEGMENTO        TO SAL1-SEGMENTO
                                        SAL2-SEGMENTO
           MOVE ENT1-DSC-COLECTIVO   TO SAL1-DSC-COLECTIVO
           MOVE ENT1-COLECTIVO(2:4)  TO SAL1-COLECTIVO
                                        SAL2-COLECTIVO
           MOVE ENT1-DSC-EDAD        TO SAL1-DSC-EDAD
           MOVE ENT1-EDAD            TO SAL1-EDAD SAL2-EDAD
           MOVE ENT1-DSC-SITU-LABO   TO SAL1-DSC-SITU-LABO
           MOVE ENT1-SITU-LABO       TO SAL1-SITU-LABO
                                        SAL2-SITU-LABO
           MOVE ENT1-TIPO-CARTERA    TO SAL2-TCARTE
           MOVE ENT1-CLUSTER         TO SAL2-TCLUST
           IF ENT1-TIPO-CARTERA  NOT = 'VEHICULO'
              MOVE 'NO PROCEDE ' TO SAL2-GAMA-VEH
              MOVE 'NO PROCEDE ' TO SAL2-TIPO-VEH
              MOVE 'NO PROCEDE ' TO SAL2-ESTADO-VEH
              MOVE 'NO PROCEDE ' TO SAL2-PORC-FINA
           END-IF
           IF SAL2-GAMA-VEH     =  SPACES OR LOW-VALUES
              MOVE 'N/A'         TO SAL2-GAMA-VEH
           END-IF
           IF SAL2-TIPO-VEH     =  SPACES OR LOW-VALUES
              MOVE 'N/A'         TO SAL2-TIPO-VEH
           END-IF
           IF SAL2-ESTADO-VEH   =  SPACES OR LOW-VALUES
              MOVE 'N/A'         TO SAL2-ESTADO-VEH
           END-IF
           IF SAL2-PORC-FINA    =  SPACES OR LOW-VALUES
              MOVE 'N/A'         TO SAL2-PORC-FINA
           END-IF
           .
      * -------------------------------------------------------------- *
       99999-VALIDASITPRES.
           INITIALIZE           SAL2-SITPRES
           EVALUATE ENT1-SITPRES
           WHEN 'A'
            MOVE 'PROPUESTA ANULADA                    ' TO SAL2-SITPRES
           WHEN 'B'
            MOVE 'BLOQUEO POR RECLAMACIÓN DE SEGUROS   ' TO SAL2-SITPRES
           WHEN 'P'
            MOVE 'CANC. POR RESOLUCION PROCEDIM.NOTAR. ' TO SAL2-SITPRES
           WHEN 'R'
            MOVE 'CANCELACION POR REESTRUCTURA         ' TO SAL2-SITPRES
           WHEN 'V'
            MOVE 'VENDIDA - PROCESO DE VENTA DE CARTERA' TO SAL2-SITPRES
           WHEN '0'
            MOVE 'PROPUESTA EN VIGOR O ACTIVO          ' TO SAL2-SITPRES
           WHEN '1'
            MOVE 'PROPUESTA CANCELADA                  ' TO SAL2-SITPRES
           WHEN '2'
            MOVE 'BLOQUEO JUDICIAL                     ' TO SAL2-SITPRES
           WHEN '3'
            MOVE 'BLOQUEO ADMINISTRATIVO               ' TO SAL2-SITPRES
           WHEN '4'
            MOVE 'MIBOR MARCO ACTIVO                   ' TO SAL2-SITPRES
           WHEN '5'
            MOVE 'MIBOR RETROCEDIDO                    ' TO SAL2-SITPRES
           WHEN '7'
            MOVE 'PROPUESTA EN TRAMITE                 ' TO SAL2-SITPRES
            INITIALIZE          ENT1-FECDESEMBOL ENT1-FECAPROBACI
           WHEN '8'
            MOVE 'PROPUESTA APROBADA SIN FORMALIZAR    ' TO SAL2-SITPRES
            INITIALIZE          ENT1-FECDESEMBOL
           WHEN '9'
            MOVE 'PROPUESTA DENEGADA                   ' TO SAL2-SITPRES
           WHEN OTHER
            STRING 'PROPUESTA EN ESTADO ' DELIMITED BY SIZE
                             ENT1-SITPRES DELIMITED BY SIZE
                    INTO SAL2-SITPRES
           END-EVALUATE.
      * -------------------------------------------------------------- *
       99999-VALIDATIPCART.
      * COL01-I
           IF ENT1-TIPOCREDITO = SPACES OR
              ENT1-TIPOCREDITO = LOW-VALUES
              PERFORM 99999-BUSCATIPCART
           END-IF
      * COL01-F
           EVALUATE ENT1-TIPOCREDITO
              WHEN 'C'
                   MOVE 'COMERCIAL     ' TO  ENT1-TIPO-CARTERA
              WHEN 'H'
                   MOVE 'HIPOTECARIO   ' TO  ENT1-TIPO-CARTERA
              WHEN 'M'
                   MOVE 'MICROCREDITO  ' TO  ENT1-TIPO-CARTERA
              WHEN 'N'
                   MOVE 'CONSUMO       ' TO  ENT1-TIPO-CARTERA
              WHEN OTHER
                   MOVE 'NO DEFINIDO   ' TO  ENT1-TIPO-CARTERA
           END-EVALUATE.
      *
      * COL01-I
      * -------------------------------------------------------------- *
       99999-BUSCATIPCART.
           MOVE ENT1-SUBPRO     TO URMPCT37-I-ELEMENTO
           MOVE '1901'          TO URMPCT37-I-SECCION
           PERFORM 99999-CONSULTAT37.
           MOVE URMPCT37-O-RESTO(1:1) TO ENT1-TIPOCREDITO.
      *
      * -------------------------------------------------------------- *
       99999-CONSULTAT37.
           CALL CTA-UR9CCT37       USING AREA-URMPCT37

           IF URMPCT37-O-COD-RETURN = '00'
              CONTINUE
           ELSE
              DISPLAY '----------------------------------------------'
              DISPLAY 'ERROR CONSULTAR UMTA SECCION ' URMPCT37-I-SECCION
              DISPLAY 'URMPCT37-O-COD-RETURN  : ' URMPCT37-O-COD-RETURN
              DISPLAY '----------------------------------------------'
              MOVE 12           TO RETURN-CODE
              STOP RUN
           END-IF.
      *
      * COL01-F
      * -------------------------------------------------------------- *
       99999-CARACTESPE.
           MOVE 1               TO WS-INDSTRING
           INITIALIZE           WS-CONT
           PERFORM UNTIL WS-INDSTRING > 32
              MOVE ZEROS        TO WS-CONT
              MOVE CTE-ESPECIALES(WS-INDSTRING:1) TO WS-CARACTER
              INSPECT REG-TASAULOG REPLACING ALL WS-CARACTER BY SPACES
              ADD 1             TO WS-INDSTRING
           END-PERFORM.
      * -------------------------------------------------------------- *