      *  UG7CCNRA: RUTINA QUE BUSCA LA TASA RAR DE ACUERDO A LAS       *
      *            CONDICIONES SEGUN EL PRODUCTO                       *
      *            GP17916 CCSS-6856                                   *
      ******************************************************************
      * COL01  26-10-2021  SE REALIZAN AJUSTES EN CONSULTA SEGMENTO    *
      * INETUM CE56375     TASA RAR Y TASA FORMALIZACION               *
      *                    RSD INC000007720682 PROCESO PUGDRAR1        *
      ******************************************************************00001000
      * COL02  01-02-2022  MODIFICACION PARA INCLUIR COLECTIVO-DESTINO *
      * INETUM CE56375     Y CONTROLES TASA RAR LIBRANZA               *
      * SCRUM - SDA36560 - COLWSPREST-54 - COLWSPREST-383 OTORGAR TASAS*
      * PERSONALIZADAS LIBRANZAS                                       *
      ******************************************************************00001000
      * COL03  25-10-2023  CAMBIO EN LA CONSULTA DEL CLUSTERS PARA OBTE*
      * C810846            NER LA TASA PERSONALIZADA                   *
      * SCRUM GLADIADORES  COLWSPREST-21609                            *
      ******************************************************************
      * REFERENCIA : COL04                                             *
      * REALIZO    : BBVA - CFFP                                       *
      * FECHA      : 12/09/2024                                        *
      * SDA-FEATURE: SDA-41748 / COLONECAPN-38                         *
      * DESCRIPCION: CUOTA FIJA - TASA VARIABLE PARA CREDITOS DE       *
      * METODOLOGIA  CONSUMO Y VEHICULO                                *
      * TRADICIONAL  SE INCLUYE DENTRO DE LAS VALIDACIONES DEL PRODUCTO*
      *              DE VEHICULO LA NUEVA LINEA DE VEHICULO CUOTA FIJA *
      *              TASA VARIABLE                                     *
      *----------------------------------------------------------------*00013779
      *  REFERENCIA : BBVA01                                           *00013780
      *  SOLICITO   : C811394                                          *00013781
      *  REALIZO    : BBVA                                             *00013782
      *  FECHA      : 02/10/2024                                       *00013783
      *  DESCRIPCION: AJUSTES CONTROL DB2  OPTIMIZACIONES              *00013784
      *               FEATURE: COLONESCOR-59                           *00013786
      *================================================================*
      *REFERENCIA : COL05                                              *00006894
      *REALIZO    : MICHAEL ANDRES LEON (INDRA COMPANY)                *00006895
      *FECHA      : 12/05/2025                                         *00006896
      *SDA/FEATURE: SDA-42647 / COLONEPRE1-8812                        *00006897
      *DESCRIPCION: SE AJUSTA LA VARIABLE CONTADOR (WS-IND) QUE SE USA *00006898
      *EQUIPO SCRUM PARA ASIGNAR LA POSICION  EN LA VARIABLE WS-VAR-V  *00006899
      *<<AUTOBOTS>> DADO QUE NO COINCIDE PARA ALGUNAS VARIABLES CON LA *00006900
      *             POSICION DE CARGA DE LOS DATOS                     *00006900
      ******************************************************************
      *REFERENCIA : COL06                                              *
      *REALIZO    : RUBEN DAVID GUTIERREZ                              *
      *FECHA      : 25/02/2026                                         *
      *SDA/FEATURE: SDA-56033 / COLONEPRE1-16456                       *
      *DESCRIPCION: SE AJUSTA LA RUTINA PARA APLICAR LA                *
      *             REESTRUCTURACION, OPTIMIZACION Y VALIDACION DE     *
      *             LAS VARIABLES TENIENDO EN CUENTA LA CONSULTA A     *
      *             LOS NUEVOS REGISTROS 99 POR CADA UNA DE LAS        *
      *             LINEAS DE PRODUCTO DE VIVIENDA.                    *
      ******************************************************************
      *REFERENCIA : COL07                                              *
      *REALIZO    : RUBEN DAVID GUTIERREZ                              *
      *FECHA      : 28/05/2026                                         *
      *SDA/FEATURE: SDA-55492 / COLONEPRE1-18373                       *
      *DESCRIPCION: SE AJUSTA PARA INCLUIR LA LINEA ZV PARA TASA       *
      *             VARIABLE LIBRANZAS                                 *
      ******************************************************************
      *REFERENCIA : COL08                                              *
      *REALIZO    : GUSTAVO PAREDES GONZALEZ                          *
      *FECHA      : 01/07/2026                                         *
      *SDA/FEATURE: SDA-56033 / COLONEPRE1-20650                       *
      *DESCRIPCION: SE AJUSTA VALOR DE SALIDA CAMPO UGNRA-CLUSTER PARA *
      *             RETORNAR LA NRA-CLAVEID                            *
      ******************************************************************00001000
      *        I D E N T I F I C A T I O N   D I V I S I O N           *00003000
      ******************************************************************00005000
       IDENTIFICATION DIVISION.                                         00006000
      *                                                                 00007000
         PROGRAM-ID.    UG7CCNRA.                                       00008000
         AUTHOR.        TATIANA SANCHEZ                                 00009000
         DATE-WRITTEN.  27-07-2021.                                     00010000
         DATE-COMPILED. 27-07-2021.                                     00011000
      *                                                                 00012000
      ******************************************************************00028000
      *           E N V I R O N M E N T    D I V I S I O N             *00029000
      ******************************************************************00030000
       ENVIRONMENT DIVISION.                                            00031000
       CONFIGURATION SECTION.                                           00032000
      *                                                                 00033000
      ******************************************************************00034000
      *                   D A T A   D I V I S I O N                    *00035000
      ******************************************************************00036000
       DATA DIVISION.                                                   00037000
      *                                                                 00038000
      ******************************************************************00039000
      *          W O R K I N G   S T O R A G E   S E C T I O N         *00041000
      ******************************************************************00043000
       WORKING-STORAGE SECTION.                                         00045000
      *                                                                 00046000
       01  LT-INICIO-DE-WS.                                             00046100
           05  FILLER                PIC X(42) VALUE                    00046200
               '*** INICIO WORKING STORAGE UG7CCNRA ***'.               00046300
      *                                                                 00052000
      *----------------------------------------------------------------*00053000
      *                      AREA DE CONSTANTES                        *00055000
      *----------------------------------------------------------------*00053000
       01 WSC-CONSTANTES.                                               00058000
           05 WSC-ALF-C                     PIC X(01) VALUE 'C'.        00060000
           05 WSC-ALF-00                    PIC X(02) VALUE '00'.       00061000
           05 WSC-ALF-10                    PIC X(02) VALUE '10'.       00062000
           05 WSC-ALF-20                    PIC X(02) VALUE '20'.       00063000
           05 WSC-ALF-99                    PIC X(02) VALUE '99'.       00064000
           05 WSC-ALF-001                   PIC X(03) VALUE '001'.      00064000
           05 WSC-ALF-00000                 PIC X(05) VALUE '00000'.    00064000
           05 WSC-NUM-15                    PIC 9(02) VALUE 15.         00064000
           05 CTE-C                         PIC X(01) VALUE 'C'.
           05 CTE-V                         PIC X(01) VALUE 'V'.
      *                                                                 00066000
      *-----------------------------------------------------------------00090000
      *                        AREA DE VARIABLES                       *00076000
      *-----------------------------------------------------------------00090000
       01  WSV-VARIABLES.
           05 WSV-X                         PIC 9(15) VALUE 0.
           05 WS-PUNTAJE-BURO               PIC X(03) VALUE SPACES.
           05 WS-PUNT-BURO                  REDEFINES
              WS-PUNTAJE-BURO               PIC 9(03).
           05 WS-PUNTAJE-BURO-N             PIC 9(04) COMP-3 VALUE 0.
           05 WS-CLAVE-ID                   PIC X(01).
           05 WS-CLUSTER                    PIC X(25).
           05 WS-TASA-RAR                   PIC S9(3)V9(5) VALUE 0.
           05 WS-VALIDO                     PIC 9(01).
           05 WS-IND                        PIC 9(04).
           05 WS-I                          PIC 9(04).
      * COL02-I
      *    05 WS-VAR-V                      PIC X(15) VALUE SPACES.
      *    05 WS-RAR-V                      PIC X(15) VALUE SPACES.
           05 WS-VAR-V                      PIC X(17) VALUE SPACES.
           05 WS-RAR-V                      PIC X(17) VALUE SPACES.
      * COL02-F
      * COL03-I
           05 WS-NRA-CLAVEID                PIC X(25) VALUE SPACES.
      * COL03-F
      *
      *-----------------------------------------------------------------00090000
      *              PARA REALIZAR EL CHEQUEO DEL SQLCODE              *00091000
      *-----------------------------------------------------------------00092000
       01  DB2-RETURN-CDE                   PIC S9(9) COMP.             00094000
           88 DB2-OK                        VALUE +0.                   00095000
           88 DB2-NOTFND                    VALUE +100.                 00096000
           88 DB2-DUPREC                    VALUE -811.                 00097000
           88 DB2-EXIREC                    VALUE -803.                 00098000
      *                                                                 00099000
      *-----------------------------------------------------------------00090000
      *               AREA DE SWITCHES                                 *00091000
      *-----------------------------------------------------------------00092000
       01  WSV-SWITCHES.                                                00094000
      *BBVA01-I
      *    05 SW-CURNRA-D                    PIC X.
      *       88 SI-FIN-CURNRA-D                      VALUE 'S'.
      *       88 NO-FIN-CURNRA-D                      VALUE 'N'.
      *BBVA01-F
      *COL06-I
         05 SW-CURCLAVEID                 PIC X(01) VALUE 'N'.
             88 SI-FIN-CURCLAVEID              VALUE 'S'.
             88 NO-FIN-CURCLAVEID              VALUE 'N'.
         05 SW-VAR-01                     PIC X(01) VALUE 'N'.
             88 SI-VAR-01                      VALUE 'S'.
             88 NO-VAR-01                      VALUE 'N'.
         05 SW-VAR-02                     PIC X(01) VALUE 'N'.
             88 SI-VAR-02                      VALUE 'S'.
             88 NO-VAR-02                      VALUE 'N'.
         05 SW-VAR-03                     PIC X(01) VALUE 'N'.
             88 SI-VAR-03                      VALUE 'S'.
             88 NO-VAR-03                      VALUE 'N'.
         05 SW-VAR-04                     PIC X(01) VALUE 'N'.
             88 SI-VAR-04                      VALUE 'S'.
             88 NO-VAR-04                      VALUE 'N'.
         05 SW-VAR-05                     PIC X(01) VALUE 'N'.
             88 SI-VAR-05                      VALUE 'S'.
             88 NO-VAR-05                      VALUE 'N'.
         05 SW-VAR-06                     PIC X(01) VALUE 'N'.
             88 SI-VAR-06                      VALUE 'S'.
             88 NO-VAR-06                      VALUE 'N'.
         05 SW-VAR-07                     PIC X(01) VALUE 'N'.
             88 SI-VAR-07                      VALUE 'S'.
             88 NO-VAR-07                      VALUE 'N'.
         05 SW-VAR-08                     PIC X(01) VALUE 'N'.
             88 SI-VAR-08                      VALUE 'S'.
             88 NO-VAR-08                      VALUE 'N'.
         05 SW-VAR-09                     PIC X(01) VALUE 'N'.
             88 SI-VAR-09                      VALUE 'S'.
             88 NO-VAR-09                      VALUE 'N'.
         05 SW-VAR-10                     PIC X(01) VALUE 'N'.
             88 SI-VAR-10                      VALUE 'S'.
             88 NO-VAR-10                      VALUE 'N'.
         05 SW-VAR-11                     PIC X(01) VALUE 'N'.
             88 SI-VAR-11                      VALUE 'S'.
             88 NO-VAR-11                      VALUE 'N'.
         05 SW-VAR-12                     PIC X(01) VALUE 'N'.
             88 SI-VAR-12                      VALUE 'S'.
             88 NO-VAR-12                      VALUE 'N'.
         05 SW-VAR-13                     PIC X(01) VALUE 'N'.
             88 SI-VAR-13                      VALUE 'S'.
             88 NO-VAR-13                      VALUE 'N'.
         05 SW-VAR-14                     PIC X(01) VALUE 'N'.
             88 SI-VAR-14                      VALUE 'S'.
             88 NO-VAR-14                      VALUE 'N'.
         05 SW-VAR-15                     PIC X(01) VALUE 'N'.
             88 SI-VAR-15                      VALUE 'S'.
             88 NO-VAR-15                      VALUE 'N'.
         05 SW-VAR-16                     PIC X(01) VALUE 'N'.
             88 SI-VAR-16                      VALUE 'S'.
             88 NO-VAR-16                      VALUE 'N'.
         05 SW-VAR-17                     PIC X(01) VALUE 'N'.
             88 SI-VAR-17                      VALUE 'S'.
             88 NO-VAR-17                      VALUE 'N'.
         05 SW-VAR-18                     PIC X(01) VALUE 'N'.
             88 SI-VAR-18                      VALUE 'S'.
             88 NO-VAR-18                      VALUE 'N'.
         05 SW-VAR-19                     PIC X(01) VALUE 'N'.
             88 SI-VAR-19                      VALUE 'S'.
             88 NO-VAR-19                      VALUE 'N'.
         05 SW-VAR-20                     PIC X(01) VALUE 'N'.
             88 SI-VAR-20                      VALUE 'S'.
             88 NO-VAR-20                      VALUE 'N'.
         05 SW-VAR-21                     PIC X(01) VALUE 'N'.
             88 SI-VAR-21                      VALUE 'S'.
             88 NO-VAR-21                      VALUE 'N'.
         05 SW-VAR-22                     PIC X(01) VALUE 'N'.
             88 SI-VAR-22                      VALUE 'S'.
             88 NO-VAR-22                      VALUE 'N'.
         05 SW-VAR-23                     PIC X(01) VALUE 'N'.
             88 SI-VAR-23                      VALUE 'S'.
             88 NO-VAR-23                      VALUE 'N'.
         05 SW-REG99                      PIC X(01) VALUE 'N'.
             88 SI-REG99                       VALUE 'S'.
             88 NO-REG99                       VALUE 'N'.
      *COL06-F
      *
           05 WSV-ERRORES                    PIC X.
              88 WS-ERROR-SI                          VALUE 'S'.
              88 WS-ERROR-NO                          VALUE 'N'.

      *-----------------------------------------------------------------
      *                  COPY DE MANEJO DE MENSAJES DB2                *00111000
      *-----------------------------------------------------------------
           EXEC SQL
               INCLUDE SQLCA
           END-EXEC.
      *
      *----------------------------------------------------------------*
      *      INCLUDE DE LA TABLA : UGDTNRA                             *
      *----------------------------------------------------------------*

           EXEC SQL
              INCLUDE UGGTNRA
           END-EXEC.

           EXEC SQL
              INCLUDE UGTCNRA
           END-EXEC.

      *-----------------------------------------------------------------
      *                 DEFINICION DE CURSORES                         *00108000
      *-----------------------------------------------------------------
      *COL06-I
      *-----------------------------------------------------------------
      *     CURSOR PARA TRAER LAS DIFERENTES VARIABLES A CONSULTAR     *
      *-----------------------------------------------------------------
           EXEC SQL
              DECLARE CURCLAVEID CURSOR FOR
              SELECT NRA_CLAVE_ID
              FROM   UGDTNRA
              WHERE  NRA_VARIABLE      = '99'   AND
                     NRA_ESTADO        = 'VS'   AND
                     NRA_TIPO_PRODUCTO =:NRA-TIPO-PRODUCTO
           END-EXEC.
      *COL06-F
      *-----------------------------------------------------------------
      *     BUSCA LA TASA DE ACUERDO A LAS CLAVES DE CADA VARIABLE     *00111000
      *-----------------------------------------------------------------
      *BBVA01-I
      *    EXEC SQL                                                     00208500
      *    DECLARE CURNRA-D CURSOR FOR                                  00208600
      *    SELECT NRA_CLAVE_ID   ,                                      00208700
      *           NRA_CLUSTER    ,                                      00208800
      *           NRA_ESTADO     ,                                      00208900
      *           NRA_TASA       ,                                      00209000
      *           NRA_TIMESTAMP                                         00209500
      *    FROM   UGDTNRA                                               00209600
      *    WHERE  NRA_TIPO_PRODUCTO =:NRA-TIPO-PRODUCTO AND             00209700
      *           NRA_VARIABLE      =:NRA-VARIABLE      AND             00209800
      *           NRA_ESTADO        =:NRA-ESTADO                        00209900
      *    END-EXEC.                                                    00210100
      *BBVA01-F

      ******************************************************************00162100
       01  LT-FINAL-DE-WS.                                              00162200
           05  LT-FINAL-DE-WS             PIC X(42) VALUE               00162300
               '*****FINAL WORKING STORAGE UG7CCNRA *****'.             00162400
      ******************************************************************00162500
      *
      ******************************************************************00168000
      *                 L I N K A G E   S E C T I O N                  *00169000
      ******************************************************************00170000
       LINKAGE SECTION.                                                 00171000
                                                                        00172000
       01  DFHCOMMAREA.                                                 00173000
       COPY UGWCNRA.                                                    00174000
      *                                                                 00175000
      ******************************************************************00176000
      *              P R O C E D U R E   D I V I S I O N               *00178000
      ******************************************************************00180000
       PROCEDURE DIVISION USING DFHCOMMAREA.                            00181000
      *                                                                 00182000
           MOVE WSC-ALF-00                  TO UGNRA-COD-RETORNO        00213000

           EVALUATE UGNRA-OPCION
              WHEN CTE-V
                   PERFORM 9999-CONTROL-TASA
              WHEN CTE-C
                   PERFORM 9999-CONSULTA-TASARAR
              WHEN OTHER
                   MOVE WSC-ALF-10              TO UGNRA-COD-RETORNO
                   MOVE 'CAMPO OPCION NO     '  TO UGNRA-VAR1-ERROR
                   MOVE 'VALIDA              '  TO UGNRA-VAR2-ERROR
           END-EVALUATE.
           PERFORM 3000-FINAL-PROGRAMA.                                 00187000
      *                                                                 00188000
      *-----------------------------------------------------------------00222000
      *                    9999-CONSULTA-TASARAR                       *00223000
      *-----------------------------------------------------------------00222000
       9999-CONSULTA-TASARAR.
      *                                                                 00188000
           PERFORM 1000-INICIO-PROGRAMA                                 00183000
           PERFORM 2000-PROCESO-PROGRAMA.                               00185000
      *                                                                 00188000
      * -------------------------------------------------------------- *00189000
      *                      1000-INICIO-PROGRAMA                      *00191000
      *-----------------------------------------------------------------00189000
      *   REALIZA LAS FUNCIONES DE COMIENZO DE PROGRAMA:               *00193000
      *   - INICIALIZA VARIABLES                                       *00194000
      *-----------------------------------------------------------------00189000
       1000-INICIO-PROGRAMA.                                            00196000
      *                                                                 00208000
           INITIALIZE UGNRA-SALIDA
                      WSV-VARIABLES.
      *                                                                 00215000
      *-----------------------------------------------------------------00222000
      *                    2000-PROCESO-PROGRAMA                       *00223000
      *-----------------------------------------------------------------00222000
      ******************************************************************00230000
       2000-PROCESO-PROGRAMA.                                           00231000
      *                                                                 00232000
           PERFORM 2100-VALIDAR-ENTRADA                                 00233000
      *COL06-I
           PERFORM 2150-ABRIR-CURCLAVEID
           PERFORM 2165-FETCH-CURCLAVEID UNTIL SI-FIN-CURCLAVEID
           PERFORM 2170-CERRAR-CURCLAVEID
      *COL06-F
           PERFORM 2200-VALIDA-VARIABLES                                00276000
           PERFORM 2400-CONSULTA-TASA.                                  00381000
      *                                                                 00235000
      *-----------------------------------------------------------------00237000
      *                    2100-VALIDAR-ENTRADA                        *00239000
      *-----------------------------------------------------------------00237000
       2100-VALIDAR-ENTRADA.                                            00244000
      *                                                                 00260000
           IF UGNRA-PRODUCTO EQUAL SPACES OR LOW-VALUES                 00261000
               MOVE WSC-ALF-10              TO UGNRA-COD-RETORNO
               MOVE 'CAMPO NO INFORMADO  '  TO UGNRA-VAR1-ERROR
               MOVE 'TIPO PRODUCTO       '  TO UGNRA-VAR2-ERROR
               PERFORM 3000-FINAL-PROGRAMA
           END-IF                                                       00278000
      *                                                                 00260000
           IF UGNRA-BURO EQUAL SPACES OR LOW-VALUES                     00261000
               MOVE WSC-ALF-10              TO UGNRA-COD-RETORNO
               MOVE 'CAMPO NO INFORMADO  '  TO UGNRA-VAR1-ERROR
               MOVE 'BURO                '  TO UGNRA-VAR2-ERROR
               PERFORM 3000-FINAL-PROGRAMA
           END-IF                                                       00278000
      *                                                                 00260000
           IF UGNRA-NOMINA EQUAL SPACES OR LOW-VALUES                   00261000
               MOVE WSC-ALF-10              TO UGNRA-COD-RETORNO
               MOVE 'CAMPO NO INFORMADO  '  TO UGNRA-VAR1-ERROR
               MOVE 'DOMICILIACION NOMINA'  TO UGNRA-VAR2-ERROR
               PERFORM 3000-FINAL-PROGRAMA
           END-IF                                                       00278000
      *                                                                 00260000
           IF UGNRA-SITLAB EQUAL SPACES OR LOW-VALUES                   00261000
               MOVE WSC-ALF-10              TO UGNRA-COD-RETORNO
               MOVE 'CAMPO NO INFORMADO  '  TO UGNRA-VAR1-ERROR
               MOVE 'SITUACION LABORAL   '  TO UGNRA-VAR2-ERROR
               PERFORM 3000-FINAL-PROGRAMA
           END-IF                                                       00278000
      *                                                                 00260000
      *COL04-I
      *    IF UGNRA-PRODUCTO = 'V'
           IF UGNRA-PRODUCTO = 'V' OR UGNRA-PRODUCTO = 'VV'
      *COL04-F
              IF UGNRA-TIPVEH EQUAL SPACES OR LOW-VALUES                   00261
                  MOVE WSC-ALF-10              TO UGNRA-COD-RETORNO
                  MOVE 'CAMPO NO INFORMADO  '  TO UGNRA-VAR1-ERROR
                  MOVE 'TIPO VEHICULO       '  TO UGNRA-VAR2-ERROR
                  PERFORM 3000-FINAL-PROGRAMA
              END-IF                                                       00278
      *                                                                 00260000
              IF UGNRA-ESTADO EQUAL SPACES OR LOW-VALUES                   00261
                  MOVE WSC-ALF-10              TO UGNRA-COD-RETORNO
                  MOVE 'CAMPO NO INFORMADO  '  TO UGNRA-VAR1-ERROR
                  MOVE 'ESTADO VEHICULO     '  TO UGNRA-VAR2-ERROR
                  PERFORM 3000-FINAL-PROGRAMA
              END-IF                                                       00278
           END-IF.                                                         00278
      *                                                                 00260000
      *COL06-I
      *----------------------------------------------------------------*
      *                      2150-ABRIR-CURCLAVEID                     *
      *----------------------------------------------------------------*
       2150-ABRIR-CURCLAVEID.
      *
           SET NO-FIN-CURCLAVEID    TO TRUE
           SET NO-REG99             TO TRUE
           SET NO-VAR-01 NO-VAR-02 NO-VAR-03 NO-VAR-04 NO-VAR-05
               NO-VAR-06 NO-VAR-07 NO-VAR-08 NO-VAR-09 NO-VAR-10
               NO-VAR-11 NO-VAR-12 NO-VAR-13 NO-VAR-14 NO-VAR-15
               NO-VAR-16 NO-VAR-17 NO-VAR-18 NO-VAR-19 NO-VAR-20
               NO-VAR-21 NO-VAR-22 NO-VAR-23            TO TRUE

           MOVE UGNRA-PRODUCTO TO NRA-TIPO-PRODUCTO
      *
           EXEC SQL
              OPEN CURCLAVEID
           END-EXEC
      *
           MOVE SQLCODE                   TO DB2-RETURN-CDE
           EVALUATE TRUE
              WHEN DB2-OK
                 CONTINUE
              WHEN OTHER
                 MOVE WSC-ALF-99              TO UGNRA-COD-RETORNO
                 MOVE SQLERRM                 TO UGNRA-SQLERRM
                 MOVE 'ERROR OPEN'            TO UGNRA-VAR1-ERROR
                 MOVE 'CURSOR CURCLAVEID'     TO UGNRA-VAR2-ERROR
                 MOVE DB2-RETURN-CDE          TO UGNRA-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *----------------------------------------------------------------*
      *                      2165-FETCH-CURCLAVEID                     *
      *----------------------------------------------------------------*
       2165-FETCH-CURCLAVEID.
      *
           EXEC SQL
              FETCH CURCLAVEID
              INTO :NRA-CLAVE-ID
           END-EXEC
      *
           MOVE SQLCODE                   TO DB2-RETURN-CDE
           EVALUATE TRUE
              WHEN DB2-OK
                 SET SI-REG99 TO TRUE
                 PERFORM 21651-VALIDA-VARIABLES
              WHEN DB2-NOTFND
                 SET SI-FIN-CURCLAVEID TO TRUE
              WHEN OTHER
                 MOVE WSC-ALF-99               TO UGNRA-COD-RETORNO
                 MOVE SQLERRM                  TO UGNRA-SQLERRM
                 MOVE 'ERROR FETCH'            TO UGNRA-VAR1-ERROR
                 MOVE 'CURSOR CURCLAVEID'      TO UGNRA-VAR2-ERROR
                 MOVE DB2-RETURN-CDE           TO UGNRA-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *----------------------------------------------------------------*
      *                     21651-VALIDA-VARIABLES                     *
      *----------------------------------------------------------------*
       21651-VALIDA-VARIABLES.
      *
           EVALUATE NRA-CLAVE-ID
              WHEN '01'
                 SET SI-VAR-01 TO TRUE
              WHEN '02'
                 SET SI-VAR-02 TO TRUE
              WHEN '03'
                 SET SI-VAR-03 TO TRUE
              WHEN '04'
                 SET SI-VAR-04 TO TRUE
              WHEN '05'
                 SET SI-VAR-05 TO TRUE
              WHEN '06'
                 SET SI-VAR-06 TO TRUE
              WHEN '07'
                 SET SI-VAR-07 TO TRUE
              WHEN '08'
                 SET SI-VAR-08 TO TRUE
              WHEN '09'
                 SET SI-VAR-09 TO TRUE
              WHEN '10'
                 SET SI-VAR-10 TO TRUE
              WHEN '11'
                 SET SI-VAR-11 TO TRUE
              WHEN '12'
                 SET SI-VAR-12 TO TRUE
              WHEN '13'
                 SET SI-VAR-13 TO TRUE
              WHEN '14'
                 SET SI-VAR-14 TO TRUE
              WHEN '15'
                 SET SI-VAR-15 TO TRUE
              WHEN '16'
                 SET SI-VAR-16 TO TRUE
              WHEN '17'
                 SET SI-VAR-17 TO TRUE
              WHEN '18'
                 SET SI-VAR-18 TO TRUE
              WHEN '19'
                 SET SI-VAR-19 TO TRUE
              WHEN '20'
                 SET SI-VAR-20 TO TRUE
              WHEN '21'
                 SET SI-VAR-21 TO TRUE
              WHEN '22'
                 SET SI-VAR-22 TO TRUE
              WHEN '23'
                 SET SI-VAR-23 TO TRUE
           END-EVALUATE.
      *
      *----------------------------------------------------------------*
      *                      2170-CERRAR-CURCLAVEID                    *
      *----------------------------------------------------------------*
       2170-CERRAR-CURCLAVEID.
      *
           EXEC SQL
              CLOSE CURCLAVEID
           END-EXEC
      *
           MOVE SQLCODE                   TO DB2-RETURN-CDE
           EVALUATE TRUE
              WHEN DB2-OK
                 CONTINUE
              WHEN OTHER
                 MOVE WSC-ALF-99               TO UGNRA-COD-RETORNO
                 MOVE SQLERRM                  TO UGNRA-SQLERRM
                 MOVE 'ERROR CLOSE'            TO UGNRA-VAR1-ERROR
                 MOVE 'CURSOR CURCLAVEID'      TO UGNRA-VAR2-ERROR
                 MOVE DB2-RETURN-CDE           TO UGNRA-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *COL06-F
      *----------------------------------------------------------------*00351000
      *                      2200-CONSULTA-UGDTNRA                     *00353000
      *----------------------------------------------------------------*00351000
       2200-VALIDA-VARIABLES.                                           00358000
           MOVE UGNRA-PRODUCTO            TO NRA-TIPO-PRODUCTO
           MOVE UGNRA-FECHA               TO NRA-FECHA-INI
                                             NRA-FECHA-FIN
           MOVE 1                         TO WS-IND

           MOVE ALL '0'                   TO WS-VAR-V
                                             WS-RAR-V

      *COL06-I
           IF SI-REG99
              IF SI-VAR-01
                 PERFORM 2210-VALIDA-BURO
              END-IF
              IF SI-VAR-02
                 PERFORM 2220-VALIDA-DOM-NOMINA
              END-IF
              IF SI-VAR-03
                 PERFORM 2230-VALIDA-LABORAL
              END-IF
              IF SI-VAR-04
                 PERFORM 2240-VALIDA-INGRESOS
              END-IF
              IF SI-VAR-05
                 PERFORM 2250-VALIDA-MONTO
              END-IF
              IF SI-VAR-06
                 PERFORM 2260-VALIDA-PLAZO
              END-IF
              IF SI-VAR-07
                 PERFORM 2270-VALIDA-EDAD
              END-IF
              IF SI-VAR-08
                 PERFORM 2280-VALIDA-SEGMENTO
              END-IF
              IF SI-VAR-09
                 PERFORM 2290-VALIDA-COLECTIVO
              END-IF
              IF SI-VAR-10
                 PERFORM 2300-VALIDA-RIESGO
              END-IF
              IF SI-VAR-11
                 PERFORM 2320-VALIDA-ESTADO
              END-IF
              IF SI-VAR-12
                 PERFORM 2350-VALIDA-FINANCIA
              END-IF
              IF SI-VAR-13
                 PERFORM 2330-VALIDA-GAMA
              END-IF
              IF SI-VAR-14
                 PERFORM 2340-VALIDA-TIPO
              END-IF
              IF SI-VAR-15
                 PERFORM 2310-VALIDA-CLIENTEV
              END-IF
              IF SI-VAR-16
                 PERFORM 2360-VALIDA-COLECTIVO-LB
              END-IF
              IF SI-VAR-17
                 PERFORM 2370-VALIDA-DESTINO-LB
              END-IF
           ELSE
      *COL06-F
              PERFORM 2210-VALIDA-BURO
              PERFORM 2220-VALIDA-DOM-NOMINA
              PERFORM 2230-VALIDA-LABORAL
              PERFORM 2240-VALIDA-INGRESOS
              PERFORM 2250-VALIDA-MONTO
              PERFORM 2260-VALIDA-PLAZO
              PERFORM 2270-VALIDA-EDAD
              PERFORM 2280-VALIDA-SEGMENTO
              PERFORM 2290-VALIDA-COLECTIVO
              PERFORM 2300-VALIDA-RIESGO
              PERFORM 2310-VALIDA-CLIENTEV
              PERFORM 2350-VALIDA-FINANCIA
      *COL02-I
      *COL07-I
      *        IF NRA-TIPO-PRODUCTO = 'Z'
              IF NRA-TIPO-PRODUCTO = 'Z' OR NRA-TIPO-PRODUCTO = 'ZV'
      *COL07-F
                 PERFORM 2360-VALIDA-COLECTIVO-LB
                 PERFORM 2370-VALIDA-DESTINO-LB
              END-IF
      *COL02-F
      *COL04-I
              IF NRA-TIPO-PRODUCTO = 'V' OR NRA-TIPO-PRODUCTO = 'VV'
                 PERFORM 2320-VALIDA-ESTADO
                 PERFORM 2330-VALIDA-GAMA
                 PERFORM 2340-VALIDA-TIPO
              END-IF
      *COL04-F
      *COL06-F
           END-IF
           .
      *COL06-F
      *                                                                 00359600
      *----------------------------------------------------------------*00351000
      *                     2210-VALIDA-BURO                           *00353000
      *----------------------------------------------------------------*00351000
       2210-VALIDA-BURO.                                                00358000
      *                                                                 00359600
           MOVE '01'                      TO NRA-VARIABLE
           MOVE 'VS'                      TO NRA-ESTADO
           MOVE UGNRA-BURO                TO WS-PUNTAJE-BURO
           MOVE WS-PUNT-BURO              TO WS-PUNTAJE-BURO-N
           MOVE WS-PUNTAJE-BURO-N         TO NRA-RANGO-INI
                                             NRA-RANGO-FIN
      *
           PERFORM 2299-CONSULTA-RANGO

           IF DB2-OK
              MOVE NRA-CLAVE-ID            TO WS-CLAVE-ID
           ELSE
              MOVE WSC-ALF-00000           TO WS-CLAVE-ID               00381000
           END-IF

      *COL06-I
           MOVE 1                   TO WS-IND
           MOVE WS-CLAVE-ID         TO WS-VAR-V(WS-IND:1).
      *    ADD 1                    TO WS-IND.
      *COL06-F

      *----------------------------------------------------------------*00351000
      *                    2220-VALIDA-DOM-NOMINA                      *00353000
      *----------------------------------------------------------------*00351000
       2220-VALIDA-DOM-NOMINA.                                          00358000
      *                                                                 00359600
           MOVE '02'                      TO NRA-VARIABLE
           MOVE 'VS'                      TO NRA-ESTADO
           MOVE UGNRA-NOMINA              TO NRA-IND-DOM-NOMINA
      *
           EXEC SQL
             SELECT NRA_CLAVE_ID
               INTO :NRA-CLAVE-ID
               FROM UGDTNRA
              WHERE NRA_VARIABLE        =:NRA-VARIABLE
                AND NRA_TIPO_PRODUCTO   =:NRA-TIPO-PRODUCTO
                AND NRA_FECHA_INI      <=:NRA-FECHA-INI
                AND NRA_FECHA_FIN      >=:NRA-FECHA-FIN
                AND NRA_IND_DOM_NOMINA  =:NRA-IND-DOM-NOMINA
                AND NRA_ESTADO          =:NRA-ESTADO
           END-EXEC
      *                                                                 00378000
           MOVE SQLCODE                   TO DB2-RETURN-CDE
           EVALUATE TRUE                                                00379000
              WHEN DB2-OK                                               00380000
                 MOVE NRA-CLAVE-ID        TO WS-CLAVE-ID                00213000
              WHEN DB2-NOTFND                                           00380000
                 MOVE WSC-ALF-20          TO UGNRA-COD-RETORNO          00213000
                 MOVE ZEROES              TO WS-CLAVE-ID                00213000
              WHEN OTHER                                                00382000
                 MOVE WSC-ALF-99              TO UGNRA-COD-RETORNO
                 MOVE SQLERRM                 TO UGNRA-SQLERRM
                 MOVE 'UGDTNRA'               TO UGNRA-VAR1-ERROR
                 MOVE 'DOMICIALIZACION    '   TO UGNRA-VAR2-ERROR
                 MOVE DB2-RETURN-CDE          TO UGNRA-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE                                                 00392000

      *COL06-I
           MOVE 2                   TO WS-IND
           MOVE WS-CLAVE-ID         TO WS-VAR-V(WS-IND:1).              00213000
      *    ADD 1                    TO WS-IND.
      *COL06-F
      *                                                                 00390000
      *----------------------------------------------------------------*00351000
      *                      2230-VALIDA-LABORAL                       *00353000
      *----------------------------------------------------------------*00351000
       2230-VALIDA-LABORAL.                                             00358000
      *                                                                 00359600
           MOVE '03'                      TO NRA-VARIABLE
           MOVE 'VS'                      TO NRA-ESTADO
           MOVE UGNRA-SITLAB              TO NRA-SITUA-LABORAL
      *
           EXEC SQL
             SELECT NRA_CLAVE_ID
               INTO :NRA-CLAVE-ID
               FROM UGDTNRA
              WHERE NRA_VARIABLE        =:NRA-VARIABLE
                AND NRA_TIPO_PRODUCTO   =:NRA-TIPO-PRODUCTO
                AND NRA_FECHA_INI      <=:NRA-FECHA-INI
                AND NRA_FECHA_FIN      >=:NRA-FECHA-FIN
                AND NRA_SITUA_LABORAL   =:NRA-SITUA-LABORAL
                AND NRA_ESTADO          =:NRA-ESTADO
           END-EXEC.
      *                                                                 00378000
           MOVE SQLCODE                       TO DB2-RETURN-CDE
           EVALUATE TRUE                                                00379000
              WHEN DB2-OK                                               00380000
                 MOVE NRA-CLAVE-ID            TO WS-CLAVE-ID            00213000
              WHEN DB2-NOTFND                                           00380000
                 MOVE WSC-ALF-20              TO UGNRA-COD-RETORNO      00213000
                 MOVE WSC-ALF-00000           TO WS-CLAVE-ID            00381000
              WHEN OTHER                                                00382000
                 MOVE WSC-ALF-99              TO UGNRA-COD-RETORNO
                 MOVE SQLERRM                 TO UGNRA-SQLERRM
                 MOVE 'UGDTNRA'               TO UGNRA-VAR1-ERROR
                 MOVE 'SIT. LABORAL       '   TO UGNRA-VAR2-ERROR
                 MOVE DB2-RETURN-CDE          TO UGNRA-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE                                                 00392000

      *COL06-I
           MOVE 3                             TO WS-IND
           MOVE WS-CLAVE-ID                   TO WS-VAR-V(WS-IND:1).    00213000
      *    ADD 1                              TO WS-IND.
      *COL06-F
      *                                                                 00390000
      *----------------------------------------------------------------*00351000
      *                     2240-VALIDA-INGRESOS                       *00353000
      *----------------------------------------------------------------*00351000
       2240-VALIDA-INGRESOS.                                            00358000
      *                                                                 00359600
           MOVE '04'                      TO NRA-VARIABLE
           MOVE 'VS'                      TO NRA-ESTADO
           MOVE UGNRA-INGRESOS            TO NRA-MONTO-INICIAL
                                             NRA-MONTO-FINAL
      *
           PERFORM 2299-CONSULTA-MONTO

           IF DB2-OK
              MOVE NRA-CLAVE-ID            TO WS-CLAVE-ID
           ELSE
              MOVE WSC-ALF-00000           TO WS-CLAVE-ID               00381000
           END-IF

      *COL06-I
           MOVE 4                          TO WS-IND
           MOVE WS-CLAVE-ID                TO WS-VAR-V(WS-IND:1).       00213000
      *    ADD 1                           TO WS-IND.
      *COL06-F

      *----------------------------------------------------------------*00351000
      *                    2250-VALIDA-MONTO                           *00353000
      *----------------------------------------------------------------*00351000
       2250-VALIDA-MONTO.                                               00358000
      *                                                                 00359600
           MOVE '05'                      TO NRA-VARIABLE
           MOVE 'VS'                      TO NRA-ESTADO
           MOVE UGNRA-MONTO               TO NRA-MONTO-INICIAL
                                             NRA-MONTO-FINAL
      *
           PERFORM 2299-CONSULTA-MONTO

           IF DB2-OK
              MOVE NRA-CLAVE-ID            TO WS-CLAVE-ID
           ELSE
              MOVE WSC-ALF-00000           TO WS-CLAVE-ID               00381000
           END-IF

      *COL06-I
           MOVE 5                          TO WS-IND
           MOVE WS-CLAVE-ID                TO WS-VAR-V(WS-IND:1).       00213000
      *    ADD 1                           TO WS-IND.
      *COL06-F

      *----------------------------------------------------------------*00351000
      *                      2260-VALIDA-PLAZO                         *00353000
      *----------------------------------------------------------------*00351000
       2260-VALIDA-PLAZO.                                               00358000
      *                                                                 00359600
           MOVE '06'                      TO NRA-VARIABLE
           MOVE 'VS'                      TO NRA-ESTADO
           MOVE UGNRA-PLAZO               TO NRA-RANGO-INI
                                             NRA-RANGO-FIN
      *
           PERFORM 2299-CONSULTA-RANGO

           IF DB2-OK
              MOVE NRA-CLAVE-ID            TO WS-CLAVE-ID
           ELSE
              MOVE WSC-ALF-00000           TO WS-CLAVE-ID               00381000
           END-IF

      *COL06-I
           MOVE 6                          TO WS-IND
           MOVE WS-CLAVE-ID                TO WS-VAR-V(WS-IND:1).       00213000
      *    ADD 1                           TO WS-IND.
      *COL06-F

      *----------------------------------------------------------------*00351000
      *                      2270-VALIDA-EDAD                          *00353000
      *----------------------------------------------------------------*00351000
       2270-VALIDA-EDAD.                                                00358000
      *                                                                 00359600
           MOVE '07'                      TO NRA-VARIABLE
           MOVE 'VS'                      TO NRA-ESTADO
           MOVE UGNRA-EDAD                TO NRA-RANGO-INI
                                             NRA-RANGO-FIN
      *
           PERFORM 2299-CONSULTA-RANGO

           IF DB2-OK
              MOVE NRA-CLAVE-ID            TO WS-CLAVE-ID
           ELSE
              MOVE WSC-ALF-00000           TO WS-CLAVE-ID               00381000
           END-IF

      *COL06-I
           MOVE 7                          TO WS-IND
           MOVE WS-CLAVE-ID                TO WS-VAR-V(WS-IND:1).       00213000
      *    ADD 1                           TO WS-IND.
      *COL06-F

      *----------------------------------------------------------------*00351000
      *                    2280-VALIDA-SEGMENTO                        *00353000
      *----------------------------------------------------------------*00351000
       2280-VALIDA-SEGMENTO.                                            00358000
      *
           MOVE '08'                      TO NRA-VARIABLE
           MOVE 'VS'                      TO NRA-ESTADO
      *COL01-I
      *    MOVE UGNRA-SEGMENTO            TO NRA-MONTO-INICIAL
      *                                      NRA-MONTO-FINAL
           MOVE UGNRA-SEGMENTO            TO NRA-SEGMENTO
      *COL01-F
      *
           PERFORM 2299-CONSULTA-VALOR

           IF DB2-OK
              MOVE NRA-CLAVE-ID            TO WS-CLAVE-ID
           ELSE
              MOVE WSC-ALF-00000           TO WS-CLAVE-ID               00381000
           END-IF

      *COL06-I
           MOVE 8                          TO WS-IND
           MOVE WS-CLAVE-ID                TO WS-VAR-V(WS-IND:1).       00213000
      *    ADD 1                           TO WS-IND.
      *COL06-F

      *----------------------------------------------------------------*00351000
      *                    2290-VALIDA-COLECTIVO                       *00353000
      *----------------------------------------------------------------*00351000
       2290-VALIDA-COLECTIVO.                                           00358000
      *                                                                 00359600
           MOVE '09'                      TO NRA-VARIABLE
           MOVE 'VS'                      TO NRA-ESTADO
      *COL01-I
      *    MOVE UGNRA-COLECTIVO           TO NRA-MONTO-INICIAL
      *                                      NRA-MONTO-FINAL
           MOVE UGNRA-COLECTIVO           TO NRA-SEGMENTO
      *COL01-F
      *
           PERFORM 2299-CONSULTA-VALOR

           IF DB2-OK
              MOVE NRA-CLAVE-ID            TO WS-CLAVE-ID
           ELSE
              MOVE WSC-ALF-00000           TO WS-CLAVE-ID               00381000
           END-IF

      *COL06-I
           MOVE 9                          TO WS-IND
           MOVE WS-CLAVE-ID                TO WS-VAR-V(WS-IND:1).       00213000
      *    ADD 1                           TO WS-IND.
      *COL06-F

      *----------------------------------------------------------------*00351000
      *                    2300-VALIDA-RIESGO                          *00353000
      *----------------------------------------------------------------*00351000
       2300-VALIDA-RIESGO.                                              00358000
      *                                                                 00359600
           MOVE '10'                      TO NRA-VARIABLE
           MOVE 'VS'                      TO NRA-ESTADO
           MOVE UGNRA-RIESGO              TO NRA-MONTO-INICIAL
                                             NRA-MONTO-FINAL
      *
           PERFORM 2299-CONSULTA-MONTO

           IF DB2-OK
              MOVE NRA-CLAVE-ID            TO WS-CLAVE-ID
           ELSE
              MOVE WSC-ALF-00000           TO WS-CLAVE-ID               00381000
           END-IF

      *COL06-I
           MOVE 10                         TO WS-IND
           MOVE WS-CLAVE-ID                TO WS-VAR-V(WS-IND:1).       00213000
      *    ADD 1                           TO WS-IND.
      *COL06-F

      *----------------------------------------------------------------*00351000
      *                     2310-VALIDA-CLIENTEV                       *00353000
      *----------------------------------------------------------------*00351000
       2310-VALIDA-CLIENTEV.                                            00358000
      *                                                                 00359600
           MOVE '15'                      TO NRA-VARIABLE
           MOVE 'VS'                      TO NRA-ESTADO
           MOVE UGNRA-INDVIP              TO NRA-IND-CLIENTE-VIP
      *
           EXEC SQL
             SELECT NRA_CLAVE_ID
               INTO :NRA-CLAVE-ID
               FROM UGDTNRA
              WHERE NRA_VARIABLE        =:NRA-VARIABLE
                AND NRA_TIPO_PRODUCTO   =:NRA-TIPO-PRODUCTO
                AND NRA_FECHA_INI      <=:NRA-FECHA-INI
                AND NRA_FECHA_FIN      >=:NRA-FECHA-FIN
                AND NRA_IND_CLIENTE_VIP =:NRA-IND-CLIENTE-VIP
                AND NRA_ESTADO          =:NRA-ESTADO
           END-EXEC.
      *                                                                 00378000
           MOVE SQLCODE                       TO DB2-RETURN-CDE
           EVALUATE TRUE                                                00379000
              WHEN DB2-OK                                               00380000
                 MOVE NRA-CLAVE-ID            TO WS-CLAVE-ID            00213000
              WHEN DB2-NOTFND                                           00380000
                 MOVE WSC-ALF-20              TO UGNRA-COD-RETORNO      00213000
                 MOVE WSC-ALF-00000           TO WS-CLAVE-ID            00381000
              WHEN OTHER                                                00382000
                 MOVE WSC-ALF-99              TO UGNRA-COD-RETORNO
                 MOVE SQLERRM                 TO UGNRA-SQLERRM
                 MOVE 'UGDTNRA'               TO UGNRA-VAR1-ERROR
                 MOVE 'CLIENTE VIP        '   TO UGNRA-VAR2-ERROR
                 MOVE DB2-RETURN-CDE          TO UGNRA-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE                                                 00392000

      *COL05-I
           MOVE 15  TO WS-IND
           MOVE WS-CLAVE-ID                TO WS-VAR-V(WS-IND:1).
      *    MOVE WS-CLAVE-ID                TO WS-VAR-V(WS-IND:1)        00213000
      *    ADD 1                           TO WS-IND.
      *COL05-F
      *                                                                 00390000
      *----------------------------------------------------------------*00351000
      *                    2320-VALIDA-ESTADO                          *00353000
      *----------------------------------------------------------------*00351000
       2320-VALIDA-ESTADO.                                              00358000
      *                                                                 00359600
           MOVE '11'                      TO NRA-VARIABLE
           MOVE 'VS'                      TO NRA-ESTADO
           MOVE UGNRA-ESTADO              TO NRA-IND-ESTADO-VEH
      *
           EXEC SQL
             SELECT NRA_CLAVE_ID
               INTO :NRA-CLAVE-ID
               FROM UGDTNRA
              WHERE NRA_VARIABLE        =:NRA-VARIABLE
                AND NRA_TIPO_PRODUCTO   =:NRA-TIPO-PRODUCTO
                AND NRA_FECHA_INI      <=:NRA-FECHA-INI
                AND NRA_FECHA_FIN      >=:NRA-FECHA-FIN
                AND NRA_IND_ESTADO_VEH  =:NRA-IND-ESTADO-VEH
                AND NRA_ESTADO          =:NRA-ESTADO
           END-EXEC.
      *                                                                 00378000
           MOVE SQLCODE                       TO DB2-RETURN-CDE
           EVALUATE TRUE                                                00379000
              WHEN DB2-OK                                               00380000
                 MOVE NRA-CLAVE-ID            TO WS-CLAVE-ID            00213000
              WHEN DB2-NOTFND                                           00380000
                 MOVE WSC-ALF-20              TO UGNRA-COD-RETORNO      00213000
                 MOVE WSC-ALF-00000           TO WS-CLAVE-ID            00381000
              WHEN OTHER                                                00382000
                 MOVE WSC-ALF-99              TO UGNRA-COD-RETORNO
                 MOVE SQLERRM                 TO UGNRA-SQLERRM
                 MOVE 'UGDTNRA'               TO UGNRA-VAR1-ERROR
                 MOVE 'ERROR ESTADO VEH   '   TO UGNRA-VAR2-ERROR
                 MOVE DB2-RETURN-CDE          TO UGNRA-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE                                                 00392000

      *COL05-I
           MOVE 11  TO WS-IND
           MOVE WS-CLAVE-ID                TO WS-VAR-V(WS-IND:1).
      *    MOVE WS-CLAVE-ID                TO WS-VAR-V(WS-IND:1)        00213000
      *    ADD 1                           TO WS-IND.
      *COL05-F
      *                                                                 00390000
      *----------------------------------------------------------------*00351000
      *                     2330-VALIDA-GAMA                           *00353000
      *----------------------------------------------------------------*00351000
       2330-VALIDA-GAMA.                                                00358000
      *                                                                 00359600
           MOVE '13'                      TO NRA-VARIABLE
           MOVE 'VS'                      TO NRA-ESTADO
           MOVE UGNRA-GAMA                TO NRA-MONTO-INICIAL
                                             NRA-MONTO-FINAL
      *
           PERFORM 2299-CONSULTA-MONTO

           IF DB2-OK
              MOVE NRA-CLAVE-ID            TO WS-CLAVE-ID
           ELSE
              MOVE WSC-ALF-00000           TO WS-CLAVE-ID               00381000
           END-IF

      *COL05-I
           MOVE 13  TO WS-IND
           MOVE WS-CLAVE-ID                TO WS-VAR-V(WS-IND:1).
      *    MOVE WS-CLAVE-ID                TO WS-VAR-V(WS-IND:1)        00213000
      *    ADD 1                           TO WS-IND.
      *COL05-F

      *----------------------------------------------------------------*00351000
      *                    2340-VALIDA-TIPO                            *00353000
      *----------------------------------------------------------------*00351000
       2340-VALIDA-TIPO.                                                00358000
      *                                                                 00359600
           MOVE '14'                      TO NRA-VARIABLE
           MOVE 'VS'                      TO NRA-ESTADO
           MOVE UGNRA-TIPVEH              TO NRA-IND-TIPO-VEH
      *
           EXEC SQL
             SELECT NRA_CLAVE_ID
               INTO :NRA-CLAVE-ID
               FROM UGDTNRA
              WHERE NRA_VARIABLE        =:NRA-VARIABLE
                AND NRA_TIPO_PRODUCTO   =:NRA-TIPO-PRODUCTO
                AND NRA_FECHA_INI      <=:NRA-FECHA-INI
                AND NRA_FECHA_FIN      >=:NRA-FECHA-FIN
                AND NRA_IND_TIPO_VEH    =:NRA-IND-TIPO-VEH
                AND NRA_ESTADO          =:NRA-ESTADO
           END-EXEC
      *                                                                 00378000
           MOVE SQLCODE                       TO DB2-RETURN-CDE
           EVALUATE TRUE                                                00379000
              WHEN DB2-OK                                               00380000
                 MOVE NRA-CLAVE-ID            TO WS-CLAVE-ID            00213000
              WHEN DB2-NOTFND                                           00380000
                 MOVE WSC-ALF-20              TO UGNRA-COD-RETORNO      00213000
                 MOVE WSC-ALF-00000           TO WS-CLAVE-ID            00381000
              WHEN OTHER                                                00382000
                 MOVE WSC-ALF-99              TO UGNRA-COD-RETORNO
                 MOVE SQLERRM                 TO UGNRA-SQLERRM
                 MOVE 'UGDTNRA'               TO UGNRA-VAR1-ERROR
                 MOVE 'ERROR ESTADO VEH   '   TO UGNRA-VAR2-ERROR
                 MOVE DB2-RETURN-CDE          TO UGNRA-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE                                                 00392000

      *COL05-I
           MOVE 14  TO WS-IND
           MOVE WS-CLAVE-ID                TO WS-VAR-V(WS-IND:1).
      *    MOVE WS-CLAVE-ID                TO WS-VAR-V(WS-IND:1)        00213000
      *    ADD 1                           TO WS-IND.
      *COL05-F
      *                                                                 00390000
      *----------------------------------------------------------------*00351000
      *                     2350-VALIDA-FINANCIA                       *00353000
      *----------------------------------------------------------------*00351000
       2350-VALIDA-FINANCIA.                                            00358000
      *                                                                 00359600
           MOVE '12'                      TO NRA-VARIABLE
           MOVE 'VS'                      TO NRA-ESTADO
           MOVE UGNRA-FINANCIA            TO NRA-MONTO-INICIAL
                                             NRA-MONTO-FINAL
      *
           PERFORM 2299-CONSULTA-MONTO

           IF DB2-OK
              MOVE NRA-CLAVE-ID            TO WS-CLAVE-ID
           ELSE
              MOVE WSC-ALF-00000           TO WS-CLAVE-ID               00381000
           END-IF

      *COL05-I
           MOVE 12  TO WS-IND
           MOVE WS-CLAVE-ID                TO WS-VAR-V(WS-IND:1).
      *    MOVE WS-CLAVE-ID                TO WS-VAR-V(WS-IND:1)        00213000
      *    ADD 1                           TO WS-IND.
      *COL05-F

      *COL02-I
      *----------------------------------------------------------------*00351000
      *                    2360-VALIDA-COLECTIVO-LB                    *00353000
      *----------------------------------------------------------------*00351000
       2360-VALIDA-COLECTIVO-LB.                                        00358000
      *                                                                 00359600
           MOVE '16'                      TO NRA-VARIABLE
           MOVE 'VS'                      TO NRA-ESTADO
           MOVE UGNRA-CLTVOLB             TO NRA-SEGMENTO

           PERFORM 2299-CONSULTA-VALOR

           IF DB2-OK
              MOVE NRA-CLAVE-ID            TO WS-CLAVE-ID
           ELSE
              MOVE WSC-ALF-00000           TO WS-CLAVE-ID               00381000
           END-IF
           MOVE 16  TO WS-IND
           MOVE WS-CLAVE-ID                TO WS-VAR-V(WS-IND:1)        00213000
      *    ADD 1                           TO WS-IND.
           .
      *----------------------------------------------------------------*00351000
      *                    2370-VALIDA-DESTINO-LB                      *00353000
      *----------------------------------------------------------------*00351000
       2370-VALIDA-DESTINO-LB.                                          00358000
      *                                                                 00359600
           MOVE '17'                      TO NRA-VARIABLE
           MOVE 'VS'                      TO NRA-ESTADO
           MOVE UGNRA-DESTNLB             TO NRA-SEGMENTO

           PERFORM 2299-CONSULTA-VALOR

           IF DB2-OK
              MOVE NRA-CLAVE-ID            TO WS-CLAVE-ID
           ELSE
              MOVE WSC-ALF-00000           TO WS-CLAVE-ID               00381000
           END-IF
           MOVE 17  TO WS-IND
           MOVE WS-CLAVE-ID                TO WS-VAR-V(WS-IND:1)        00213000
      *    ADD 1                           TO WS-IND.
           .
      *
      *COL02-F

      *----------------------------------------------------------------*00351000
      *                     2299-CONSULTA-RANGO                        *00353000
      *----------------------------------------------------------------*00351000
       2299-CONSULTA-RANGO.                                             00358000
      *                                                                 00359600
           EXEC SQL
             SELECT NRA_CLAVE_ID
               INTO :NRA-CLAVE-ID
               FROM UGDTNRA
              WHERE NRA_VARIABLE       =:NRA-VARIABLE
                AND NRA_TIPO_PRODUCTO  =:NRA-TIPO-PRODUCTO
                AND NRA_FECHA_INI     <=:NRA-FECHA-INI
                AND NRA_FECHA_FIN     >=:NRA-FECHA-FIN
                AND NRA_RANGO_INI     <=:NRA-RANGO-INI
                AND NRA_RANGO_FIN     >=:NRA-RANGO-FIN
                AND NRA_ESTADO         =:NRA-ESTADO
      *COL01-I
                FETCH FIRST 1 ROWS ONLY
      *COL01-F
           END-EXEC
      *                                                                 00378000
           MOVE SQLCODE                       TO DB2-RETURN-CDE
           EVALUATE TRUE                                                00379000
              WHEN DB2-OK                                               00380000
                 CONTINUE                                               00213000
              WHEN DB2-NOTFND                                           00380000
                 MOVE WSC-ALF-20              TO UGNRA-COD-RETORNO      00213000
              WHEN OTHER                                                00382000
                 MOVE WSC-ALF-99              TO UGNRA-COD-RETORNO
                 MOVE SQLERRM                 TO UGNRA-SQLERRM
                 MOVE 'ERROR UGDTNRA'         TO UGNRA-VAR1-ERROR
                 MOVE 'CONSULTA RANGO     '   TO UGNRA-VAR2-ERROR
                 MOVE DB2-RETURN-CDE          TO UGNRA-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.                                                00392000
      *                                                                 00390000
      *----------------------------------------------------------------*00351000
      *                     2299-CONSULTA-MONTO                        *00353000
      *----------------------------------------------------------------*00351000
       2299-CONSULTA-MONTO.                                             00358000
      *                                                                 00359600
           EXEC SQL
             SELECT NRA_CLAVE_ID
               INTO :NRA-CLAVE-ID
               FROM UGDTNRA
              WHERE NRA_VARIABLE       =:NRA-VARIABLE
                AND NRA_TIPO_PRODUCTO  =:NRA-TIPO-PRODUCTO
                AND NRA_FECHA_INI     <=:NRA-FECHA-INI
                AND NRA_FECHA_FIN     >=:NRA-FECHA-FIN
                AND NRA_MONTO_INICIAL <=:NRA-MONTO-INICIAL
                AND NRA_MONTO_FINAL   >=:NRA-MONTO-FINAL
                AND NRA_ESTADO         =:NRA-ESTADO
      *COL01-I
                FETCH FIRST 1 ROWS ONLY
      *COL01-F
           END-EXEC
      *                                                                 00378000
           MOVE SQLCODE                       TO DB2-RETURN-CDE
           EVALUATE TRUE                                                00379000
              WHEN DB2-OK                                               00380000
                 CONTINUE                                               00213000
              WHEN DB2-NOTFND                                           00380000
                 MOVE WSC-ALF-20              TO UGNRA-COD-RETORNO      00213000
              WHEN OTHER                                                00382000
                 MOVE WSC-ALF-99              TO UGNRA-COD-RETORNO
                 MOVE SQLERRM                 TO UGNRA-SQLERRM
                 MOVE 'ERROR UGDTNRA'         TO UGNRA-VAR1-ERROR
                 MOVE 'CONSULTA MONTO     '   TO UGNRA-VAR2-ERROR
                 MOVE DB2-RETURN-CDE          TO UGNRA-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.                                                00392000
      *                                                                 00390000
      *----------------------------------------------------------------*00351000
      *                     2299-CONSULTA-VALOR                        *00353000
      *----------------------------------------------------------------*00351000
       2299-CONSULTA-VALOR.                                             00358000
      *                                                                 00359600
           EXEC SQL
             SELECT NRA_CLAVE_ID
               INTO :NRA-CLAVE-ID
               FROM UGDTNRA
              WHERE NRA_VARIABLE       =:NRA-VARIABLE
                AND NRA_TIPO_PRODUCTO  =:NRA-TIPO-PRODUCTO
                AND NRA_FECHA_INI     <=:NRA-FECHA-INI
                AND NRA_FECHA_FIN     >=:NRA-FECHA-FIN
      *COL01-I
      *         AND NRA_MONTO_INICIAL =:NRA-MONTO-INICIAL
                AND NRA_SEGMENTO      =:NRA-SEGMENTO
      *COL01-F
                AND NRA_ESTADO         =:NRA-ESTADO
      *COL01-I
                FETCH FIRST 1 ROWS ONLY
      *COL01-F
           END-EXEC
      *                                                                 00378000
           MOVE SQLCODE                       TO DB2-RETURN-CDE
           EVALUATE TRUE                                                00379000
              WHEN DB2-OK                                               00380000
                 CONTINUE                                               00213000
              WHEN DB2-NOTFND                                           00380000
                 MOVE WSC-ALF-20              TO UGNRA-COD-RETORNO      00213000
              WHEN OTHER                                                00382000
                 MOVE WSC-ALF-99              TO UGNRA-COD-RETORNO
                 MOVE SQLERRM                 TO UGNRA-SQLERRM
                 MOVE 'ERROR UGDTNRA'         TO UGNRA-VAR1-ERROR
                 MOVE 'CONSULTA VALOR     '   TO UGNRA-VAR2-ERROR
                 MOVE DB2-RETURN-CDE          TO UGNRA-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.                                                00392000
      *                                                                 00390000
      *----------------------------------------------------------------*00351000
      *                    2400-CONSULTA-TASA                          *00353000
      *----------------------------------------------------------------*00351000
       2400-CONSULTA-TASA.                                              00358000
      *                                                                 00359600
           INITIALIZE WS-IND
                      WS-I
           MOVE '90'                      TO NRA-VARIABLE
           MOVE 'VS'                      TO NRA-ESTADO
           MOVE 1                         TO WS-IND
                                             WS-I
      *
      *COL03-I
      *    SET SI-FIN-CURNRA-D            TO TRUE

      *    PERFORM 2410-OPEN-CURNRAD                                    00298100
      *    PERFORM 2420-FETCH-CURNRAD UNTIL SI-FIN-CURNRA-D             00298200
      *    PERFORM 2430-CLOSE-CURNRAD.                                  00298300
           PERFORM 2440-CONSULTA-CLUSTER.
      *COL03-F
      *                                                                 00390000
      *----------------------------------------------------------------*00351000
      *                      2410-OPEN-CURNRAD                         *00298600
      *----------------------------------------------------------------*00351000
      *BBVA01-I
      *2410-OPEN-CURNRAD.                                               00298800
      *                                                                 00298900
      *    EXEC SQL                                                     00299000
      *          OPEN CURNRA-D                                          00299100
      *    END-EXEC                                                     00299200
      *                                                                 00299300
      *    MOVE SQLCODE       TO DB2-RETURN-CDE                         00299400
      *                                                                 00299500
      *    IF DB2-OK AND SQLWARN0 EQUAL SPACES                          00299600
      *       SET NO-FIN-CURNRA-D TO TRUE                               00299700
      *    ELSE                                                         00299800
      *       MOVE WSC-ALF-99              TO UGNRA-COD-RETORNO
      *       MOVE SQLERRM                 TO UGNRA-SQLERRM
      *       MOVE 'ERROR OPEN'            TO UGNRA-VAR1-ERROR
      *       MOVE 'CURSOR UGDTNRA     '   TO UGNRA-VAR2-ERROR
      *       MOVE DB2-RETURN-CDE          TO UGNRA-SQLCODE
      *       PERFORM 3000-FINAL-PROGRAMA
      *    END-IF.                                                      00300400
      *                                                                 00300500
      *----------------------------------------------------------------*00351000
      *                       2420-FETCH-CURNRAD                       *00300700
      *----------------------------------------------------------------*00351000
      *2420-FETCH-CURNRAD.                                              00300900
      *                                                                 00301000
      *    EXEC SQL                                                     00301100
      *      FETCH   CURNRA-D                                           00301200
      *      INTO    :NRA-CLAVE-ID,                                     00301300
      *              :NRA-CLUSTER ,                                     00301400
      *              :NRA-ESTADO  ,                                     00301500
      *              :NRA-TASA    ,                                     00301600
      *              :NRA-TIMESTAMP                                     00301700
      *    END-EXEC                                                     00302200
      *    MOVE SQLCODE       TO DB2-RETURN-CDE                         00302400
      *                                                                 00302500
      *    IF DB2-OK AND SQLWARN0 EQUAL SPACES                          00302600
      *       MOVE NRA-CLAVE-ID           TO WS-RAR-V
      *       IF WS-VAR-V EQUAL WS-RAR-V
      *          MOVE NRA-TASA               TO WS-TASA-RAR
      *          MOVE WS-TASA-RAR            TO UGNRA-TASA-RAR
      *          MOVE NRA-CLUSTER            TO UGNRA-CLUSTER
      *          MOVE WSC-ALF-00             TO UGNRA-COD-RETORNO
      *          SET SI-FIN-CURNRA-D TO TRUE
      *       END-IF
      *    ELSE                                                         00303200
      *       IF DB2-NOTFND                                             00303300
      *          SET SI-FIN-CURNRA-D TO TRUE                            00303400
      *          MOVE WSC-ALF-20              TO UGNRA-COD-RETORNO
      *         IF SQLCODE  = 100
      *            MOVE ZEROS                  TO WS-TASA-RAR
      *            MOVE '00'                   TO UGNRA-COD-RETORNO
      *            SET SI-FIN-CURNRA-D TO TRUE
      *          END-IF
      *       ELSE                                                      00303500
      *          MOVE WSC-ALF-99              TO UGNRA-COD-RETORNO
      *          MOVE SQLERRM                 TO UGNRA-SQLERRM
      *          MOVE 'ERROR FETCH'           TO UGNRA-VAR1-ERROR
      *          MOVE 'CURSOR UGDTNRA     '   TO UGNRA-VAR2-ERROR
      *          MOVE DB2-RETURN-CDE          TO UGNRA-SQLCODE
      *          PERFORM 3000-FINAL-PROGRAMA
      *       END-IF                                                    00304100
      *    END-IF.                                                      00304200
      *----------------------------------------------------------------*00351000
      *                       2430-CLOSE-CURNRAD                       *00304500
      *----------------------------------------------------------------*00351000
      *2430-CLOSE-CURNRAD.                                              00304700
      *                                                                 00304800
      *    EXEC SQL                                                     00304900
      *          CLOSE CURNRA-D                                         00305000
      *    END-EXEC                                                     00305100
      *                                                                 00305200
      *    MOVE SQLCODE       TO DB2-RETURN-CDE                         00305300
      *                                                                 00305400
      *    IF DB2-OK AND SQLWARN0 EQUAL SPACES                          00305500
      *       CONTINUE                                                  00305600
      *    ELSE                                                         00305700
      *       MOVE WSC-ALF-99              TO UGNRA-COD-RETORNO
      *       MOVE SQLERRM                 TO UGNRA-SQLERRM
      *       MOVE 'ERROR CLOSE'           TO UGNRA-VAR1-ERROR
      *       MOVE 'CURSOR UGDTNRA     '   TO UGNRA-VAR2-ERROR
      *       MOVE DB2-RETURN-CDE          TO UGNRA-SQLCODE
      *       PERFORM 3000-FINAL-PROGRAMA
      *    END-IF.                                                      00306300
      *                                                                 00404000
      *BBVA01-F
      *COL03-I
      *----------------------------------------------------------------*00351000
      *                    2440-CONSULTA-CLUSTER                       *
      *----------------------------------------------------------------*00351000
       2440-CONSULTA-CLUSTER.
      *
           INITIALIZE                        WS-NRA-CLAVEID
           MOVE '90'                      TO NRA-VARIABLE
           MOVE 'VS'                      TO NRA-ESTADO
           MOVE WS-VAR-V                  TO WS-NRA-CLAVEID(1:17)
           MOVE '000000'                  TO WS-NRA-CLAVEID(18:6)
           MOVE WS-NRA-CLAVEID            TO NRA-CLAVE-ID
      *
           EXEC SQL
             SELECT NRA_CLAVE_ID,
                    NRA_CLUSTER ,                                       00301400
                    NRA_ESTADO  ,                                       00301500
                    NRA_TASA    ,                                       00301600
                    NRA_TIMESTAMP                                       00301700
               INTO :NRA-CLAVE-ID,                                      00301300
                    :NRA-CLUSTER ,                                      00301400
                    :NRA-ESTADO  ,                                      00301500
                    :NRA-TASA    ,                                      00301600
                    :NRA-TIMESTAMP                                      00301700
               FROM UGDTNRA
              WHERE NRA_TIPO_PRODUCTO  =:NRA-TIPO-PRODUCTO
                AND NRA_VARIABLE       =:NRA-VARIABLE
                AND NRA_ESTADO         =:NRA-ESTADO
                AND NRA_CLAVE_ID       =:NRA-CLAVE-ID
                FETCH FIRST 1 ROWS ONLY
           END-EXEC
      *                                                                 00378000
           MOVE SQLCODE                       TO DB2-RETURN-CDE
           EVALUATE TRUE                                                00379000
              WHEN DB2-OK                                               00380000
      **      WHEN DB2-DUPREC                                           00380000
                 MOVE NRA-TASA               TO WS-TASA-RAR
                 MOVE WS-TASA-RAR            TO UGNRA-TASA-RAR
      *COL08-I
      *          MOVE NRA-CLUSTER            TO UGNRA-CLUSTER
                 MOVE WS-NRA-CLAVEID         TO UGNRA-CLUSTER
      *COL08-F
                 MOVE WSC-ALF-00             TO UGNRA-COD-RETORNO
              WHEN DB2-NOTFND                                           00380000
      *COL08-I
                 MOVE WS-NRA-CLAVEID          TO UGNRA-CLUSTER
      *COL08-F
                 MOVE WSC-ALF-20              TO UGNRA-COD-RETORNO
                 MOVE ZEROS                   TO WS-TASA-RAR
                 MOVE '00'                    TO UGNRA-COD-RETORNO
              WHEN OTHER                                                00382000
                 MOVE WSC-ALF-99              TO UGNRA-COD-RETORNO
                 MOVE SQLERRM                 TO UGNRA-SQLERRM
                 MOVE 'ERROR UGDTNRA'         TO UGNRA-VAR1-ERROR
                 MOVE 'CONSULTA CLUSTER   '   TO UGNRA-VAR2-ERROR
                 MOVE DB2-RETURN-CDE          TO UGNRA-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.                                                00392000
      *                                                                 00390000
      *COL03-F
      *----------------------------------------------------------------*00351000
      *                     9999-CONTROL-TASA                          *
      *----------------------------------------------------------------*00351000
       9999-CONTROL-TASA.
           INITIALIZE UGNRA-TASA-FORM
      * CONTROL TASA RAR
           EVALUATE TRUE
      *COL02-I
              WHEN (UGNRA-TASA-PREF = ZEROS)
                   MOVE UGNRA-TASA-POLI  TO UGNRA-TASA-RAR
      *COL02-F
              WHEN (UGNRA-TASA-PREF < UGNRA-TASA-PISO)
      *COL02-I
      *            MOVE UGNRA-TASA-POLI  TO UGNRA-TASA-RAR
                   MOVE UGNRA-TASA-PISO  TO UGNRA-TASA-RAR
      *COL02-F
              WHEN (UGNRA-TASA-PREF >= UGNRA-TASA-PISO AND
                    UGNRA-TASA-PREF <  UGNRA-TASA-POLI)
                   MOVE UGNRA-TASA-PREF  TO UGNRA-TASA-RAR
              WHEN (UGNRA-TASA-PREF >= UGNRA-TASA-POLI AND
                    UGNRA-TASA-PREF <  UGNRA-TASA-USURA)
                   MOVE UGNRA-TASA-PREF  TO UGNRA-TASA-RAR
              WHEN (UGNRA-TASA-PREF >= UGNRA-TASA-POLI AND
                    UGNRA-TASA-PREF >= UGNRA-TASA-USURA)
                   MOVE UGNRA-TASA-USURA TO UGNRA-TASA-RAR
              WHEN OTHER
                   MOVE UGNRA-TASA-POLI  TO UGNRA-TASA-RAR
           END-EVALUATE

      * CONTROL TASA FORMALIZACION
           EVALUATE TRUE
              WHEN (UGNRA-TASA-RAR  < UGNRA-TASA-PISO)
                   MOVE UGNRA-TASA-POLI  TO UGNRA-TASA-FORM
              WHEN (UGNRA-TASA-RAR  >= UGNRA-TASA-PISO AND
                    UGNRA-TASA-RAR  <  UGNRA-TASA-POLI)
                   MOVE UGNRA-TASA-RAR   TO UGNRA-TASA-FORM
              WHEN (UGNRA-TASA-RAR  >= UGNRA-TASA-POLI AND
                    UGNRA-TASA-RAR  <  UGNRA-TASA-USURA)
                   MOVE UGNRA-TASA-RAR   TO UGNRA-TASA-FORM
              WHEN (UGNRA-TASA-RAR  >= UGNRA-TASA-USURA)
                   MOVE UGNRA-TASA-USURA TO UGNRA-TASA-FORM
           END-EVALUATE.
      *                                                                 00836800
      *
      *----------------------------------------------------------------*00404000
      *                      3000-FINAL-PROGRAMA                       *00405000
      *----------------------------------------------------------------*00404000
       3000-FINAL-PROGRAMA.                                             00408000
           GOBACK.
      *                                                                 00411000
