      *  UR7CCRAR: RUTINA QUE CALCULA EL DESCUENTO EN LA TASA E.A.
      *            SIMULACION PARA WEB
      *****************************************************************
       IDENTIFICATION DIVISION.
      *
       PROGRAM-ID.   UR7CCRAR.
       AUTHOR.       EFRON CONSULTING - DIANA PE#A
       DATE-WRITTEN. 01/09/2015.
       DATE-COMPILED.
      *
      ******************************************************************
      *           L O G    D E   M O D I F I C A C I O N E S           *
      ******************************************************************
      *   AUTOR    FECHA             DESCRIPCION                       *
      * -------- -------- -------------------------------------------- *
      * COL01    15092017 SE AJUSTA LA MASCARA DE LAS VARIABLES DE TASA*
      * GFI-DCP           PISO Y DESCUENTO COL595317I856434 GP10992    *
      * -------- -------- -------------------------------------------- *
      * COL02    26022018 SE ADICIONAN DOS NUEVAS VARIABLES A LA RUTINA*
      * GFI               PARA CALCULAR EL PUNTAJE DE DESCUENTO.       *
      * COLOMBIA          GP16016-AJUSTE MODELO RAR INCLUSION NUEVAS   *
      *                   VARIABLES. GESI COL472318S616235 GP16016     *
      * -------- -------- -------------------------------------------- *
      * COL03    03082018 SE ADICIONAN DOS VARIABLES DE SALIDA QUE     *
      * GFI      GP16016  ALMACENAN LA TASA USURA Y LA POLITICA        *
      * OMAR F ORTEGON    AJUSTE SERVICIO ASO. COL472318S616235        *
      * -------- -------- -------------------------------------------- *
      * @COL04   05042019 SE INCLUYEN AJUSTES PARA SOLUCIONAR INCIDENCI*
      * BBVA     C343126  A COL595319I000572.                          *
      * -------------------------------------------------------------- *
      * COL05    09082021 SE INCLUYE TASA PREFERENTE PARA NUEVO MODELO *
      * INETUM   CE59519  RAR TOMANDO COMO BASE LA INFORMACION DEL     *
      * GP17916 CCSS-6856 CLIENTE                                      *
      * -------- -------- -------------------------------------------- *
      * @COL06   11032021 SE MODIFICA LA CONSULTA PARA TRAER LA TASA   *
      * BBVA     CE61132  POLITICA DEL SUBPRODUCTO - VIGENCIA (FECHA)  *
      * MN-829                                                         *
      * -------- -------- -------------------------------------------- *
      * @COL07   11032021 SE MODIFICA LA CONSULTA PARA TRAER LA TASA   *
      * CFGC     C342057  POLITICA CUANDO NO APLICA RAR                *
      * IN-88763                                                       *
      * -------- -------- -------------------------------------------- *
      * COL08    07/02/2022   AJUSTE PARA INCLUIR VARIABLE COLECTIVO Y *
      * CE56375               DESTINO PRICING LIBRANZA                 *
      * SCRUM - SDA36560 - COLWSPREST-54 - COLWSPREST-383 OTORGAR TASAS*
      * PERSONALIZADAS LIBRANZAS                                       *
      * -------- -------- ---------------------------------------------*
      * COL09    28042022 SE AJUSTA PARA INCLUIR TIPO-OPERACION HV(HIPO*
      * C810846           TECARIO VIS) Y HS(HIPOTECARIO SOSTENIBLE)    *
      *                   PRICING HIPOTECARIO.                         *
      *                   CCSS-13169.                                  *
      * -------- -------- ---------------------------------------------*
      * COL10    26092022 SE AJUSTA PARA TRAER EL CLUSTER CORRECTO     *
      * INETUM            CUANDO SE HACE EL LLAMADO DE VIVIENDA DIGITAL*
      *                   COLWSPREST-2844                              *
      ******************************************************************
      * PROYECTO      : SERVICIOS CREDITO VIRTUAL.                     *00002232
      * MARCA         : COL11                                          *00002233
      * GP            : COLWSPREST-1289 ---> HUQA: COLWSPREST-5117     *00002234
      * MARCA         : GRUPO BBVA - REDBULL NETCASH                   *00002235
      * USUARIO       : INETUM COLOMBIA - CE58814 - MIGUEL PINZON      *00002236
      * FECHA         : 2022-03-17.                                    *00002238
      * DESCRIPCION   : SE AJUSTA PARA TRAER LA TASA POLITICA DEL      *00002239
      *                 TRAMO 102 SOLO CUANDO EL SUBPRODUCTO SEA DE    *00002240
      *                 CREDITO VIRTUAL Y ESTE NO TENGA TRAMO 101.     *
      ******************************************************************
      * PROYECTO      : VIVIENDA DIGITAL                               *00002232
      *                 INTEGRACIóN SUBPRODUCTOS VIS/NO VIS            *
      * MARCA         : COL12                                          *00002233
      * FEATURE       : COLWSPREST-15556                               *00002234
      * MARCA         : GRUPO BBVA - THE MATRIX                        *00002235
      * USUARIO       : BBVA COLOMBIA - C810908 - DIANA C PE¦A         *00002236
      * FECHA         : 2024-03-18.                                    *00002238
      * DESCRIPCION   : SE AJUSTA PARA ENVIAR EL VLR.INGRESOS A LAS    *00002239
      *                 RUTINAS DE PRICING, PARA CREDITOS HIPOTECARIOS *00002240
      *                 Y LEASING.                                     *
      ******************************************************************
      * PROYECTO      : VIVIENDA DIGITAL                               *00002232
      *                 OPEN MARKET VIVIENDA DIGITAL.                  *
      * FEATURE       : COLWSPREST-24657                               *00002234
      * MARCA         : GRUPO BBVA - THE MATRIX                        *00002235
      * USUARIO       : BBVA COLOMBIA - C810908                        *00002236
      * FECHA         : 2024-04-01.                                    *00002238
      * DESCRIPCION   : SE COMPILA COMPONENTE CON COBOL-4 POR REPORTE  *00002239
      *                 PRODUCTIVO.                                    *00002240
      ******************************************************************
      * REFERENCIA  : COL13                                            *
      * REALIZO     : MICHAEL ANDRES LEON DIAZ (INDRA COMPANY)         *
      * FECHA       : 10/07/2024                                       *
      * SDA/FEATURE : SDATOOL-41748 /COLONEPRE1-981                    *
      * DESCRIPCION : IMPLEMENTACION MANEJO SUBPRODUCTOS CUOTA FIJA    *
      *               TASA VARIABLE LISTADOR DE PRODUCTOS - CAP        *
      * METODOLOGIA   SE AJUSTA PARA SUBPRODUCTOS QUE MANEJAN TASA     *
      * TRADICIONAL   VARIABLE                                         *
      ******************************************************************
      * PROYECTO      : VIVIENDA DIGITAL                               *00002232
      *                                                                *
      * MARCA         : COL14                                          *00002233
      * FEATURE       : COLONEPRE1-2110                                *00002234
      * MARCA         : GRUPO BBVA - THE MATRIX                        *00002235
      * USUARIO       : BBVA COLOMBIA - O001111 - JENNYFER MORENO      *00002236
      * FECHA         : 2024-10-03.                                    *00002238
      * DESCRIPCION   : SE AJUSTA PARA CONSULTAR VLR.INGRESOS A LAS    *00002239
      *                 RUTINAS DE PRICING, PARA CREDITOS HIPOTECARIOS *00002240
      *                 Y LEASING UNICAMENTE EN LOS FLUJOS DIGITALES.  *
      ******************************************************************
      *REFERENCIA : COL15                                              *
      *REALIZO    : JAYSON GABRIEL PINILLA SUAREZ (INETUM - T059363)   *
      *FECHA      : 24/02/2026                                         *
      *SDA/FEATURE: SDA-56033 / COLONEPRE1-16456                       *
      *DESCRIPTION: AJUSTES                                            *
      *                                                                *
      ******************************************************************
      *REFERENCIA : COL16                                              *
      *REALIZO    : JAYSON GABRIEL PINILLA SUAREZ (INETUM - T059363)   *
      *FECHA      : 20/05/2026                                         *
      *SDA/FEATURE: SDA-55492 / COLONEPRE1-20872                       *
      *DESCRIPTION: AJUSTES TASA VARIABLE                              *
      *UR7CCRAR9879258842032026-06-03Z789000000150000N0000005000000036 *
      ******************************************************************
      *REFERENCIA : COL17                                              *
      *REALIZO    : GUSTAVO PAREDES GONZALEZ  ( BBVA  - O019015)   *
      *FECHA      : 14/09/2026                                         *
      *SDA/FEATURE: SDA-56034 / COLONEPRE1-25794                       *
      *DESCRIPTION: AJUSTES EN LA CONSULTA DE LA VID PARA NO ACTUALIZAR*
      *             BURO E IDENTIFICACION DE LA LINEA LEASING PARA LOS *
      *             SUBPRODUCTOS DE REMODELACION                       *
      ******************************************************************
           EJECT
      ******************************************************************
      *       E N V I R O N M E N T    D I V I S I O N                 *
      ******************************************************************
       ENVIRONMENT DIVISION.
      *
      ******************************************************************
      *                   D A T A      D I V I S I O N                 *
      ******************************************************************
       DATA DIVISION.
      *
       WORKING-STORAGE SECTION.
      *
      ******************************************************************
      *       MARCA DE COMIENZO DE LA WORKING STORAGE                  *
      ******************************************************************
      *
       01  LT-INICIO-DE-WS.
           05  LT-INICIO-DE-WS          PIC X(42)  VALUE
               '*****INICIO WORKING STORAGE UR7CCRAR*****'.
           EJECT
      *
      ************** COPY SQLCA ****************************************
           EXEC SQL
              INCLUDE SQLCA
           END-EXEC.
      *
      ******************************************************************
      *      ESTA VARIABLE SE INCORPORA A LOS PROGRAMAS QUE LLAMAN     *
      *      A DB2 PARA REALIZAR EL CHEQUEO DEL SQLCODE.               *
      ******************************************************************
       01  DB2-RETURN-CDE                  PIC S9(9) COMP.
           88 DB2-OK                       VALUE +0.
           88 DB2-NOTFND                   VALUE +100.
           88 DB2-DUPREC                   VALUE -803.
      *
      *-----------------------------------------------------------------
      *                  COPY DE LA TABLA UGDTT37
      *-----------------------------------------------------------------
            EXEC SQL INCLUDE UGGTT37 END-EXEC.
            EXEC SQL INCLUDE UGTCT37 END-EXEC.
      *
      *-----------------------------------------------------------------
      *                  COPY DE LA TABLA UGDTPRO
      *-----------------------------------------------------------------
            EXEC SQL INCLUDE UGGTPRO END-EXEC.
            EXEC SQL INCLUDE UGTCPRO END-EXEC.
      *
      *-----------------------------------------------------------------
      *                  COPY DE LA TABLA UGDTDTE
      *-----------------------------------------------------------------
            EXEC SQL INCLUDE UGGTDTE END-EXEC.
            EXEC SQL INCLUDE UGTCDTE END-EXEC.
      *
      ******************************************************************
      *                  COPY DE LA TABLA PEDT011
      ******************************************************************
            EXEC SQL INCLUDE PEGV1110 END-EXEC.
      *
      *COL03-I
      *----------------------------------------------------------------*
      *                  COPY DE LA TABLA RVDTREG                      *
      *----------------------------------------------------------------*
            EXEC SQL INCLUDE RVGTREG END-EXEC.
            EXEC SQL INCLUDE RVTCREG END-EXEC.
      *COL03-F
      *COL10-I
      ******************************************************************
      * INCLUDE DE LA TABLA RVDTVID PARA INCLUIR DATOS DE POLITICAS    *
      ******************************************************************
            EXEC SQL INCLUDE RVGVVID0 END-EXEC.
      *COL10-F
      *-----------------------------------------------------------------
      *               COPY PARA EL MANEJO DE FECHAS                    *
      *-----------------------------------------------------------------
      *01 TCWC0750-01.
          COPY TCWC1750.
      *
      *-----------------------------------------------------------------
      *                  COPY DATOS PERSONAS(CORASU)
      *-----------------------------------------------------------------
       01 PEWC5200-01.
          COPY PEWC5200.
      *
      *-----------------------------------------------------------------
      *       COPY PARA TRAER LOS DATOS PATRIMONIALES DEL CLIENTE
      *-----------------------------------------------------------------
       01 PEWC0920-01.
          COPY PEWC0920.
      *
      *-----------------------------------------------------------------
      *             COPY PARA TRAER EL SEGMENTO DEL CLIENTE
      *-----------------------------------------------------------------
       01 PEWC0020-01.
          COPY PEWC0020.
      *
      *-----------------------------------------------------------------
      *             COPY PARA TRAER EL COLECTIVO DEL CLIENTE
      *-----------------------------------------------------------------
          COPY PE9TCLC.
      *
      *-----------------------------------------------------------------
      *    COPY RUTINA TCOM PARA TRAER SEGMENTO
      *-----------------------------------------------------------------
       01 AREA-PMECT011.
           COPY PMECT011.
      *
      *COL09-I
      *----------------------------------------------------------------*
      *           COPY DE COMUNICACION CON LA RUTINA UR2CIT37          *
      *----------------------------------------------------------------*
       01 UGWCIT37-REG-1.
          COPY URWCIT37.
      *COL09-F
      *COL11-I
      *----------------------------------------------------------------*
      *           COPY DE LA RUTINA UG9CT370                           *
      *----------------------------------------------------------------*
       COPY UGWCT370.
      *COL11-F
      * COL05-I
      *-----------------------------------------------------------------
      *    COPY RUTINA NRA PARA CONSULTA TASA PREFERENTE
      *-----------------------------------------------------------------
       01 REG-UGWCNRA.
           COPY UGWCNRA.
      * COL05-F
      * COL10-I
      *-----------------------------------------------------------------
      *    COPY RUTINA RVI PARA CONSULTA RVDTVID-TRAER BURO
      *-----------------------------------------------------------------
       01 REG-UGWCRVI.
           COPY UGWCRVI.
      * COL10-F
      *COL13-I
      ******************************************************************
      * AREA DE COMUNICACION CON EL MODULO UR8CDFP0                    *
      ******************************************************************
       COPY URWCRES.
      *
       COPY URWCDF3.
      ******************************************************************
      * AREA DE COMUNICACION CON EL MODULO CONVERSION TASA             *
      ******************************************************************
       COPY URWCCVR.
      *----------------------------------------------------------------*00014400
      * COPY RUTINA CONSULTA IBR
      *----------------------------------------------------------------*00014400
       01  W-VARS-IBR.
           03 WS-DIAS-IBR                PIC 9(5).
           03 WS-TASA-IBR                PIC S9(03)V9(04).
           03 WS-CODTIPRE                PIC X(3) VALUE SPACES.
           03 RUT-BR8CCOF1               PIC X(8) VALUE 'BR8CCOF1'.
           03 WS-COEFICI                 PIC X(4) VALUE SPACES.
           COPY BRECOF1.
      *COL13-F
      *COL02-I
	     *----------------------------------------------------------------*05800
      *     TABLA  DONDE SE CONSULTA LA TASA POLITICA (UGDTLQS).       *00005900
      *----------------------------------------------------------------*00005800
	       EXEC SQL
                INCLUDE UGGTLQS
           END-EXEC.

           EXEC SQL
                INCLUDE UGTCLQS
           END-EXEC.
      *----------------------------------------------------------------*00005500
      *       WORKAS DE LA UGDTRFI -TASA DE USURA-                     *00005600
      *----------------------------------------------------------------*00005700
           EXEC SQL INCLUDE UGGTRFI END-EXEC.                           00005800
           EXEC SQL INCLUDE UGTCRFI END-EXEC.                           00005900
      *COL02-F
      *COL08-I
      *----------------------------------------------------------------*00005500
      *       WORKAS DE LA UGDTMAL, UGDTCNL Y UGDTTPA                  *00005600
      *----------------------------------------------------------------*00005700
           EXEC SQL INCLUDE UGGTMAL END-EXEC.                           00005800
           EXEC SQL INCLUDE UGGTCNL END-EXEC.                           00005800
           EXEC SQL INCLUDE UGGTTPA END-EXEC.                           00005800
           EXEC SQL INCLUDE UGTCMAL END-EXEC.                           00005900
           EXEC SQL INCLUDE UGTCCNL END-EXEC.                           00005900
           EXEC SQL INCLUDE UGTCTPA END-EXEC.                           00005900
      *COL08-F
      *COL13-I
      *----------------------------------------------------------------*00005500
      *       WORKAS DE LA UGDTADS - COND. ADMON ESTANDAR              *00005600
      *----------------------------------------------------------------*00005700
           EXEC SQL INCLUDE UGGTADS END-EXEC.                           00005800
           EXEC SQL INCLUDE UGTCADS END-EXEC.                           00005900
      *COL13-F
      *COL03-I
           EXEC SQL
             DECLARE CURCIF CURSOR FOR
               SELECT INFORMACION_REG
               FROM RVDTREG
               WHERE TIPID           = :RVREG-LLAVE-TIP-ID
               AND   NUMID           = :RVREG-LLAVE-NUM-ID
               AND   TIPOREG         = :RVREG-TIPO-REGISTRO
           END-EXEC.
      *COL03-F
      ******************************************************************
      *                                                                *
      *       WORKA DE CAMPOS VARIABLES                                *
      *                                                                *
      ******************************************************************
       01  SWITCHES.
           05  SW-UGDTT37-1056              PIC X(01)  VALUE 'N'.
               88 SW-SI-RAR-SECC1056                   VALUE 'S'.
               88 SW-NO-RAR-SECC1056                   VALUE 'N'.
      *COL03-I
           05  SW-TASAS                     PIC X      VALUE 'N'.
               88  SW-SI-TASAS                         VALUE 'S'.
               88  SW-NO-TASAS                         VALUE 'N'.
           05  SW-TIPO-P                    PIC X      VALUE 'N'.
               88  SW-SI-TIPO                          VALUE 'S'.
               88  SW-NO-TIPO                          VALUE 'N'.
           05  SW-CURSOR                    PIC X      VALUE 'N'.
               88  SW-FIN-CUR                          VALUE 'S'.
               88  SW-NO-FIN-CUR                       VALUE 'N'.
      *COL03-F
      *COL11-I
           05 SW-CREDITOVIRTUAL             PIC X(01) VALUE 'N'.
              88 SW-CREDITOVIRTUAL-SI                 VALUE 'S'.
              88 SW-CREDITOVIRTUAL-NO                 VALUE 'N'.
      *COL11-F
      *COL02-I
           05 SW-UGDTT37-1054               PIC X(01)  VALUE 'N'.
               88 SW-SI-APLI-RAR                       VALUE 'S'.
               88 SW-NO-APLI-RAR                       VALUE 'N'.
      *COL02-F
      *COL15-I
           05 SW-UMTA                       PIC X(01)  VALUE 'N'.
               88 SW-SI-APLI-UMTA                      VALUE 'S'.
               88 SW-NO-APLI-UMTA                      VALUE 'N'.
      *COL15-F
      *SWITCHES PARA DETERMINAR QUE DESCUENTO APLICAR AL CLIENTE
           05  SW-PUNTAJE-BURO              PIC X(01)  VALUE 'N'.
               88  SW-NO-PUNTAJE-BURO                  VALUE 'N'.
               88  SW-SI-PUNTAJE-BURO                  VALUE 'S'.
           05  SW-DOMICILIA-NOM             PIC X(01)  VALUE 'N'.
               88  SW-NO-DOMIC-NOMINA                  VALUE 'N'.
               88  SW-SI-DOMIC-NOMINA                  VALUE 'S'.
           05  SW-SEGMENTO-VIP              PIC X(01)  VALUE 'N'.
               88  SW-NO-SEGMENTO-VIP                  VALUE 'N'.
               88  SW-SI-SEGMENTO-VIP                  VALUE 'S'.
           05  SW-TIPO-CLIENTE              PIC X(01)  VALUE 'N'.
               88  SW-NO-TIPO-CLIENTE                  VALUE 'N'.
               88  SW-SI-TIPO-CLIENTE                  VALUE 'S'.
           05  SW-INGRESOS-CLIENTE          PIC X(01)  VALUE 'N'.
               88  SW-NO-INGRESOS-CLIENTE              VALUE 'N'.
               88  SW-SI-INGRESOS-CLIENTE              VALUE 'S'.
      *SWITCHES CON LOS TIPOS DE CARTERAS PERMITIDOS PARA CONSULTAR EL
      *TIPO DE CLIENTE
           05  SW-HIPOTECARIO               PIC X(01)  VALUE SPACES.
               88  SW-SI-HIPOTECARIO        VALUE 'H' 'L'.
           05  SW-CONSUMO                   PIC X(01)  VALUE SPACES.
               88  SW-SI-CONSUMO            VALUE 'N' 'V' 'Z'.
      *
      * SWITCHES PARA DETERMINAR EL TIPO DE CARTERA
           05  SW-SUBPRO-VEHICULO           PIC X(01)  VALUE 'N'.
               88  SW-NO-SUBPRO-V                      VALUE 'N'.
               88  SW-SI-SUBPRO-V                      VALUE 'S'.
           05  SW-SUBPRO-LEASING            PIC X(01)  VALUE 'N'.
               88  SW-NO-SUBPRO-L                      VALUE 'N'.
               88  SW-SI-SUBPRO-L                      VALUE 'S'.
           05  SW-SUBPRO-HIPOTECARIO        PIC X(01)  VALUE 'N'.
               88  SW-NO-SUBPRO-H                      VALUE 'N'.
               88  SW-SI-SUBPRO-H                      VALUE 'S'.
           05  SW-SUBPRO-CONSUMO            PIC X(01)  VALUE 'N'.
               88  SW-NO-SUBPRO-N                      VALUE 'N'.
               88  SW-SI-SUBPRO-N                      VALUE 'S'.
           05  SW-SUBPRO-COMERCIO           PIC X(01)  VALUE 'N'.
               88  SW-NO-SUBPRO-C                      VALUE 'N'.
               88  SW-SI-SUBPRO-C                      VALUE 'S'.
           05  SW-SUBPRO-LIBRANZA           PIC X(01)  VALUE 'N'.
               88  SW-NO-SUBPRO-Z                      VALUE 'N'.
               88  SW-SI-SUBPRO-Z                      VALUE 'S'.
           05  SW-SUBPRO-NO-APLICA          PIC X(01)  VALUE 'N'.
               88  SW-NO-SUBPRO-X                      VALUE 'N'.
               88  SW-SI-SUBPRO-X                      VALUE 'S'.
      *COL09-I
           05  SW-SUBPRO-HIPOT-SOS          PIC X(01)  VALUE 'N'.
               88  SW-SI-HIPOT-SOS                     VALUE 'S'.
               88  SW-NO-HIPOT-SOS                     VALUE 'N'.
      *
           05  SW-SUBPRO-PARAM-T37          PIC X(01)  VALUE 'N'.
               88  SW-SI-PARAM-T37                     VALUE 'S'.
               88  SW-NO-PARAM-T37                     VALUE 'N'.
      *COL09-F
      *COL13-I
           05  SW-SUBPRO-CON-TASAV          PIC X(01)  VALUE 'N'.
               88  SW-SI-CON-TASAV                     VALUE 'S'.
               88  SW-NO-CON-TASAV                     VALUE 'N'.
      *
           05  SW-SUBPRO-VEH-TASAV          PIC X(01)  VALUE 'N'.
               88  SW-SI-VEH-TASAV                     VALUE 'S'.
               88  SW-NO-VEH-TASAV                     VALUE 'N'.
      *COL13-F
      *
      *COL16-I
           05  SW-SUBPRO-LIB-TASAV          PIC X(01)  VALUE 'N'.
               88  SW-SI-LIB-TASAV                     VALUE 'S'.
               88  SW-NO-LIB-TASAV                     VALUE 'N'.
      *COL16-F
      *
       01  CONSTANTES.
           05  WS-CON-S                     PIC X(1)   VALUE 'S'.
           05  WS-OK                        PIC X(2)   VALUE '00'.
           05  WS-NO-ADMON                  PIC X(2)   VALUE '10'.
           05  WS-ERROR-DB2                 PIC X(2)   VALUE '99'.
           05  WSC-ALF-1                    PIC X(01)  VALUE '1'.
           05  WSC-ALF-2                    PIC X(01)  VALUE '2'.
           05  WSC-ALF-001                  PIC X(03)  VALUE '001'.
           05  WSC-ALF-00                   PIC X(02)  VALUE '00'.
      *COL15-I
           05  WSC-ALF-06                   PIC X(02)  VALUE '06'.
           05  WSC-ALF-03                   PIC X(02)  VALUE '03'.
           05  WSC-ALF-9639                 PIC X(04)  VALUE '9639'.
      *COL15-F
           05  WSC-ALF-10                   PIC X(02)  VALUE '10'.
           05  WSC-ALF-20                   PIC X(02)  VALUE '20'.
           05  WSC-ALF-50                   PIC X(02)  VALUE '50'.
           05  WSC-ALF-90                   PIC X(02)  VALUE '90'.
           05  WSC-ALF-99                   PIC X(02)  VALUE '99'.
           05  WSC-ALF-F17                  PIC X(03)  VALUE 'F17'.
           05  WSC-UGE3631                  PIC X(07)  VALUE 'UGE3631'.
           05  WSC-ALF-1733                 PIC X(04)  VALUE '1733'.
           05  WSC-PM9CT011                 PIC X(8)   VALUE 'PM9CT011'.
           05  WSC-PE9C0CLC                 PIC X(8)   VALUE 'PE9C0CLC'.
           05  CON-TC8C1220                 PIC X(8)   VALUE 'TC8C1220'.
      *COL05-I
           05  CON-UG7CCNRA                 PIC X(8)   VALUE 'UG7CCNRA'.
      *COL05-F
      *COL02-I
           05 CTE-96                        PIC X(02) VALUE '96'.
      *COL02-F
      *COL08-I
           05 W-TASA-POLI-EXT               PIC S9(3)V9(5) VALUE ZEROS.
      *COL08-F
      *COL09-I
           05  WSC-UR2CIT37                 PIC X(08)  VALUE 'UR2CIT37'.
           05  WSC-ALF-1737                 PIC X(04)  VALUE '1737'.
           05  WSC-ALF-5011                 PIC X(04)  VALUE '5011'.
           05  WSC-ALF-D                    PIC X(01)  VALUE 'D'.
           05  WSC-PRODUC-96                PIC X(10)  VALUE
                                                           'PRODUC-96-'.
      *COL09-F
      *COL11-I
           05 BBVA-UG9CT370                 PIC X(08) VALUE 'UG9CT370'.
      *COL11-F
      *COL13-I
           05 BBVA-UR8CCVT0                 PIC X(08) VALUE 'UR8CCVT0'.
           05 BBVA-UR8CDFP0                 PIC X(08) VALUE 'UR8CDFP0'.
           05 CON-UR8CRET2                  PIC X(08) VALUE 'UR8CRET2'.
           05 WSC-ALF-0028                  PIC X(04) VALUE '0028'.
           05 WSC-ALF-0542                  PIC X(04) VALUE '0542'.
           05 CTE-CON-3                     PIC X(01) VALUE '3'.
      *COL13-F
      *COL14-I
           05 CTE-1                         PIC 9(05) VALUE 1.
      *COL14-F
       01  VARIABLES.
           05  WS-PUNTAJE-BURO              PIC X(03) VALUE SPACES.
           05  WS-PUNT-BURO                 REDEFINES
               WS-PUNTAJE-BURO              PIC 9(03).
           05  WS-PUNTAJE-BURO-N            PIC 9(04) COMP-3 VALUE 0.
           05  WS-TOTAL-DESC                PIC S9(2)V9(3) VALUE 0.
           05  WS-TASA-PISO                 PIC S9(2)V9(3) VALUE 0.
      *COL11-I
           05 WS-EFECTIVA-CV                PIC S9(3)V9(10) COMP-3.
      *COL11-F
      *COL15-I
           05 WS-UMTA-SECCION              PIC X(04)  VALUE SPACES.
           05 WS-UMTA-ELEMENTO             PIC X(07)  VALUE SPACES.
           05 WS-UMTA-COD-RESP             PIC X(02)  VALUE SPACES.
           05 WS-UMTA-DESCRIPCION.
              10 WS-DESTINO                PIC X(01).
              10 WS-PROYECTO               PIC X(02).
           05 WS-UMTA-DESCRIPCION-RAW      PIC X(20).
      *COL15-F
           05  WSV-X                        PIC 9(15) VALUE 0.
           05 WSV-FECHA-PROCESO.
              10 WSV-DIA-PROCESO            PIC X(02) VALUE SPACES.
              10 WSV-MES-PROCESO            PIC X(02) VALUE SPACES.
              10 WSV-ANO-PROCESO            PIC X(04) VALUE SPACES.
           05 WSV-INGRESOS-FIJ              PIC 9(15)V9(2) VALUE 0.
           05 WSV-INGRESOS-VAR              PIC 9(15)V9(2) VALUE 0.

           05 WSV-MONTO-SOLICI              PIC 9(15)V9(2) VALUE 0.
           05 WSV-RANGO-MONTO               PIC 9(05)V9(4) VALUE 0.

           05 WS-PLAZO                      PIC 9(04) VALUE 0.
           05 WS-PLAZO-MES                  PIC 9(03) VALUE 0.
           05 PLAZO-MES                     PIC 9(03) VALUE 0.
           05 WSV-RANGO-PLAZO               PIC X(04) VALUE SPACES.

           05 WSV-VLR-BIEN                  PIC 9(15)V9(2) VALUE 0.
           05 WSV-RANGO-GAMA                PIC 9(05)V9(4) VALUE 0.

           05 WSV-RANGO-TIPVEH              PIC X(02) VALUE SPACES.

           05 WSV-RANGO-ESTADO              PIC X(01) VALUE SPACES.

           05 WSV-RANGO-PORCENTA            PIC 9(05)V9(4) VALUE 0.

           05 WSV-RANGO-SEG                 PIC 9(05) VALUE 0.

           05 WSV-RANGO-COL                 PIC 9(05) VALUE 0.

           05 WSV-RANGO-NOMINA              PIC X(01) VALUE SPACES.
           05 WSV-RANGO-SMLV                PIC 9(05)V9(4) VALUE 0.
           05 WSV-SUMA-INGRESOS             PIC 9(15)V9(2) VALUE 0.
           05 WSV-SALARIO-MINIMO            PIC S9(10) VALUE 0.
           05 WSV-TIPO-PRODUCTO             PIC X(01) VALUE SPACES.
           05 WSV-NPROB-MORA                PIC S9(5)V9(2) COMP-3
                                                           VALUE 0.
           05 WSV-NPROB-MORA-F              PIC S9(5)V9(4) COMP-3
                                                           VALUE 0.
      *COL03-I
           05 WS-NPROB-MORA-CFIN            PIC S9(5)V9(4) VALUE ZEROS.
           05 WS-AUX-MORA                   PIC Z9.99.
           05 WS-AUX-MORA-NUM               PIC 9(2)V9(2) VALUE ZEROS.
      *COL03-F
           05 WS-INGRESOS-A                 PIC X(12) VALUE SPACES.
           05 WS-INGRESOS                   REDEFINES
              WS-INGRESOS-A                 PIC 9999999.9999.

           05 WS-MONTOSOL-A                 PIC X(12) VALUE SPACES.
           05 WS-MONTOSOL                   REDEFINES
              WS-MONTOSOL-A                 PIC 9999999.9999.

           05 WS-PORCENTA-A                 PIC X(12) VALUE SPACES.
           05 WS-PORCENTA                   REDEFINES
              WS-PORCENTA-A                 PIC 999999999.99.

           05 WS-GAMAVEHI-A                 PIC X(12) VALUE SPACES.
           05 WS-GAMAVEHI                   REDEFINES
              WS-GAMAVEHI-A                 PIC 9999999.9999.
      *
      *DESCUENTO X CADA UNA DE LAS VARIABLES
           05 WS-SMLV-MONTO                 PIC 99999.9999.
           05 WS-SMLV-GAMA                  PIC 99999.9999.
           05 WS-PORCENTAJE                 PIC 99999.9999.
           05 WS-SEGMENTO                   PIC 99999.9999.
           05 WS-COLECTIVO                  PIC 99999.9999.
           05 WS-SMLV-CLIENTE               PIC 99999.9999.
           05 WS-PROB-MORA-F                PIC 99999.9999.
           05 WS-IND-NOMINA                 PIC X(01) VALUE SPACES.
           05 WS-IND-VIP                    PIC X(01) VALUE SPACES.

      *COL02-I
      *    05 WS-DESC-MONTO                 PIC 99999.9999.
      *    05 WS-DESC-PLAZO                 PIC 99999.9999.
      *    05 WS-DESC-GAMA                  PIC 99999.9999.
      *    05 WS-DESC-TIPVEH                PIC 99999.9999.
      *    05 WS-DESC-ESTADO                PIC 99999.9999.
      *    05 WS-DESC-PORCENTA              PIC 99999.9999.
      *    05 WS-DESC-SEG                   PIC 99999.9999.
      *    05 WS-DESC-COL                   PIC 99999.9999.
      *    05 WS-DESC-BURO                  PIC 99999.9999.
      *    05 WS-DESC-PROB                  PIC 99999.9999.
      *    05 WS-DESC-SMLV                  PIC 99999.9999.
      *    05 WS-DESC-NOMINA                PIC 99999.9999.
      *    05 WS-DESC-VIP                   PIC 99999.9999.
           05 WS-DESC-MONTO                 PIC +99999.9999.
           05 WS-DESC-PLAZO                 PIC +99999.9999.
           05 WS-DESC-GAMA                  PIC +99999.9999.
           05 WS-DESC-TIPVEH                PIC +99999.9999.
           05 WS-DESC-ESTADO                PIC +99999.9999.
           05 WS-DESC-PORCENTA              PIC +99999.9999.
           05 WS-DESC-SEG                   PIC +99999.9999.
           05 WS-DESC-COL                   PIC +99999.9999.
           05 WS-DESC-BURO                  PIC +99999.9999.
           05 WS-DESC-PROB                  PIC +99999.9999.
           05 WS-DESC-SMLV                  PIC +99999.9999.
           05 WS-DESC-NOMINA                PIC +99999.9999.
           05 WS-DESC-VIP                   PIC +99999.9999.
           05 WS-DESC-EDAD                  PIC +99.999.
           05 WS-DESC-SITU                  PIC +99.999.
      *
           05 WS-FECHA-NACIMI               PIC 9(8).
           05 WS-FECHA-PROC                 PIC 9(8).
           05 WS-SITU-LABO                  PIC X.
           05 WS-EDAD                       PIC 9(02) VALUE ZEROS.
           05 WS-AUX-DDMMAAAA.
              10 WS-AUX-AAAA                PIC 9(4).
              10 WS-AUX-MM                  PIC 9(2).
              10 WS-AUX-DD                  PIC 9(2).
           05 WS-AUX1-DDMMAAAA.
              10 WS-AUX1-AAAA               PIC 9(4).
              10 WS-AUX1-MM                 PIC 9(2).
              10 WS-AUX1-DD                 PIC 9(2).
      *
          05 WS-SECC1056                    PIC S9(2)V9(3).
          05 WS-SECC1056-AUX                PIC +99.999.
          05 WS-TASA-USURA                  PIC S9(3)V9(4) VALUE ZEROS.
          05 W-TASA-POLI                    PIC S9(3)V9(5) VALUE ZEROS.


          05 WS-DEN-UVR                     PIC X.
             88 WS-SI-UVR                          VALUE 'S'.
             88 WS-NO-UVR                          VALUE 'N'.
          05 WS-HIP-VIS                     PIC X.
             88 WS-SI-VIS                          VALUE 'S'.
             88 WS-NO-VIS                          VALUE 'N'.
          05 WS-TOTAL                      PIC S9(2)V9(3) VALUE 0.

          05 WS-FECHA-ANTES.
             10 WS-ANIO-ANTES              PIC 9(04).
             10 WS-MES-ANTES               PIC 9(02).
             10 WS-DIA-ANTES               PIC 9(02).

          05 WS-VARIACION                  PIC S9(3)V9(4).
          05 WS-UVR-FIN                    PIC X(14).
          05 WS-UVR-F-NUM REDEFINES WS-UVR-FIN PIC 9(10)V9(4).
          05 WS-UVR-INI                    PIC X(14).
          05 WS-UVR-I-NUM REDEFINES WS-UVR-INI PIC 9(10)V9(4).

      *
      *COL02-F

      *COL01-I
      *    05 WS-DESCUENTO                  PIC ZZZ.ZZZ.
      *    05 WS-TASAPISO                   PIC ZZZ.ZZZ.
      *COL02-I
      *    05 WS-DESCUENTO                  PIC 999.999.
           05 WS-DESCUENTO                  PIC +99.999.
      *COL02-F
           05 WS-TASAPISO                   PIC 999.999.
      *COL01-F
      *COL09-I
           05 WS-SECCION                    PIC X(04) VALUE SPACES.
           05 WS-ELEMENTO                   PIC X(22) VALUE SPACES.
      *COL09-F
      *COL13-I
           05 WS-TASA-NOM                   PIC S9(03)V9(5) COMP-3.
           05 WS-FEC-DD-MM-AAAA.
              10  WS-FEC-DD                 PIC 9(2).
              10  WS-FEC-MM                 PIC 9(2).
              10  WS-FEC-AAAA               PIC 9(4).
      *COL13-F
      *COL16-I
           05 WS-SECCION-1                  PIC X(04) VALUE SPACES.
           05 WS-SECCION-2                  PIC X(04) VALUE SPACES.
      *COL16-F
      ******************************************************************
      *                                                                *
      *       MARCA DE FINAL DE WORKING-STORAGE                        *
      *                                                                *
      ******************************************************************
       01  LT-FINAL-DE-WS.
           05  LT-FINAL-DE-WS          PIC X(42)  VALUE
               '*****FINAL WORKING STORAGE UR7CCRAR******'.
      *
           EJECT
      *
      ******************************************************************
      *                   L I N K A G E   S E C T I O N                *
      ******************************************************************
       LINKAGE SECTION.
      *
       01 DFHCOMMAREA.
      *********** AREA DE COMUNICACION CON EL PROGRAMA LLAMADOR ********
           COPY UGWCRAR.
      *
           EJECT
      *
      ******************************************************************
      *           P R O C E D U R E   D I V I S I O N                  *
      ******************************************************************
       PROCEDURE DIVISION USING DFHCOMMAREA.
      *
           PERFORM 1000-INICIO-PROGRAMA
           PERFORM 2000-PROCESO-PROGRAMA
           PERFORM 3000-FINAL-PROGRAMA.
      *
      ******************************************************************
      *                     1000-INICIO-PROGRAMA                       *
      ******************************************************************
       1000-INICIO-PROGRAMA.
      *
      *COL08-I
           IF UGRAR-TASA-POLI IS NUMERIC
              MOVE UGRAR-TASA-POLI          TO W-TASA-POLI-EXT
           END-IF
      *COL08-F
           INITIALIZE UGRAR-SALIDA
                      VARIABLES
           MOVE WSC-ALF-00                  TO UGRAR-COD-RETORNO.
      *
      ******************************************************************
      *                     2000-PROCESO-PROGRAMA                      *
      ******************************************************************
       2000-PROCESO-PROGRAMA.
      *
           PERFORM 2100-VALIDAR-ENTRADA
      *COL11-I
           PERFORM LLAMA-RUTINA-UG9CT370
      *COL11-F
      *COL02-I
           PERFORM 28000-BUSCAR-UGDTT37
      *COL02-F
            PERFORM 2301-VALIDAR-SECCION
             IF SW-SI-RAR-SECC1056
      *COL02-I
      *       MOVE T37-RESTO(1:6)              TO UGRAR-TOTAL-DESC
                MOVE T37-RESTO(1:2)              TO WS-SECC1056(1:2)
                MOVE T37-RESTO(4:3)              TO WS-SECC1056(3:3)
                COMPUTE WS-SECC1056 = WS-SECC1056 * -1
                MOVE WS-SECC1056                 TO WS-SECC1056-AUX
                MOVE WS-SECC1056-AUX             TO UGRAR-TOTAL-DESC
      *COL02-F
                PERFORM 2230-VALIDAR-LIBRANZAS
                IF WS-TASA-PISO <= ZEROS
                   MOVE '11.000'                 TO UGRAR-TASA-PISO
                ELSE
                   MOVE WS-TASA-PISO             TO WS-TASAPISO
                   MOVE WS-TASAPISO              TO UGRAR-TASA-PISO
                END-IF
             ELSE
                PERFORM 2201-VALIDAR-PARAMETRIA
      *COL03-I
      *      END-IF.
             END-IF
             IF SW-NO-TASAS THEN
                IF SW-NO-TIPO THEN
                   PERFORM 2200-CONSULTAR-TIPO-PRODUCTO
                END-IF
                PERFORM 2560-OBT-TASAPOLI
                PERFORM 2570-OBT-TASA-USURA
                COMPUTE WS-TASA-USURA = WS-VARIACION + RFI-UGTIPINT
                MOVE WS-TASA-USURA               TO UGRAR-TASA-USURA
                MOVE W-TASA-POLI                 TO UGRAR-TASA-POLI
      * COL07-I
                                                    WS-DESCUENTO
                MOVE WS-DESCUENTO                TO UGRAR-TOTAL-DESC
      * COL07-F
      * COL05-I
      *      END-IF.
             END-IF
      *COL03-F
             IF SW-SI-APLI-RAR
                PERFORM 9999-CONTROL-TASA
             END-IF.
      * COL05-F
      *
      *----------------------------------------------------------------*
      *                   2301-VALIDAR-SECCION
      *----------------------------------------------------------------*
       2301-VALIDAR-SECCION.
      *
           INITIALIZE UGTCT37
           MOVE '1056'                         TO T37-SECCION
           MOVE UGRAR-SUBPROD                  TO T37-ELEMENTO

           EXEC SQL
                 SELECT RESTO
                 INTO  :T37-RESTO
                 FROM UGDTT37
                 WHERE SECCION  = :T37-SECCION  AND
                       ELEMENTO = :T37-ELEMENTO
            END-EXEC.
      *
           EVALUATE SQLCODE
              WHEN ZERO
                 SET SW-SI-RAR-SECC1056         TO TRUE
              WHEN +100
                 SET SW-NO-RAR-SECC1056       TO TRUE
              WHEN OTHER
                 MOVE WSC-ALF-99              TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                 TO UGRAR-SQLERRM
                 MOVE 'UGDTT37'               TO UGRAR-VAR1-ERROR
                 MOVE 'VAL SECCION 1056'      TO UGRAR-VAR1-ERROR
                 MOVE DB2-RETURN-CDE          TO UGRAR-SQLCODE
                 MOVE UGRAR-SQLCODE           TO UGRAR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *COL02-I
      ******************************************************************
      *             28000-BUSCAR-UGDTT37.                              *
      *----------------------------------------------------------------*
      *  SE BUSCA EN LA TABLA DE PARAMETROS DE PRESTAMOS(UGDTT37) LOS  *
      *  SUBPRODUCTOS A LOS CUALES NO SE APLICA RAR.                   *
      ******************************************************************
       28000-BUSCAR-UGDTT37.
           INITIALIZE UGTCT37
           MOVE '1054'                         TO T37-SECCION
           MOVE UGRAR-SUBPROD                  TO T37-ELEMENTO
           EXEC SQL
                 SELECT RESTO
                 INTO  :T37-RESTO
                 FROM UGDTT37
                WHERE SECCION  = :T37-SECCION  AND
                      ELEMENTO = :T37-ELEMENTO
            END-EXEC.

           EVALUATE SQLCODE
              WHEN ZERO
                 SET SW-NO-APLI-RAR           TO TRUE
              WHEN +100
                 SET SW-SI-APLI-RAR           TO TRUE
              WHEN OTHER
                 MOVE WSC-ALF-99              TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                 TO UGRAR-SQLERRM
                 MOVE 'UGDTT37'               TO UGRAR-VAR1-ERROR
                 MOVE 'VAL SECCION 1056'      TO UGRAR-VAR1-ERROR
                 MOVE DB2-RETURN-CDE          TO UGRAR-SQLCODE
                 MOVE UGRAR-SQLCODE           TO UGRAR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *COL02-F
      *----------------------------------------------------------------*
      *                 2201-VALIDAR-PARAMETRIA
      *----------------------------------------------------------------*
       2201-VALIDAR-PARAMETRIA.
      *
           PERFORM 2200-CONSULTAR-TIPO-PRODUCTO
           IF WSV-TIPO-PRODUCTO NOT EQUAL 'X'
      *COL03-I
              IF WSV-TIPO-PRODUCTO = 'V' OR 'H' OR 'L' THEN
                 IF UGRAR-PORCENTA-FINA = SPACES OR LOW-VALUES THEN
                    MOVE WSC-ALF-10              TO UGRAR-COD-RETORNO
                    MOVE 'CAMPO NO INFORMADO  '  TO UGRAR-VAR2-ERROR
                    MOVE '% DE FINANCIACION  '   TO UGRAR-VAR1-ERROR
                    PERFORM 3000-FINAL-PROGRAMA
                 END-IF
              END-IF
              IF WSV-TIPO-PRODUCTO = 'V' THEN
                IF UGRAR-TIPO-VEHICULO = SPACES OR LOW-VALUES THEN
                   MOVE WSC-ALF-10              TO UGRAR-COD-RETORNO
                   MOVE 'CAMPO NO INFORMADO  '  TO UGRAR-VAR2-ERROR
                   MOVE 'TIPO DE VEHICULO   '   TO UGRAR-VAR1-ERROR
                   PERFORM 3000-FINAL-PROGRAMA
                ELSE
                 IF UGRAR-TIPO-VEHICULO = 'NO PROCEDE' OR 'PARTICULAR'
                    OR 'PUBLICO' THEN
                    CONTINUE
                 ELSE
                   MOVE WSC-ALF-10              TO UGRAR-COD-RETORNO
                   MOVE 'CAMPO INCORRECTO TIP'  TO UGRAR-VAR2-ERROR
                   MOVE 'VEHICULO '             TO UGRAR-VAR1-ERROR(1:9)
                   MOVE UGRAR-TIPO-VEHICULO     TO UGRAR-VAR1-ERROR(10:)
                   PERFORM 3000-FINAL-PROGRAMA
                 END-IF
                END-IF
              END-IF
      *COL03-F
              PERFORM 2300-CONSULTAR-INFO-CLIENTE
      *COL02-I
      *COL03-I
              SET SW-SI-TIPO               TO TRUE
      *COL03-F
           IF SW-NO-APLI-RAR
              MOVE ZEROES                  TO WS-DESCUENTO
           ELSE
      * COL05-I
      *       PERFORM 2400-CONSULTAR-PARAMETRIA
              PERFORM 9999-TASA-PREFERENTE
      * COL05-F
      *COL03-I
              SET SW-SI-TASAS              TO TRUE
              IF UGRAR-IND = 'NMC' THEN
                 MOVE WS-TOTAL-DESC        TO WS-DESCUENTO
              ELSE
      *COL03-F
      *COL02-I
      * SE HACE ESTA VALIDACION PARA COMPLETAR LOS PUNTOS PARA LLEGAR
      * A LA TASA DE USURA Y WEB SCORING
              COMPUTE WS-TOTAL = W-TASA-POLI + WS-TOTAL-DESC
      *
              IF WS-TOTAL < W-TASA-POLI
                 MOVE WS-TOTAL-DESC        TO WS-DESCUENTO
              ELSE
                IF WS-TOTAL < WS-TASA-USURA
                 MOVE WS-TOTAL-DESC        TO WS-DESCUENTO
                ELSE
                COMPUTE WS-TOTAL-DESC = WS-TASA-USURA - W-TASA-POLI
                 MOVE WS-TOTAL-DESC        TO WS-DESCUENTO
                END-IF
              END-IF
      *COL03-I
              END-IF
      *COL03-F
             END-IF
      *
      *       MOVE WS-TOTAL-DESC           TO WS-DESCUENTO
      *COL02-F
              MOVE WS-DESCUENTO            TO UGRAR-TOTAL-DESC
      *COL03-I
              MOVE WS-TASA-USURA           TO UGRAR-TASA-USURA
              MOVE W-TASA-POLI             TO UGRAR-TASA-POLI
      *COL03-F
              IF WS-TASA-PISO <= ZEROS
                 MOVE '11.000'             TO UGRAR-TASA-PISO
              ELSE
                 MOVE WS-TASA-PISO         TO WS-TASAPISO
                 MOVE WS-TASAPISO          TO UGRAR-TASA-PISO
              END-IF
           ELSE
              MOVE '20'                    TO UGRAR-COD-RETORNO
              MOVE SPACES                  TO UGRAR-TOTAL-DESC
              MOVE SPACES                  TO UGRAR-TASA-PISO
      *COL03-I
              MOVE ZEROES                  TO UGRAR-TASA-USURA
                                              UGRAR-TASA-POLI
      *COL03-F
           END-IF.
      *
      *----------------------------------------------------------------*
      *                     21-VALIDAR-ENTRADA
      *----------------------------------------------------------------*
       2100-VALIDAR-ENTRADA.
      *
           IF UGRAR-NUMCLIEN EQUAL SPACES OR LOW-VALUES
              MOVE WSC-ALF-10              TO UGRAR-COD-RETORNO
              MOVE 'CAMPO NO INFORMADO  '  TO UGRAR-VAR2-ERROR
              MOVE 'NUMERO DE CLIENTE   '  TO UGRAR-VAR1-ERROR
              PERFORM 3000-FINAL-PROGRAMA
           END-IF
      *
           IF UGRAR-SUBPROD EQUAL SPACES OR LOW-VALUES
              MOVE WSC-ALF-10              TO UGRAR-COD-RETORNO
              MOVE 'CAMPO NO INFORMADO  '  TO UGRAR-VAR2-ERROR
              MOVE 'SUBPRODUCTO         '  TO UGRAR-VAR1-ERROR
              PERFORM 3000-FINAL-PROGRAMA
           END-IF
      *
           IF UGRAR-FECHA-PROCESO EQUAL SPACES OR LOW-VALUES
              MOVE WSC-ALF-10              TO UGRAR-COD-RETORNO
              MOVE 'CAMPO NO INFORMADO  '  TO UGRAR-VAR2-ERROR
              MOVE 'FECHA PROCESO       '  TO UGRAR-VAR1-ERROR
              PERFORM 3000-FINAL-PROGRAMA
           END-IF
      *COL02-I
           IF UGRAR-FECHA-NACI EQUAL '0001-01-01' AND
              UGRAR-SITU-LABO EQUAL 'X'
              CONTINUE
           ELSE
              IF UGRAR-FECHA-NACI = SPACES OR LOW-VALUES THEN
                 MOVE WSC-ALF-10              TO UGRAR-COD-RETORNO
                 MOVE 'CAMPO NO INFORMADO  '  TO UGRAR-VAR1-ERROR
                 MOVE 'FECHA DE NACIMIENTO '  TO UGRAR-VAR2-ERROR
                 PERFORM 3000-FINAL-PROGRAMA
              END-IF
      *
              IF UGRAR-SITU-LABO(2:1) = SPACES OR LOW-VALUES THEN
                 MOVE WSC-ALF-10              TO UGRAR-COD-RETORNO
                 MOVE 'CAMPO NO INFORMADO  '  TO UGRAR-VAR1-ERROR
                 MOVE 'SITUACION LABORAL   '  TO UGRAR-VAR2-ERROR
                 PERFORM 3000-FINAL-PROGRAMA
              END-IF
           END-IF
      *COL02-F
      *
           PERFORM 2110-VALIDAR-FECHA
           PERFORM 2111-MUEVE-ENTRADA.
      *
      *----------------------------------------------------------------*
      *                    2110-VALIDAR-FECHA                          *
      *----------------------------------------------------------------*
       2110-VALIDAR-FECHA.
      *
           INITIALIZE TCWC1750
           MOVE UGRAR-FECHA-PROCESO(9:2)     TO WSV-DIA-PROCESO
           MOVE UGRAR-FECHA-PROCESO(6:2)     TO WSV-MES-PROCESO
           MOVE UGRAR-FECHA-PROCESO(1:4)     TO WSV-ANO-PROCESO
           MOVE WSC-ALF-1                    TO W175-CDOPCIO
           MOVE WSV-FECHA-PROCESO            TO W175-FHGRE1

           CALL CON-TC8C1220 USING TCWC1750

           IF W175-CDRETORN NOT EQUAL '00'
              MOVE W175-CDRETORN             TO UGRAR-COD-RETORNO
              MOVE 'FECHA PROCESO ILOGIC'    TO UGRAR-VAR1-ERROR
              MOVE 'DDMMAAAA'                TO UGRAR-VAR2-ERROR
              PERFORM 3000-FINAL-PROGRAMA
           END-IF.
      *
      *----------------------------------------------------------------*
      *                    2111-MUEVE-ENTRADA                          *
      *----------------------------------------------------------------*
       2111-MUEVE-ENTRADA.
      *
           MOVE UGRAR-BURO                     TO WS-PUNTAJE-BURO

           MOVE UGRAR-INGRESOS                 TO WS-INGRESOS-A
           MOVE WS-INGRESOS                    TO WSV-RANGO-SMLV

           MOVE UGRAR-DOMI-NOMINA              TO WSV-RANGO-NOMINA

           MOVE UGRAR-MONTO-SOLI               TO WS-MONTOSOL-A
           MOVE WS-MONTOSOL                    TO WSV-RANGO-MONTO

           MOVE UGRAR-PLAZO-CREDITO            TO WSV-RANGO-PLAZO

           MOVE UGRAR-PORCENTA-FINA            TO WS-PORCENTA-A
           MOVE WS-PORCENTA                    TO WSV-RANGO-PORCENTA
           MOVE UGRAR-GAMA-VEHICULO            TO WS-GAMAVEHI-A
           MOVE WS-GAMAVEHI                    TO WSV-RANGO-GAMA
           MOVE UGRAR-ESTADO-BIEN              TO WSV-RANGO-ESTADO
           MOVE UGRAR-TIPO-VEHICULO            TO WSV-RANGO-TIPVEH.
      *
      *----------------------------------------------------------------*
      *                     2200-CONSULTAR-TIPO-PRODUCTO
      *----------------------------------------------------------------*
       2200-CONSULTAR-TIPO-PRODUCTO.
      *
            INITIALIZE WSV-TIPO-PRODUCTO
      *
            PERFORM 2210-VALIDAR-UGDTT37
            IF SW-SI-SUBPRO-N
               MOVE 'N'                      TO WSV-TIPO-PRODUCTO
            END-IF
      *
            PERFORM 2220-VALIDAR-VEHICULO
            IF SW-SI-SUBPRO-V
               MOVE 'V'                      TO WSV-TIPO-PRODUCTO
            END-IF
      *
      *COL16-I
      **COL13-I
      *     IF SW-SI-SUBPRO-N  OR SW-SI-SUBPRO-V
      *        PERFORM 2221-VALIDAR-TASA-VARIABLE
      *     END-IF
      **COL13-F
      *COL16-F
            PERFORM 2230-VALIDAR-LIBRANZAS
            IF SW-SI-SUBPRO-Z
               MOVE 'Z'                      TO WSV-TIPO-PRODUCTO
            END-IF
      *COL16-I
            IF SW-SI-SUBPRO-N OR SW-SI-SUBPRO-V OR SW-SI-SUBPRO-Z
               PERFORM 2221-VALIDAR-TASA-VARIABLE
            END-IF
      *COL16-F
      *
            IF SW-SI-SUBPRO-H
               MOVE 'H'                      TO WSV-TIPO-PRODUCTO
            END-IF
      *
            IF SW-SI-SUBPRO-C
               MOVE 'C'                      TO WSV-TIPO-PRODUCTO
            END-IF
      *
            PERFORM 2240-VALIDAR-LEASING-HAB
            IF SW-SI-SUBPRO-L
               MOVE 'L'                      TO WSV-TIPO-PRODUCTO
            END-IF
      *
            IF WSV-TIPO-PRODUCTO EQUAL SPACES
               MOVE 'X'                      TO WSV-TIPO-PRODUCTO
            END-IF.
      *
      *----------------------------------------------------------------*
      *                     2210-VALIDAR-UGDTT37
      *----------------------------------------------------------------*
       2210-VALIDAR-UGDTT37.
      *
           INITIALIZE UGTCT37
           MOVE '1901'                        TO T37-SECCION
           MOVE UGRAR-SUBPROD                 TO T37-ELEMENTO(1:4)
      *
             EXEC SQL
                 SELECT RESTO
                   INTO :T37-RESTO
                   FROM UGDTT37
                  WHERE SECCION  = :T37-SECCION
                    AND ELEMENTO   = :T37-ELEMENTO
             END-EXEC
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE

           IF DB2-OK AND SQLWARN0 = SPACES
              EVALUATE  T37-RESTO(1:1)
                WHEN 'H'
                  SET SW-SI-SUBPRO-H            TO TRUE
                WHEN 'C'
                  SET SW-SI-SUBPRO-C            TO TRUE
                WHEN 'N'
                  SET SW-SI-SUBPRO-N            TO TRUE
                WHEN OTHER
                  SET SW-SI-SUBPRO-X            TO TRUE
              END-EVALUATE
           ELSE
              IF DB2-NOTFND AND SQLWARN0 = SPACES
                 SET SW-SI-SUBPRO-X            TO TRUE
              ELSE
                 MOVE WSC-ALF-99               TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                  TO UGRAR-SQLERRM
                 MOVE 'UGDTT37'                TO UGRAR-VAR1-ERROR
                 MOVE 'VAL TIPO CARTERA'       TO UGRAR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE           TO UGRAR-SQLCODE
                 MOVE UGRAR-SQLCODE            TO UGRAR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
              END-IF
           END-IF.
      *
      *----------------------------------------------------------------*
      *                     2220-VALIDAR-VEHICULO
      *----------------------------------------------------------------*
       2220-VALIDAR-VEHICULO.
      *
           INITIALIZE UGTCT37
           MOVE '9040'                        TO T37-SECCION
           MOVE UGRAR-SUBPROD                 TO T37-ELEMENTO(1:4)
      *
             EXEC SQL
                 SELECT RESTO
                   INTO :T37-RESTO
                   FROM UGDTT37
                  WHERE SECCION  = :T37-SECCION
                    AND ELEMENTO   = :T37-ELEMENTO
             END-EXEC
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE

           IF DB2-OK AND SQLWARN0 = SPACES
              SET SW-SI-SUBPRO-V               TO TRUE
           ELSE
              IF DB2-NOTFND AND SQLWARN0 = SPACES
                 SET SW-NO-SUBPRO-V            TO TRUE
              ELSE
                 MOVE WSC-ALF-99               TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                  TO UGRAR-SQLERRM
                 MOVE 'UGDTT37'                TO UGRAR-VAR1-ERROR
                 MOVE 'VAL TIPO VEHIC. '       TO UGRAR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE           TO UGRAR-SQLCODE
                 MOVE UGRAR-SQLCODE            TO UGRAR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
              END-IF
           END-IF.
      *
      *----------------------------------------------------------------*
      *                     2230-VALIDAR-LIBRANZAS
      *----------------------------------------------------------------*
       2230-VALIDAR-LIBRANZAS.
      *
           INITIALIZE UGTCPRO
           MOVE '96'                          TO PRO-PRODUCTO
           MOVE UGRAR-SUBPROD                 TO PRO-SUBPRO
      *
             EXEC SQL
                 SELECT INDEALER,
                        PORINMIN,
                        INDCRSCO
                   INTO :PRO-INDEALER,
                        :PRO-PORINMIN,
                        :PRO-INDCRSCO
                   FROM UGDTPRO
                  WHERE PRODUCTO      = :PRO-PRODUCTO
                    AND SUBPRO        = :PRO-SUBPRO
             END-EXEC
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE

           IF DB2-OK AND SQLWARN0 = SPACES
              IF PRO-INDEALER = 'S'
                 SET SW-SI-SUBPRO-Z            TO TRUE
              ELSE
                 SET SW-NO-SUBPRO-Z            TO TRUE
              END-IF
              MOVE PRO-PORINMIN                TO WS-TASA-PISO
           ELSE
              IF DB2-NOTFND AND SQLWARN0 = SPACES
                 SET SW-NO-SUBPRO-Z            TO TRUE
              ELSE
                 MOVE WSC-ALF-99               TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                  TO UGRAR-SQLERRM
                 MOVE 'UGDTPRO'                TO UGRAR-VAR1-ERROR
                 MOVE 'VAL TIPO LIBRZ. '       TO UGRAR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE           TO UGRAR-SQLCODE
                 MOVE UGRAR-SQLCODE            TO UGRAR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
              END-IF
           END-IF.
      *
      *----------------------------------------------------------------*
      *                     2240-VALIDAR-LEASING-HAB
      *----------------------------------------------------------------*
       2240-VALIDAR-LEASING-HAB.
      *
           INITIALIZE UGTCT37
      *COL17-I
           SET SW-NO-SUBPRO-L                 TO TRUE
      *    MOVE '1250'                        TO T37-SECCION
      *COL17-F
           MOVE UGRAR-SUBPROD                 TO T37-ELEMENTO(1:4)
      *COL17-I
           MOVE '1250'                        TO WS-SECCION-1
           MOVE '1254'                        TO WS-SECCION-2
      *      EXEC SQL
      *          SELECT RESTO
      *             INTO :T37-RESTO
      *            FROM UGDTT37
      *           WHERE SECCION  = :T37-SECCION
      *             AND ELEMENTO   = :T37-ELEMENTO
      *      END-EXEC
      *
             EXEC SQL
                 SELECT RESTO
                    INTO :T37-RESTO
                   FROM UGDTT37
                  WHERE SECCION  IN (:WS-SECCION-1, :WS-SECCION-2)
                    AND ELEMENTO   = :T37-ELEMENTO
                  FETCH FIRST 1 ROW ONLY
             END-EXEC
      *COL17-F
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE

           IF DB2-OK AND SQLWARN0 = SPACES
              SET SW-SI-SUBPRO-L               TO TRUE
           ELSE
              IF DB2-NOTFND AND SQLWARN0 = SPACES
                 SET SW-NO-SUBPRO-L            TO TRUE
              ELSE
                 MOVE WSC-ALF-99              TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                 TO UGRAR-SQLERRM
                 MOVE 'UGDTT37'               TO UGRAR-VAR1-ERROR
                 MOVE 'VAL TIP LEASING '      TO UGRAR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE          TO UGRAR-SQLCODE
                 MOVE UGRAR-SQLCODE           TO UGRAR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
              END-IF
           END-IF.
      *
      *----------------------------------------------------------------*
      *                     2300-CONSULTAR-INFO-CLIENTE
      *----------------------------------------------------------------*
       2300-CONSULTAR-INFO-CLIENTE.
      *
           PERFORM 2340-VALIDAR-TIPO-CLIENTE.
      *
      *----------------------------------------------------------------*
      *                     2331-BUSCAR-SMLV
      *----------------------------------------------------------------*
       2331-BUSCAR-SMLV.
      *
           INITIALIZE                           UGTCT37
           MOVE WSC-ALF-1733                    TO T37-SECCION
           MOVE UGRAR-FECHA-PROCESO             TO T37-ELEMENTO(1:4)
           MOVE '-01-01'                        TO T37-ELEMENTO(5:6)
      *
           EXEC SQL
             SELECT
                    RESTO
               INTO
                   :T37-RESTO
               FROM UGDTT37
              WHERE SECCION  = :T37-SECCION
                AND ELEMENTO = :T37-ELEMENTO
           END-EXEC.
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE

           EVALUATE SQLCODE
              WHEN ZERO
                 MOVE T37-RESTO(1:10)          TO WSV-SALARIO-MINIMO
              WHEN +100
                 MOVE WSC-ALF-99               TO UGRAR-COD-RETORNO
                 MOVE 'UGDTT37'                TO UGRAR-VAR1-ERROR
                 MOVE 'NO EXISTE SMLV'         TO UGRAR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE           TO UGRAR-SQLCODE
                 MOVE UGRAR-SQLCODE            TO UGRAR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
              WHEN OTHER
                 MOVE WSC-ALF-99              TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                 TO UGRAR-SQLERRM
                 MOVE 'UGDTT37'               TO UGRAR-VAR1-ERROR
                 MOVE 'BUSCAR SMLV '          TO UGRAR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE          TO UGRAR-SQLCODE
                 MOVE UGRAR-SQLCODE           TO UGRAR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *---------------------------------------------------------------*
      *                   2340-VALIDAR-TIPO-CLIENTE.                  *
      *---------------------------------------------------------------*
       2340-VALIDAR-TIPO-CLIENTE.
           MOVE UGRAR-NUMCLIEN TO NUMCLIEN
           MOVE 'R01'          TO CODINRE

           EXEC SQL
             SELECT NUMCLIEN,SECUINRE ,
                    CODINRE ,IMPINRE  ,
                    USUARIO ,OFICOMEN ,
                    FECOMENT,HORCOMEN ,
                    PEHSTAMP,PENOFMOD ,
                    TEXINRES
             INTO
                :NUMCLIEN ,
                :SECUINRE ,
                :CODINRE  ,
                :IMPINRE  ,
                :USUARIO  ,
                :OFICOMEN ,
                :FECOMENT ,
                :HORCOMEN ,
                :PEHSTAMP ,
                :PENOFMOD ,
                :TEXINRES
            FROM PEDV1101
             WHERE NUMCLIEN = :PEDV1101-INFORES.NUMCLIEN
               AND CODINRE = :PEDV1101-INFORES.CODINRE
             END-EXEC

             MOVE SQLCODE TO DB2-RETURN-CDE
             IF DB2-OK
                 MOVE IMPINRE                TO WSV-NPROB-MORA
                                                WSV-NPROB-MORA-F
                 COMPUTE WSV-NPROB-MORA-F = WSV-NPROB-MORA/100
             ELSE
                 IF DB2-NOTFND
      *COL03-I
      *              MOVE 99999              TO WSV-NPROB-MORA-F
                     MOVE 99999              TO WS-NPROB-MORA-CFIN
                     IF UGRAR-IND = 'NMC' THEN
                        PERFORM 23402-OPENC
                        PERFORM 23401-BUSCA-CIFIN UNTIL SW-FIN-CUR
                        PERFORM 23404-CLOSEC
                     END-IF
                     MOVE WS-NPROB-MORA-CFIN TO WSV-NPROB-MORA-F
      *COL03-F
                 ELSE
                     MOVE SQLCODE            TO UGRAR-COD-RETORNO
                     MOVE NUMCLIEN           TO UGRAR-VAR1-ERROR
                     MOVE 'R01'              TO UGRAR-VAR2-ERROR
                     MOVE 'MAL INFORMADO'    TO UGRAR-VAR2-ERROR
                     PERFORM 3000-FINAL-PROGRAMA
                 END-IF
             END-IF.

      *COL02-I
      ******************************************************************
      *   PROCESO QUE OBTIENE LOS A#OS DE EDAD QUE TIENE EL CLIENTE AL *
      *            MOMENTO DE RALIZAR EL SCORING DEL CREDITO           *
      ******************************************************************
       9999-VALIDA-FEC-NACIM.
           INITIALIZE TCWC1750
           MOVE UGRAR-FECHA-NACI(9:2)        TO WSV-DIA-PROCESO
           MOVE UGRAR-FECHA-NACI(6:2)        TO WSV-MES-PROCESO
           MOVE UGRAR-FECHA-NACI(1:4)        TO WSV-ANO-PROCESO
           MOVE WSC-ALF-1                    TO W175-CDOPCIO
           MOVE WSV-FECHA-PROCESO            TO W175-FHGRE1

           CALL CON-TC8C1220 USING TCWC1750

           IF W175-CDRETORN NOT EQUAL '00'
              EVALUATE W175-CDRETORN
                WHEN '10'
                   MOVE W175-CDRETORN          TO UGRAR-COD-RETORNO
                   MOVE 'FECHA ILOGICA       ' TO UGRAR-VAR1-ERROR
                   MOVE SPACES                 TO UGRAR-VAR2-ERROR
                   PERFORM 3000-FINAL-PROGRAMA
                WHEN '20'
                   MOVE W175-CDRETORN          TO UGRAR-COD-RETORNO
                   MOVE 'ERR FECHA NACIMIENTO' TO UGRAR-VAR1-ERROR
                   MOVE 'AAAA-MM-DD'           TO UGRAR-VAR2-ERROR
                   PERFORM 3000-FINAL-PROGRAMA
                WHEN OTHER
                   MOVE W175-CDRETORN          TO UGRAR-COD-RETORNO
                   MOVE 'DATOS ERRONEOS      ' TO UGRAR-VAR1-ERROR
                   MOVE 'RUTINA TC8C1220     ' TO UGRAR-VAR2-ERROR
                   PERFORM 3000-FINAL-PROGRAMA
              END-EVALUATE
           END-IF.

       2350-OBTENER-EDAD-CLIEN.
      *
           PERFORM 9999-VALIDA-FEC-NACIM
           IF UGRAR-FECHA-NACI NOT = SPACES OR LOW-VALUES
              IF UGRAR-FECHA-NACI >=UGRAR-FECHA-PROCESO THEN
                 MOVE WSC-ALF-10              TO UGRAR-COD-RETORNO
                 MOVE 'ERROR FECHA NACIMI'    TO UGRAR-VAR1-ERROR
                 MOVE 'ES MAYOR A HOY'        TO UGRAR-VAR2-ERROR
                 PERFORM 3000-FINAL-PROGRAMA
              END-IF
      *
           END-IF
      *
           MOVE UGRAR-FECHA-NACI(1:4)          TO WS-FECHA-NACIMI(1:4)
           MOVE UGRAR-FECHA-NACI(6:2)          TO WS-FECHA-NACIMI(5:2)
           MOVE UGRAR-FECHA-NACI(9:2)          TO WS-FECHA-NACIMI(7:2)
           MOVE UGRAR-FECHA-PROCESO(1:4)       TO WS-FECHA-PROC(1:4)
           MOVE UGRAR-FECHA-PROCESO(6:2)       TO WS-FECHA-PROC(5:2)
           MOVE UGRAR-FECHA-PROCESO(9:2)       TO WS-FECHA-PROC(7:2)
           MOVE WS-FECHA-PROC                  TO WS-AUX-DDMMAAAA
           MOVE WS-FECHA-NACIMI                TO WS-AUX1-DDMMAAAA
           IF WS-AUX-AAAA  IS NUMERIC AND
              WS-AUX1-AAAA IS NUMERIC
              COMPUTE WS-EDAD = WS-AUX-AAAA - WS-AUX1-AAAA
              IF WS-AUX-MM  < WS-AUX1-MM
                 COMPUTE WS-EDAD = WS-EDAD - 1
              END-IF
                 IF WS-AUX-MM = WS-AUX1-MM
                    IF WS-AUX-DD < WS-AUX1-DD
                       COMPUTE WS-EDAD = WS-EDAD - 1
                    END-IF
                 END-IF
           END-IF.
      *
       2360-VALIDAR-SITU-LABO.
           IF UGRAR-SITU-LABO = '01' OR '02' OR '03' OR '04' OR
                                '05' THEN
              CONTINUE
           ELSE
              MOVE WSC-ALF-10                  TO UGRAR-COD-RETORNO
              MOVE 'SITUAC. LAB NO EXIST'      TO UGRAR-VAR1-ERROR
              MOVE UGRAR-SITU-LABO             TO UGRAR-VAR2-ERROR
              PERFORM 3000-FINAL-PROGRAMA
           END-IF.
      *COL02-F
      *----------------------------------------------------------------*
      *                     2400-CONSULTAR-PARAMETRIA
      *----------------------------------------------------------------*
       2400-CONSULTAR-PARAMETRIA.
      *
           INITIALIZE WS-TOTAL-DESC

           PERFORM 2410-PARM-BURO
           PERFORM 2420-PARM-GRUPO-RIESGO
           PERFORM 2430-PARM-INGRESOS
           PERFORM 2440-PARM-DOMICILIA-NOMINA
           PERFORM 2460-PARM-MONTO-SOLICI
           PERFORM 2470-PARM-PLAZO
           IF WSV-TIPO-PRODUCTO = 'V'
              PERFORM 2480-PARM-GAMA
              PERFORM 2490-PARM-TIPVEH
              PERFORM 2500-PARM-ESTADO
           END-IF
           IF WSV-TIPO-PRODUCTO = 'H' OR 'V' OR 'L'
              PERFORM 2510-PARM-PORCENTAJE
           END-IF
           PERFORM 2520-PARM-SEGMENTO
      *COL02-I
      *    PERFORM 2530-PARM-COLECTIVO.
           PERFORM 2530-PARM-COLECTIVO
           IF UGRAR-FECHA-NACI EQUAL '0001-01-01' AND
              UGRAR-SITU-LABO  EQUAL 'X'
              CONTINUE
           ELSE
              PERFORM 2540-PARM-EDAD
              PERFORM 2550-PARM-SITUACION-LABORAL
           END-IF
           PERFORM 2560-OBT-TASAPOLI
           IF WSV-TIPO-PRODUCTO = 'X'
              MOVE 99.999                       TO    RFI-UGTIPINT
           ELSE
              PERFORM 2570-OBT-TASA-USURA
           END-IF
           COMPUTE WS-TASA-USURA = WS-VARIACION + RFI-UGTIPINT.
      *COL02-F
      *
      *----------------------------------------------------------------*
      *                     2410-PARM-BURO
      *----------------------------------------------------------------*
       2410-PARM-BURO.
      *
           INITIALIZE                           UGTCDTE
           MOVE 0                               TO WS-DESC-BURO
           MOVE WSV-TIPO-PRODUCTO               TO DTE-TIPO-PRODUCTO
           MOVE UGRAR-FECHA-PROCESO             TO DTE-FECHA-INI
                                                   DTE-FECHA-FIN
           MOVE '01'                            TO DTE-COD-TIPO-PUNTAJE
           MOVE WS-PUNT-BURO                    TO WS-PUNTAJE-BURO-N
           MOVE WS-PUNTAJE-BURO-N               TO DTE-RANGO-INI
                                                   DTE-RANGO-FIN
      *
           EXEC SQL
             SELECT DTE_TASA_DESCUENTO
               INTO :DTE-TASA-DESCUENTO
               FROM UGDTDTE
              WHERE DTE_COD_TIPO_PUNTAJE  =:DTE-COD-TIPO-PUNTAJE
                AND DTE_TIPO_PRODUCTO     =:DTE-TIPO-PRODUCTO
                AND DTE_FECHA_INI        <=:DTE-FECHA-INI
                AND DTE_FECHA_FIN        >=:DTE-FECHA-FIN
                AND DTE_RANGO_INI        <=:DTE-RANGO-INI
                AND DTE_RANGO_FIN        >=:DTE-RANGO-FIN
           END-EXEC.
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE

           EVALUATE SQLCODE
              WHEN ZERO
                 MOVE DTE-TASA-DESCUENTO       TO WS-DESC-BURO
                 ADD DTE-TASA-DESCUENTO        TO WS-TOTAL-DESC
              WHEN +100
                 MOVE WSC-ALF-99               TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                  TO UGRAR-SQLERRM
                 MOVE WS-PUNTAJE-BURO          TO UGRAR-VAR1-ERROR
                 MOVE 'PARAMETRIZAR P.BURO'    TO UGRAR-VAR2-ERROR
                 MOVE DB2-RETURN-CDE           TO UGRAR-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
              WHEN OTHER
                 MOVE WSC-ALF-99              TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                 TO UGRAR-SQLERRM
                 MOVE 'UGDTDTE'               TO UGRAR-VAR1-ERROR
                 MOVE 'BUSCAR RANGO '         TO UGRAR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE          TO UGRAR-SQLCODE
                 MOVE UGRAR-SQLCODE           TO UGRAR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *----------------------------------------------------------------*
      *                     2420-PARM-GRUPO-RIESGO
      *----------------------------------------------------------------*
       2420-PARM-GRUPO-RIESGO.
      *
           INITIALIZE                       UGTCDTE
           MOVE 0                        TO WS-DESC-PROB
           MOVE WSV-TIPO-PRODUCTO        TO DTE-TIPO-PRODUCTO
           MOVE UGRAR-FECHA-PROCESO      TO DTE-FECHA-INI
                                            DTE-FECHA-FIN
           MOVE '02'                     TO DTE-COD-TIPO-PUNTAJE
           MOVE WSV-NPROB-MORA-F         TO DTE-PROB-RIESGO-INICIAL
                                            DTE-PROB-RIESGO-FINAL
           MOVE WSV-NPROB-MORA-F         TO WS-PROB-MORA-F
      *
           EXEC SQL
             SELECT DTE_TASA_DESCUENTO
               INTO :DTE-TASA-DESCUENTO
               FROM UGDTDTE
              WHERE DTE_COD_TIPO_PUNTAJE  =:DTE-COD-TIPO-PUNTAJE
                AND DTE_TIPO_PRODUCTO     =:DTE-TIPO-PRODUCTO
                AND DTE_FECHA_INI        <=:DTE-FECHA-INI
                AND DTE_FECHA_FIN        >=:DTE-FECHA-FIN
                AND DTE_PROB_RIESGO_INICIAL <=
                                         :DTE-PROB-RIESGO-INICIAL
                AND DTE_PROB_RIESGO_FINAL   >=
                                         :DTE-PROB-RIESGO-FINAL
           END-EXEC.
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE

           EVALUATE SQLCODE
              WHEN ZERO
                 MOVE DTE-TASA-DESCUENTO       TO WS-DESC-PROB
                 ADD DTE-TASA-DESCUENTO        TO WS-TOTAL-DESC
              WHEN +100
                 MOVE WSC-ALF-99               TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                  TO UGRAR-SQLERRM
                 MOVE WS-PROB-MORA-F           TO UGRAR-VAR1-ERROR
                 MOVE 'PARAM. TIPO CLIENTE'    TO UGRAR-VAR2-ERROR
                 MOVE DB2-RETURN-CDE           TO UGRAR-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
              WHEN OTHER
                 MOVE WSC-ALF-99              TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                 TO UGRAR-SQLERRM
                 MOVE 'UGDTDTE'               TO UGRAR-VAR1-ERROR
                 MOVE 'PROB. DE MORA '        TO UGRAR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE          TO UGRAR-SQLCODE
                 MOVE UGRAR-SQLCODE           TO UGRAR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *----------------------------------------------------------------*
      *                     2430-PARM-INGRESOS
      *----------------------------------------------------------------*
       2430-PARM-INGRESOS.
      *
           INITIALIZE                           UGTCDTE
           MOVE WSV-TIPO-PRODUCTO        TO DTE-TIPO-PRODUCTO
           MOVE UGRAR-FECHA-PROCESO      TO DTE-FECHA-INI
                                            DTE-FECHA-FIN
           MOVE '03'                     TO DTE-COD-TIPO-PUNTAJE
           MOVE WSV-RANGO-SMLV           TO DTE-PROB-RIESGO-INICIAL
                                            DTE-PROB-RIESGO-FINAL
           MOVE WSV-RANGO-SMLV           TO WS-SMLV-CLIENTE
           MOVE 0                        TO WS-DESC-SMLV
      *
           EXEC SQL
             SELECT DTE_TASA_DESCUENTO
               INTO :DTE-TASA-DESCUENTO
               FROM UGDTDTE
              WHERE DTE_COD_TIPO_PUNTAJE  =:DTE-COD-TIPO-PUNTAJE
                AND DTE_TIPO_PRODUCTO     =:DTE-TIPO-PRODUCTO
                AND DTE_FECHA_INI        <=:DTE-FECHA-INI
                AND DTE_FECHA_FIN        >=:DTE-FECHA-FIN
                AND DTE_PROB_RIESGO_INICIAL <=
                                         :DTE-PROB-RIESGO-INICIAL
                AND DTE_PROB_RIESGO_FINAL   >=
                                         :DTE-PROB-RIESGO-FINAL
           END-EXEC.
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE

           EVALUATE SQLCODE
              WHEN ZERO
                 MOVE DTE-TASA-DESCUENTO       TO WS-DESC-SMLV
                 ADD DTE-TASA-DESCUENTO        TO WS-TOTAL-DESC
              WHEN +100
                 MOVE WSC-ALF-99               TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                  TO UGRAR-SQLERRM
                 MOVE WS-SMLV-CLIENTE          TO UGRAR-VAR1-ERROR
                 MOVE 'PARAM. RANGO SMLV  '    TO UGRAR-VAR2-ERROR
                 MOVE DB2-RETURN-CDE           TO UGRAR-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
              WHEN OTHER
                 MOVE WSC-ALF-99               TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                  TO UGRAR-SQLERRM
                 MOVE 'UGDTDTE'                TO UGRAR-VAR1-ERROR
                 MOVE 'RANGO SMLV   '          TO UGRAR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE           TO UGRAR-SQLCODE
                 MOVE UGRAR-SQLCODE            TO UGRAR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *----------------------------------------------------------------*
      *                     2440-PARM-DOMICILIA-NOMINA
      *----------------------------------------------------------------*
       2440-PARM-DOMICILIA-NOMINA.
      *
           INITIALIZE                       UGTCDTE
           MOVE WSV-TIPO-PRODUCTO        TO DTE-TIPO-PRODUCTO
           MOVE UGRAR-FECHA-PROCESO      TO DTE-FECHA-INI
                                            DTE-FECHA-FIN
           MOVE '04'                     TO DTE-COD-TIPO-PUNTAJE
           MOVE WSV-RANGO-NOMINA         TO DTE-IND-DOM-NOMINA
           MOVE DTE-IND-DOM-NOMINA       TO WS-IND-NOMINA
           MOVE 0                        TO WS-DESC-NOMINA
      *
           EXEC SQL
             SELECT DTE_TASA_DESCUENTO
               INTO :DTE-TASA-DESCUENTO
               FROM UGDTDTE
              WHERE DTE_COD_TIPO_PUNTAJE  =:DTE-COD-TIPO-PUNTAJE
                AND DTE_TIPO_PRODUCTO     =:DTE-TIPO-PRODUCTO
                AND DTE_FECHA_INI        <=:DTE-FECHA-INI
                AND DTE_FECHA_FIN        >=:DTE-FECHA-FIN
                AND DTE_IND_DOM_NOMINA    =:DTE-IND-DOM-NOMINA
           END-EXEC.
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE

           EVALUATE SQLCODE
              WHEN ZERO
                 MOVE DTE-TASA-DESCUENTO       TO WS-DESC-NOMINA
                 ADD DTE-TASA-DESCUENTO        TO WS-TOTAL-DESC
              WHEN +100
                 MOVE WSC-ALF-99               TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                  TO UGRAR-SQLERRM
                 MOVE DTE-IND-DOM-NOMINA       TO UGRAR-VAR1-ERROR
                 MOVE 'PARAM. DOMICIL NOM '    TO UGRAR-VAR2-ERROR
                 MOVE DB2-RETURN-CDE           TO UGRAR-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
              WHEN OTHER
                 MOVE WSC-ALF-99              TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                 TO UGRAR-SQLERRM
                 MOVE 'UGDTDTE'               TO UGRAR-VAR1-ERROR
                 MOVE 'DOMICILIA NOMINA'      TO UGRAR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE          TO UGRAR-SQLCODE
                 MOVE UGRAR-SQLCODE           TO UGRAR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *----------------------------------------------------------------*
      *                     2450-PARM-SEGMENTO-VIP
      *----------------------------------------------------------------*
       2450-PARM-SEGMENTO-VIP.
      *
           INITIALIZE                       UGTCDTE
           MOVE WSV-TIPO-PRODUCTO        TO DTE-TIPO-PRODUCTO
           MOVE UGRAR-FECHA-PROCESO      TO DTE-FECHA-INI
                                            DTE-FECHA-FIN
           MOVE '05'                     TO DTE-COD-TIPO-PUNTAJE
           IF SW-SI-SEGMENTO-VIP
              MOVE 'S'                   TO DTE-IND-CLIENTE-VIP
           ELSE
              MOVE 'N'                   TO DTE-IND-CLIENTE-VIP
           END-IF
           MOVE DTE-IND-CLIENTE-VIP      TO WS-IND-VIP
           MOVE 0                        TO WS-DESC-VIP
      *
           EXEC SQL
             SELECT DTE_TASA_DESCUENTO
               INTO :DTE-TASA-DESCUENTO
               FROM UGDTDTE
              WHERE DTE_COD_TIPO_PUNTAJE  =:DTE-COD-TIPO-PUNTAJE
                AND DTE_TIPO_PRODUCTO     =:DTE-TIPO-PRODUCTO
                AND DTE_FECHA_INI        <=:DTE-FECHA-INI
                AND DTE_FECHA_FIN        >=:DTE-FECHA-FIN
                AND DTE_IND_CLIENTE_VIP   =:DTE-IND-CLIENTE-VIP
           END-EXEC.
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE

           EVALUATE SQLCODE
              WHEN ZERO
                 MOVE DTE-TASA-DESCUENTO       TO WS-DESC-VIP
                 ADD DTE-TASA-DESCUENTO        TO WS-TOTAL-DESC
              WHEN +100
                 MOVE WSC-ALF-99               TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                  TO UGRAR-SQLERRM
                 MOVE DTE-IND-CLIENTE-VIP      TO UGRAR-VAR1-ERROR
                 MOVE 'PARAM. CLIENTE VIP '    TO UGRAR-VAR2-ERROR
                 MOVE DB2-RETURN-CDE           TO UGRAR-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
                 CONTINUE
              WHEN OTHER
                 MOVE WSC-ALF-99              TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                 TO UGRAR-SQLERRM
                 MOVE 'UGDTDTE'               TO UGRAR-VAR1-ERROR
                 MOVE 'BUSCAR CLIENTE VIP '   TO UGRAR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE          TO UGRAR-SQLCODE
                 MOVE UGRAR-SQLCODE           TO UGRAR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *----------------------------------------------------------------*
      *                      3000-FINAL-PROGRAMA                       *
      *----------------------------------------------------------------*
       3000-FINAL-PROGRAMA.
           GOBACK.
      *
      *----------------------------------------------------------------*
      *                   2460-PARM-MONTO-SOLICI                       *
      *----------------------------------------------------------------*
        2460-PARM-MONTO-SOLICI.
      *
           INITIALIZE                           UGTCDTE
           MOVE WSV-TIPO-PRODUCTO        TO DTE-TIPO-PRODUCTO
           MOVE UGRAR-FECHA-PROCESO      TO DTE-FECHA-INI
                                            DTE-FECHA-FIN
           MOVE '06'                     TO DTE-COD-TIPO-PUNTAJE
           MOVE WSV-RANGO-MONTO          TO DTE-PROB-RIESGO-INICIAL
                                            DTE-PROB-RIESGO-FINAL
           MOVE WSV-RANGO-MONTO          TO WS-SMLV-MONTO
           MOVE 0                        TO WS-DESC-MONTO
      *
           EXEC SQL
             SELECT DTE_TASA_DESCUENTO
               INTO :DTE-TASA-DESCUENTO
               FROM UGDTDTE
              WHERE DTE_COD_TIPO_PUNTAJE  =:DTE-COD-TIPO-PUNTAJE
                AND DTE_TIPO_PRODUCTO     =:DTE-TIPO-PRODUCTO
                AND DTE_FECHA_INI        <=:DTE-FECHA-INI
                AND DTE_FECHA_FIN        >=:DTE-FECHA-FIN
                AND DTE_PROB_RIESGO_INICIAL <=
                                         :DTE-PROB-RIESGO-INICIAL
                AND DTE_PROB_RIESGO_FINAL   >=
                                         :DTE-PROB-RIESGO-FINAL
           END-EXEC.
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE

           EVALUATE SQLCODE
              WHEN ZERO
                 MOVE DTE-TASA-DESCUENTO       TO WS-DESC-MONTO
                 ADD DTE-TASA-DESCUENTO        TO WS-TOTAL-DESC
              WHEN +100
                 MOVE WSC-ALF-99               TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                  TO UGRAR-SQLERRM
                 MOVE WS-SMLV-MONTO            TO UGRAR-VAR1-ERROR
                 MOVE 'PARAM. RANGO MONTO '    TO UGRAR-VAR2-ERROR
                 MOVE DB2-RETURN-CDE           TO UGRAR-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
              WHEN OTHER
                 MOVE WSC-ALF-99              TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                 TO UGRAR-SQLERRM
                 MOVE 'UGDTDTE'               TO UGRAR-VAR1-ERROR
                 MOVE 'RANGO MONTO  '         TO UGRAR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE          TO UGRAR-SQLCODE
                 MOVE UGRAR-SQLCODE           TO UGRAR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *----------------------------------------------------------------*
      *                     2470-PARM-PLAZO
      *----------------------------------------------------------------*
       2470-PARM-PLAZO.
      *
           INITIALIZE                          UGTCDTE
           MOVE 0                              TO WS-DESC-PLAZO
           MOVE WSV-TIPO-PRODUCTO              TO DTE-TIPO-PRODUCTO
           MOVE UGRAR-FECHA-PROCESO            TO DTE-FECHA-INI
                                                  DTE-FECHA-FIN
           MOVE '07'                           TO DTE-COD-TIPO-PUNTAJE
           MOVE WSV-RANGO-PLAZO                TO DTE-RANGO-INI
                                                  DTE-RANGO-FIN
      *
           EXEC SQL
             SELECT DTE_TASA_DESCUENTO
               INTO :DTE-TASA-DESCUENTO
               FROM UGDTDTE
              WHERE DTE_COD_TIPO_PUNTAJE  =:DTE-COD-TIPO-PUNTAJE
                AND DTE_TIPO_PRODUCTO     =:DTE-TIPO-PRODUCTO
                AND DTE_FECHA_INI        <=:DTE-FECHA-INI
                AND DTE_FECHA_FIN        >=:DTE-FECHA-FIN
                AND DTE_RANGO_INI        <=:DTE-RANGO-INI
                AND DTE_RANGO_FIN        >=:DTE-RANGO-FIN
           END-EXEC.
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE

           EVALUATE SQLCODE
              WHEN ZERO
                 MOVE DTE-TASA-DESCUENTO       TO WS-DESC-PLAZO
                 ADD DTE-TASA-DESCUENTO        TO WS-TOTAL-DESC
              WHEN +100
                 MOVE WSC-ALF-99               TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                  TO UGRAR-SQLERRM
                 MOVE WSV-RANGO-PLAZO          TO UGRAR-VAR1-ERROR
                 MOVE 'PARAMETRIZAR PLAZO '    TO UGRAR-VAR2-ERROR
                 MOVE DB2-RETURN-CDE           TO UGRAR-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
              WHEN OTHER
                 MOVE WSC-ALF-99              TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                 TO UGRAR-SQLERRM
                 MOVE 'UGDTDTE '              TO UGRAR-VAR1-ERROR
                 MOVE 'RANGO PLAZO '          TO UGRAR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE          TO UGRAR-SQLCODE
                 MOVE UGRAR-SQLCODE           TO UGRAR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *----------------------------------------------------------------*
      *                      2480-PARM-GAMA                            *
      *----------------------------------------------------------------*
        2480-PARM-GAMA.
      *
           INITIALIZE                           UGTCDTE
           MOVE WSV-TIPO-PRODUCTO        TO DTE-TIPO-PRODUCTO
           MOVE UGRAR-FECHA-PROCESO      TO DTE-FECHA-INI
                                            DTE-FECHA-FIN
           MOVE '08'                     TO DTE-COD-TIPO-PUNTAJE
           MOVE WSV-RANGO-GAMA           TO DTE-PROB-RIESGO-INICIAL
                                            DTE-PROB-RIESGO-FINAL
           MOVE WSV-RANGO-GAMA           TO WS-SMLV-GAMA
           MOVE 0                        TO WS-DESC-GAMA
      *
           EXEC SQL
             SELECT DTE_TASA_DESCUENTO
               INTO :DTE-TASA-DESCUENTO
               FROM UGDTDTE
              WHERE DTE_COD_TIPO_PUNTAJE  =:DTE-COD-TIPO-PUNTAJE
                AND DTE_TIPO_PRODUCTO     =:DTE-TIPO-PRODUCTO
                AND DTE_FECHA_INI        <=:DTE-FECHA-INI
                AND DTE_FECHA_FIN        >=:DTE-FECHA-FIN
                AND DTE_PROB_RIESGO_INICIAL <=
                                         :DTE-PROB-RIESGO-INICIAL
                AND DTE_PROB_RIESGO_FINAL   >=
                                         :DTE-PROB-RIESGO-FINAL
           END-EXEC.
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE

           EVALUATE SQLCODE
              WHEN ZERO
                 MOVE DTE-TASA-DESCUENTO       TO WS-DESC-GAMA
                 ADD DTE-TASA-DESCUENTO        TO WS-TOTAL-DESC
              WHEN +100
                 MOVE WSC-ALF-99               TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                  TO UGRAR-SQLERRM
                 MOVE WS-SMLV-GAMA             TO UGRAR-VAR1-ERROR
                 MOVE 'PARAM. RANGO GAMA '     TO UGRAR-VAR2-ERROR
                 MOVE DB2-RETURN-CDE           TO UGRAR-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
              WHEN OTHER
                 MOVE WSC-ALF-99              TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                 TO UGRAR-SQLERRM
                 MOVE 'UGDTDTE'               TO UGRAR-VAR1-ERROR
                 MOVE 'RANGO GAMA   '         TO UGRAR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE          TO UGRAR-SQLCODE
                 MOVE UGRAR-SQLCODE           TO UGRAR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *----------------------------------------------------------------*
      *                    2490-PARM-TIPVEH                            *
      *----------------------------------------------------------------*
        2490-PARM-TIPVEH.
      *
           INITIALIZE                    UGTCDTE
           MOVE WSV-TIPO-PRODUCTO        TO DTE-TIPO-PRODUCTO
           MOVE UGRAR-FECHA-PROCESO      TO DTE-FECHA-INI
                                            DTE-FECHA-FIN
           MOVE '09'                     TO DTE-COD-TIPO-PUNTAJE
           IF WSV-RANGO-TIPVEH(1:2)= 'PA'
              MOVE 'P'                   TO DTE-IND-CLIENTE-VIP
           ELSE
              IF WSV-RANGO-TIPVEH(1:2)= 'PU'
                 MOVE 'S'                TO DTE-IND-CLIENTE-VIP
              END-IF
           END-IF

           MOVE 0                        TO WS-DESC-TIPVEH
      *
           EXEC SQL
             SELECT DTE_TASA_DESCUENTO
               INTO :DTE-TASA-DESCUENTO
               FROM UGDTDTE
              WHERE DTE_COD_TIPO_PUNTAJE  =:DTE-COD-TIPO-PUNTAJE
                AND DTE_TIPO_PRODUCTO     =:DTE-TIPO-PRODUCTO
                AND DTE_FECHA_INI        <=:DTE-FECHA-INI
                AND DTE_FECHA_FIN        >=:DTE-FECHA-FIN
                AND DTE_IND_CLIENTE_VIP   =:DTE-IND-CLIENTE-VIP
           END-EXEC.
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE

           EVALUATE SQLCODE
              WHEN ZERO
                 MOVE DTE-TASA-DESCUENTO       TO WS-DESC-TIPVEH
                 ADD DTE-TASA-DESCUENTO        TO WS-TOTAL-DESC
              WHEN +100
                 MOVE WSC-ALF-99               TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                  TO UGRAR-SQLERRM
                 MOVE 'PARAM. TIPO VEHICUL'    TO UGRAR-VAR2-ERROR
                 MOVE DB2-RETURN-CDE           TO UGRAR-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
                 CONTINUE
              WHEN OTHER
                 MOVE WSC-ALF-99              TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                 TO UGRAR-SQLERRM
                 MOVE 'UGDTDTE'               TO UGRAR-VAR1-ERROR
                 MOVE 'BUSCAR TIP VEHICULO'   TO UGRAR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE          TO UGRAR-SQLCODE
                 MOVE UGRAR-SQLCODE           TO UGRAR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *----------------------------------------------------------------*
      *                    2500-PARM-ESTADO                            *
      *----------------------------------------------------------------*
        2500-PARM-ESTADO.
      *
           INITIALIZE                    UGTCDTE
           MOVE WSV-TIPO-PRODUCTO        TO DTE-TIPO-PRODUCTO
           MOVE UGRAR-FECHA-PROCESO      TO DTE-FECHA-INI
                                            DTE-FECHA-FIN
           MOVE '10'                     TO DTE-COD-TIPO-PUNTAJE
           MOVE WSV-RANGO-ESTADO         TO DTE-IND-CLIENTE-VIP
           MOVE 0                        TO WS-DESC-ESTADO
      *
           EXEC SQL
             SELECT DTE_TASA_DESCUENTO
               INTO :DTE-TASA-DESCUENTO
               FROM UGDTDTE
              WHERE DTE_COD_TIPO_PUNTAJE  =:DTE-COD-TIPO-PUNTAJE
                AND DTE_TIPO_PRODUCTO     =:DTE-TIPO-PRODUCTO
                AND DTE_FECHA_INI        <=:DTE-FECHA-INI
                AND DTE_FECHA_FIN        >=:DTE-FECHA-FIN
                AND DTE_IND_CLIENTE_VIP   =:DTE-IND-CLIENTE-VIP
           END-EXEC.
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE

           EVALUATE SQLCODE
              WHEN ZERO
                 MOVE DTE-TASA-DESCUENTO       TO WS-DESC-ESTADO
                 ADD DTE-TASA-DESCUENTO        TO WS-TOTAL-DESC
              WHEN +100
                 MOVE WSC-ALF-99               TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                  TO UGRAR-SQLERRM
                 MOVE 'PARAM. ESTADO VEH  '    TO UGRAR-VAR2-ERROR
                 MOVE DB2-RETURN-CDE           TO UGRAR-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
                 CONTINUE
              WHEN OTHER
                 MOVE WSC-ALF-99              TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                 TO UGRAR-SQLERRM
                 MOVE 'UGDTDTE'               TO UGRAR-VAR1-ERROR
                 MOVE 'BUSCAR ESTADO VEH  '   TO UGRAR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE          TO UGRAR-SQLCODE
                 MOVE UGRAR-SQLCODE           TO UGRAR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *----------------------------------------------------------------*
      *                   2510-PARM-PORCENTAJE                         *
      *----------------------------------------------------------------*
        2510-PARM-PORCENTAJE.
      *
           INITIALIZE                       UGTCDTE
           MOVE WSV-TIPO-PRODUCTO        TO DTE-TIPO-PRODUCTO
           MOVE UGRAR-FECHA-PROCESO      TO DTE-FECHA-INI
                                            DTE-FECHA-FIN
           MOVE '11'                     TO DTE-COD-TIPO-PUNTAJE
           MOVE WSV-RANGO-PORCENTA       TO DTE-PROB-RIESGO-INICIAL
                                            DTE-PROB-RIESGO-FINAL
           MOVE WSV-RANGO-PORCENTA       TO WS-PORCENTAJE
           MOVE 0                        TO WS-DESC-PORCENTA
      *
           EXEC SQL
             SELECT DTE_TASA_DESCUENTO
               INTO :DTE-TASA-DESCUENTO
               FROM UGDTDTE
              WHERE DTE_COD_TIPO_PUNTAJE  =:DTE-COD-TIPO-PUNTAJE
                AND DTE_TIPO_PRODUCTO     =:DTE-TIPO-PRODUCTO
                AND DTE_FECHA_INI        <=:DTE-FECHA-INI
                AND DTE_FECHA_FIN        >=:DTE-FECHA-FIN
                AND DTE_PROB_RIESGO_INICIAL <=
                                         :DTE-PROB-RIESGO-INICIAL
                AND DTE_PROB_RIESGO_FINAL   >=
                                         :DTE-PROB-RIESGO-FINAL
           END-EXEC.
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE

           EVALUATE SQLCODE
              WHEN ZERO
                 MOVE DTE-TASA-DESCUENTO       TO WS-DESC-PORCENTA
                 ADD DTE-TASA-DESCUENTO        TO WS-TOTAL-DESC
              WHEN +100
                 MOVE WSC-ALF-99               TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                  TO UGRAR-SQLERRM
                 MOVE WS-PORCENTAJE            TO UGRAR-VAR1-ERROR
                 MOVE 'PARAM.% FINANCIACION'   TO UGRAR-VAR2-ERROR
                 MOVE DB2-RETURN-CDE           TO UGRAR-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
              WHEN OTHER
                 MOVE WSC-ALF-99              TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                 TO UGRAR-SQLERRM
                 MOVE 'UGDTDTE'               TO UGRAR-VAR1-ERROR
                 MOVE 'RANGO % FINAN'         TO UGRAR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE          TO UGRAR-SQLCODE
                 MOVE UGRAR-SQLCODE           TO UGRAR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *----------------------------------------------------------------*
      *                       2520-PARM-SEGMENTO                       *
      *----------------------------------------------------------------*
        2520-PARM-SEGMENTO.
      *
           PERFORM 25201-VALIDA-SEGMENTO

           IF PMT01-S-CODRET = '00'
              INITIALIZE                    UGTCDTE
              MOVE WSV-TIPO-PRODUCTO     TO DTE-TIPO-PRODUCTO
              MOVE UGRAR-FECHA-PROCESO   TO DTE-FECHA-INI
                                            DTE-FECHA-FIN
              MOVE '12'                  TO DTE-COD-TIPO-PUNTAJE
              MOVE WSV-RANGO-SEG         TO DTE-PROB-RIESGO-INICIAL
      *                                     DTE-PROB-RIESGO-FINAL
              MOVE WSV-RANGO-SEG         TO WS-SEGMENTO
              MOVE 0                     TO WS-DESC-SEG
      *
              EXEC SQL
                 SELECT DTE_TASA_DESCUENTO
                 INTO :DTE-TASA-DESCUENTO
                 FROM UGDTDTE
                 WHERE DTE_COD_TIPO_PUNTAJE =:DTE-COD-TIPO-PUNTAJE
                   AND DTE_TIPO_PRODUCTO    =:DTE-TIPO-PRODUCTO
                   AND DTE_FECHA_INI       <=:DTE-FECHA-INI
                   AND DTE_FECHA_FIN       >=:DTE-FECHA-FIN
                   AND DTE_PROB_RIESGO_INICIAL =
                                             :DTE-PROB-RIESGO-INICIAL
              END-EXEC
      *
              MOVE SQLCODE                     TO DB2-RETURN-CDE

              EVALUATE SQLCODE
                 WHEN ZERO
                    MOVE DTE-TASA-DESCUENTO    TO WS-DESC-SEG
                    ADD DTE-TASA-DESCUENTO     TO WS-TOTAL-DESC
                 WHEN +100
                    MOVE WSC-ALF-99            TO UGRAR-COD-RETORNO
                    MOVE SQLERRM               TO UGRAR-SQLERRM
                    MOVE WS-SEGMENTO           TO UGRAR-VAR1-ERROR
                    MOVE 'PARAM. SEGMENTO '    TO UGRAR-VAR2-ERROR
                    MOVE DB2-RETURN-CDE        TO UGRAR-SQLCODE
                    PERFORM 3000-FINAL-PROGRAMA
              WHEN OTHER
                    MOVE WSC-ALF-99           TO UGRAR-COD-RETORNO
                    MOVE SQLERRM              TO UGRAR-SQLERRM
                    MOVE 'UGDTDTE'            TO UGRAR-VAR1-ERROR
                    MOVE 'RANGO SEGMENTO'     TO UGRAR-VAR2-ERROR(1:16)
                    MOVE DB2-RETURN-CDE       TO UGRAR-SQLCODE
                    MOVE UGRAR-SQLCODE        TO UGRAR-VAR2-ERROR(17:4)
                    PERFORM 3000-FINAL-PROGRAMA
              END-EVALUATE
           ELSE
              CONTINUE
           END-IF.
      *
      *----------------------------------------------------------------*
      *                   25201-VALIDA-SEGMENTO
      *----------------------------------------------------------------*
      *  ACCESO A LA RUTINA QUE RETORNA EL CODIGO TCOM DEL CLIENTE     *
      *----------------------------------------------------------------*
       25201-VALIDA-SEGMENTO.

           MOVE UGRAR-NUMCLIEN               TO PMT01-E-NUMCLIEN
           MOVE '1'                          TO PMT01-E-FUNCION
           CALL WSC-PM9CT011 USING AREA-PMECT011

           EVALUATE PMT01-S-CODRET
           WHEN '00'
              MOVE PMT01-S-SEGMENTO          TO WSV-RANGO-SEG
           WHEN OTHER
              MOVE ZEROS                     TO WSV-RANGO-SEG
           END-EVALUATE.
      *
      *----------------------------------------------------------------*
      *                       2530-PARM-COLECTIVO                      *
      *----------------------------------------------------------------*
        2530-PARM-COLECTIVO.
      *
           PERFORM 25301-VALIDA-COLECTIVO

           IF WSCLC-RETORNO = '00'
              INITIALIZE                        UGTCDTE
              MOVE WSV-TIPO-PRODUCTO     TO DTE-TIPO-PRODUCTO
              MOVE UGRAR-FECHA-PROCESO   TO DTE-FECHA-INI
                                            DTE-FECHA-FIN
              MOVE '13'                  TO DTE-COD-TIPO-PUNTAJE
              MOVE WSV-RANGO-COL         TO DTE-PROB-RIESGO-INICIAL
      *                                     DTE-PROB-RIESGO-FINAL
              MOVE WSV-RANGO-COL         TO WS-COLECTIVO
              MOVE 0                     TO WS-DESC-COL
      *
              EXEC SQL
                SELECT DTE_TASA_DESCUENTO
                INTO :DTE-TASA-DESCUENTO
                FROM UGDTDTE
                WHERE DTE_COD_TIPO_PUNTAJE  =:DTE-COD-TIPO-PUNTAJE
                  AND DTE_TIPO_PRODUCTO     =:DTE-TIPO-PRODUCTO
                  AND DTE_FECHA_INI        <=:DTE-FECHA-INI
                  AND DTE_FECHA_FIN        >=:DTE-FECHA-FIN
                  AND DTE_PROB_RIESGO_INICIAL =
                                             :DTE-PROB-RIESGO-INICIAL
              END-EXEC
      *
              MOVE SQLCODE                     TO DB2-RETURN-CDE

              EVALUATE SQLCODE
                 WHEN ZERO
                    MOVE DTE-TASA-DESCUENTO    TO WS-DESC-COL
                    ADD DTE-TASA-DESCUENTO     TO WS-TOTAL-DESC
                 WHEN +100
                    MOVE WSC-ALF-99            TO UGRAR-COD-RETORNO
                    MOVE SQLERRM               TO UGRAR-SQLERRM
                    MOVE WS-COLECTIVO          TO UGRAR-VAR1-ERROR
                    MOVE 'PARAM. COLECTIVO'    TO UGRAR-VAR2-ERROR
                    MOVE DB2-RETURN-CDE        TO UGRAR-SQLCODE
                    PERFORM 3000-FINAL-PROGRAMA
                 WHEN OTHER
                    MOVE WSC-ALF-99           TO UGRAR-COD-RETORNO
                    MOVE SQLERRM              TO UGRAR-SQLERRM
                    MOVE 'UGDTDTE'            TO UGRAR-VAR1-ERROR
                    MOVE 'RANGO COLECTIVO'    TO UGRAR-VAR2-ERROR(1:16)
                    MOVE DB2-RETURN-CDE       TO UGRAR-SQLCODE
                    MOVE UGRAR-SQLCODE        TO UGRAR-VAR2-ERROR(17:4)
                    PERFORM 3000-FINAL-PROGRAMA
              END-EVALUATE
           ELSE
              CONTINUE
           END-IF.
      *COL02-I
      *----------------------------------------------------------------*
      *                     2540-PARM-EDAD
      *----------------------------------------------------------------*
       2540-PARM-EDAD.
      *
           INITIALIZE                           UGTCDTE
                                                WS-DESC-EDAD
           PERFORM 2350-OBTENER-EDAD-CLIEN
      *
           MOVE WSV-TIPO-PRODUCTO               TO DTE-TIPO-PRODUCTO
           MOVE UGRAR-FECHA-PROCESO             TO DTE-FECHA-INI
                                                   DTE-FECHA-FIN
           MOVE WS-EDAD                         TO DTE-RANGO-INI
                                                   DTE-RANGO-FIN
           MOVE '14'                            TO DTE-COD-TIPO-PUNTAJE
      *
           EXEC SQL
             SELECT DTE_TASA_DESCUENTO
               INTO :DTE-TASA-DESCUENTO
               FROM UGDTDTE
              WHERE DTE_COD_TIPO_PUNTAJE  =:DTE-COD-TIPO-PUNTAJE
                AND DTE_TIPO_PRODUCTO     =:DTE-TIPO-PRODUCTO
                AND DTE_FECHA_INI        <=:DTE-FECHA-INI
                AND DTE_FECHA_FIN        >=:DTE-FECHA-FIN
                AND DTE_RANGO_INI        <=:DTE-RANGO-INI
                AND DTE_RANGO_FIN        >=:DTE-RANGO-FIN
           END-EXEC
           MOVE SQLCODE                        TO DB2-RETURN-CDE
           EVALUATE SQLCODE
              WHEN ZERO
                 MOVE DTE-TASA-DESCUENTO       TO WS-DESC-EDAD
      *
                 ADD DTE-TASA-DESCUENTO        TO WS-TOTAL-DESC
              WHEN +100
                 MOVE WSC-ALF-99               TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                  TO UGRAR-SQLERRM
                 MOVE WS-EDAD                  TO UGRAR-VAR1-ERROR
                 MOVE 'PARAMETRIZAR EDAD'      TO UGRAR-VAR2-ERROR
                 MOVE DB2-RETURN-CDE           TO UGRAR-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
              WHEN OTHER
                 MOVE WSC-ALF-99               TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                  TO UGRAR-SQLERRM
                 MOVE 'UGDTDTE'                TO UGRAR-VAR1-ERROR
                 MOVE 'BUSCAR RANGO '          TO UGRAR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE           TO UGRAR-SQLCODE
                 MOVE UGRAR-SQLCODE            TO UGRAR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *----------------------------------------------------------------*
      *                    2550-PARM-SITUACION-LABORAL                 *
      *----------------------------------------------------------------*
        2550-PARM-SITUACION-LABORAL.
           PERFORM 2360-VALIDAR-SITU-LABO
           INITIALIZE                    UGTCDTE
                                         WS-DESC-SITU
           MOVE WSV-TIPO-PRODUCTO        TO DTE-TIPO-PRODUCTO
           MOVE UGRAR-FECHA-PROCESO      TO DTE-FECHA-INI
                                            DTE-FECHA-FIN
           MOVE '15'                     TO DTE-COD-TIPO-PUNTAJE
           MOVE UGRAR-SITU-LABO(2:1)     TO DTE-IND-CLIENTE-VIP
      *
           EXEC SQL
             SELECT DTE_TASA_DESCUENTO
               INTO :DTE-TASA-DESCUENTO
               FROM UGDTDTE
              WHERE DTE_COD_TIPO_PUNTAJE  =:DTE-COD-TIPO-PUNTAJE
                AND DTE_TIPO_PRODUCTO     =:DTE-TIPO-PRODUCTO
                AND DTE_FECHA_INI        <=:DTE-FECHA-INI
                AND DTE_FECHA_FIN        >=:DTE-FECHA-FIN
                AND DTE_IND_CLIENTE_VIP   =:DTE-IND-CLIENTE-VIP
           END-EXEC.
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE
      *
           EVALUATE SQLCODE
              WHEN ZERO
                 MOVE DTE-TASA-DESCUENTO       TO WS-DESC-SITU
                 ADD DTE-TASA-DESCUENTO        TO WS-TOTAL-DESC
              WHEN +100
                 MOVE WSC-ALF-99               TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                  TO UGRAR-SQLERRM
                 MOVE 'PARAM. SITU LABORAL'    TO UGRAR-VAR2-ERROR
                 MOVE DB2-RETURN-CDE           TO UGRAR-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
              WHEN OTHER
                 MOVE WSC-ALF-99               TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                  TO UGRAR-SQLERRM
                 MOVE 'UGDTDTE'                TO UGRAR-VAR1-ERROR
                 MOVE 'BUSCAR SITU. LABORA'    TO UGRAR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE           TO UGRAR-SQLCODE
                 MOVE UGRAR-SQLCODE            TO UGRAR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      ******************************************************************
      *                      2560-OBT-TASAPOLI                         *
      *  SE REALIZA UN SELECT EN LA TABLA UGDTLQS PARA CONSULTAR LA    *
	     *  TASA POLITICA DEL SUBPRODUCTO                                 *
      ******************************************************************
       2560-OBT-TASAPOLI.
           INITIALIZE UGTCLQS
           MOVE CTE-96                      TO LQS-PRODUCTO
           MOVE UGRAR-SUBPROD               TO LQS-SUBPRO
           MOVE UGRAR-PLAZO-CREDITO         TO LQS-PLAZO
           MOVE UGRAR-FECHA-PROCESO         TO LQS-FECOVALI
           MOVE '101'                       TO LQS-CODCONLI
      *
           EXEC SQL
              SELECT  TIPOAPLI
                INTO :LQS-TIPOAPLI
                FROM UGDTLQS
               WHERE PRODUCTO  = :LQS-PRODUCTO
                 AND SUBPRO    = :LQS-SUBPRO
                 AND CODCONLI  = '101'
      *COL06-INI
                 AND FECOVALI <= :LQS-FECOVALI
                 AND FEFIVALI >= :LQS-FECOVALI
      *          AND FECOVALI  = (SELECT MAX(FECOVALI)
      *                             FROM UGDTLQS
      *                            WHERE PRODUCTO = :LQS-PRODUCTO
      *                              AND SUBPRO   = :LQS-SUBPRO )
      *COL06-FIN
                 AND PLAZO     =
                         (SELECT MIN(PLAZO)
                            FROM UGDTLQS
                            WHERE PRODUCTO  = :LQS-PRODUCTO  AND
                                  SUBPRO    = :LQS-SUBPRO    AND
                                  CODCONLI  = :LQS-CODCONLI  AND
                                  PLAZO    >= :LQS-PLAZO     AND
                                  FECOVALI <= :LQS-FECOVALI  AND
                                  FEFIVALI >= :LQS-FECOVALI )
           END-EXEC
      *
            MOVE SQLCODE                    TO DB2-RETURN-CDE
            IF DB2-OK
               MOVE LQS-TIPOAPLI            TO W-TASA-POLI
            ELSE
               IF DB2-NOTFND
      *COL11-I
                IF SW-CREDITOVIRTUAL-SI
      *COL13-I
                  OR SW-SI-CON-TASAV OR SW-SI-VEH-TASAV
      *COL16-I
                  OR SW-SI-LIB-TASAV
      *COL16-F
      *COL13-F
                  PERFORM CONSULTA-LQS-102
      *COL13-I
                  IF SW-SI-CON-TASAV OR SW-SI-VEH-TASAV
      *COL16-I
                     OR SW-SI-LIB-TASAV
      *COL16-F
                     PERFORM 2561-TASA-IBR
                  END-IF
      *COL13-F
                ELSE
      *COL11-F
                  MOVE '99'                 TO UGRAR-COD-RETORNO
                  MOVE 'UGDTLQS'            TO UGRAR-VAR1-ERROR
                  MOVE SQLCODE              TO UGRAR-SQLERRM
                  PERFORM 3000-FINAL-PROGRAMA
      *COL11-I
                END-IF
      *COL11-F
			            END-IF
            END-IF.

      *****************************************************************
      *                      2570-OBT-TASA-USURA                      *
      *          BUSCA EL LIMITE DE USURA PARA LOS SUBPRODUCTOS       *
      *****************************************************************
       2570-OBT-TASA-USURA.
      *
           INITIALIZE UGTCRFI
      *
           EVALUATE WSV-TIPO-PRODUCTO
           WHEN 'N'
           WHEN 'Z'
           WHEN 'V'
              MOVE 'TUN'   TO RFI-UGIDXREF
           WHEN 'C'
              MOVE 'TUC'   TO RFI-UGIDXREF
           WHEN 'H'
           WHEN 'L'
                PERFORM 2580-VALIDA-HIPOTECA
                PERFORM 2590-CODIGO-USURA-HIP

                IF WS-NO-UVR
                    INITIALIZE            UGTCT37
                    MOVE UGRAR-FECHA-PROCESO(9:2)     TO WS-DIA-ANTES
                    MOVE UGRAR-FECHA-PROCESO(6:2)     TO WS-MES-ANTES
                    MOVE UGRAR-FECHA-PROCESO(1:4)     TO WS-ANIO-ANTES
                    MOVE UGRAR-FECHA-PROCESO  TO T37-ELEMENTO
                    PERFORM 2600-CALCULAR-UVR
                    MOVE T37-RESTO       TO WS-UVR-FIN
                   INITIALIZE            UGTCT37
                   COMPUTE WS-ANIO-ANTES = WS-ANIO-ANTES - 1
                   MOVE WS-ANIO-ANTES   TO T37-ELEMENTO(1:4)
                   MOVE WS-MES-ANTES    TO T37-ELEMENTO(6:2)
                   MOVE WS-DIA-ANTES    TO T37-ELEMENTO(9:2)
                   MOVE '-'             TO T37-ELEMENTO(5:1)
                                           T37-ELEMENTO(8:1)
                   PERFORM 2600-CALCULAR-UVR
                   MOVE T37-RESTO       TO WS-UVR-INI
                   IF WS-NO-UVR
                     IF WS-UVR-F-NUM NOT = ZEROS AND
                        WS-UVR-I-NUM NOT = ZEROS
                        COMPUTE WS-VARIACION ROUNDED =
                                ( ( WS-UVR-F-NUM / WS-UVR-I-NUM ) - 1 )
                                * 100
                        END-COMPUTE
                     ELSE
                        MOVE ZEROS      TO WS-VARIACION
                     END-IF
                   END-IF
                END-IF

           WHEN 'M'
              MOVE 'TUM'   TO RFI-UGIDXREF
           WHEN OTHER                                                   00022900
              MOVE WSC-ALF-99               TO UGRAR-COD-RETORNO
              MOVE 'VAL TIPO CARTERA'       TO UGRAR-VAR1-ERROR
              PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE

           MOVE UGRAR-FECHA-PROCESO    TO RFI-FECOVALI
      *
           EXEC SQL
                SELECT UGTIPINT
                INTO :RFI-UGTIPINT
                FROM UGDTRFI
                WHERE UGIDXREF =  :RFI-UGIDXREF AND
                      FECOVALI <= :RFI-FECOVALI AND
                      FEFIVALI >= :RFI-FECOVALI
           END-EXEC.

           MOVE SQLCODE TO DB2-RETURN-CDE

      *SI NO ENCUENTRA CON FECHA INDICADA,BUSCA POR LA FECHA MAX DE
      *-LA TABLA UGDTRFI PARA RETORNAR LA MAS RECIENTE TASA USURA
      *
           IF DB2-NOTFND
      *
              EXEC SQL
                   SELECT UGTIPINT
                   INTO :RFI-UGTIPINT
                   FROM UGDTRFI
                   WHERE UGIDXREF = :RFI-UGIDXREF AND
                         FECOVALI = (SELECT MAX(FECOVALI)
                                     FROM UGDTRFI
                                     WHERE UGIDXREF = :RFI-UGIDXREF)
              END-EXEC

              MOVE SQLCODE TO DB2-RETURN-CDE

              IF NOT DB2-OK
                 MOVE '99'        TO UGRAR-COD-RETORNO
                 MOVE 'UGDTRFI'   TO UGRAR-VAR1-ERROR
                 MOVE SQLCODE     TO UGRAR-SQLERRM
                 PERFORM 3000-FINAL-PROGRAMA
              END-IF
           ELSE
              IF NOT DB2-OK
                 MOVE '99'        TO UGRAR-COD-RETORNO
                 MOVE 'UGDTRFI'   TO UGRAR-VAR1-ERROR
                 MOVE SQLCODE     TO UGRAR-SQLERRM
                 PERFORM 3000-FINAL-PROGRAMA
              END-IF
           END-IF.
      *****************************************************************
      *                    2580-VALIDA-HIPOTECA                       *
      *   VALIDA LA DENOMINACION DEL SUBPRODUCTO HIPOTECARIO (UVR-COP)*
      *****************************************************************
       2580-VALIDA-HIPOTECA.

            MOVE CTE-96                     TO PRO-PRODUCTO
            MOVE UGRAR-SUBPROD              TO PRO-SUBPRO

            EXEC SQL
               SELECT LIBRE_CAR1
                 INTO: PRO-LIBRE-CAR1
               FROM  UGDTPRO
               WHERE  SUBPRO   = :PRO-SUBPRO   AND
                      PRODUCTO = :PRO-PRODUCTO
            END-EXEC

           MOVE SQLCODE                        TO DB2-RETURN-CDE
      *
           IF DB2-OK
                IF PRO-LIBRE-CAR1 = 'S'
                  SET WS-SI-UVR             TO TRUE
                ELSE
                  SET WS-NO-UVR             TO TRUE
                END-IF
              PERFORM 2585-VALIDA-VIS-NO-VIS
           ELSE
           IF DB2-NOTFND
			              MOVE '99'                 TO UGRAR-COD-RETORNO
                 MOVE 'UGDTPRO'            TO UGRAR-VAR1-ERROR
                 MOVE SQLCODE              TO UGRAR-SQLERRM
                 PERFORM 3000-FINAL-PROGRAMA
              ELSE
                 MOVE '99'        TO UGRAR-COD-RETORNO
                 MOVE 'UGDTPRO'   TO UGRAR-VAR1-ERROR
                 MOVE SQLCODE     TO UGRAR-SQLERRM
                 PERFORM 3000-FINAL-PROGRAMA
              END-IF
           END-IF.
      *****************************************************************
      *                   2585-VALIDA-VIS-NO-VIS                      *
      *          VALIDA SI EL SUBPRODUCTO ES VIS O NO VIS             *
      *****************************************************************
       2585-VALIDA-VIS-NO-VIS.

           INITIALIZE                         UGTCT37
           MOVE '1737'                        TO T37-SECCION
           MOVE 'PRODUC-96-'                  TO T37-ELEMENTO
           MOVE UGRAR-SUBPROD                 TO T37-ELEMENTO(11:4)

           EXEC SQL
               SELECT
                      SECCION ,
                      ELEMENTO,
                      RESTO
                 INTO
                      :T37-SECCION ,
                      :T37-ELEMENTO,
                      :T37-RESTO
                  FROM UGDTT37
                 WHERE SECCION    = :T37-SECCION
                   AND ELEMENTO   = :T37-ELEMENTO
           END-EXEC.
      *
           MOVE SQLCODE                       TO DB2-RETURN-CDE
      *
           IF DB2-OK
              IF T37-RESTO NOT = SPACES
                 SET WS-SI-VIS                TO TRUE
              ELSE
                 SET WS-NO-VIS                TO TRUE
              END-IF
           ELSE
              IF DB2-NOTFND
                 SET WS-NO-VIS                TO TRUE
              ELSE
                 MOVE '99'        TO UGRAR-COD-RETORNO
                 MOVE 'UGDTT37'   TO UGRAR-VAR1-ERROR
                 MOVE SQLCODE     TO UGRAR-SQLERRM
                 PERFORM 3000-FINAL-PROGRAMA
              END-IF
           END-IF.
      *****************************************************************
      *                   2590-CODIGO-USURA-HIP                       *
      *****************************************************************
       2590-CODIGO-USURA-HIP.
              IF WS-SI-UVR
                 IF WS-SI-VIS
      *CUANDO SEA UVR Y VIS
                    MOVE 'TUV' TO RFI-UGIDXREF
                 ELSE
      *CUANDO SEA UVR Y NO VIS
                    MOVE 'TLV' TO RFI-UGIDXREF
                 END-IF
              ELSE
                 IF WS-SI-VIS
      *CUANDO SEA COP Y VIS
                    MOVE 'TPV' TO RFI-UGIDXREF
                 ELSE
      *CUANDO SEA COP Y NO VIS
                    MOVE 'TPN' TO RFI-UGIDXREF
                 END-IF
              END-IF.
      *****************************************************************
      *                   2600-CALCULAR-UVR                           *
      *****************************************************************
       2600-CALCULAR-UVR.
           MOVE '1701'                        TO T37-SECCION

           EXEC SQL
               SELECT
                      SECCION ,
                      ELEMENTO,
                      RESTO
                 INTO
                      :T37-SECCION ,
                      :T37-ELEMENTO,
                      :T37-RESTO
                  FROM UGDTT37
                 WHERE SECCION    = :T37-SECCION
                   AND ELEMENTO   = :T37-ELEMENTO
           END-EXEC.
      *
           MOVE SQLCODE                       TO DB2-RETURN-CDE
           IF DB2-OK
              CONTINUE
           ELSE
              IF DB2-NOTFND
                 SET WS-NO-VIS                TO TRUE
              ELSE
                 MOVE '99'        TO UGRAR-COD-RETORNO
                 MOVE 'UGDTT37'   TO UGRAR-VAR1-ERROR
                 MOVE SQLCODE     TO UGRAR-SQLERRM
                 PERFORM 3000-FINAL-PROGRAMA
              END-IF
           END-IF.

      *COL02-F
      *COL03-I
      *----------------------------------------------------------------*
      * PARRAFO QUE SE ENCARGA DE BUSCAR EL CIFIN TABLA RVDTREG
      *----------------------------------------------------------------*
       23401-BUSCA-CIFIN.
      *
           EXEC SQL
                FETCH CURCIF
                INTO :RVREG-DATO-REGISTRO
           END-EXEC
      *
           EVALUATE SQLCODE
              WHEN ZEROS
                 IF RVREG-DATO-REGISTRO(17:3) = '001' THEN
                    IF RVREG-DATO-REGISTRO(134:4) = SPACES
                       OR RVREG-DATO-REGISTRO(134:1) IS NOT NUMERIC
                       MOVE 99999                  TO WS-NPROB-MORA-CFIN
                    ELSE
                       MOVE RVREG-DATO-REGISTRO(133:2)
                                                   TO WS-AUX-MORA(1:2)
                       MOVE RVREG-DATO-REGISTRO(136:2)
                                                   TO WS-AUX-MORA(4:2)
                       MOVE WS-AUX-MORA            TO WS-AUX-MORA-NUM
      *@COL04-I
      *                MOVE WS-AUX-MORA-NUM        TO WS-NPROB-MORA-CFIN
                       DIVIDE 100 INTO WS-AUX-MORA-NUM GIVING
                       WS-NPROB-MORA-CFIN
      *@COL04-F
                    END-IF
                 END-IF
              WHEN +100
                 SET SW-FIN-CUR                    TO TRUE
              WHEN OTHER
                 MOVE '99'                         TO UGRAR-COD-RETORNO
                 MOVE 'RVDTREG'                    TO UGRAR-VAR1-ERROR
                 MOVE SQLCODE                      TO UGRAR-SQLERRM
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *----------------------------------------------------------------*
      *                          OPEN CURSOR
      *----------------------------------------------------------------*
       23402-OPENC.
      *
           INITIALIZE RVTCREG
           MOVE '0'                         TO RVREG-LLAVE-TIP-ID(1:1)
           MOVE UGRAR-CODIDENT              TO RVREG-LLAVE-TIP-ID(2:1)
           MOVE UGRAR-CLAIDENT              TO RVREG-LLAVE-NUM-ID
           MOVE '5000'                      TO RVREG-TIPO-REGISTRO

           EXEC SQL
                OPEN CURCIF
           END-EXEC
      *
           EVALUATE SQLCODE
              WHEN ZEROS
                 CONTINUE
              WHEN OTHER
                 MOVE '99'                         TO UGRAR-COD-RETORNO
                 MOVE 'OPEN CURSIF'                TO UGRAR-VAR1-ERROR
                 MOVE SQLCODE                      TO UGRAR-SQLERRM
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *----------------------------------------------------------------*
      *                          CLOSE CURSOR
      *----------------------------------------------------------------*
       23404-CLOSEC.
      *
           EXEC SQL
                CLOSE CURCIF
           END-EXEC
      *
           EVALUATE SQLCODE
              WHEN ZEROS
                 CONTINUE
              WHEN OTHER
                 MOVE '99'                         TO UGRAR-COD-RETORNO
                 MOVE 'CLOSE CURCIF'               TO UGRAR-VAR1-ERROR
                 MOVE SQLCODE                      TO UGRAR-SQLERRM
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *COL03-F
      *----------------------------------------------------------------*
      *                   25301-VALIDA-SEGMENTO
      *----------------------------------------------------------------*
      *  ACCESO A LA RUTINA QUE RETORNA EL CODIGO DE COLECTIVO DEL     *
      *  CLIENTE.
      *----------------------------------------------------------------*
       25301-VALIDA-COLECTIVO.

           MOVE 'S1'                         TO WECLC-OPCION
           MOVE UGRAR-NUMCLIEN               TO WECLC-NUMCLIEN

           CALL WSC-PE9C0CLC USING AREA-PE9TCLC

           EVALUATE WSCLC-RETORNO
           WHEN '00'
              MOVE WSCLC-CODIGO-COL          TO WSV-RANGO-COL
           WHEN OTHER
              MOVE ZEROS                     TO WSV-RANGO-COL
           END-EVALUATE.
      *
      * COL05-I
      * -------------------------------------------------------------- *
       9999-TASA-PREFERENTE.
           PERFORM 2350-OBTENER-EDAD-CLIEN
           PERFORM 999-CLIENTES-CAP
           INITIALIZE UGWCNRA
           MOVE 'C'                 TO UGNRA-OPCION
           MOVE WSV-TIPO-PRODUCTO   TO UGNRA-PRODUCTO                   00077000
           SET WS-NO-UVR            TO TRUE
           PERFORM 2580-VALIDA-HIPOTECA
      *COL15-I
      *    IF WS-SI-UVR
      *       MOVE 'HU'               TO UGNRA-PRODUCTO
      *    END-IF
           IF (WSV-TIPO-PRODUCTO EQUAL 'H' OR
               WSV-TIPO-PRODUCTO EQUAL 'L')
              PERFORM 2580-VALIDA-HIPOTECA
              IF WSV-TIPO-PRODUCTO EQUAL 'H'
                 IF WS-SI-VIS
                    IF WS-SI-UVR
                       MOVE 'HA'            TO UGNRA-PRODUCTO
                    ELSE
                       MOVE 'HV'            TO UGNRA-PRODUCTO
                    END-IF
                 ELSE
                    IF WS-SI-UVR
                       MOVE 'HU'            TO UGNRA-PRODUCTO
                    ELSE
                       MOVE 'H'             TO UGNRA-PRODUCTO
                    END-IF
                 END-IF
              ELSE
                 IF WS-SI-VIS
                    IF WS-SI-UVR
                       MOVE 'LA'            TO UGNRA-PRODUCTO
                    ELSE
                       MOVE 'LV'            TO UGNRA-PRODUCTO
                    END-IF
                 ELSE
                    IF WS-SI-UVR
                       MOVE 'LB'            TO UGNRA-PRODUCTO
                    ELSE
                       MOVE 'L'             TO UGNRA-PRODUCTO
                    END-IF
                 END-IF
              END-IF
      *
              MOVE WSV-RANGO-ESTADO         TO UGNRA-ESTADO
      *
      *VALIDA SI ES INDEPENDIENTE Y PERTENECE A UN NICHO
              IF UGRAR-SITU-LABO = WSC-ALF-03
                 INITIALIZE WS-UMTA-SECCION
                            WS-UMTA-ELEMENTO
                            WS-UMTA-COD-RESP
                 STRING 'N-HX-' DELIMITED BY SIZE
                        UGRAR-PROFESION-ID DELIMITED BY SIZE
                 INTO WS-UMTA-ELEMENTO
                 END-STRING
      *
                 MOVE WSC-ALF-9639          TO WS-UMTA-SECCION
                 PERFORM 9999-PARAMETRIA-UMTA
      *
      *SI ENCUENTRA LA PROFESION SE INFORMA '06' EN UGRAR-SITU-LABO
                 IF WS-UMTA-COD-RESP = WS-OK
                    MOVE WSC-ALF-06         TO UGRAR-SITU-LABO
                 END-IF
              END-IF
      *
      *VALIDAR EL DESTINO DEL SUBPRODUCTO
              INITIALIZE WS-UMTA-SECCION
                         WS-UMTA-ELEMENTO
                         WS-UMTA-COD-RESP
              STRING 'S-' DELIMITED BY SIZE
                     UGRAR-SUBPROD DELIMITED BY SIZE
              INTO WS-UMTA-ELEMENTO
              END-STRING
      *
              MOVE WSC-ALF-9639          TO WS-UMTA-SECCION
              PERFORM 9999-PARAMETRIA-UMTA
      *
      *SI ENCUENTRA EL SUBPRODUCTO
              SET SW-NO-APLI-UMTA        TO TRUE
      *
              IF WS-UMTA-COD-RESP = WS-OK
                 SET SW-SI-APLI-UMTA     TO TRUE

                 MOVE UT37-RESTO(1:4)    TO WS-UMTA-DESCRIPCION-RAW
                 UNSTRING WS-UMTA-DESCRIPCION-RAW
                    DELIMITED BY ';'
                    INTO WS-DESTINO
                         WS-PROYECTO
                 END-UNSTRING
              END-IF
           END-IF
      *COL15-F
      *COL13-I
           IF SW-SI-CON-TASAV
              MOVE 'NV'               TO UGNRA-PRODUCTO
           END-IF
      *
           IF SW-SI-VEH-TASAV
              MOVE 'VV'               TO UGNRA-PRODUCTO
           END-IF
      *COL13-F
      *
      *COL16-I
           IF SW-SI-LIB-TASAV
              MOVE 'ZV'               TO UGNRA-PRODUCTO
           END-IF
      *COL16-F
           PERFORM 25302-VALIDA-SUBPRODUCTO
      *COL09-I
           IF WSV-TIPO-PRODUCTO EQUAL 'H'
             PERFORM 25304-CONSULTA-HS
             IF SW-SI-HIPOT-SOS
               MOVE 'HS'                    TO UGNRA-PRODUCTO
      *COL15-I
      *      ELSE
      *        IF WS-SI-VIS
      *          MOVE 'HV'                  TO UGNRA-PRODUCTO
      *        END-IF
      *COL15-F
             END-IF
           END-IF
      *COL09-F
           MOVE UGRAR-FECHA-PROCESO   TO UGNRA-FECHA                    00077000
           MOVE UGRAR-BURO            TO UGNRA-BURO                     00077000
           MOVE UGRAR-DOMI-NOMINA     TO UGNRA-NOMINA                   00077000
           MOVE UGRAR-SITU-LABO (2:1) TO UGNRA-SITLAB                   00082000
           MOVE WSV-RANGO-SMLV        TO UGNRA-INGRESOS                 00082000
           MOVE WSV-RANGO-MONTO       TO UGNRA-MONTO                    00082000
           MOVE UGRAR-PLAZO-CREDITO   TO UGNRA-PLAZO                    00082000
           MOVE WS-EDAD               TO UGNRA-EDAD                     00082000
           MOVE WSV-RANGO-SEG         TO UGNRA-SEGMENTO                 00082000
           MOVE WS-COLECTIVO          TO UGNRA-COLECTIVO                00082000
           MOVE WSV-NPROB-MORA-F      TO UGNRA-RIESGO                   00082000
           MOVE 'N'                   TO UGNRA-INDVIP                   00082000
           MOVE WSV-RANGO-PORCENTA    TO UGNRA-FINANCIA                 00082000
           MOVE WSV-RANGO-GAMA        TO UGNRA-GAMA                     00082000
      *COL08-I
           IF WSV-TIPO-PRODUCTO = 'Z'
              MOVE UGRAR-CLTVOLB      TO UGNRA-CLTVOLB
              MOVE UGRAR-DESTNLB      TO UGNRA-DESTNLB
           END-IF
      *COL08-I
           IF WSV-TIPO-PRODUCTO = 'V' AND
              WSV-RANGO-GAMA   NOT EQUAL ZEROS AND
              WSV-RANGO-ESTADO NOT EQUAL SPACES
              MOVE WSV-RANGO-ESTADO       TO UGNRA-ESTADO
              MOVE WSV-RANGO-GAMA         TO UGNRA-GAMA
              IF WSV-RANGO-TIPVEH(1:2)= 'PU'
                 MOVE 'S'                 TO UGNRA-TIPVEH
              ELSE
                 MOVE 'P'                 TO UGNRA-TIPVEH
              END-IF
           ELSE
              MOVE ZEROS                  TO UGNRA-GAMA
              MOVE SPACES                 TO UGNRA-TIPVEH
                                             UGNRA-ESTADO
           END-IF
      *COL10-I
      *COL12-I
      *    IF WSV-TIPO-PRODUCTO EQUAL 'H'
      *COL14-I
      *    IF WSV-TIPO-PRODUCTO EQUAL 'H' OR
      *       WSV-TIPO-PRODUCTO EQUAL 'L'
           IF (WSV-TIPO-PRODUCTO EQUAL 'H' OR
               WSV-TIPO-PRODUCTO EQUAL 'L') AND
               UGRAR-SEGMENTO    EQUAL CTE-1
      *COL14-F
      *COL12-F
              PERFORM 25305-CONSULTA-VID2
           END-IF
      *COL10-F
      *COL15-I
           IF (UGNRA-PRODUCTO(1:1) = 'H' OR
               UGNRA-PRODUCTO(1:1) = 'L') AND
               UGNRA-PRODUCTO NOT = 'HS'
              IF WS-UMTA-DESCRIPCION-RAW NOT = SPACES
                 EVALUATE WS-PROYECTO
                    WHEN 'NA'
                       MOVE 0               TO UGNRA-SEGMENTO
                    WHEN 'SI'
                       MOVE 1               TO UGNRA-SEGMENTO
                    WHEN 'NO'
                       MOVE 2               TO UGNRA-SEGMENTO
                 END-EVALUATE
                 MOVE WS-DESTINO            TO UGNRA-COLECTIVO
              END-IF
              MOVE WSV-RANGO-ESTADO      TO UGNRA-ESTADO
           END-IF
      *COL15-F
      *
           CALL 'UG7CCNRA' USING  REG-UGWCNRA


           EVALUATE UGNRA-COD-RETORNO
           WHEN '00'
                 MOVE UGNRA-TASA-RAR          TO WS-DESC-PROB
                 ADD UGNRA-TASA-RAR           TO WS-TOTAL-DESC
           WHEN OTHER
                 MOVE WSC-ALF-99              TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                 TO UGRAR-SQLERRM
                 MOVE 'NOVEDAD UG7CCNRA    '  TO UGRAR-VAR1-ERROR
                 MOVE UGNRA-VAR2-ERROR        TO UGRAR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE          TO UGRAR-SQLCODE
                 MOVE UGNRA-COD-RETORNO       TO UGRAR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *COL15-I
      ******************************************************************
      *                      9999-PARAMETRIA-UMTA                      *
      * CONSULTA PARAMETRIA DE PROFESION O SUBPRODUCTO EN LA UMTA      *
      * EN LA SECCION 9639                                             *
      ******************************************************************
       9999-PARAMETRIA-UMTA.
           INITIALIZE UGWCT370
           MOVE WS-UMTA-SECCION             TO UT37-SECCION
           MOVE WS-UMTA-ELEMENTO            TO UT37-ELEMENTO
      *
           CALL BBVA-UG9CT370 USING UGWCT370
      *
           EVALUATE UT37-COD-RESPUESTA
             WHEN WS-OK
               MOVE UT37-COD-RESPUESTA      TO WS-UMTA-COD-RESP
             WHEN WSC-ALF-20
               MOVE UT37-COD-RESPUESTA      TO WS-UMTA-COD-RESP
             WHEN OTHER
               MOVE UT37-COD-RESPUESTA      TO UGRAR-COD-RETORNO
               MOVE UT37-ERROR-UNO          TO UGRAR-VAR1-ERROR
               MOVE UT37-ERROR-DOS          TO UGRAR-VAR2-ERROR
               MOVE UT37-SQLCODE            TO UGRAR-SQLERRM
               PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *COL15-F
      * -------------------------------------------------------------- *
       999-CLIENTES-CAP.
           IF UGRAR-BURO            = SPACES
              MOVE '0000'           TO UGRAR-BURO
           END-IF
           IF UGRAR-DOMI-NOMINA     = SPACES
              MOVE 'N'              TO UGRAR-DOMI-NOMINA
           END-IF
           IF WSV-RANGO-SEG         = SPACES
              MOVE '99999'          TO WSV-RANGO-SEG
           END-IF
           IF WS-COLECTIVO          = SPACES
              MOVE '0000'           TO WS-COLECTIVO
           END-IF
           IF WSV-NPROB-MORA-F      = 00000
              MOVE 99999            TO WSV-NPROB-MORA-F
           END-IF.
      *
      * -------------------------------------------------------------- *
       9999-CONTROL-TASA.
      *COL08-I
      *    PERFORM 2560-OBT-TASAPOLI
           IF W-TASA-POLI-EXT NOT EQUAL ZERO
              MOVE W-TASA-POLI-EXT            TO W-TASA-POLI
           ELSE
              PERFORM 2560-OBT-TASAPOLI
           END-IF
      *COL08-F
           PERFORM 2570-OBT-TASA-USURA
           COMPUTE WS-TASA-USURA = WS-VARIACION + RFI-UGTIPINT
           MOVE WS-TASA-USURA               TO UGRAR-TASA-USURA
           MOVE 'V'              TO UGNRA-OPCION
           MOVE UGNRA-TASA-RAR   TO UGNRA-TASA-PREF
           MOVE W-TASA-POLI      TO UGNRA-TASA-POLI UGRAR-TASA-POLI
           MOVE UGRAR-TASA-USURA TO UGNRA-TASA-USURA
           MOVE WS-TASA-PISO     TO UGNRA-TASA-PISO

           CALL 'UG7CCNRA' USING  REG-UGWCNRA

           EVALUATE UGNRA-COD-RETORNO
           WHEN '00'
                  MOVE UGNRA-TASA-RAR          TO WS-DESCUENTO
                  MOVE WS-DESCUENTO            TO UGRAR-TOTAL-DESC
           WHEN OTHER
                 MOVE WSC-ALF-99              TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                 TO UGRAR-SQLERRM
                 MOVE 'NOV CTL TASA UG7CCNRA' TO UGRAR-VAR1-ERROR
                 MOVE UGNRA-VAR2-ERROR        TO UGRAR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE          TO UGRAR-SQLCODE
                 MOVE UGNRA-COD-RETORNO       TO UGRAR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *----------------------------------------------------------------*
      *                   25302-VALIDA-SUBPRODUCTO
      *----------------------------------------------------------------*
      *  ACCESO A LA RUTINA QUE RETORNA EL CODIGO DE COLECTIVO DEL     *
      *  CLIENTE.
      *----------------------------------------------------------------*
       25302-VALIDA-SUBPRODUCTO.

           INITIALIZE UGTCT37
           MOVE '9931'                        TO T37-SECCION
           MOVE UGRAR-SUBPROD                 TO T37-ELEMENTO(1:4)
      *
             EXEC SQL
                 SELECT RESTO
                   INTO :T37-RESTO
                   FROM UGDTT37
                  WHERE SECCION  = :T37-SECCION
                    AND ELEMENTO   = :T37-ELEMENTO
             END-EXEC
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE
      *
           IF DB2-OK AND SQLWARN0 = SPACES
              EVALUATE WSV-TIPO-PRODUCTO
                 WHEN 'N'
                       MOVE 'NC'               TO UGNRA-PRODUCTO
      *COL13-I
                       IF SW-SI-CON-TASAV
                          MOVE 'NK'            TO UGNRA-PRODUCTO
                       END-IF
      *COL13-F
                 WHEN 'V'
                       MOVE 'VC'               TO UGNRA-PRODUCTO
      *COL13-I
                       IF SW-SI-VEH-TASAV
                          MOVE 'VK'            TO UGNRA-PRODUCTO
                       END-IF
      *COL13-F
                 WHEN 'H'
                       IF WS-SI-UVR
                         MOVE 'HK'             TO UGNRA-PRODUCTO
                       ELSE
                         MOVE 'HC'             TO UGNRA-PRODUCTO
                       END-IF
              END-EVALUATE
           ELSE
              IF DB2-NOTFND AND SQLWARN0 = SPACES
                 SET SW-SI-SUBPRO-X           TO TRUE
              ELSE
                 MOVE WSC-ALF-99              TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                 TO UGRAR-SQLERRM
                 MOVE 'UGDTT37'               TO UGRAR-VAR1-ERROR
                 MOVE 'VAL TIPO CARTERA'      TO UGRAR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE          TO UGRAR-SQLCODE
                 MOVE UGNRA-COD-RETORNO       TO UGRAR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
              END-IF
           END-IF.
      *COL05-F
      *COL09-I
      *----------------------------------------------------------------*
      *                   25304-CONSULTA-HS
      *----------------------------------------------------------------*
      *  ACCESO A LA RUTINA UR2CIT37 PARA CONSULTAR SI EL SUBPRODUCTO  *
      *  CORRESPONDE A UN CREDITO HIPOTECARIO SOSTENIBLE
      *----------------------------------------------------------------*
       25304-CONSULTA-HS.
      *
           SET SW-NO-HIPOT-SOS              TO TRUE
           INITIALIZE UGTCT37
           MOVE WSC-ALF-5011                  TO T37-SECCION
           MOVE UGRAR-SUBPROD                 TO T37-ELEMENTO(1:4)
      *
             EXEC SQL
                 SELECT RESTO
                   INTO :T37-RESTO
                   FROM UGDTT37
                  WHERE SECCION  = :T37-SECCION
                    AND ELEMENTO   = :T37-ELEMENTO
             END-EXEC
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE
      *
           IF DB2-OK AND SQLWARN0 = SPACES
             SET SW-SI-HIPOT-SOS               TO TRUE
           ELSE
              IF DB2-NOTFND AND SQLWARN0 = SPACES
                SET SW-NO-HIPOT-SOS            TO TRUE
              ELSE
                 MOVE WSC-ALF-99               TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                  TO UGRAR-SQLERRM
                 MOVE 'UGDTT37'                TO UGRAR-VAR1-ERROR
                 MOVE 'SECCION '               TO UGRAR-VAR2-ERROR(1:08)
                 MOVE IT37-SECCION             TO UGRAR-VAR2-ERROR(9:04)
                 MOVE IT37-SQLCODE             TO UGRAR-SQLCODE
                 MOVE UGRAR-SQLCODE            TO UGRAR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
              END-IF
           END-IF.
      *COL09-F
      *COL10-I
      *----------------------------------------------------------------*
      *                   25305-CONSULTA-VID2
      *----------------------------------------------------------------*
      *  ACCESO A LA TABLA  RVDTVID  PARA CONSULTAR EL BURO            *
      *----------------------------------------------------------------*
       25305-CONSULTA-VID2.
      *
           MOVE 'C'            TO UGRVI-OPCION
           MOVE UGRAR-CODIDENT TO UGRVI-CODIDENT
           MOVE UGRAR-CLAIDENT TO UGRVI-CLAIDENT
           CALL 'RV7CRVID' USING  REG-UGWCRVI
      *
           EVALUATE UGRVI-COD-RETORNO
           WHEN '00'
      *COL17-I
      *          MOVE UGRVI-BURO              TO UGRAR-BURO
      *          MOVE UGRVI-BURO              TO UGNRA-BURO
      *COL17-F
                 MOVE UGRVI-SITULAB           TO UGNRA-SITLAB
      *COL12-I
                 MOVE UGRVI-INGRESOS          TO WSV-INGRESOS-FIJ
                 MOVE UGRVI-INGRESOS-VAR      TO WSV-INGRESOS-VAR
                 PERFORM 2331-BUSCAR-SMLV
                 PERFORM 2332-CALCULAR-SMLV
                 MOVE WSV-RANGO-SMLV          TO UGNRA-INGRESOS
      *COL12-F
           WHEN OTHER
                 MOVE WSC-ALF-99              TO UGRAR-COD-RETORNO
                 MOVE SQLERRM                 TO UGRAR-SQLERRM
                 MOVE UGRVI-VAR2-ERROR        TO UGRAR-VAR1-ERROR
                 MOVE UGRVI-VAR2-ERROR        TO UGRAR-VAR2-ERROR(1:16)
                 MOVE UGRVI-SQLCODE           TO UGRAR-SQLCODE
                 MOVE UGRVI-COD-RETORNO       TO UGRAR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *COL10-F
      *COL11-I
      ******************************************************************
      *                      LLAMA-RUTINA-UG9CT370                     *
      * LLAMA A LA RUTINA UG9CT370 PARA SABER SI LOS SUBPRODUCTOS CON  *
      * LOS QUE SE ESTAN HACIENDO LA SIMULACION SON DE CREDITO VIRTUAL *
      ******************************************************************
       LLAMA-RUTINA-UG9CT370.
      *
           INITIALIZE UGWCT370
           SET SW-CREDITOVIRTUAL-NO         TO TRUE
           MOVE '9101'                      TO UT37-SECCION
           MOVE '%'                         TO UT37-ELEMENTO(01:01)
           MOVE UGRAR-SUBPROD               TO UT37-ELEMENTO(02:04)
      *
           CALL BBVA-UG9CT370 USING UGWCT370
      *
           EVALUATE UT37-COD-RESPUESTA
             WHEN WS-OK
               SET SW-CREDITOVIRTUAL-SI  TO TRUE
             WHEN WSC-ALF-20
               SET SW-CREDITOVIRTUAL-NO  TO TRUE
             WHEN OTHER
               MOVE UT37-COD-RESPUESTA      TO UGRAR-COD-RETORNO
               MOVE UT37-ERROR-UNO          TO UGRAR-VAR1-ERROR
               MOVE UT37-ERROR-DOS          TO UGRAR-VAR2-ERROR
               MOVE UT37-SQLCODE            TO UGRAR-SQLERRM
               PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE
           .
      *
      ******************************************************************
      *                       CONSULTA-LQS-102                         *
      * SE REALIZA UN SELECT EN LA TABLA UGDTLQS POR EL SUBPRODUCTO Y  *
      * EL TRAMO 101 PARA OBTENER LA TASA POLITICA DEL SUBPRODUCTO QUE *
      * ES EL CAMPO LQS-TIPOAPLI EN LA TABLA Y MOVERLO A VARIABLE DE   *
      * TASA EFECTIVA                                                  *
      ******************************************************************
       CONSULTA-LQS-102.
           INITIALIZE UGTCLQS
                      WS-EFECTIVA-CV
           MOVE UGRAR-FECHA-PROCESO          TO LQS-FECOVALI
           MOVE '102'                        TO LQS-CODCONLI
           MOVE UGRAR-SUBPROD                TO LQS-SUBPRO
           MOVE CTE-96                       TO LQS-PRODUCTO

           EXEC SQL
              SELECT  TIPOAPLI
                INTO :LQS-TIPOAPLI
                FROM  UGDTLQS
              WHERE PRODUCTO  = :LQS-PRODUCTO
                AND SUBPRO    = :LQS-SUBPRO
                AND CODCONLI  = :LQS-CODCONLI
                AND FECOVALI <= :LQS-FECOVALI
                AND FEFIVALI >= :LQS-FECOVALI
           END-EXEC

           MOVE SQLCODE                      TO DB2-RETURN-CDE

           IF DB2-OK AND SQLWARN0 = SPACES
              MOVE LQS-TIPOAPLI              TO WS-EFECTIVA-CV
              MOVE WS-EFECTIVA-CV            TO W-TASA-POLI
           ELSE
             IF DB2-NOTFND AND SQLWARN0 = SPACES
                MOVE '90'                    TO UGRAR-COD-RETORNO
                MOVE 'REGISTRO NO ENCONTRA'  TO UGRAR-VAR1-ERROR
                MOVE 'DO SELECT UGDTLQS   '  TO UGRAR-VAR2-ERROR
                MOVE SQLCODE                 TO UGRAR-SQLERRM
                PERFORM 3000-FINAL-PROGRAMA
             ELSE
                MOVE '99'                    TO UGRAR-COD-RETORNO
                MOVE 'ERROR SELECT UGDTLQS'  TO UGRAR-VAR1-ERROR
                MOVE SQLCODE                 TO UGRAR-SQLERRM
                PERFORM 3000-FINAL-PROGRAMA
             END-IF
           END-IF
           .
      *COL11-F
      *COL12-I
      ******************************************************************
      *                     2332-CALCULAR-SMLV *
      ******************************************************************
       2332-CALCULAR-SMLV.

            MOVE 0                            TO WSV-RANGO-SMLV
            MOVE 0                            TO WSV-SUMA-INGRESOS

            COMPUTE WSV-SUMA-INGRESOS = WSV-INGRESOS-FIJ  +
                                        WSV-INGRESOS-VAR
            COMPUTE WSV-RANGO-SMLV    = WSV-SUMA-INGRESOS /
                                        WSV-SALARIO-MINIMO.
      *COL12-F
      *COL13-I
      ******************************************************************
      *                      2221-VALIDAR-TASA-VARIABLE                *
      * SE VERIFICA SI EL SUBPRODUCTO CORRESPONDE A CONSUMO O VEHICULO *
      * CUOTA FIJA TASA VARIABLE                                       *
      ******************************************************************
       2221-VALIDAR-TASA-VARIABLE.
      *
           INITIALIZE UGWCT370
           SET SW-NO-VEH-TASAV              TO TRUE
           SET SW-NO-CON-TASAV              TO TRUE
           MOVE WSC-ALF-0028                TO UT37-SECCION
           MOVE UGRAR-SUBPROD               TO UT37-ELEMENTO(01:04)
      *
           CALL BBVA-UG9CT370 USING UGWCT370
      *
           EVALUATE UT37-COD-RESPUESTA
             WHEN WS-OK
               EVALUATE WSV-TIPO-PRODUCTO
                  WHEN 'N'
                    SET SW-SI-CON-TASAV     TO TRUE
                  WHEN 'V'
                    SET SW-SI-VEH-TASAV     TO TRUE
      *COL16-I
                  WHEN 'Z'
                    SET SW-SI-LIB-TASAV     TO TRUE
      *COL16-F
               END-EVALUATE
             WHEN WSC-ALF-20
               SET SW-NO-VEH-TASAV          TO TRUE
               SET SW-NO-CON-TASAV          TO TRUE
      *COL16-I
               SET SW-NO-LIB-TASAV          TO TRUE
      *COL16-F
             WHEN OTHER
               MOVE UT37-COD-RESPUESTA      TO UGRAR-COD-RETORNO
               MOVE UT37-ERROR-UNO          TO UGRAR-VAR1-ERROR
               MOVE UT37-ERROR-DOS          TO UGRAR-VAR2-ERROR
               MOVE UT37-SQLCODE            TO UGRAR-SQLERRM
               PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      ******************************************************************
      *                         2561-TASA-IBR                          *
      * CONSULTA EL VALOR DE LA COTIZACION DEL REFERENCIAL ASOCIADO AL *
      * SUBPRODUCTO                                                    *
      ******************************************************************
       2561-TASA-IBR.

             INITIALIZE BRECOF1
             MOVE ZEROS TO WS-TASA-NOM

             PERFORM 2562-BUSCAR-ADMON-ESTA
             IF ADS-CODTIPRE(1:2) = 'IB'
                PERFORM 2563-OBT-COEFICIENTE

                MOVE WS-COEFICI           TO COF1-COEFICI
                MOVE UGRAR-FECHA-PROCESO  TO COF1-FECBUS
                MOVE '2'                  TO COF1-OPCION
                MOVE 'O'                  TO COF1-INVOCO

                CALL RUT-BR8CCOF1 USING BRECOF1

                IF COF1-RETORNO = '00'
                   ADD LQS-TIPOAPLI COF1-VALOR GIVING WS-TASA-NOM
                   PERFORM 2564-CALCULAR-DIAS
                ELSE
                   IF COF1-RETORNO = '88'
                      MOVE '30'             TO UGRAR-COD-RETORNO
                      MOVE COF1-DESERR      TO UGRAR-VAR1-ERROR
                      MOVE 'RUT BR8CCOF1'   TO UGRAR-VAR2-ERROR(1:14)
                      MOVE COF1-RETORNO     TO UGRAR-VAR2-ERROR(15:)
                      PERFORM 3000-FINAL-PROGRAMA
                   ELSE
                      MOVE WSC-ALF-99       TO UGRAR-COD-RETORNO
                      MOVE COF1-DESERR      TO UGRAR-VAR1-ERROR
                      MOVE WS-CODTIPRE      TO UGRAR-VAR2-ERROR(1:3)
                      MOVE COF1-FECBUS      TO UGRAR-VAR2-ERROR(4:10)
                      MOVE COF1-SQLCODE     TO UGRAR-VAR2-ERROR(15:)
                      PERFORM 3000-FINAL-PROGRAMA
                   END-IF
                END-IF
             ELSE
                MOVE WSC-ALF-99             TO UGRAR-COD-RETORNO
                MOVE 'REFERENCIAL '         TO UGRAR-VAR1-ERROR(1:12)
                MOVE ADS-CODTIPRE           TO UGRAR-VAR1-ERROR(13:4)
                MOVE 'NO DISPONIBLE'        TO UGRAR-VAR2-ERROR
                PERFORM 3000-FINAL-PROGRAMA
             END-IF.
      ******************************************************************
      *                          2563-OBT-COEFICIENTE                  *
      * HOMOLOGA REFERENCIAL PARA POSTERIOR BUSQUEDA DE VLR COTIZACION *
      ******************************************************************
       2563-OBT-COEFICIENTE.

           INITIALIZE UGWCT370
           MOVE WSC-ALF-0542                TO UT37-SECCION
           MOVE ADS-CODTIPRE(1:3)           TO UT37-ELEMENTO(01:03)

           CALL BBVA-UG9CT370 USING UGWCT370

           EVALUATE UT37-COD-RESPUESTA
             WHEN WS-OK
               MOVE UT37-RESTO(1:4)         TO WS-COEFICI
             WHEN WSC-ALF-20
               MOVE UT37-COD-RESPUESTA      TO UGRAR-COD-RETORNO
               MOVE 'SIN HOMOLOGO: '        TO UGRAR-VAR1-ERROR(1:14)
               MOVE ADS-CODTIPRE(1:3)       TO UGRAR-VAR1-ERROR(15:3)
               MOVE UT37-ERROR-DOS          TO UGRAR-VAR2-ERROR
               MOVE UT37-SQLCODE            TO UGRAR-SQLERRM
               PERFORM 3000-FINAL-PROGRAMA
             WHEN OTHER
               MOVE UT37-COD-RESPUESTA      TO UGRAR-COD-RETORNO
               MOVE UT37-ERROR-DOS          TO UGRAR-VAR1-ERROR
               MOVE UT37-ERROR-UNO          TO UGRAR-VAR2-ERROR
               MOVE UT37-SQLCODE            TO UGRAR-SQLERRM
               PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      ******************************************************************00069000
      *               232-BUSCAR-ADMON-ESTA                            *00069200
      *  OBTENEMOS LAS CONDICIONES DE ADMINISTRACION DEL SUBPRODUCTO   *00069400
      ******************************************************************00069600
       2562-BUSCAR-ADMON-ESTA.                                          00069700
      *                                                                 00069800
           INITIALIZE UGTCADS
           MOVE CTE-96               TO ADS-PRODUCTO                    00070100
           MOVE UGRAR-SUBPROD        TO ADS-SUBPRO                      00070200
           MOVE UGRAR-FECHA-PROCESO  TO ADS-FECOVALI                    00070300
      *                                                                 00070400
           EXEC SQL                                                     00070500
               SELECT  CODTIPRE,                                        00070600
                       PERINT,
                       DIASCAL,
                       TIPODIAS
                 INTO :ADS-CODTIPRE,                                    00071200
                      :ADS-PERINT,
                      :ADS-DIASCAL,
                      :ADS-TIPODIAS
                 FROM  UGDTADS                                          00071800
                WHERE  PRODUCTO  = :ADS-PRODUCTO     AND                00071900
                       SUBPRO    = :ADS-SUBPRO       AND                00072000
                       FECOVALI <= :ADS-FECOVALI     AND                00072100
                       FEFIVALI >= :ADS-FECOVALI                        00072200
           END-EXEC                                                     00072300
      *                                                                 00072400
           MOVE SQLCODE            TO DB2-RETURN-CDE                    00072500
           IF DB2-OK                                                    00072600
              CONTINUE                                                  00072700
           ELSE
             IF DB2-NOTFND AND SQLWARN0 = SPACES
                MOVE '90'                   TO UGRAR-COD-RETORNO
                MOVE 'SIN COND ADMON ADS'   TO UGRAR-VAR1-ERROR
                MOVE ADS-SUBPRO             TO UGRAR-VAR2-ERROR(01:04)
                MOVE '-'                    TO UGRAR-VAR2-ERROR(05:01)
                MOVE ADS-FECOVALI           TO UGRAR-VAR2-ERROR(06:10)
                MOVE SQLCODE                TO UGRAR-SQLERRM
                PERFORM 3000-FINAL-PROGRAMA
             ELSE
                MOVE '99'                   TO UGRAR-COD-RETORNO
                MOVE 'ERROR ACCESO DB2 ADS' TO UGRAR-VAR1-ERROR
                MOVE 'VALIDAR COD RETORNO ' TO UGRAR-VAR2-ERROR
                MOVE SQLCODE                TO UGRAR-SQLERRM
                PERFORM 3000-FINAL-PROGRAMA
             END-IF
           END-IF.
      ******************************************************************
      * REALIZA CONVERSION DE TASA NOMINAL A EFECTIVA PARA CASOS DE    *
      * SUBPRODUCTOS CUOTA FIJA TASA VARIABLE                          *
      ******************************************************************
       2566-INTERES-NOMINAL.

           INITIALIZE URWCCVR
           MOVE 'DTF'                     TO CVT-TIPO-TASA
           MOVE 'S'                       TO CVT-IND-CONV
           MOVE ZEROS                     TO CVT-PUNTOS
           MOVE WS-TASA-NOM               TO CVT-TASA
           MOVE ADS-PERINT                TO CVT-PERINT
           MOVE UGRAR-PLAZO-CREDITO       TO CVT-PLAZO
           MOVE 'E'                       TO CVT-RESULTADO

           MOVE ADS-DIASCAL               TO CVT-MSG(1:1)
           MOVE WS-DIAS-IBR               TO CVT-MSG(2:5)
           MOVE DF3-ANO-INICIAL(3:2)      TO CVT-MSG(7:2)

           CALL BBVA-UR8CCVT0
                              USING URWCCVR

           IF CVT-COD-ERROR EQUAL ZEROS
              MOVE CVT-EFECTIVA           TO W-TASA-POLI
           ELSE
              MOVE CVT-COD-ERROR          TO UGRAR-COD-RETORNO
              MOVE 'ER CAL EFE'           TO UGRAR-VAR1-ERROR
              MOVE CVT-MSG(1:10)          TO UGRAR-VAR1-ERROR(11:10)
              MOVE CVT-MSG(11:20)         TO UGRAR-VAR2-ERROR
              PERFORM 3000-FINAL-PROGRAMA
           END-IF.
      ******************************************************************
      *                      2564-CALCULAR-DIAS                        *
      ******************************************************************
       2564-CALCULAR-DIAS.

           INITIALIZE TCWC1750
           PERFORM 2565-OBT-FIN-PER
           MOVE DF3-DIA-INICIAL             TO WS-FEC-DD
           MOVE DF3-MES-INICIAL             TO WS-FEC-MM
           MOVE DF3-ANO-INICIAL             TO WS-FEC-AAAA
           MOVE WS-FEC-DD-MM-AAAA           TO W175-FHGRE2
      *
           MOVE DF3-DIA-FINAL               TO WS-FEC-DD
           MOVE DF3-MES-FINAL               TO WS-FEC-MM
           MOVE DF3-ANO-FINAL               TO WS-FEC-AAAA
           MOVE WS-FEC-DD-MM-AAAA           TO W175-FHGRE1
           MOVE ZEROS                       TO W175-NUMDIAS
           MOVE CTE-CON-3                   TO W175-CDOPCIO

           IF ADS-DIASCAL = 'C'
              MOVE 'CO'                     TO W175-TPTRAT
           ELSE
              MOVE 'NA'                     TO W175-TPTRAT
           END-IF

           CALL CON-TC8C1220 USING TCWC1750

           EVALUATE W175-CDRETORN
             WHEN '00'
                MOVE W175-NUMDIAS           TO WS-DIAS-IBR
                PERFORM 2566-INTERES-NOMINAL
             WHEN '10'
                MOVE W175-CDRETORN          TO UGRAR-COD-RETORNO
                MOVE 'FECHA NO LOGICA     ' TO UGRAR-VAR1-ERROR
                MOVE W175-FHGRE1            TO UGRAR-VAR2-ERROR(01:08)
                MOVE '-'                    TO UGRAR-VAR2-ERROR(09:01)
                MOVE W175-FHGRE2            TO UGRAR-VAR2-ERROR(10:08)
                PERFORM 3000-FINAL-PROGRAMA
             WHEN '20'
                MOVE W175-CDRETORN          TO UGRAR-COD-RETORNO
                MOVE 'ERROR EN DIFERENCIA ' TO UGRAR-VAR1-ERROR
                MOVE 'DE DIAS - TASA VAR  ' TO UGRAR-VAR2-ERROR
                PERFORM 3000-FINAL-PROGRAMA
             WHEN OTHER
                MOVE W175-CDRETORN          TO UGRAR-COD-RETORNO
                MOVE 'ERR. DATOS ERRADOS  ' TO UGRAR-VAR1-ERROR
                MOVE 'EN RUTINA TC8C1220  ' TO UGRAR-VAR2-ERROR
                PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      ******************************************************************
      *                          2565-OBT-FIN-PER                      *
      *                  SE OBTIENE LA FECHA FIN DEL PERIODO           *
      ******************************************************************
       2565-OBT-FIN-PER.

             INITIALIZE URECRES URECDF3
             MOVE UGRAR-FECHA-PROCESO        TO DF3-FECHA-INICIAL
             MOVE UGRAR-FECHA-PROCESO(9:2)   TO DF3-DIA
             MOVE ADS-PERINT                 TO DF3-PERCAP
             MOVE +1                         TO DF3-NUM-PERIODOS
             MOVE ADS-TIPODIAS               TO DF3-TIPODIAS

             CALL  BBVA-UR8CDFP0  USING  URECRES
                                         URECDF3
      *
             IF RES-CORESPUE = '10'
                CONTINUE
             ELSE
                MOVE RES-CORESPUE            TO UGRAR-COD-RETORNO
                MOVE 'ERR. CALCULO PERIODO'  TO UGRAR-VAR1-ERROR
                MOVE 'RUT. UR8CDFP0: '       TO UGRAR-VAR2-ERROR(1:15)
                MOVE RES-CORESPUE            TO UGRAR-VAR2-ERROR(16:2)
                PERFORM 3000-FINAL-PROGRAMA
             END-IF.
      *COL13-F