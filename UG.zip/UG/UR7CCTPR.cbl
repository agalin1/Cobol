      *  UR7CCTPR: RUTINA QUE CALCULA EL DESCUENTO EN LA TASA E.A.
      * ***************************************************************
      *                          B B V A                               *
      *                     C O L O M B I A                            *
      ******************************************************************
       IDENTIFICATION DIVISION.
      *
       PROGRAM-ID.   UR7CCTPR.
       AUTHOR.       GLOKAL CONSULTING
       DATE-WRITTEN. 23/10/2012.
       DATE-COMPILED.
      *
      ******************************************************************
      *           L O G    D E   M O D I F I C A C I O N E S           *
      ******************************************************************
      *   AUTOR    FECHA             DESCRIPCION                       *
      * -------- -------- -------------------------------------------- *
      * @COL01   14092013 SE AJUSTA VALOR DE PROBABILIDAD DE MORA Y SE *
      *                   REGISTRAN TODOS LOS PUNTAJES EN LA UGDTLOG   *
      *----------------------------------------------------------------*
      *   AJOE   01/08/13    GP9226 - MARCACION DE CLIENTES PREMIUM.   *
      *----------------------------------------------------------------*
      *   AJOE1  25/11/16 GP13870 - CREACION DEL NUEVO SEGMENTO BANCA  *
      *                   PERSONAL ESPECIAL.                           *
      *----------------------------------------------------------------*
      * @COL02   08082015 SE AJUSTA PARA INCLUIR NUEVAS VARIABLES PARA *
      * EFRON             EL CALCULO DE LA RAR, SE ALMACENAN EN NUEVAS *
      * GP10992           TABLAS UGDTRAR Y UGDTRVE
      * CE33513           NO SE ACTUALIZAR LAS TABLAS UGDTRVE YUGDTRAL *
      *                   SI EL CONTRATO TIENE RELACION ENLA TABLA     *
      *                   UGDTREL (RESTRUCTURADOS)                     *
      ******************************************************************
      * EFRON    0806217  SE AJUSTA POR INCIDENCIA COL591517I856351    *
      * COL03             PARA SELECCIONAR EL PRIMER REGISTRO DE LAS   *
      *                   TABLAS UGDTRAR Y UGDTRVE - GP10992           *
      ******************************************************************
      * COL04    20022018 SE ADICIONAN DOS NUEVAS VARIABLES A LA RUTINA*
      * GFI               RAR_EDAD Y RAR_SITU_LABO PARA EL CALCULO DE  *
      * COLOMBIA          LA TASA RAR.                                 *
      *                   AJUSTE ALCANCE SIGNADO PARAMETRIA.           *
      *                   GP16016-AJUSTE MODELO RAR INCLUSION NUEVAS   *
      *                   VARIABLES GESI COL472318S616235              *
      ******************************************************************
      * COL05    26072021 SE AJUSTA PARA INCLUIR RUTINA UG7CCNRA POR   *
      * C805385           CAMBIO DEL CONSULTA DE LA TASARAR            *
      *                   GP17916 CCSS-6856                            *
      ******************************************************************
      * COL06    07/02/2022   AJUSTE PARA INCLUIR VARIABLE COLECTIVO Y *
      * CE56375               DESTINO PRICING LIBRANZA                 *
      * SCRUM - SDA36560 - COLWSPREST-54 - COLWSPREST-383 OTORGAR TASAS*
      * PERSONALIZADAS LIBRANZAS                                       *
      ******************************************************************
      * COL07    10032022 SE AJUSTA PARA INCLUIR TIPO-OPERACION HV(HIPO*
      * C810846           TECARIO VIS) Y HS(HIPOTECARIO SOSTENIBLE)    *
      *                   PRICING HIPOTECARIO. CCSS-13169.             *
      ******************************************************************
      * @COL08        2022-05-06  AJUSTE POR INCIDENCIA INDICADOR DOMI-*
      * C810846                   CILIACION DE NOMINA. MN-1855.        *
      ******************************************************************
      * @COL09        2022-08-03  AJUSTE PARA TOMAR PARA LIBRANZAS LOS-*
      * C810846                   INGRESOS CAP DE DESCUENTO PARA EL    *
      *                           CALCULO DE LA TASA PERSONALIZADA     *
      *                           MN-2124                              *
      ******************************************************************
      * @COL10        2022-10-04  AJUSTE PARA TOMAR PARA LIBRANZA DIGI-*
      * C810846                   TAL LOS INGRESOS CAP DESCUENTO ENVIA-*
      *                           DOS DESDE EL SCORING                 *
      * GLADIADORES            COLWSCANAL-5869-PRICING LIBRANZA DIGITAL*
      ******************************************************************
      * COL11     06-06-2023                                    A DIGI-*
      * CE59519   INETUM   REPORTERIA DE CONTRATOS QUE APLICARON ENVIA-*
      *                    TASA RAR POR CANAL DE SOLICITUD             *
      * SCRUM - SDA36560 - PLAN REPORTERIA TASA RAR-COLWSPREST-15693   *
      ******************************************************************
      *_______________________________________________________________*
      *                   LOG DE MODIFICACIONES
      *_______________________________________________________________*
      * CODIGO  AUTOR   FECHA       DESCRIPCION                       *
      * ------- ------- ----------  ----------------------------------*
      * C804405 JNSS    09/10/2023  RECOMPILACION CON DIVISION DE DCL *
      * REALIZO  : BBVA-COLOMBIA                                      *
      * MARCA    : COL12                                              *
      * PROYECTO : DEPURACION DE PRESTAMOS                            *
      * FEATURE  : COLWSMANTE-184  VL                                 *
      * ENABLER  : COLWSMANTE-184                                     *
      * HUQA     : COLWSMANTE-334                                     *
      *_______________________________________________________________*
      * REFERENCIA : COL13                                            *
      * REALIZO    : BBVA - CFFP                                      *
      * FECHA      : 10/09/2024                                       *
      * SDA-FEATURE: SDA-41748 / COLONECAPN-38                        *
      * DESCRIPCION: CUOTA FIJA - TASA VARIABLE PARA CREDITOS DE      *
      * METODOLOGIA  CONSUMO Y VEHICULO                               *
      * TRADICIONAL  VALIDACION PARA NUEVOS CLUSTER DE TASA VARIABLE  *
      *              EN PRODUCTOS DE CONSUMO - VEHICULO               *
      *_______________________________________________________________*
      * REFERENCIA : COL14                                            *
      * REALIZO    : RUBEN DAVID GUTIERREZ.                           *
      * FECHA      : 03/03/2026                                       *
      * SDA/FEATURE: SDA-56033 / COLONEPRE1-17054                     *
      * DESCRIPCION: SE AJUSTA LA RUTINA PARA INCLUIR EL MANEJO DE    *
      *              LAS NUEVAS LINEAS Y VARIABLES DE CREDITOS        *
      *              HIPOTECARIOS, INCLUYENDO LA NUEVA VARIABLE DE    *
      *              PROFESION.                                       *
      *_______________________________________________________________*
      * REFERENCIA : COL15                                            *
      * REALIZO    : JAYSON GABRIEL PINILLA SUAREZ - INETUM (T059363) *
      * FECHA      : 21/05/2026                                       *
      * SDA/FEATURE: SDA-55492 / COLONEPRE1-20877                     *
      * DESCRIPCION: SE AJUSTA LA RUTINA PARA INCLUIR EL MANEJO DE    *
      *              LAS NUEVAS LINEAS Y VARIABLES DE CREDITOS        *
      *              LIBRANZAS - TASA VARIABLE                        *
      *_______________________________________________________________*
      * REFERENCIA : COL15A                                           *
      * REALIZO    : INDRA - CE64919.                                 *
      * FECHA      : 23/03/2026                                       *
      * SDA/FEATURE: COLONENUE1-966                                   *
      * DESCRIPCION: SE AJUSTA LA RUTINA PARA VALIDAR QUE EL CAMPO    *
      *              PMT01-S-SEGMENTO TENGA VALORES NUMERICOS Y ASI   *
      *              EVITAR LOS  WARNINGS.                            *
      *_______________________________________________________________*
      * REFERENCIA : COL16                                            *
      * REALIZO    : O019015    GUSTAVO PAREDES GONZALEZ              *
      * FECHA      : 28/07/2026                                       *
      * SDA/FEATURE: COLONEPRE1-24113                                 *
      * DESCRIPCION: SE AJUSTA LA RUTINA CON EL FIN DE IDENTIFICAR EL *
      *              SUBPRODUCTO CORRESPONDIENTE A LA LINEA DE LEASING*
      *              REMODELACION Y CLASIFICARLO COMO 'L' LEASING     *
      *_______________________________________________________________*
           EJECT
      ******************************************************************
      *       E N V I R O N M E N T    D I V I S I O N                 *
      ******************************************************************
       ENVIRONMENT DIVISION.
      *
      ******************************************************************
      *                   D A T A      D I V I S I O N                 *
      ******************************************************************
       DATA DIVISION.
      *
       WORKING-STORAGE SECTION.
      *
      ******************************************************************
      *       MARCA DE COMIENZO DE LA WORKING STORAGE                  *
      ******************************************************************
      *
       01  LT-INICIO-DE-WS.
           05  LT-INICIO-DE-WS          PIC X(42)  VALUE
               '*****INICIO WORKING STORAGE UR7CCTPR*****'.
           EJECT
      *
      ************** COPY SQLCA ****************************************
           EXEC SQL
              INCLUDE SQLCA
           END-EXEC.
      *
      ******************************************************************
      *      ESTA VARIABLE SE INCORPORA A LOS PROGRAMAS QUE LLAMAN     *
      *      A DB2 PARA REALIZAR EL CHEQUEO DEL SQLCODE.               *
      ******************************************************************
       01  DB2-RETURN-CDE                  PIC S9(9) COMP.
           88 DB2-OK                       VALUE +0.
           88 DB2-NOTFND                   VALUE +100.
           88 DB2-DUPREC                   VALUE -803.
      *
      *-----------------------------------------------------------------
      *                  COPY DE LA TABLA UGDTT37
      *-----------------------------------------------------------------
            EXEC SQL INCLUDE UGGTT37 END-EXEC.
            EXEC SQL INCLUDE UGTCT37 END-EXEC.
      *
      *-----------------------------------------------------------------
      *                  COPY DE LA TABLA UGDTPRO
      *-----------------------------------------------------------------
            EXEC SQL INCLUDE UGGTPRO END-EXEC.
            EXEC SQL INCLUDE UGTCPRO END-EXEC.
      *
      *-----------------------------------------------------------------
      *                  COPY DE LA TABLA UGDTDTE
      *-----------------------------------------------------------------
            EXEC SQL INCLUDE UGGTDTE END-EXEC.
            EXEC SQL INCLUDE UGTCDTE END-EXEC.
      *
      ******************************************************************
      *                  COPY DE LA TABLA PEDT011
      ******************************************************************
            EXEC SQL INCLUDE PEGV1110 END-EXEC.
      *
      *@COL01-I
      *-----------------------------------------------------------------
      *                  COPY DE LA TABLA UGDTLOG
      *-----------------------------------------------------------------
            EXEC SQL INCLUDE UGTCLOG END-EXEC.
            EXEC SQL INCLUDE UGGTLOG END-EXEC.
      *
      *@COL01-F
      *COL02-I
      *-----------------------------------------------------------------
      *                  COPY DE LA TABLA UGDTMAE
      *-----------------------------------------------------------------
            EXEC SQL INCLUDE UGTCMAE END-EXEC.
            EXEC SQL INCLUDE UGGTMAE END-EXEC.
      *
      *-----------------------------------------------------------------
      *                  COPY DE LA TABLA UGDTRAR
      *-----------------------------------------------------------------
            EXEC SQL INCLUDE UGGTRAR END-EXEC.
      *@COL12-JNS-INI
           EXEC SQL
                INCLUDE UGTCRAR
           END-EXEC.
      *@COL12-JNS-FIN
      *
      *-----------------------------------------------------------------
      *                  COPY DE LA TABLA UGDTRVE
      *-----------------------------------------------------------------
            EXEC SQL INCLUDE UGGTRVE END-EXEC.
      *@COL12-JNS-INI
           EXEC SQL
                INCLUDE UGTCRVE
           END-EXEC.
      *@COL12-JNS-FIN
      *
      *-----------------------------------------------------------------
      *                  COPY DE LA TABLA UGDTREL
      *-----------------------------------------------------------------
            EXEC SQL INCLUDE UGGTREL END-EXEC.
            EXEC SQL INCLUDE UGTCREL END-EXEC.
      *COL02-F
      *COL09-I
      ******************************************************************
      *   COPY INFORMACION RESERVADA DE LA BASE DE DATOS DE CLIENTES   *
      ******************************************************************
           COPY PEWC1111.
      *COL09-F
      *-----------------------------------------------------------------
      *               COPY PARA EL MANEJO DE FECHAS                    *
      *-----------------------------------------------------------------
       01 TCWC0750-01.
       COPY TCWC0750.
      *
      *-----------------------------------------------------------------
      *                  COPY DATOS PERSONAS(CORASU)
      *-----------------------------------------------------------------
       01 PEWC5200-01.
          COPY PEWC5200.
      *
      *-----------------------------------------------------------------
      *       COPY PARA TRAER LOS DATOS PATRIMONIALES DEL CLIENTE
      *-----------------------------------------------------------------
       01 PEWC0920-01.
          COPY PEWC0920.
      *
      *-----------------------------------------------------------------
      *             COPY PARA TRAER EL SEGMENTO DEL CLIENTE
      *-----------------------------------------------------------------
       01 PEWC0020-01.
          COPY PEWC0020.
      *
      *COL08-I
      *----------------------------------------------------------------*
      *    COPY PARA LA RUTINA DE PRODUCTOS DEL CLIENTE                *
      *----------------------------------------------------------------
       01 PEWC4390.
          COPY PEWC4390.
      *----------------------------------------------------------------*
      *                COPY DE LA RUTINA CA7CCBE2                      *
      *----------------------------------------------------------------*
       01 CATCCBE2-01.
          COPY CATCCBE2.
      *----------------------------------------------------------------*
      *                 COPY DE LA RUTINA BG7CPRT0
      *----------------------------------------------------------------*
       COPY BGTCPRT0.
      *COL08-F
      *-----------------------------------------------------------------
      *    COPY DE LA RUTINA QUE INFORMA SI EL CLIENTE DOM. NOMINA
      *-----------------------------------------------------------------
       01 REG-BGTCPDS0.
       COPY BGTCPDS0.
      *-----------------------------------------------------------------
      *           COPY DE LA RUTINA QUE TRAE EL PUNTAJE BURO
      *-----------------------------------------------------------------
       01 REG-RVWCTPR.
       COPY RVWCTPR.
      *-----------------------------------------------------------------
      *    COPY PARA LA RUTINA QUE TRAE LA PROB. DE MORA DEL CLIENTE
      *-----------------------------------------------------------------
       COPY HXWC014A.
      *-----------------------------------------------------------------
      *    COPY PARA LA RUTINA QUE TRAE LA PROB. DE MORA DEL CLIENTE
      *-----------------------------------------------------------------
       01 HXWCPRMO-REG.
           COPY HXWCPRMO.
      *COL02-I
      *-----------------------------------------------------------------
      *    COPY RUTINA TCOM PARA AVERIGUAR SEGMENTO
      *-----------------------------------------------------------------
       01 AREA-PMECT011.
           COPY PMECT011.
      *-----------------------------------------------------------------
      *             COPY PARA TRAER EL COLECTIVO DEL CLIENTE
      *-----------------------------------------------------------------
          COPY PE9TCLC.
      *
      *COL02-F
      *COL04-I
      ******************************************************************
      * COPY DE LA TABLA PEDT001  FECHA DE NACIMIENTO PEDTMAR SITULABO *
      *                  RUTINA PE9C1000                               *
      ******************************************************************
          COPY PEWC1000.
      *COL04-F
      *COL05-I
      *-----------------------------------------------------------------
      *           COPY DE LA RUTINA QUE TRAE LA TASA RAR
      *-----------------------------------------------------------------
       01 REG-UGWCNRA.
       COPY UGWCNRA.
      *COL05-F
      *COL07-I
      *----------------------------------------------------------------*
      *           COPY DE COMUNICACION CON LA RUTINA UR2CIT37          *
      *----------------------------------------------------------------*
       01 UGWCIT37-REG-1.
          COPY URWCIT37.
      *COL07-F
      *
      ******************************************************************
      *                                                                *
      *       WORKA DE CAMPOS VARIABLES                                *
      *                                                                *
      ******************************************************************
       01  SWITCHES.
           05  SW-ENCONTRADO-STATUS         PIC 9      VALUE 0.
               88  SW-NO-ENCONTRADO                    VALUE 0.
               88  SW-ENCONTRADO                       VALUE 1.
      *SWITCHES PARA DETERMINAR QUE DESCUENTO APLICAR AL CLIENTE
           05  SW-PUNTAJE-BURO              PIC X(01)  VALUE 'N'.
               88  SW-NO-PUNTAJE-BURO                  VALUE 'N'.
               88  SW-SI-PUNTAJE-BURO                  VALUE 'S'.
           05  SW-DOMICILIA-NOM             PIC X(01)  VALUE 'N'.
               88  SW-NO-DOMIC-NOMINA                  VALUE 'N'.
               88  SW-SI-DOMIC-NOMINA                  VALUE 'S'.
           05  SW-SEGMENTO-VIP              PIC X(01)  VALUE 'N'.
               88  SW-NO-SEGMENTO-VIP                  VALUE 'N'.
               88  SW-SI-SEGMENTO-VIP                  VALUE 'S'.
           05  SW-TIPO-CLIENTE              PIC X(01)  VALUE 'N'.
               88  SW-NO-TIPO-CLIENTE                  VALUE 'N'.
               88  SW-SI-TIPO-CLIENTE                  VALUE 'S'.
           05  SW-INGRESOS-CLIENTE          PIC X(01)  VALUE 'N'.
               88  SW-NO-INGRESOS-CLIENTE              VALUE 'N'.
               88  SW-SI-INGRESOS-CLIENTE              VALUE 'S'.
      *COL02-I
           05  SW-VALOR-COMPRA              PIC X(01)  VALUE 'N'.
               88  NO-VALOR-COMPRA                     VALUE 'N'.
               88  SI-VALOR-COMPRA                     VALUE 'S'.
           05  SW-DATOS-VEH                 PIC X(01)  VALUE 'N'.
               88  NO-DTS-VEH                          VALUE 'N'.
               88  SI-DTS-VEH                          VALUE 'S'.
      *COL02-F
      *SWITCHES CON LOS TIPOS DE CARTERAS PERMITIDOS PARA CONSULTAR EL
      *TIPO DE CLIENTE
           05  SW-HIPOTECARIO               PIC X(01)  VALUE SPACES.
               88  SW-SI-HIPOTECARIO        VALUE 'H' 'L'.
           05  SW-CONSUMO                   PIC X(01)  VALUE SPACES.
               88  SW-SI-CONSUMO            VALUE 'N' 'V' 'Z'.
      *
      * SWITCHES PARA DETERMINAR EL TIPO DE CARTERA
           05  SW-SUBPRO-VEHICULO           PIC X(01)  VALUE 'N'.
               88  SW-NO-SUBPRO-V                      VALUE 'N'.
               88  SW-SI-SUBPRO-V                      VALUE 'S'.
           05  SW-SUBPRO-LEASING            PIC X(01)  VALUE 'N'.
               88  SW-NO-SUBPRO-L                      VALUE 'N'.
               88  SW-SI-SUBPRO-L                      VALUE 'S'.
           05  SW-SUBPRO-HIPOTECARIO        PIC X(01)  VALUE 'N'.
               88  SW-NO-SUBPRO-H                      VALUE 'N'.
               88  SW-SI-SUBPRO-H                      VALUE 'S'.
           05  SW-SUBPRO-CONSUMO            PIC X(01)  VALUE 'N'.
               88  SW-NO-SUBPRO-N                      VALUE 'N'.
               88  SW-SI-SUBPRO-N                      VALUE 'S'.
           05  SW-SUBPRO-COMERCIO           PIC X(01)  VALUE 'N'.
               88  SW-NO-SUBPRO-C                      VALUE 'N'.
               88  SW-SI-SUBPRO-C                      VALUE 'S'.
           05  SW-SUBPRO-LIBRANZA           PIC X(01)  VALUE 'N'.
               88  SW-NO-SUBPRO-Z                      VALUE 'N'.
               88  SW-SI-SUBPRO-Z                      VALUE 'S'.
           05  SW-SUBPRO-NO-APLICA          PIC X(01)  VALUE 'N'.
               88  SW-NO-SUBPRO-X                      VALUE 'N'.
               88  SW-SI-SUBPRO-X                      VALUE 'S'.
      *COL05-I
           05  SW-SUBPRO-HIPOT-UVR          PIC X(01)  VALUE 'N'.
               88  SW-SI-HIPOT-UVR                     VALUE 'S'.
               88  SW-NO-HIPOT-UVR                     VALUE 'N'.
      *COL05-F
      *COL07-I
           05  SW-SUBPRO-HIPOT-SOS          PIC X(01)  VALUE 'N'.
               88  SW-SI-HIPOT-SOS                     VALUE 'S'.
               88  SW-NO-HIPOT-SOS                     VALUE 'N'.
      *
           05  SW-SUBPRO-HIPOT-VIS          PIC X(01)  VALUE 'N'.
               88  SW-SI-HIPOT-VIS                     VALUE 'S'.
               88  SW-NO-HIPOT-VIS                     VALUE 'N'.
      *
           05  SW-SUBPRO-PARAM-T37          PIC X(01)  VALUE 'N'.
               88  SW-SI-PARAM-T37                     VALUE 'S'.
               88  SW-NO-PARAM-T37                     VALUE 'N'.
      *COL07-F
      *COL08-I
           05  SW-CUENTA                    PIC X(01)  VALUE 'N'.
               88  SW-SI-CUENTA                        VALUE 'S'.
               88  SW-NO-CUENTA                        VALUE 'N'.
      *COL08-F
      *COL13-I
           05  SW-SUBPRO-CON-TASAV          PIC X(01)  VALUE 'N'.
               88  SW-SI-CON-TASAV                     VALUE 'S'.
               88  SW-NO-CON-TASAV                     VALUE 'N'.
      *
           05  SW-SUBPRO-VEH-TASAV          PIC X(01)  VALUE 'N'.
               88  SW-SI-VEH-TASAV                     VALUE 'S'.
               88  SW-NO-VEH-TASAV                     VALUE 'N'.
      *COL13-F
      *COL15-I
           05  SW-SUBPRO-LIB-TASAV          PIC X(01)  VALUE 'N'.
               88  SW-SI-LIB-TASAV                     VALUE 'S'.
               88  SW-NO-LIB-TASAV                     VALUE 'N'.
      *COL15-F
      *COL14-I
           05  SW-PROY-FINAN-ALIAD          PIC X(02)  VALUE 'NA'.
               88  SW-SI-PROY-FINAN                    VALUE 'SI'.
               88  SW-NO-PROY-FINAN                    VALUE 'NO'.
               88  SW-NA-PROY-FINAN                    VALUE 'NA'.
      *COL14-F
      *
       01  CONSTANTES.
           05  WSC-CF                       PIC X(02)  VALUE 'CF'.
           05  WS-CON-S                     PIC X(1)   VALUE 'S'.
           05  WS-OK                        PIC X(2)   VALUE '00'.
           05  WS-NO-ADMON                  PIC X(2)   VALUE '10'.
           05  WS-ERROR-DB2                 PIC X(2)   VALUE '99'.
           05  WSC-ALF-1                    PIC X(01)  VALUE '1'.
           05  WSC-ALF-2                    PIC X(01)  VALUE '2'.
           05  WSC-ALF-001                  PIC X(03)  VALUE '001'.
           05  WSC-ALF-00                   PIC X(02)  VALUE '00'.
           05  WSC-ALF-10                   PIC X(02)  VALUE '10'.
           05  WSC-ALF-20                   PIC X(02)  VALUE '20'.
           05  WSC-ALF-50                   PIC X(02)  VALUE '50'.
           05  WSC-ALF-90                   PIC X(02)  VALUE '90'.
           05  WSC-ALF-99                   PIC X(02)  VALUE '99'.
           05  WSC-ALF-F17                  PIC X(03)  VALUE 'F17'.
           05  WSC-UGE3631                  PIC X(07)  VALUE 'UGE3631'.
      *COL04-I
           05  WSC-PE9C1000                 PIC X(8)  VALUE 'PE9C1000'.
      *COL04-F
           05  WSC-PE7C9210                 PIC X(08)  VALUE 'PE7C9210'.
           05  WSC-ALF-1733                 PIC X(04)  VALUE '1733'.
      *COL07-I
           05  WSC-UR2CIT37                 PIC X(08)  VALUE 'UR2CIT37'.
           05  WSC-ALF-1737                 PIC X(04)  VALUE '1737'.
           05  WSC-ALF-5011                 PIC X(04)  VALUE '5011'.
      *COL14-I
           05  WSC-ALF-9639                 PIC X(04)  VALUE '9639'.
      *COL14-F
           05  WSC-ALF-D                    PIC X(01)  VALUE 'D'.
           05  WSC-PRODUC-96                PIC X(10)  VALUE
                                                           'PRODUC-96-'.
      *COL07-F
      *COL02-I
           05 WSC-PE9C0CLC                  PIC X(8)   VALUE 'PE9C0CLC'.
           05 WSC-PM9CT011                  PIC X(8)   VALUE 'PM9CT011'.
           05 CTN-UNO                       PIC X(01)  VALUE '1'.
           05 CTN-DOS                       PIC X(01)  VALUE '2'.
           05 CTN-TRES                      PIC X(01)  VALUE '3'.
           05 AUX-RELACION                  PIC X(02).
      *COL02-F
		         05 WS-IND2                       PIC S9(4) COMP.
		         05 AUX-RAR-DESCRIPCION           PIC X(10).
      *COL08-I
           05 WSC-01                        PIC X(02)  VALUE '01'.
           05 WSC-02                        PIC X(02)  VALUE '02'.
           05 WSC-C                         PIC X(01)  VALUE 'C'.
           05 WSC-N                         PIC X(01)  VALUE 'N'.
           05 WSC-S                         PIC X(01)  VALUE 'S'.
           05 WSC-T                         PIC X(01)  VALUE 'T'.
           05 WSC-PE9C5390                  PIC X(08)  VALUE 'PE9C5390'.
           05 WSC-UGE0939                   PIC X(07)  VALUE 'UGE0939'.
      *COL08-F
      *COL10-I
           05 WSC-LDIG                      PIC X(4)   VALUE 'LIB'.
      *COL10-F
      *COL13-I
           05 WSC-ALF-0028                  PIC X(04)  VALUE '0028'.
      *COL13-F
      *
       01  VARIABLES.
           05  WS-CORASU                    PIC X(03) VALUE SPACES.
           05  WS-PUNTAJE-BURO              PIC X(03) VALUE SPACES.
           05  WS-PUNT-BURO                 REDEFINES
               WS-PUNTAJE-BURO              PIC 9(03).
           05  WS-PUNTAJE-BURO-N            PIC 9(04) COMP-3 VALUE 0.
           05  WS-TOTAL-DESC                PIC S9(2)V9(3) VALUE 0.
           05  WS-TASA-PISO                 PIC S9(2)V9(3) VALUE 0.
      *COL04-I
           05  WS-FE-NACIMI                 PIC X(10).
           05  WS-FECHA-NACIMI              PIC 9(8).
           05  WS-FECHA-PROC                PIC 9(8).
           05  WS-TIPO-PROD                 PIC X.
           05  WS-AUX-AAAAMMDD.
               10 WS-AUX-AAAA               PIC 9(4).
               10 WS-AUX-MM                 PIC 9(2).
               10 WS-AUX-DD                 PIC 9(2).
           05  WS-AUX1-AAAAMMDD.
               10 WS-AUX1-AAAA              PIC 9(4).
               10 WS-AUX1-MM                PIC 9(2).
               10 WS-AUX1-DD                PIC 9(2).
      *COL04-F
           05  WSV-X                        PIC 9(15) VALUE 0.
           05 WSV-FECHA-PROCESO.
              10 WSV-DIA-PROCESO            PIC X(02) VALUE SPACES.
              10 WSV-MES-PROCESO            PIC X(02) VALUE SPACES.
              10 WSV-ANO-PROCESO            PIC X(04) VALUE SPACES.
           05 WSV-INGRESOS-FIJ              PIC 9(15)V9(2) VALUE 0.
           05 WSV-INGRESOS-VAR              PIC 9(15)V9(2) VALUE 0.
      *COL02-I
           05 WS-OFICINA                    PIC X(05) VALUE SPACES.
           05 WS-SECUENCIA                  PIC X(04) VALUE SPACES.

           05 WSV-MONTO-SOLICI              PIC 9(15)V9(2) VALUE 0.
           05 WSV-RANGO-MONTO               PIC 9(05)V9(4) VALUE 0.

           05 WS-PLAZO                      PIC 9(04) VALUE 0.
           05 WS-PLAZO-MES                  PIC 9(03) VALUE 0.
           05 PLAZO-MES                     PIC 9(03) VALUE 0.
           05 WSV-RANGO-PLAZO               PIC 9(04) VALUE 0.
           05 WSV-RANGO-PLAZO-I             PIC X(03) VALUE SPACES.

           05 WSV-VLR-BIEN                  PIC 9(15)V9(2) VALUE 0.
           05 WSV-RANGO-GAMA                PIC 9(05)V9(4) VALUE 0.

           05 WSV-RANGO-TIPVEH              PIC X(02) VALUE SPACES.

           05 WSV-RANGO-ESTADO              PIC X(01) VALUE SPACES.

           05 WSV-RANGO-PORCENTA            PIC 9(01)V9(4) VALUE 0.

           05 WSV-RANGO-SEG                 PIC 9(05) VALUE 0.

           05 WSV-RANGO-COL                 PIC 9(04) VALUE 0.

      *    05 WS-PORCENTA-A                 PIC 9(7) VALUE ZEROS.
      *    05 WS-PORCENTA                   REDEFINES
      *       WS-PORCENTA-A                 PIC Z.ZZZZZ.

      *VARIABLES ALMACENADAS UGDTRAR
           05 WS-SMLV-MONTO                 PIC 99999.9999.
      *COL04-I
      *    05 WS-DESC-MONTO                 PIC 99999.9999.
           05 WS-DESC-MONTO                 PIC +9999.9999.
      *    05 WS-DESC-PLAZO                 PIC 99999.9999.
           05 WS-DESC-PLAZO                 PIC +9999.9999.
      *COL04-F
           05 WS-SMLV-GAMA                  PIC 99999.9999.
      *COL04-I
      *    05 WS-DESC-GAMA                  PIC 99999.9999.
           05 WS-DESC-GAMA                  PIC +9999.9999.
      *    05 WS-DESC-TIPVEH                PIC 99999.9999.
           05 WS-DESC-TIPVEH                PIC +9999.9999.
      *    05 WS-DESC-ESTADO                PIC 99999.9999.
           05 WS-DESC-ESTADO                PIC +9999.9999.
      *COL04-F
           05 WS-PORCENTAJE                 PIC 99999.9999.
           05 WS-PORCENTAJE-S               PIC 9.9999.
      *COL04-I
      *    05 WS-DESC-PORCENTA              PIC 99999.9999.
           05 WS-DESC-PORCENTA              PIC +9999.9999.
      *COL04-F
           05 WS-SEGMENTO                   PIC 99999.9999.
      *COL04-I
      *    05 WS-DESC-SEG                   PIC 99999.9999.
           05 WS-DESC-SEG                   PIC +9999.9999.
      *COL04-F
           05 WS-COLECTIVO                  PIC 99999.9999.
      *COL04-I
      *    05 WS-DESC-COL                   PIC 99999.9999.
           05 WS-DESC-COL                   PIC +9999.9999.
      *COL02-F
           05 WS-EDAD                       PIC 9(2).
           05 WS-DESC-EDAD                  PIC +99.999.
           05 WS-SITU-LABO                  PIC X(1).
           05 WS-DESC-SITU                  PIC +99.999.
      *COL04-F
      *@COL01-I
      *    05 WSV-RANGO-SMLV                PIC 9(05)V9(2) VALUE 0.
           05 WSV-RANGO-SMLV                PIC 9(05)V9(4) VALUE 0.
      *@COL01-F
           05 WSV-SUMA-INGRESOS             PIC 9(15)V9(2) VALUE 0.
           05 WSV-SALARIO-MINIMO            PIC S9(10) VALUE 0.
           05 WSV-TIPO-PRODUCTO             PIC X(01) VALUE SPACES.
           05 WSV-HXWCPRMO.
              10 WSV-HXWCPRMO-01            PIC X(101).
              10 WSV-HXWCPRMO-14A           PIC X(4000).
           05 WSV-NPROB-MORA                PIC S9(5)V9(2) COMP-3
                                                           VALUE 0.
      *@COL01-I
      *    05 WSV-NPROB-MORA-F              PIC S9(5)V9(2) COMP-3
           05 WSV-NPROB-MORA-F              PIC S9(5)V9(4) COMP-3
      *@COL01-F
                                                           VALUE 0.
      *@COL01-I
      *    05 WS-PROB-MORA-F                PIC 99999.99.
           05 WS-PROB-MORA-F                PIC 99999.9999.
           05 WS-SMLV-CLIENTE               PIC 99999.9999.
      *COL04-I
      *    05 WS-DESC-BURO                  PIC 99999.9999.
      *    05 WS-DESC-PROB                  PIC 99999.9999.
      *    05 WS-DESC-SMLV                  PIC 99999.9999.
      *    05 WS-DESC-NOMINA                PIC 99999.9999.
      *    05 WS-DESC-VIP                   PIC 99999.9999.
           05 WS-DESC-BURO                  PIC +9999.9999.
           05 WS-DESC-PROB                  PIC +9999.9999.
           05 WS-DESC-SMLV                  PIC +9999.9999.
           05 WS-DESC-NOMINA                PIC +9999.9999.
           05 WS-DESC-VIP                   PIC +9999.9999.
      *COL04-F
           05 WS-IND-NOMINA                 PIC X(01) VALUE SPACES.
           05 WS-IND-VIP                    PIC X(01) VALUE SPACES.
      *@COL01-F
      *COL05-I
           05 WS-DESTINO                    PIC X(20) VALUE SPACES.
           05 WS-CLUSTER                    PIC X(25) VALUE SPACES.
      *COL05-F
      *COL07-I
           05 WS-SECCION                    PIC X(04) VALUE SPACES.
           05 WS-ELEMENTO                   PIC X(22) VALUE SPACES.
      *COL07-F
      *COL14-I
           05 WS-DEST-SUBPRO                PIC 9(01) VALUE ZEROS.
           05 WS-IND-PROY-FINAN             PIC X(02) VALUE SPACES.
      *COL14-F
      *COL08-I
           05 WS-I                          PIC 9(03) VALUE ZEROS.
           05 WS-PRODCTA                    PIC X(02) VALUE SPACES.
      *COL08-F
      *COL09-I
           05 WS-INUMCLIEN                  PIC X(8)  VALUE SPACES.
           05 WS-INGRCTAP                   PIC 9(15)V9(2) VALUE 0.
      *COL09-F
      *COL16-I
           05 WS-SECCION-1                  PIC X(04) VALUE SPACES.
           05 WS-SECCION-2                  PIC X(04) VALUE SPACES.
      *COL16-F
      *
      ******************************************************************
      *                                                                *
      *       MARCA DE FINAL DE WORKING-STORAGE                        *
      *                                                                *
      ******************************************************************
       01  LT-FINAL-DE-WS.
           05  LT-FINAL-DE-WS          PIC X(42)  VALUE
               '*****FINAL WORKING STORAGE UR2CINT0 *****'.
      *
           EJECT
      *
      ******************************************************************
      *                   L I N K A G E   S E C T I O N                *
      ******************************************************************
       LINKAGE SECTION.
      *
       01 DFHCOMMAREA.
      *********** AREA DE COMUNICACION CON EL PROGRAMA LLAMADOR ********
       COPY URWCTPR.
      *
           EJECT
      *
      ******************************************************************
      *           P R O C E D U R E   D I V I S I O N                  *
      ******************************************************************
       PROCEDURE DIVISION.
      *
           PERFORM 1000-INICIO-PROGRAMA
           PERFORM 2000-PROCESO-PROGRAMA
           PERFORM 3000-FINAL-PROGRAMA.
      *
      ******************************************************************
      *                     1000-INICIO-PROGRAMA                       *
      ******************************************************************
       1000-INICIO-PROGRAMA.
      *
           INITIALIZE CTPR-SALIDA
                      VARIABLES
      *COL02-I
           SET NO-VALOR-COMPRA              TO TRUE
           SET NO-DTS-VEH                   TO TRUE
      *COL02-F
           MOVE WSC-ALF-00                  TO CTPR-CODIGO-RETORNO.
      *
      ******************************************************************
      *                     2000-PROCESO-PROGRAMA                      *
      ******************************************************************
       2000-PROCESO-PROGRAMA.
      *
           PERFORM 2100-VALIDAR-ENTRADA
           PERFORM 2200-CONSULTAR-TIPO-PRODUCTO
           IF WSV-TIPO-PRODUCTO NOT EQUAL 'X'
              PERFORM 2300-CONSULTAR-INFO-CLIENTE
      *COL05-I
      *       PERFORM 2400-CONSULTAR-PARAMETRIA
              PERFORM 2400-CONSULTA-NUEVO-MOD
      *COL05-F
      *@COL01-I
              PERFORM INSERTAR-LOG-PDIF
      *@COL01-F
      *COL02-I
              PERFORM VALIDA-RELACION
              IF WSV-TIPO-PRODUCTO NOT EQUAL 'C' AND
                 AUX-RELACION NOT EQUAL 'S'
                 PERFORM INSERTAR-UGDTRAR
                 IF WSV-TIPO-PRODUCTO = 'V'
                    PERFORM INSERTAR-UGDTRVE
                 END-IF
              END-IF
      *COL02-F
              MOVE WS-TOTAL-DESC           TO CTPR-DESC-TASA
              MOVE WS-TASA-PISO            TO CTPR-TASA-PISO
      *COL05-I
              MOVE WS-DESTINO              TO CTPR-DESTINO
              MOVE WS-CLUSTER              TO CTPR-CLUSTER
      *COL05-F
           ELSE
              MOVE '20'                    TO CTPR-CODIGO-RETORNO
              MOVE 0                       TO CTPR-DESC-TASA
              MOVE 0                       TO CTPR-TASA-PISO
           END-IF.
      *
      *----------------------------------------------------------------*
      *                     21-VALIDAR-ENTRADA
      *----------------------------------------------------------------*
       2100-VALIDAR-ENTRADA.
      *
           IF CTPR-NUMCLIEN EQUAL SPACES OR LOW-VALUES
              MOVE WSC-ALF-10              TO CTPR-CODIGO-RETORNO
              MOVE 'CAMPO NO INFORMADO  '  TO CTPR-VAR2-ERROR
              MOVE 'TIPIDENT            '  TO CTPR-VAR1-ERROR
              PERFORM 3000-FINAL-PROGRAMA
           END-IF
      *
           PERFORM VARYING WSV-X FROM 1 BY 1 UNTIL WSV-X > 8
             IF CTPR-NUMCLIEN(WSV-X:1) IS NOT NUMERIC
              MOVE WSC-ALF-10              TO CTPR-CODIGO-RETORNO
              MOVE 'CAMPO NUMERICO      '  TO CTPR-VAR2-ERROR
              MOVE 'TIPIDENT            '  TO CTPR-VAR1-ERROR
              PERFORM 3000-FINAL-PROGRAMA
             END-IF
           END-PERFORM.
      *
           IF CTPR-ENTIOFI EQUAL SPACES OR LOW-VALUES
              MOVE WSC-ALF-10              TO CTPR-CODIGO-RETORNO
              MOVE 'CAMPO NO INFORMADO  '  TO CTPR-VAR2-ERROR
              MOVE 'ENTIOFI             '  TO CTPR-VAR1-ERROR
              PERFORM 3000-FINAL-PROGRAMA
           END-IF
      *
           PERFORM VARYING WSV-X FROM 1 BY 1 UNTIL WSV-X > 8
             IF CTPR-ENTIOFI(WSV-X:1) IS NOT NUMERIC
              MOVE WSC-ALF-10              TO CTPR-CODIGO-RETORNO
              MOVE 'CAMPO NUMERICO      '  TO CTPR-VAR2-ERROR
              MOVE 'ENTIOFI             '  TO CTPR-VAR1-ERROR
              PERFORM 3000-FINAL-PROGRAMA
             END-IF
           END-PERFORM.
      *
           IF CTPR-CUENTA EQUAL SPACES OR LOW-VALUES
              MOVE WSC-ALF-10              TO CTPR-CODIGO-RETORNO
              MOVE 'CAMPO NO INFORMADO  '  TO CTPR-VAR2-ERROR
              MOVE 'CUENTA              '  TO CTPR-VAR1-ERROR
              PERFORM 3000-FINAL-PROGRAMA
           END-IF
      *
           PERFORM VARYING WSV-X FROM 1 BY 1 UNTIL WSV-X > 10
             IF CTPR-CUENTA(WSV-X:1) IS NOT NUMERIC
              MOVE WSC-ALF-10              TO CTPR-CODIGO-RETORNO
              MOVE 'CAMPO NUMERICO      '  TO CTPR-VAR2-ERROR
              MOVE 'CUENTA              '  TO CTPR-VAR1-ERROR
              PERFORM 3000-FINAL-PROGRAMA
             END-IF
           END-PERFORM.
      *
           IF CTPR-SUBPRO EQUAL SPACES OR LOW-VALUES
              MOVE WSC-ALF-10              TO CTPR-CODIGO-RETORNO
              MOVE 'CAMPO NO INFORMADO  '  TO CTPR-VAR2-ERROR
              MOVE 'SUBPRODUCTO         '  TO CTPR-VAR1-ERROR
              PERFORM 3000-FINAL-PROGRAMA
           END-IF
      *
           PERFORM VARYING WSV-X FROM 1 BY 1 UNTIL WSV-X > 4
             IF CTPR-SUBPRO(WSV-X:1) IS NOT NUMERIC
              MOVE WSC-ALF-10              TO CTPR-CODIGO-RETORNO
              MOVE 'CAMPO NUMERICO      '  TO CTPR-VAR2-ERROR
              MOVE 'SUBPRODUCTO         '  TO CTPR-VAR1-ERROR
              PERFORM 3000-FINAL-PROGRAMA
             END-IF
           END-PERFORM.
      *
           IF CTPR-FECHA-PROCESO EQUAL SPACES OR LOW-VALUES
              MOVE WSC-ALF-10              TO CTPR-CODIGO-RETORNO
              MOVE 'CAMPO NO INFORMADO  '  TO CTPR-VAR2-ERROR
              MOVE 'FECHA PROCESO       '  TO CTPR-VAR1-ERROR
              PERFORM 3000-FINAL-PROGRAMA
           END-IF
      *
      *COL10-I
           IF CTPR-CANAL = WSC-LDIG
             IF CTPR-INGRCTAP IS NOT NUMERIC
                MOVE WSC-ALF-10              TO CTPR-CODIGO-RETORNO
                MOVE 'CAMPO NO INFORMADO  '  TO CTPR-VAR2-ERROR
                MOVE 'INGRCTAP            '  TO CTPR-VAR1-ERROR
                PERFORM 3000-FINAL-PROGRAMA
             END-IF
           END-IF
      *COL10-F
           PERFORM 2110-VALIDAR-FECHA.
      *
      *----------------------------------------------------------------*
      *                    2110-VALIDAR-FECHA                          *
      *----------------------------------------------------------------*
       2110-VALIDAR-FECHA.
      *
           INITIALIZE W075-ENTRADA
           MOVE CTPR-FECHA-PROCESO(9:2)      TO WSV-DIA-PROCESO
           MOVE CTPR-FECHA-PROCESO(6:2)      TO WSV-MES-PROCESO
           MOVE CTPR-FECHA-PROCESO(1:4)      TO WSV-ANO-PROCESO
           MOVE WSC-ALF-1                    TO W075-CDOPCIO
           MOVE WSV-FECHA-PROCESO            TO W075-FHGRE1
      *
           EXEC CICS
                LINK PROGRAM  ('TC1C1220')
                     COMMAREA (TCWC0750)
                     LENGTH   (W075-LONL075)
           END-EXEC.
      *
           IF EIBRESP NOT EQUAL DFHRESP(NORMAL)
              MOVE '90'                      TO BDS0-COD-ERROR
              MOVE 'LINK TC1C1220 '          TO BDS0-VAR1-ERROR
              PERFORM 999-ABEND-CICS
              PERFORM 3000-FINAL-PROGRAMA
           END-IF.
      *
           IF W075-CDRETORN NOT = '00'
              MOVE WSC-UGE3631               TO BDS0-COD-ERROR
              MOVE WSC-ALF-50                TO BDS0-CODIGO-RETORNO
              MOVE 'FECHA PROCESO ILOGIC'    TO BDS0-VAR2-ERROR
              MOVE 'DDMMAAAA'                TO BDS0-VAR1-ERROR
              PERFORM 3000-FINAL-PROGRAMA
           END-IF.
      *
      *----------------------------------------------------------------*
      *                     2200-CONSULTAR-TIPO-PRODUCTO
      *----------------------------------------------------------------*
       2200-CONSULTAR-TIPO-PRODUCTO.
      *
            INITIALIZE WSV-TIPO-PRODUCTO
      *
            PERFORM 2210-VALIDAR-UGDTT37
            IF SW-SI-SUBPRO-N
               MOVE 'N'                      TO WSV-TIPO-PRODUCTO
      *COL05-I
               MOVE 'CONSUMO'                TO WS-DESTINO
      *COL05-F
            END-IF
      *
            PERFORM 2220-VALIDAR-VEHICULO
            IF SW-SI-SUBPRO-V
               MOVE 'V'                      TO WSV-TIPO-PRODUCTO
      *COL05-I
               MOVE 'VEHICULO'               TO WS-DESTINO
      *COL05-F
            END-IF
      *COL15-I
      *COL13-I
      *     IF SW-SI-SUBPRO-N  OR SW-SI-SUBPRO-V
      *        PERFORM 2221-VALIDAR-TASA-VARIABLE
      *     END-IF
      *COL13-F
      *COL15-F
      *
            PERFORM 2230-VALIDAR-LIBRANZAS
            IF SW-SI-SUBPRO-Z
               MOVE 'Z'                      TO WSV-TIPO-PRODUCTO
      *COL05-I
               MOVE 'LIBRANZA'               TO WS-DESTINO
      *COL05-F
            END-IF
      *
            IF SW-SI-SUBPRO-H
               MOVE 'H'                      TO WSV-TIPO-PRODUCTO
      *COL05-I
               MOVE 'HIPOTECARIO'            TO WS-DESTINO
      *COL05-F
            END-IF
      *
            IF SW-SI-SUBPRO-C
               MOVE 'C'                      TO WSV-TIPO-PRODUCTO
      *COL05-I
               MOVE 'COMERCIAL'              TO WS-DESTINO
      *COL05-F
            END-IF
      *
            PERFORM 2240-VALIDAR-LEASING-HAB
            IF SW-SI-SUBPRO-L
               MOVE 'L'                      TO WSV-TIPO-PRODUCTO
      *COL05-I
               MOVE 'LEASING'                TO WS-DESTINO
      *COL05-F
            END-IF
      *
      *COL15-I
            IF SW-SI-SUBPRO-N OR SW-SI-SUBPRO-V OR SW-SI-SUBPRO-Z
               PERFORM 2221-VALIDAR-TASA-VARIABLE
            END-IF
      *COL15-F
      *
            IF WSV-TIPO-PRODUCTO EQUAL SPACES
               MOVE 'X'                      TO WSV-TIPO-PRODUCTO
            END-IF.
      *
      *----------------------------------------------------------------*
      *                     2210-VALIDAR-UGDTT37
      *----------------------------------------------------------------*
       2210-VALIDAR-UGDTT37.
      *
           INITIALIZE UGTCT37
           MOVE '1901'                        TO T37-SECCION
           MOVE CTPR-SUBPRO                   TO T37-ELEMENTO(1:4)
      *
             EXEC SQL
                 SELECT RESTO
                   INTO :T37-RESTO
                   FROM UGDTT37
                  WHERE SECCION  = :T37-SECCION
                    AND ELEMENTO   = :T37-ELEMENTO
             END-EXEC
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE
      *
           IF DB2-OK AND SQLWARN0 = SPACES
              EVALUATE  T37-RESTO(1:1)
                WHEN 'H'
                  SET SW-SI-SUBPRO-H            TO TRUE
                WHEN 'C'
                  SET SW-SI-SUBPRO-C            TO TRUE
                WHEN 'N'
                  SET SW-SI-SUBPRO-N            TO TRUE
                WHEN OTHER
                  SET SW-SI-SUBPRO-X            TO TRUE
              END-EVALUATE
           ELSE
              IF DB2-NOTFND AND SQLWARN0 = SPACES
                 SET SW-SI-SUBPRO-X            TO TRUE
              ELSE
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE 'UGDTT37'                TO CTPR-VAR1-ERROR
                 MOVE 'VAL TIPO CARTERA'       TO CTPR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 MOVE CTPR-SQLCODE             TO CTPR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
              END-IF
           END-IF.
      *
      *----------------------------------------------------------------*
      *                     2220-VALIDAR-VEHICULO
      *----------------------------------------------------------------*
       2220-VALIDAR-VEHICULO.
      *
           INITIALIZE UGTCT37
           MOVE '9040'                        TO T37-SECCION
           MOVE CTPR-SUBPRO                   TO T37-ELEMENTO(1:4)
      *
             EXEC SQL
                 SELECT RESTO
                   INTO :T37-RESTO
                   FROM UGDTT37
                  WHERE SECCION  = :T37-SECCION
                    AND ELEMENTO   = :T37-ELEMENTO
             END-EXEC
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE
      *
           IF DB2-OK AND SQLWARN0 = SPACES
              SET SW-SI-SUBPRO-V               TO TRUE
           ELSE
              IF DB2-NOTFND AND SQLWARN0 = SPACES
                 SET SW-NO-SUBPRO-V            TO TRUE
              ELSE
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE 'UGDTT37'                TO CTPR-VAR1-ERROR
                 MOVE 'VAL TIPO VEHIC. '       TO CTPR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 MOVE CTPR-SQLCODE             TO CTPR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
              END-IF
           END-IF.
      *
      *----------------------------------------------------------------*
      *                     2230-VALIDAR-LIBRANZAS
      *----------------------------------------------------------------*
       2230-VALIDAR-LIBRANZAS.
      *
           INITIALIZE UGTCPRO
           MOVE '96'                          TO PRO-PRODUCTO
           MOVE CTPR-SUBPRO                   TO PRO-SUBPRO
      *
             EXEC SQL
                 SELECT INDEALER,
                        PORINMIN,
                        INDCRSCO
                   INTO :PRO-INDEALER,
                        :PRO-PORINMIN,
                        :PRO-INDCRSCO
                   FROM UGDTPRO
                  WHERE PRODUCTO      = :PRO-PRODUCTO
                    AND SUBPRO        = :PRO-SUBPRO
             END-EXEC
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE
      *
           IF DB2-OK AND SQLWARN0 = SPACES
              IF PRO-INDEALER = 'S'
                 SET SW-SI-SUBPRO-Z            TO TRUE
              ELSE
                 SET SW-NO-SUBPRO-Z            TO TRUE
              END-IF
              MOVE PRO-PORINMIN                TO WS-TASA-PISO
           ELSE
              IF DB2-NOTFND AND SQLWARN0 = SPACES
                 SET SW-NO-SUBPRO-Z            TO TRUE
              ELSE
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE 'UGDTPRO'                TO CTPR-VAR1-ERROR
                 MOVE 'VAL TIPO LIBRZ. '       TO CTPR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 MOVE CTPR-SQLCODE             TO CTPR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
              END-IF
           END-IF.
      *
      *----------------------------------------------------------------*
      *                     2240-VALIDAR-LEASING-HAB
      *----------------------------------------------------------------*
       2240-VALIDAR-LEASING-HAB.
      *
           INITIALIZE UGTCT37
      *COL16-I
           SET SW-NO-SUBPRO-L                 TO TRUE
      *    MOVE '1250'                        TO T37-SECCION
      *COL16-F
           MOVE CTPR-SUBPRO                   TO T37-ELEMENTO(1:4)
      *COL16-I
           MOVE '1250'                        TO WS-SECCION-1
           MOVE '1254'                        TO WS-SECCION-2
      *      EXEC SQL
      *          SELECT RESTO
      *             INTO :T37-RESTO
      *            FROM UGDTT37
      *           WHERE SECCION  = :T37-SECCION
      *             AND ELEMENTO   = :T37-ELEMENTO
      *      END-EXEC
      *
             EXEC SQL
                 SELECT RESTO
                    INTO :T37-RESTO
                   FROM UGDTT37
                  WHERE SECCION  IN (:WS-SECCION-1, :WS-SECCION-2)
                    AND ELEMENTO   = :T37-ELEMENTO
                  FETCH FIRST 1 ROW ONLY
             END-EXEC
      *COL16-F
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE
      *
           IF DB2-OK AND SQLWARN0 = SPACES
              SET SW-SI-SUBPRO-L               TO TRUE
           ELSE
              IF DB2-NOTFND AND SQLWARN0 = SPACES
                 SET SW-NO-SUBPRO-L            TO TRUE
              ELSE
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE 'UGDTT37'                TO CTPR-VAR1-ERROR
                 MOVE 'VAL TIP LEASING '       TO CTPR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 MOVE CTPR-SQLCODE             TO CTPR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
              END-IF
           END-IF.
      *
      *----------------------------------------------------------------*
      *                     2300-CONSULTAR-INFO-CLIENTE
      *----------------------------------------------------------------*
       2300-CONSULTAR-INFO-CLIENTE.
      *
           PERFORM 2310-VALIDAR-DOM-NOMINA
           PERFORM 2320-VALIDAR-PUNTAJE-BURO
      *COL09-I
           IF WSV-TIPO-PRODUCTO EQUAL 'Z'
      *COL10-I
            IF CTPR-CANAL = WSC-LDIG
             MOVE CTPR-INGRCTAP        TO WSV-INGRESOS-FIJ
             MOVE ZEROS                TO WSV-INGRESOS-VAR
             PERFORM 2331-BUSCAR-SMLV
             PERFORM 2332-CALCULAR-SMLV
            ELSE
      *COL10-F
             PERFORM 2330-VALIDAR-INGRESOS-LB
      *COL10-I
            END-IF
      *COL10-F
           ELSE
      *COL09-F
           PERFORM 2330-VALIDAR-INGRESOS
      *COL09-I
           END-IF
      *COL09-F
      *COL02-I
           PERFORM 2340-VALIDA-MONTO
           PERFORM 2350-VALIDA-PLAZO
           PERFORM 2360-BUSCA-VLRCOMPRA
      *COL14-I
      *     IF WSV-TIPO-PRODUCTO = 'V'
           IF WSV-TIPO-PRODUCTO = 'V' OR 'H' OR 'L'
      *COL14-F
              PERFORM 2370-BUSCA-DTS-VEHI
           END-IF
      *COL02-F
      *GLOKAL-I
      *    IF PRO-INDCRSCO EQUAL 'S'
      *       MOVE WSV-TIPO-PRODUCTO          TO SW-HIPOTECARIO
      *                                          SW-CONSUMO
      *       EVALUATE TRUE
      *          WHEN  SW-SI-HIPOTECARIO
      *              MOVE 'H'                 TO HXWCPRMO-OPCION
      *              PERFORM 2340-VALIDAR-TIPO-CLIENTE
      *          WHEN  SW-SI-CONSUMO
      *              MOVE 'C'                 TO HXWCPRMO-OPCION
      *              PERFORM 2340-VALIDAR-TIPO-CLIENTE
      *          WHEN OTHER
      *              SET SW-NO-TIPO-CLIENTE   TO TRUE
      *       END-EVALUATE
      *    ELSE
      *       SET SW-NO-TIPO-CLIENTE          TO TRUE
      *    END-IF
      *
           PERFORM 2340-VALIDAR-TIPO-CLIENTE
      *GLOKAL-F
      *
           PERFORM 2350-VALIDAR-SEGMENTO-VIP.
      *
      *----------------------------------------------------------------*
      *                     2310-VALIDAR-DOM-NOMINA
      *----------------------------------------------------------------*
       2310-VALIDAR-DOM-NOMINA.
      *
           INITIALIZE WS-CORASU
           SET SW-NO-DOMIC-NOMINA              TO TRUE
      *
           PERFORM 2311-VALIDAR-CORASU
           IF WS-CORASU = WSC-ALF-F17
              SET SW-SI-DOMIC-NOMINA           TO TRUE
           ELSE
      *COL08-I
             PERFORM 2314-CONSULTA-CTAS-CTE
             IF SW-NO-DOMIC-NOMINA
      *       PERFORM 2312-VALIDAR-PORTAFOLIO
               PERFORM 2316-VALIDAR-PORTAFOLIO
             END-IF
      *COL08-F
           END-IF.
      *
      *----------------------------------------------------------------*
      *                     2311-VALIDAR-CORASU
      *----------------------------------------------------------------*
       2311-VALIDAR-CORASU.
      *
           INITIALIZE W520-REGISTRO
           MOVE CTPR-NUMCLIEN                  TO W520-NUMCLIEN
      *
           EXEC CICS
              LINK PROGRAM('PE2C5200')
              COMMAREA(PEWC5200-01)
           END-EXEC

           EVALUATE W520-PECRETOR
              WHEN '00'
                 MOVE W520-SUJGRUP             TO WS-CORASU(1:1)
                 MOVE W520-SUJSUBG1            TO WS-CORASU(2:)
              WHEN OTHER
                 MOVE SPACES                   TO WS-CORASU
           END-EVALUATE.
      *
      *----------------------------------------------------------------*
      *                     2312-VALIDAR-PORTAFOLIO
      *----------------------------------------------------------------*
       2312-VALIDAR-PORTAFOLIO.
      *
           MOVE W520-DIGIDENT                  TO BDS0-DIGIDENT
           MOVE W520-CLAIDENT                  TO BDS0-CLAIDENT
           MOVE W520-CODIDENT                  TO BDS0-CODIDENT
           MOVE CTPR-FECHA-PROCESO             TO BDS0-FECHA-PROCESO
      *
           EXEC CICS
               LINK PROGRAM ('BG7CPDS0')
               COMMAREA (BGTCPDS0)
               NOHANDLE
           END-EXEC
      *
           IF EIBRESP NOT EQUAL DFHRESP(NORMAL)
              MOVE BDS0-COD-ERROR              TO CTPR-COD-ERROR
              MOVE BDS0-VAR1-ERROR             TO CTPR-VAR1-ERROR
              PERFORM 999-ABEND-CICS
              PERFORM 3000-FINAL-PROGRAMA
           END-IF.
      *
           EVALUATE BDS0-CODIGO-RETORNO
              WHEN WSC-ALF-00
                   SET SW-SI-DOMIC-NOMINA      TO TRUE
              WHEN WSC-ALF-20
                   SET SW-NO-DOMIC-NOMINA      TO TRUE
              WHEN OTHER
                 MOVE BDS0-COD-ERROR           TO CTPR-COD-ERROR
                 MOVE BDS0-CODIGO-RETORNO      TO CTPR-CODIGO-RETORNO
                 MOVE BDS0-VAR1-ERROR          TO CTPR-VAR1-ERROR
                 MOVE BDS0-VAR2-ERROR          TO CTPR-VAR2-ERROR(1:16)
                 MOVE BDS0-SQLCODE             TO CTPR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *COL08-I
      *----------------------------------------------------------------*
      *                     2314-CONSULTA-CTAS-CTE
      *----------------------------------------------------------------*
       2314-CONSULTA-CTAS-CTE.
      *
           SET SW-NO-DOMIC-NOMINA   TO TRUE
           SET SW-NO-CUENTA         TO TRUE
           MOVE WSC-02              TO WS-PRODCTA                       00051400
           PERFORM 23141-OBTIENE-CUENTA                                 00051500
           IF SW-NO-CUENTA                                              00051600
             MOVE WSC-01            TO WS-PRODCTA                       00051700
             PERFORM 23141-OBTIENE-CUENTA                               00051800
           END-IF
           IF SW-SI-CUENTA
             SET SW-SI-DOMIC-NOMINA TO TRUE
           END-IF.
      *
      *----------------------------------------------------------------*
      *                     23141-OBTIENE-CUENTA
      *----------------------------------------------------------------*
       23141-OBTIENE-CUENTA.
      *
           INITIALIZE PEWC4390

           MOVE ZEROS                       TO WS-I
           MOVE CTPR-NUMCLIEN               TO W4390-NUMCLIEN
           MOVE WS-PRODCTA                  TO W4390-SERVICIO

           CALL WSC-PE9C5390                USING PEWC4390

           EVALUATE W4390-PCRETOR
             WHEN '00'
               PERFORM 231411-RECORRE-CUENTAS
                  VARYING WS-I FROM 1 BY 1
                    UNTIL WS-I > 100
                       OR WS-I > W4390-NOCCURS
                       OR SW-SI-CUENTA
             WHEN OTHER
               MOVE WSC-UGE0939             TO CTPR-COD-ERROR
               MOVE W4390-PCRETOR           TO CTPR-CODIGO-RETORNO
               MOVE 'ERROR RUT PE9C5390  '  TO CTPR-VAR1-ERROR
               MOVE 'RETORNO:'              TO CTPR-VAR2-ERROR(1:9)
               MOVE W4390-PCRETOR           TO CTPR-VAR2-ERROR(10:2)
               PERFORM 3000-FINAL-PROGRAMA
            END-EVALUATE.
      *
      *----------------------------------------------------------------*
      *                   231411-RECORRE-CUENTAS                       *
      *----------------------------------------------------------------*
       231411-RECORRE-CUENTAS.
      *
           IF W4390-CLAINTER(WS-I) EQUAL WSC-T  AND
              W4390-SECINTER(WS-I) EQUAL WSC-01 AND
              W4390-PEYESTAT(WS-I) NOT EQUAL WSC-C
             PERFORM 231411-DOMICILIA-CA25
           END-IF.
      *
      *----------------------------------------------------------------*
      *                     231411-DOMICILIA-CA25
      *----------------------------------------------------------------*
       231411-DOMICILIA-CA25.
      *
           INITIALIZE CATCCBE2-01
           MOVE W4390-PECENTID(WS-I)     TO CBE2-ENTIDAD-1
           MOVE W4390-OFIAPE  (WS-I)     TO CBE2-CENTRO-1
           MOVE W4390-CODISER (WS-I)     TO CBE2-CUENTA-1(1:2)
           MOVE W4390-NUMECTA (WS-I)     TO CBE2-CUENTA-1(3:8)
           MOVE CTPR-FECHA-PROCESO       TO CBE2-FECHA-PROCESO

           EXEC CICS
               LINK PROGRAM ('CA7CCBE2')
               COMMAREA (CATCCBE2)
               NOHANDLE
           END-EXEC

           EVALUATE CBE2-CODIGO-RETORNO
              WHEN '00'
                SET SW-SI-CUENTA             TO TRUE
              WHEN '10'
                MOVE WSC-UGE0939             TO CTPR-COD-ERROR
                MOVE CBE2-CODIGO-RETORNO     TO CTPR-CODIGO-RETORNO(1:2)
                MOVE CBE2-VAR1-ERROR         TO CTPR-VAR1-ERROR(4:)
                MOVE CBE2-VAR2-ERROR         TO CTPR-VAR2-ERROR
                PERFORM 3000-FINAL-PROGRAMA
              WHEN '20'
                SET SW-NO-CUENTA             TO TRUE
              WHEN '50'
                MOVE WSC-UGE0939             TO CTPR-COD-ERROR
                MOVE CBE2-CODIGO-RETORNO     TO CTPR-VAR1-ERROR(1:2)
                MOVE CBE2-VAR1-ERROR         TO CTPR-VAR1-ERROR(4:)
                MOVE CBE2-VAR2-ERROR         TO CTPR-VAR2-ERROR
                PERFORM 3000-FINAL-PROGRAMA
              WHEN '99'
                MOVE WSC-UGE0939             TO CTPR-COD-ERROR
                MOVE 'ERROR DOMICILIACION'   TO CTPR-VAR1-ERROR
                MOVE ' INTENTE MAS TARDE'    TO CTPR-VAR2-ERROR
                PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *----------------------------------------------------------------*
      *                     2316-VALIDAR-PORTAFOLIO
      *----------------------------------------------------------------*
       2316-VALIDAR-PORTAFOLIO.
      *
           INITIALIZE BGTCPRT0
      *
           MOVE W520-CODIDENT                  TO 020-TIPCEDULA
           MOVE W520-CLAIDENT                  TO 020-CEDULA
           MOVE W520-DIGIDENT                  TO 020-DIGVERIF
      *
           EXEC CICS
               LINK PROGRAM('BG7CPRT0')
               COMMAREA (BGTCPRT0)
           END-EXEC
      *
           IF 020-CODRET = 1
             SET SW-SI-DOMIC-NOMINA TO TRUE
           ELSE
             SET SW-NO-DOMIC-NOMINA TO TRUE
           END-IF.
      *
      *COL08-F
      *----------------------------------------------------------------*
      *                     2320-VALIDAR-PUNTAJE-BURO
      *----------------------------------------------------------------*
       2320-VALIDAR-PUNTAJE-BURO.
      *
           INITIALIZE RVTPR-SALIDA
           SET SW-NO-PUNTAJE-BURO              TO TRUE
           MOVE '000'                          TO WS-PUNTAJE-BURO
           MOVE '0'                            TO RVTPR-TIPIDENT(01:01)
           MOVE W520-CODIDENT                  TO RVTPR-TIPIDENT(02:01)
           MOVE W520-CLAIDENT                  TO RVTPR-CLAIDENT
      *
           EXEC CICS
               LINK PROGRAM ('RV7CCTPR')
               COMMAREA (REG-RVWCTPR)
               NOHANDLE
           END-EXEC
      *
           IF EIBRESP NOT EQUAL DFHRESP(NORMAL)
              MOVE 'UGE0903'                   TO CTPR-COD-ERROR
              MOVE RVTPR-VAR1-ERROR            TO CTPR-VAR1-ERROR
              PERFORM 999-ABEND-CICS
              PERFORM 3000-FINAL-PROGRAMA
           END-IF.
      *
           EVALUATE RVTPR-COD-RETORNO
              WHEN '00'
                 IF RVTPR-PUNTAJE-BUR  NOT EQUAL SPACES
                    MOVE RVTPR-PUNTAJE-BUR     TO WS-PUNTAJE-BURO
                 ELSE
                    MOVE '000'                 TO WS-PUNTAJE-BURO
                 END-IF
                 SET SW-SI-PUNTAJE-BURO        TO TRUE
              WHEN '20'
                 SET SW-NO-PUNTAJE-BURO        TO TRUE
                 MOVE '000'                    TO WS-PUNTAJE-BURO
              WHEN OTHER
                 MOVE 'UGE0903'                TO CTPR-COD-ERROR
                 MOVE RVTPR-COD-RETORNO        TO CTPR-CODIGO-RETORNO
                 MOVE RVTPR-VAR1-ERROR         TO CTPR-VAR2-ERROR(1:16)
                 MOVE RVTPR-VAR2-ERROR         TO CTPR-VAR1-ERROR
                 MOVE RVTPR-SQLCODE            TO CTPR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *COL09-I
      *----------------------------------------------------------------*
      *                   2330-VALIDAR-INGRESOS-LB                     *
      *----------------------------------------------------------------*
       2330-VALIDAR-INGRESOS-LB.
      *
           MOVE CTPR-NUMCLIEN                 TO WS-INUMCLIEN
           MOVE ZEROS                         TO WSV-INGRESOS-FIJ
           MOVE ZEROS                         TO WSV-INGRESOS-VAR
      *
           EXEC SQL
               SELECT IMPINRE
                 INTO : PEDV1101-INFORES.IMPINRE
                 FROM PEDV1101
                 WHERE NUMCLIEN  =:WS-INUMCLIEN  AND
                       CODINRE   = 'I01'
           END-EXEC.
      *
            MOVE SQLCODE                       TO DB2-RETURN-CDE
      *
            IF DB2-OK AND SQLWARN0 EQUAL SPACES
               MOVE PEDV1101-INFORES     TO PEWC1111-REGISTRO
               MOVE PEWC1111-IMPINRE     TO WS-INGRCTAP
               MOVE WS-INGRCTAP          TO WSV-INGRESOS-FIJ
               PERFORM 2331-BUSCAR-SMLV
               PERFORM 2332-CALCULAR-SMLV
            ELSE
              MOVE WSC-ALF-99            TO CTPR-CODIGO-RETORNO         82300
              MOVE WS-INUMCLIEN          TO CTPR-VAR1-ERROR(01:08)
              MOVE ' - I01'              TO CTPR-VAR1-ERROR(09:06)
              MOVE 'SIN INGRESOS '       TO CTPR-VAR2-ERROR(01:13)
              MOVE 'PEDT011'             TO CTPR-VAR2-ERROR(14:07)
              MOVE SQLCODE               TO CTPR-SQLCODE
              MOVE SQLERRM               TO CTPR-SQLERRM
              PERFORM 3000-FINAL-PROGRAMA
            END-IF.
      *COL09-F
      *----------------------------------------------------------------*
      *                     2330-VALIDAR-INGRESOS
      *----------------------------------------------------------------*
       2330-VALIDAR-INGRESOS.
      *
           INITIALIZE  PEWC0920-01
           SET SW-NO-INGRESOS-CLIENTE          TO TRUE
           MOVE WSC-CF                         TO PE920-CDOPCIO
           MOVE CTPR-NUMCLIEN                  TO PE920-NUMCLIEN-01
           MOVE 0                              TO WSV-INGRESOS-FIJ
           MOVE 0                              TO WSV-INGRESOS-VAR
      *
           EXEC CICS
                LINK PROGRAM    (WSC-PE7C9210)
                     COMMAREA   (PEWC0920-01)
           END-EXEC.
      *
           IF EIBRESP NOT EQUAL DFHRESP(NORMAL)
              MOVE W075-CDRETORN               TO CTPR-COD-ERROR
              MOVE 'LINK PE7C9210 '            TO CTPR-VAR1-ERROR
              PERFORM 999-ABEND-CICS
              PERFORM 3000-FINAL-PROGRAMA
           END-IF.
      *
           EVALUATE PE920-CODRETOR
               WHEN SPACES
                    SET SW-SI-INGRESOS-CLIENTE  TO TRUE
                    MOVE PE920-INGRCTAP-MAR     TO WSV-INGRESOS-FIJ
                    MOVE PE920-INGRVAR-MAR      TO WSV-INGRESOS-VAR
                    PERFORM 2331-BUSCAR-SMLV
                    PERFORM 2332-CALCULAR-SMLV
               WHEN OTHER
                    MOVE PE920-NUMCLIEN-01     TO CTPR-VAR1-ERROR(01:08)
                    MOVE ' SIN INGRESOS '      TO CTPR-VAR2-ERROR(01:14)
                    MOVE PE920-OBJETO-ERROR    TO CTPR-VAR2-ERROR(15:06)
                    MOVE PE920-SQLCODE         TO CTPR-SQLCODE
                    MOVE PE920-SQLERRM         TO CTPR-SQLERRM
                    PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *----------------------------------------------------------------*
      *                     2331-BUSCAR-SMLV
      *----------------------------------------------------------------*
       2331-BUSCAR-SMLV.
      *
           INITIALIZE                           UGTCT37
           MOVE WSC-ALF-1733                    TO T37-SECCION
           MOVE CTPR-FECHA-PROCESO              TO T37-ELEMENTO(1:4)
           MOVE '-01-01'                        TO T37-ELEMENTO(5:6)
      *
           EXEC SQL
             SELECT
                    RESTO
               INTO
                   :T37-RESTO
               FROM UGDTT37
              WHERE SECCION  = :T37-SECCION
                AND ELEMENTO = :T37-ELEMENTO
           END-EXEC.
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE
      *
           EVALUATE SQLCODE
              WHEN ZERO
                 MOVE T37-RESTO(1:10)          TO WSV-SALARIO-MINIMO
              WHEN +100
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE 'UGE0939'                TO CTPR-COD-ERROR
                 MOVE 'UGDTT37'                TO CTPR-VAR1-ERROR
                 MOVE 'NO EXISTE SMLV'         TO CTPR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 MOVE CTPR-SQLCODE             TO CTPR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
              WHEN OTHER
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE 'UGDTT37'                TO CTPR-VAR1-ERROR
                 MOVE 'BUSCAR SMLV '           TO CTPR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 MOVE CTPR-SQLCODE             TO CTPR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *----------------------------------------------------------------*
      *                     2332-CALCULAR-SMLV
      *----------------------------------------------------------------*
       2332-CALCULAR-SMLV.
      *
            MOVE 0                            TO WSV-RANGO-SMLV
            MOVE 0                            TO WSV-SUMA-INGRESOS
      *
            COMPUTE WSV-SUMA-INGRESOS = WSV-INGRESOS-FIJ  +
                                        WSV-INGRESOS-VAR
            COMPUTE WSV-RANGO-SMLV    = WSV-SUMA-INGRESOS /
                                        WSV-SALARIO-MINIMO.
      *
      *----------------------------------------------------------------*
      *                     2340-VALIDAR-TIPO-CLIENTE
      *----------------------------------------------------------------*
      *2340-VALIDAR-TIPO-CLIENTE.
      *
      *     MOVE CTPR-ENTIOFI(01:04)    TO HXWCPRMO-ENTIDAD
      *     MOVE CTPR-ENTIOFI(05:04)    TO HXWCPRMO-CENTRO
      *     MOVE CTPR-CUENTA            TO HXWCPRMO-CUENTA
      *     MOVE HXWCPRMO               TO WSV-HXWCPRMO-01
      *     MOVE HXWC014A-REG           TO WSV-HXWCPRMO-14A
      *
      *     EXEC CICS
      *       LINK PROGRAM('HX7CPRMO')
      *           COMMAREA(WSV-HXWCPRMO)
      *     END-EXEC
      *
      *     MOVE  WSV-HXWCPRMO-01       TO HXWCPRMO
      *     MOVE  WSV-HXWCPRMO-14A      TO HXWC014A-REG
      *
      *    IF EIBRESP NOT EQUAL DFHRESP(NORMAL)
      *       MOVE W075-CDRETORN               TO CTPR-COD-ERROR
      *       MOVE 'LINK HX7CPRMO '            TO CTPR-VAR1-ERROR
      *       PERFORM 999-ABEND-CICS
      *       PERFORM 3000-FINAL-PROGRAMA
      *    END-IF.
      *
      *    EVALUATE HXWCPRMO-RETORNO
      *        WHEN '00'
      *             EVALUATE TRUE
      *               WHEN SW-SI-HIPOTECARIO
      *                  MOVE HXWC014A-NPROB-MORA-H(1) TO
      *                                                WSV-NPROB-MORA
      *                  MOVE HXWC014A-NPROB-MOR-FI    TO
      *                                                WSV-NPROB-MORA-F
      *               WHEN SW-SI-CONSUMO
      *                  MOVE HXWC014A-NPROB-MORA-C(1) TO
      *                                                WSV-NPROB-MORA
      *                  MOVE HXWC014A-NPROB-MOR-FI    TO
      *                                                WSV-NPROB-MORA-F
      *             END-EVALUATE
      *             SET SW-SI-TIPO-CLIENTE             TO TRUE
      *        WHEN '99'
      *          MOVE HXWCPRMO-RETORNO         TO CTPR-CODIGO-RETORNO
      *          MOVE 'NO ENCONTRO SCORE HX'   TO CTPR-VAR2-ERROR
      *          IF HXWCPRMO-CAMPO-ERRONEO(21:3) EQUAL 'MAE'
      *             MOVE 'MAE'               TO CTPR-VAR1-ERROR(1:3)
      *          ELSE
      *             IF HXWCPRMO-CAMPO-ERRONEO(18:3) EQUAL 'RHI'
      *                MOVE 'RHI'               TO CTPR-VAR1-ERROR(1:3)
      *             ELSE
      *                MOVE 'RCO'               TO CTPR-VAR1-ERROR(1:3)
      *             END-IF
      *          END-IF
      *          MOVE HXWCPRMO-VALOR-CAMPO(19:4) TO CTPR-VAR1-ERROR(4:4)
      *          PERFORM 3000-FINAL-PROGRAMA
      *        WHEN OTHER
      *          MOVE HXWCPRMO-RETORNO           TO CTPR-CODIGO-RETORNO
      *          MOVE HXWCPRMO-CAMPO-ERRONEO(10:7) TO CTPR-VAR1-ERROR
      *          MOVE HXWCPRMO-VALOR-CAMPO(1:10)   TO CTPR-VAR2-ERROR
      *          MOVE 'MAL INFORM'                 TO CTPR-VAR2-ERROR
      *          PERFORM 3000-FINAL-PROGRAMA
      *    END-EVALUATE.
      *
      *GLOKAL-I
       2340-VALIDAR-TIPO-CLIENTE.
           MOVE CTPR-NUMCLIEN TO NUMCLIEN
           MOVE 'R01'         TO CODINRE

           EXEC SQL
             SELECT NUMCLIEN,SECUINRE ,
                    CODINRE ,IMPINRE  ,
                    USUARIO ,OFICOMEN ,
                    FECOMENT,HORCOMEN ,
                    PEHSTAMP,PENOFMOD ,
                    TEXINRES
             INTO
                :NUMCLIEN ,
                :SECUINRE ,
                :CODINRE  ,
                :IMPINRE  ,
                :USUARIO  ,
                :OFICOMEN ,
                :FECOMENT ,
                :HORCOMEN ,
                :PEHSTAMP ,
                :PENOFMOD ,
                :TEXINRES
            FROM PEDV1101
             WHERE NUMCLIEN = :PEDV1101-INFORES.NUMCLIEN
               AND CODINRE = :PEDV1101-INFORES.CODINRE
             END-EXEC

             MOVE SQLCODE TO DB2-RETURN-CDE
             IF DB2-OK
                 MOVE IMPINRE            TO WSV-NPROB-MORA
                                            WSV-NPROB-MORA-F
      *@COL01-I
                 COMPUTE WSV-NPROB-MORA-F = WSV-NPROB-MORA/100
      *@COL01-F
             ELSE
                 IF DB2-NOTFND
      *@COL01-I
      *              MOVE ZEROS          TO WSV-NPROB-MORA
      *                                     WSV-NPROB-MORA-F
                     MOVE 99999          TO WSV-NPROB-MORA-F
      *@COL01-F
                 ELSE
                     MOVE SQLCODE            TO CTPR-CODIGO-RETORNO
                     MOVE NUMCLIEN           TO CTPR-VAR1-ERROR
                     MOVE 'R01'              TO CTPR-VAR2-ERROR
                     MOVE 'MAL INFORMADO'    TO CTPR-VAR2-ERROR
                     PERFORM 3000-FINAL-PROGRAMA
                 END-IF
             END-IF.

      *---------------------------------- -----------------------------*
      *                     27-SEGMENTO-VIP
      *----------------------------------------------------------------*
       2350-VALIDAR-SEGMENTO-VIP.
      *
           INITIALIZE W002-REGISTRO
           SET  SW-SI-SEGMENTO-VIP           TO TRUE
           MOVE CTPR-NUMCLIEN                TO W002-NUMCLIEN
           MOVE WSC-ALF-2                    TO W002-OPCION
      *
           CALL 'PE9C0020' USING PEWC0020-01
           EVALUATE W002-PECRETOR
             WHEN '00'
      *AJOE-I
      *         IF W002-CLIENTE-VIP = 'S'
      *AJOE1-I
      *         IF W002-CLIENTE-VIP = 'S' OR W002-CLIENTE-VIP = 'P'
                IF W002-CLIENTE-VIP = 'S' OR W002-CLIENTE-VIP = 'P' OR
                   W002-CLIENTE-VIP = 'E'
      *AJOE1-F
      *AJOE-F
                   SET SW-SI-SEGMENTO-VIP    TO TRUE
                ELSE
                   SET SW-NO-SEGMENTO-VIP    TO TRUE
                END-IF
             WHEN OTHER
                SET SW-NO-SEGMENTO-VIP       TO TRUE
           END-EVALUATE.
      *
      *COL04-I
      ******************************************************************
      *  RUTINA QUE RECIBE EL NUMERO DEL CLIENTE Y RETORNA LA FECHA DE *
      *                     NACIMIENTO DEL MISMO                       *
      ******************************************************************
       2360-OBTENER-FEC-NACIMI.
           INITIALIZE                         DATOS-BASICOS
           MOVE CTPR-NUMCLIEN                 TO DATOS-NUMCLIEN
           MOVE 1                             TO DATOS-OPCION
           MOVE WSV-TIPO-PRODUCTO             TO WS-TIPO-PROD
           CALL WSC-PE9C1000  USING DATOS-BASICOS
           IF DATOS-COD-RETORNO = '00'  THEN
             MOVE PE001-FENACIMI              TO WS-FE-NACIMI
             MOVE WS-FE-NACIMI(1:4)           TO WS-FECHA-NACIMI(1:4)
             MOVE WS-FE-NACIMI(6:2)           TO WS-FECHA-NACIMI(5:2)
             MOVE WS-FE-NACIMI(9:2)           TO WS-FECHA-NACIMI(7:2)
             MOVE CTPR-FECHA-PROCESO(1:4)     TO WS-FECHA-PROC(1:4)
             MOVE CTPR-FECHA-PROCESO(6:2)     TO WS-FECHA-PROC(5:2)
             MOVE CTPR-FECHA-PROCESO(9:2)     TO WS-FECHA-PROC(7:2)
             MOVE WS-FECHA-PROC               TO WS-AUX-AAAAMMDD
             MOVE WS-FECHA-NACIMI             TO WS-AUX1-AAAAMMDD
             IF WS-AUX-AAAA  IS NUMERIC AND
                WS-AUX1-AAAA IS NUMERIC
                COMPUTE WS-EDAD = WS-AUX-AAAA - WS-AUX1-AAAA
                IF WS-AUX-MM  < WS-AUX1-MM
                   COMPUTE WS-EDAD = WS-EDAD - 1
                END-IF
                IF WS-AUX-MM = WS-AUX1-MM
                   IF WS-AUX-DD < WS-AUX1-DD
                      COMPUTE WS-EDAD = WS-EDAD - 1
                   END-IF
                END-IF
             END-IF
           ELSE
             MOVE SPACES                      TO WS-FE-NACIMI
             MOVE ZEROS                       TO WS-EDAD
           END-IF.
      ******************************************************************
      * RUTINA QUE RECIBE EL NUMERO DEL CLIENTE Y RETORNA LA SITUACION *
      *                     LABORAL DEL MISMO                          *
      ******************************************************************
       2370-OBTENER-SITU-LABO.
           INITIALIZE DATOS-BASICOS
           MOVE CTPR-NUMCLIEN                 TO DATOS-NUMCLIEN
           MOVE 1                             TO DATOS-OPCION
           CALL WSC-PE9C1000  USING DATOS-BASICOS
           IF DATOS-COD-RETORNO = '00'  THEN
             MOVE PEMAR-SITULABO              TO WS-SITU-LABO
           ELSE
             MOVE SPACES                      TO WS-SITU-LABO
           END-IF.
      *COL04-F
      *COL05-I
      *----------------------------------------------------------------*
      *                  2400-CONSULTA-NUEVO-MOD
      *----------------------------------------------------------------*
       2400-CONSULTA-NUEVO-MOD.
      *
           INITIALIZE UGNRA-SALIDA

           PERFORM 2370-OBTENER-SITU-LABO
           PERFORM 2360-OBTENER-FEC-NACIMI
           PERFORM 25201-VALIDA-SEGMENTO
           PERFORM 25301-VALIDA-COLECTIVO

           MOVE WSV-TIPO-PRODUCTO         TO UGNRA-PRODUCTO


      *COL14-I
           PERFORM 25303-ASIGNAR-PROD
      *     IF SW-SI-HIPOT-UVR25303-ASIGNAR-PROD
      *        MOVE 'HU'                   TO UGNRA-PRODUCTO
      *        MOVE 'HIPOTECARIO UVR'      TO WS-DESTINO
      *     END-IF
      *COL14-F
      *COL13-I
           IF SW-SI-CON-TASAV
              MOVE 'NV'                   TO UGNRA-PRODUCTO
              MOVE 'CONSUMO TASA VAR'     TO WS-DESTINO
           END-IF
      *
           IF SW-SI-VEH-TASAV
              MOVE 'VV'                   TO UGNRA-PRODUCTO
              MOVE 'VEHICULO TASA VAR'    TO WS-DESTINO
           END-IF
      *COL13-F

      *COL15-I
           IF SW-SI-LIB-TASAV
              MOVE 'ZV'                   TO UGNRA-PRODUCTO
              MOVE 'LIBRANZA TASA VAR'    TO WS-DESTINO
           END-IF
      *COL15-F
      *
           PERFORM 25302-VALIDA-SUBPRODUCTO
      *COL07-I
      *COL14-I
      *    IF WSV-TIPO-PRODUCTO EQUAL 'H'
      *      PERFORM 25304-CONSULTA-HV-HS
      *      IF SW-SI-HIPOT-SOS
      *        MOVE 'HS'                    TO UGNRA-PRODUCTO
      *        MOVE 'HS HIPOTECARIO SOS'    TO WS-DESTINO
      *        INITIALIZE UGNRA-ESTADO
      *                   WSV-RANGO-COL
      *                   WSV-RANGO-SEG
      *      END-IF
      *       IF SW-SI-HIPOT-VIS
      *         MOVE 'HV'                    TO UGNRA-PRODUCTO
      *         MOVE 'HV HIPOTECARIO VIS'    TO WS-DESTINO
      *       END-IF
      *    END-IF
      *COL14-F
      *COL07-I ESTO SE QUITA PORQUE SE INCLUYE EN
      *ASIGNAR-PRODUCTO-HIPOT-LEASING

           MOVE 'C'                       TO UGNRA-OPCION
           MOVE WS-PUNTAJE-BURO           TO UGNRA-BURO

           IF SW-SI-DOMIC-NOMINA
              MOVE 'S'                    TO UGNRA-NOMINA
           ELSE
              MOVE 'N'                    TO UGNRA-NOMINA
           END-IF
      * COL06-I
           MOVE UGNRA-NOMINA              TO WS-IND-NOMINA
      * COL06-F

           MOVE WS-SITU-LABO              TO UGNRA-SITLAB
           MOVE WSV-RANGO-SMLV            TO UGNRA-INGRESOS
           MOVE WSV-RANGO-MONTO           TO UGNRA-MONTO
           MOVE WSV-RANGO-PLAZO           TO UGNRA-PLAZO
           MOVE WS-EDAD                   TO UGNRA-EDAD
           MOVE WSV-RANGO-SEG             TO UGNRA-SEGMENTO
           MOVE WSV-RANGO-COL             TO UGNRA-COLECTIVO
           MOVE WSV-NPROB-MORA-F          TO UGNRA-RIESGO
           MOVE CTPR-FECHA-PROCESO        TO UGNRA-FECHA
           MOVE CTPR-SUBPRO               TO UGNRA-SUBPRO

           IF SW-SI-SEGMENTO-VIP
              MOVE 'S'                    TO UGNRA-INDVIP
           ELSE
              MOVE 'N'                    TO UGNRA-INDVIP
           END-IF
      *COL06-I
           IF WSV-TIPO-PRODUCTO = 'Z'
              MOVE CTPR-CLTVOLB           TO UGNRA-CLTVOLB
              MOVE CTPR-DESTNLB           TO UGNRA-DESTNLB
           END-IF
      *COL06-F

           IF WSV-TIPO-PRODUCTO = 'V' AND SI-DTS-VEH AND
              WSV-VLR-BIEN NOT EQUAL ZEROS AND
              WSV-RANGO-ESTADO NOT EQUAL SPACES
              MOVE WSV-RANGO-ESTADO       TO UGNRA-ESTADO
              MOVE WSV-RANGO-GAMA         TO UGNRA-GAMA
              IF WSV-RANGO-TIPVEH(1:2)= 'PU'
                 MOVE 'S'                 TO UGNRA-TIPVEH
              ELSE
                 MOVE 'P'                 TO UGNRA-TIPVEH
              END-IF
           ELSE
              MOVE ZEROS                  TO UGNRA-GAMA
              MOVE SPACES                 TO UGNRA-TIPVEH
      *COL14-I
              IF (UGNRA-PRODUCTO(1:1) = 'H' OR 'L') AND
                 UGNRA-PRODUCTO NOT = 'HS'
                 MOVE WSV-RANGO-ESTADO    TO UGNRA-ESTADO
              ELSE
                 MOVE SPACES              TO UGNRA-ESTADO
              END-IF
      *COL14-F
           END-IF

           IF (WSV-TIPO-PRODUCTO = 'H' OR 'V') AND
              (SI-VALOR-COMPRA AND WSV-VLR-BIEN NOT EQUAL ZEROS)
               COMPUTE WSV-RANGO-PORCENTA  = WSV-MONTO-SOLICI /
                                             WSV-VLR-BIEN
               MOVE WSV-RANGO-PORCENTA    TO UGNRA-FINANCIA
           ELSE
               MOVE ZEROS                 TO UGNRA-FINANCIA
           END-IF
      *
           CALL 'UG7CCNRA' USING  REG-UGWCNRA
      *
           IF EIBRESP NOT EQUAL DFHRESP(NORMAL)
              MOVE 'UGE0903'                   TO CTPR-COD-ERROR
              MOVE UGNRA-VAR1-ERROR            TO CTPR-VAR1-ERROR
              PERFORM 999-ABEND-CICS
              PERFORM 3000-FINAL-PROGRAMA
           END-IF
      *
           EVALUATE UGNRA-COD-RETORNO
              WHEN '00'
                 MOVE UGNRA-TASA-RAR           TO WS-TOTAL-DESC
                 MOVE UGNRA-CLUSTER            TO WS-CLUSTER
              WHEN '20'
                 MOVE UGNRA-COD-RETORNO        TO CTPR-CODIGO-RETORNO
              WHEN OTHER
                 MOVE 'UGE0903'                TO CTPR-COD-ERROR
                 MOVE UGNRA-COD-RETORNO        TO CTPR-CODIGO-RETORNO
                 MOVE UGNRA-VAR1-ERROR         TO CTPR-VAR2-ERROR(1:16)
                 MOVE UGNRA-VAR2-ERROR         TO CTPR-VAR1-ERROR
                 MOVE UGNRA-SQLCODE            TO CTPR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *COL05-F
      *----------------------------------------------------------------*
      *                     2400-CONSULTAR-PARAMETRIA
      *----------------------------------------------------------------*
       2400-CONSULTAR-PARAMETRIA.
      *
           INITIALIZE WS-TOTAL-DESC
      *
      *    IF SW-SI-PUNTAJE-BURO
      *COL14-I
      *       PERFORM 2410-PARM-BURO
      *COL14-F
      *    END-IF
      *GLOKAL-I
      *    IF SW-SI-TIPO-CLIENTE
      *COL14-I
      *       PERFORM 2420-PARM-TIPO-CLIENTE
      *COL14-F
      *    END-IF
      *GLOKAL
      *COL14-I
      *    IF SW-SI-INGRESOS-CLIENTE
      *       PERFORM 2430-PARM-INGRESOS
      *    END-IF
      *    IF SW-SI-DOMIC-NOMINA
      *       PERFORM 2440-PARM-DOMICILIA-NOMINA
      *COL14-F
      *    END-IF
      *    IF SW-SI-SEGMENTO-VIP
      *COL02-I
      *       PERFORM 2450-PARM-SEGMENTO-VIP
      *COL02-F
      *    END-IF.

      *COL02-I
           PERFORM 2460-PARM-MONTO-SOLICI
           PERFORM 2470-PARM-PLAZO

           IF WSV-TIPO-PRODUCTO = 'V' AND SI-DTS-VEH AND
              WSV-VLR-BIEN NOT EQUAL ZEROS AND
              WSV-RANGO-ESTADO NOT EQUAL SPACES
              PERFORM 2480-PARM-GAMA
              PERFORM 2500-PARM-ESTADO
              IF WSV-RANGO-TIPVEH NOT EQUAL 'NO'
                 PERFORM 2490-PARM-TIPVEH
              ELSE
                 MOVE ZEROS                  TO WS-DESC-TIPVEH
              END-IF
           ELSE
              MOVE ZEROS                     TO WS-DESC-GAMA
                                                WS-DESC-TIPVEH
                                                WS-DESC-ESTADO
           END-IF

           IF (WSV-TIPO-PRODUCTO = 'H' OR 'V' OR 'L') AND
              (SI-VALOR-COMPRA AND WSV-VLR-BIEN NOT EQUAL ZEROS)
              PERFORM 2510-PARM-PORCENTAJE
           ELSE
              MOVE ZEROS                     TO WS-DESC-PORCENTA
           END-IF

           PERFORM 2520-PARM-SEGMENTO
      *COL04-I
      *    PERFORM 2530-PARM-COLECTIVO.
           PERFORM 2530-PARM-COLECTIVO
           IF CTPR-IND NOT EQUAL 'NMC'
              PERFORM 2540-PARM-EDAD
              PERFORM 2550-PARM-SITU-LABO
           END-IF.
      *COL04-F
      *
      *COL02-F
      *
      *----------------------------------------------------------------*
      *                     2410-PARM-BURO
      *----------------------------------------------------------------*
       2410-PARM-BURO.
      *
           INITIALIZE                           UGTCDTE
      *@COL01-I
           MOVE 0                               TO WS-DESC-BURO
      *@COL01-F
           MOVE WSV-TIPO-PRODUCTO               TO DTE-TIPO-PRODUCTO
           MOVE CTPR-FECHA-PROCESO              TO DTE-FECHA-INI
                                                   DTE-FECHA-FIN
           MOVE '01'                            TO DTE-COD-TIPO-PUNTAJE
           MOVE WS-PUNT-BURO                    TO WS-PUNTAJE-BURO-N
           MOVE WS-PUNTAJE-BURO-N               TO DTE-RANGO-INI
                                                   DTE-RANGO-FIN
      *
           EXEC SQL
             SELECT DTE_TASA_DESCUENTO
               INTO :DTE-TASA-DESCUENTO
               FROM UGDTDTE
              WHERE DTE_COD_TIPO_PUNTAJE  =:DTE-COD-TIPO-PUNTAJE
                AND DTE_TIPO_PRODUCTO     =:DTE-TIPO-PRODUCTO
                AND DTE_FECHA_INI        <=:DTE-FECHA-INI
                AND DTE_FECHA_FIN        >=:DTE-FECHA-FIN
                AND DTE_RANGO_INI        <=:DTE-RANGO-INI
                AND DTE_RANGO_FIN        >=:DTE-RANGO-FIN
           END-EXEC.
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE
      *
           EVALUATE SQLCODE
              WHEN ZERO
      *@COL01-I
                 MOVE DTE-TASA-DESCUENTO       TO WS-DESC-BURO
      *@COL01-F
                 ADD DTE-TASA-DESCUENTO        TO WS-TOTAL-DESC
              WHEN +100
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE WS-PUNTAJE-BURO          TO CTPR-VAR1-ERROR
                 MOVE 'PARAMETRIZAR P.BURO'    TO CTPR-VAR2-ERROR
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
              WHEN OTHER
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE 'UGDTDTE'                TO CTPR-VAR1-ERROR
                 MOVE 'BUSCAR RANGO '          TO CTPR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 MOVE CTPR-SQLCODE             TO CTPR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *----------------------------------------------------------------*
      *                     2420-PARM-TIPO-CLIENTE
      *----------------------------------------------------------------*
       2420-PARM-TIPO-CLIENTE.
      *
           INITIALIZE                           UGTCDTE
      *@COL01-I
           MOVE 0                        TO WS-DESC-PROB
      *@COL01-F
           MOVE WSV-TIPO-PRODUCTO        TO DTE-TIPO-PRODUCTO
           MOVE CTPR-FECHA-PROCESO       TO DTE-FECHA-INI
                                            DTE-FECHA-FIN
           MOVE '02'                     TO DTE-COD-TIPO-PUNTAJE
           MOVE WSV-NPROB-MORA-F         TO DTE-PROB-RIESGO-INICIAL
                                            DTE-PROB-RIESGO-FINAL
           MOVE WSV-NPROB-MORA-F         TO WS-PROB-MORA-F
      *
           EXEC SQL
             SELECT DTE_TASA_DESCUENTO
               INTO :DTE-TASA-DESCUENTO
               FROM UGDTDTE
              WHERE DTE_COD_TIPO_PUNTAJE  =:DTE-COD-TIPO-PUNTAJE
                AND DTE_TIPO_PRODUCTO     =:DTE-TIPO-PRODUCTO
                AND DTE_FECHA_INI        <=:DTE-FECHA-INI
                AND DTE_FECHA_FIN        >=:DTE-FECHA-FIN
                AND DTE_PROB_RIESGO_INICIAL <=
                                         :DTE-PROB-RIESGO-INICIAL
                AND DTE_PROB_RIESGO_FINAL   >=
                                         :DTE-PROB-RIESGO-FINAL
           END-EXEC.
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE
      *
           EVALUATE SQLCODE
              WHEN ZERO
      *@COL01-I
                 MOVE DTE-TASA-DESCUENTO       TO WS-DESC-PROB
      *@COL01-F
                 ADD DTE-TASA-DESCUENTO        TO WS-TOTAL-DESC
              WHEN +100
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE WS-PROB-MORA-F           TO CTPR-VAR1-ERROR
                 MOVE 'PARAM. TIPO CLIENTE'    TO CTPR-VAR2-ERROR
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
              WHEN OTHER
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE 'UGDTDTE'                TO CTPR-VAR1-ERROR
                 MOVE 'PROB. DE MORA '         TO CTPR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 MOVE CTPR-SQLCODE             TO CTPR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *----------------------------------------------------------------*
      *                     2430-PARM-INGRESOS
      *----------------------------------------------------------------*
       2430-PARM-INGRESOS.
      *
           INITIALIZE                           UGTCDTE
           MOVE WSV-TIPO-PRODUCTO        TO DTE-TIPO-PRODUCTO
           MOVE CTPR-FECHA-PROCESO       TO DTE-FECHA-INI
                                            DTE-FECHA-FIN
           MOVE '03'                     TO DTE-COD-TIPO-PUNTAJE
           MOVE WSV-RANGO-SMLV           TO DTE-PROB-RIESGO-INICIAL
                                            DTE-PROB-RIESGO-FINAL
      *@COL01-I
      *    MOVE WSV-RANGO-SMLV           TO WS-PROB-MORA-F
           MOVE WSV-RANGO-SMLV           TO WS-SMLV-CLIENTE
           MOVE 0                        TO WS-DESC-SMLV
      *@COL01-F
      *
           EXEC SQL
             SELECT DTE_TASA_DESCUENTO
               INTO :DTE-TASA-DESCUENTO
               FROM UGDTDTE
              WHERE DTE_COD_TIPO_PUNTAJE  =:DTE-COD-TIPO-PUNTAJE
                AND DTE_TIPO_PRODUCTO     =:DTE-TIPO-PRODUCTO
                AND DTE_FECHA_INI        <=:DTE-FECHA-INI
                AND DTE_FECHA_FIN        >=:DTE-FECHA-FIN
                AND DTE_PROB_RIESGO_INICIAL <=
                                         :DTE-PROB-RIESGO-INICIAL
                AND DTE_PROB_RIESGO_FINAL   >=
                                         :DTE-PROB-RIESGO-FINAL
           END-EXEC.
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE
      *
           EVALUATE SQLCODE
              WHEN ZERO
      *@COL01-I
                 MOVE DTE-TASA-DESCUENTO       TO WS-DESC-SMLV
      *@COL01-F
                 ADD DTE-TASA-DESCUENTO        TO WS-TOTAL-DESC
              WHEN +100
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
      *@COL01-I
      *          MOVE WS-PROB-MORA-F           TO CTPR-VAR1-ERROR
                 MOVE WS-SMLV-CLIENTE          TO CTPR-VAR1-ERROR
      *@COL01-F
                 MOVE 'PARAM. RANGO SMLV  '    TO CTPR-VAR2-ERROR
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
              WHEN OTHER
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE 'UGDTDTE'                TO CTPR-VAR1-ERROR
                 MOVE 'RANGO SMLV   '          TO CTPR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 MOVE CTPR-SQLCODE             TO CTPR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *----------------------------------------------------------------*
      *                     2440-PARM-DOMICILIA-NOMINA
      *----------------------------------------------------------------*
       2440-PARM-DOMICILIA-NOMINA.
      *
           INITIALIZE                           UGTCDTE
           MOVE WSV-TIPO-PRODUCTO               TO DTE-TIPO-PRODUCTO
           MOVE CTPR-FECHA-PROCESO       TO DTE-FECHA-INI
                                            DTE-FECHA-FIN
           MOVE '04'                     TO DTE-COD-TIPO-PUNTAJE
           IF SW-SI-DOMIC-NOMINA
              MOVE 'S'                   TO DTE-IND-DOM-NOMINA
           ELSE
              MOVE 'N'                   TO DTE-IND-DOM-NOMINA
           END-IF
      *@COL01-I
           MOVE DTE-IND-DOM-NOMINA       TO WS-IND-NOMINA
           MOVE 0                        TO WS-DESC-NOMINA
      *@COL01-F
      *
           EXEC SQL
             SELECT DTE_TASA_DESCUENTO
               INTO :DTE-TASA-DESCUENTO
               FROM UGDTDTE
              WHERE DTE_COD_TIPO_PUNTAJE  =:DTE-COD-TIPO-PUNTAJE
                AND DTE_TIPO_PRODUCTO     =:DTE-TIPO-PRODUCTO
                AND DTE_FECHA_INI        <=:DTE-FECHA-INI
                AND DTE_FECHA_FIN        >=:DTE-FECHA-FIN
                AND DTE_IND_DOM_NOMINA    =:DTE-IND-DOM-NOMINA
           END-EXEC.
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE
      *
           EVALUATE SQLCODE
              WHEN ZERO
      *@COL01-I
                 MOVE DTE-TASA-DESCUENTO       TO WS-DESC-NOMINA
      *@COL01-F
                 ADD DTE-TASA-DESCUENTO        TO WS-TOTAL-DESC
              WHEN +100
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE DTE-IND-DOM-NOMINA       TO CTPR-VAR1-ERROR
                 MOVE 'PARAM. DOMICIL NOM '    TO CTPR-VAR2-ERROR
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
              WHEN OTHER
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE 'UGDTDTE'                TO CTPR-VAR1-ERROR
                 MOVE 'DOMICILIA NOMINA'       TO CTPR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 MOVE CTPR-SQLCODE             TO CTPR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *----------------------------------------------------------------*
      *                     2450-PARM-SEGMENTO-VIP
      *----------------------------------------------------------------*
       2450-PARM-SEGMENTO-VIP.
      *
           INITIALIZE                           UGTCDTE
           MOVE WSV-TIPO-PRODUCTO               TO DTE-TIPO-PRODUCTO
           MOVE CTPR-FECHA-PROCESO       TO DTE-FECHA-INI
                                            DTE-FECHA-FIN
           MOVE '05'                     TO DTE-COD-TIPO-PUNTAJE
           IF SW-SI-SEGMENTO-VIP
              MOVE 'S'                   TO DTE-IND-CLIENTE-VIP
           ELSE
              MOVE 'N'                   TO DTE-IND-CLIENTE-VIP
           END-IF
      *@COL01-I
           MOVE DTE-IND-CLIENTE-VIP      TO WS-IND-VIP
           MOVE 0                        TO WS-DESC-VIP
      *@COL01-F
      *
           EXEC SQL
             SELECT DTE_TASA_DESCUENTO
               INTO :DTE-TASA-DESCUENTO
               FROM UGDTDTE
              WHERE DTE_COD_TIPO_PUNTAJE  =:DTE-COD-TIPO-PUNTAJE
                AND DTE_TIPO_PRODUCTO     =:DTE-TIPO-PRODUCTO
                AND DTE_FECHA_INI        <=:DTE-FECHA-INI
                AND DTE_FECHA_FIN        >=:DTE-FECHA-FIN
                AND DTE_IND_CLIENTE_VIP   =:DTE-IND-CLIENTE-VIP
           END-EXEC.
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE
      *
           EVALUATE SQLCODE
              WHEN ZERO
      *@COL01-I
                 MOVE DTE-TASA-DESCUENTO       TO WS-DESC-VIP
      *@COL01-F
                 ADD DTE-TASA-DESCUENTO        TO WS-TOTAL-DESC
              WHEN +100
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE DTE-IND-CLIENTE-VIP      TO CTPR-VAR1-ERROR
                 MOVE 'PARAM. CLIENTE VIP '    TO CTPR-VAR2-ERROR
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
                 CONTINUE
              WHEN OTHER
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE 'UGDTDTE'                TO CTPR-VAR1-ERROR
                 MOVE 'BUSCAR CLIENTE VIP '    TO CTPR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 MOVE CTPR-SQLCODE             TO CTPR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *----------------------------------------------------------------*
      *                       999-ABEND-CICS                           *
      *----------------------------------------------------------------*
       999-ABEND-CICS.
      *
           MOVE EIBRSRCE                    TO CTPR-SQLERRM
           MOVE EIBRESP                     TO CTPR-SQLCODE
           MOVE EIBFN                       TO CTPR-VAR2-ERROR
           MOVE '-'                         TO CTPR-VAR2-ERROR(3:1)
           MOVE EIBRSRCE                    TO CTPR-VAR2-ERROR(4:8)
           MOVE '-'                         TO CTPR-VAR2-ERROR(12:1)
           MOVE EIBRCODE                    TO CTPR-VAR2-ERROR(13:6).
           EJECT.
      *
      *----------------------------------------------------------------*
      *                      3000-FINAL-PROGRAMA                       *
      *----------------------------------------------------------------*
       3000-FINAL-PROGRAMA.
           EXEC CICS
              RETURN
           END-EXEC.
      *
      *@COL01-I
      *----------------------------------------------------------------*
      *                        INSERTAR-LOG-PDIF                       *
      *----------------------------------------------------------------*
        INSERTAR-LOG-PDIF.
      *
           INITIALIZE UGTCLOG
           MOVE CTPR-FECHA-PROCESO      TO LOG-FECMOV
           MOVE CTPR-ENTIOFI            TO LOG-ENTIOFI
           MOVE CTPR-CUENTA             TO LOG-CUENTA
           MOVE 'UDIF'                  TO LOG-CODIGO

      *COL02-I
           EXEC SQL
               SELECT MAX(LOG_CONSOPE)
               INTO :LOG-CONSOPE  :WS-IND2
               FROM UGDTLOG
               WHERE LOG_ENTIOFI = :LOG-ENTIOFI
                 AND LOG_CUENTA  = :LOG-CUENTA
                 AND LOG_CODIGO  = :LOG-CODIGO
           END-EXEC

		         MOVE SQLCODE                     TO DB2-RETURN-CDE

           EVALUATE DB2-RETURN-CDE
             WHEN ZEROES
               ADD 1 TO LOG-CONSOPE
             WHEN +100
               ADD 1 TO LOG-CONSOPE
             WHEN OTHER
               MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
               MOVE SQLERRM                  TO CTPR-SQLERRM
               MOVE 'UGDTLOG'                TO CTPR-VAR1-ERROR
               MOVE 'COUNT LOG UR7CCTPR'     TO CTPR-VAR2-ERROR(1:16)
               MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
               MOVE CTPR-SQLCODE             TO CTPR-VAR2-ERROR(17:4)
               PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE
      *COL02-F

           MOVE '0'                     TO LOG-IMPANT
COL02 *    MOVE CTPR-NUMCLIEN           TO LOG-CARANT
           MOVE '0'                     TO LOG-CARANT
                                           LOG-TASA-ANT
                                           LOG-IMPNUE LOG-CARNUE
                                           LOG-TASA-NUE
COL02 *    MOVE '0'                     TO LOG-CONSOPE
           MOVE '0001-01-01'            TO LOG-FECANT
           MOVE '0001-01-01'            TO LOG-FECNUE
           MOVE WSV-TIPO-PRODUCTO       TO LOG-DESCRIPCION(01:01)
           MOVE WS-PUNTAJE-BURO         TO LOG-DESCRIPCION(02:03)
      *COL04-I
      *    MOVE WS-DESC-BURO            TO LOG-DESCRIPCION(05:10)
           MOVE WS-DESC-BURO(1:1)       TO LOG-DESCRIPCION(05:01)
           MOVE WS-DESC-BURO(2:9)       TO LOG-DESCRIPCION(06:09)
      *COL04-F
      *COL11-I
           MOVE UGNRA-INGRESOS          TO WS-SMLV-CLIENTE
           MOVE UGNRA-RIESGO            TO WS-PROB-MORA-F
      *COL11-F
           MOVE WS-PROB-MORA-F          TO LOG-DESCRIPCION(15:10)
      *COL04-I
      *    MOVE WS-DESC-PROB            TO LOG-DESCRIPCION(25:10)
           MOVE WS-DESC-PROB(1:1)       TO LOG-DESCRIPCION(25:01)
           MOVE WS-DESC-PROB(2:9)       TO LOG-DESCRIPCION(26:09)
      *COL04-F
           MOVE WS-SMLV-CLIENTE         TO LOG-DESCRIPCION(35:10)
      *COL04-I
      *    MOVE WS-DESC-SMLV            TO LOG-DESCRIPCION(45:10)
           MOVE WS-DESC-SMLV(1:1)       TO LOG-DESCRIPCION(45:01)
           MOVE WS-DESC-SMLV(2:9)       TO LOG-DESCRIPCION(46:09)
      *COL04-F
           MOVE WS-IND-NOMINA           TO LOG-DESCRIPCION(55:01)
      *COL04-I
      *    MOVE WS-DESC-NOMINA          TO LOG-DESCRIPCION(56:10)
           MOVE WS-DESC-NOMINA(1:1)     TO LOG-DESCRIPCION(56:01)
           MOVE WS-DESC-NOMINA(2:9)     TO LOG-DESCRIPCION(57:09)
      *COL04-F
      *COL11-I
           MOVE UGNRA-INDVIP            TO WS-IND-VIP
      *COL11-F
           MOVE WS-IND-VIP              TO LOG-DESCRIPCION(66:01)
      *COL04-I
      *    MOVE WS-DESC-VIP             TO LOG-DESCRIPCION(67:10)
           MOVE WS-DESC-VIP(1:1)        TO LOG-DESCRIPCION(67:01)
           MOVE WS-DESC-VIP(2:9)        TO LOG-DESCRIPCION(68:09)
      *COL04-F
           MOVE WS-CORASU               TO LOG-DESCRIPCION(77:03)
           MOVE CTPR-NUMCLIEN           TO LOG-COLUMNA
           MOVE CTPR-ENTIOFI(01:04)     TO LOG-ENTIDAD-UMO
           MOVE CTPR-ENTIOFI(05:04)     TO LOG-CENTRO-UMO
           MOVE 'UR7CCTPR'              TO LOG-USERID-UMO
           MOVE 'U040'                  TO LOG-NETNAME-UMO
                                           LOG-TABLA
      *COL11-I
           IF CTPR-CANAL NOT EQUAL  SPACES AND
              CTPR-CANAL NOT EQUAL  LOW-VALUES
              MOVE CTPR-CANAL TO LOG-TABLA
           END-IF
      *COL11-F
           PERFORM INSERTAR-LOG.
      *
      *----------------------------------------------------------------*
      *                      INSERTAR-LOG                              *
      *----------------------------------------------------------------*
        INSERTAR-LOG.
      *
           EXEC SQL
           INSERT INTO UGDTLOG (LOG_ENTIOFI,
                 LOG_CUENTA, LOG_TIMESTAMP,
                 LOG_CODIGO, LOG_FECMOV,
                 LOG_CONSOPE, LOG_FECANT,
                 LOG_IMPANT, LOG_CARANT,
                 LOG_TASA_ANT, LOG_FECNUE,
                 LOG_IMPNUE, LOG_CARNUE,
                 LOG_TASA_NUE, LOG_TABLA,
                 LOG_COLUMNA, LOG_DESCRIPCION,
                 LOG_ENTIDAD_UMO, LOG_CENTRO_UMO,
                 LOG_USERID_UMO, LOG_NETNAME_UMO)
           VALUES (:LOG-ENTIOFI,:LOG-CUENTA,
                    CURRENT TIMESTAMP, :LOG-CODIGO,
                    :LOG-FECMOV, :LOG-CONSOPE,
                    :LOG-FECANT, :LOG-IMPANT,
                    :LOG-CARANT, :LOG-TASA-ANT,
                    :LOG-FECNUE, :LOG-IMPNUE,
                    :LOG-CARNUE, :LOG-TASA-NUE,
                    :LOG-TABLA, :LOG-COLUMNA,
                    :LOG-DESCRIPCION, :LOG-ENTIDAD-UMO,
                    :LOG-CENTRO-UMO, :LOG-USERID-UMO,
                    :LOG-NETNAME-UMO)
               END-EXEC
      *
           MOVE SQLCODE                       TO DB2-RETURN-CDE
      *
           EVALUATE SQLCODE
              WHEN ZERO
      *COL02-I
      *          CONTINUE
                 PERFORM 888888-COMMIT
      *COL02-F
              WHEN OTHER
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE 'UGDTLOG'                TO CTPR-VAR1-ERROR
                 MOVE 'INSERT LOG UR7CCTPR'    TO CTPR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 MOVE CTPR-SQLCODE             TO CTPR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *@COL01-F
      *COL02-I
      *----------------------------------------------------------------*
      *                   2340-VALIDA-MONTO                            *
      *----------------------------------------------------------------*
        2340-VALIDA-MONTO.

           MOVE CTPR-ENTIOFI                   TO MAE-ENTIOFI
           MOVE CTPR-CUENTA                    TO MAE-CUENTA
      *COL05-I
           SET SW-NO-HIPOT-UVR                 TO TRUE
      *COL05-F

           EXEC SQL
              SELECT  CAPSOLI   ,
                      PLAZO     ,
                      LIBRE_IMP4,
      *COL05-I
                      LIBRE_CAR6,
      *COL05-F
                      EXPEDIENTE
                INTO :MAE-CAPSOLI   ,
                     :MAE-PLAZO     ,
                     :MAE-LIBRE-IMP4,
      *COL05-I
                     :MAE-LIBRE-CAR6,
      *COL05-F
                     :MAE-EXPEDIENTE
                FROM  UGDTMAE
               WHERE  ENTIOFI   = :MAE-ENTIOFI   AND
                      CUENTA    = :MAE-CUENTA
           END-EXEC.

           MOVE SQLCODE                        TO DB2-RETURN-CDE
      *
           EVALUATE SQLCODE
              WHEN ZERO
                 MOVE MAE-PLAZO                TO WS-PLAZO
                 IF MAE-EXPEDIENTE(1:8) = 'PR-UNICA'
                    MOVE MAE-CAPSOLI           TO WSV-MONTO-SOLICI
                    COMPUTE WSV-MONTO-SOLICI = WSV-MONTO-SOLICI -
                                               MAE-LIBRE-IMP4
                 ELSE
                    MOVE MAE-CAPSOLI           TO WSV-MONTO-SOLICI
                 END-IF
                 PERFORM 2331-BUSCAR-SMLV
                 COMPUTE WSV-RANGO-MONTO   = WSV-MONTO-SOLICI /
                                             WSV-SALARIO-MINIMO
      *COL05-I
                 IF MAE-LIBRE-CAR6 = 'UVR' OR 'UVRBO'
                    SET SW-SI-HIPOT-UVR        TO TRUE
                 END-IF
      *COL05-F
              WHEN +100
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE 'SIN MONTO SOLICI'       TO CTPR-VAR1-ERROR
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
              WHEN OTHER
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE 'UGDTMAE'                TO CTPR-VAR1-ERROR
                 MOVE 'SELECT MAE UR7CCTPR'    TO CTPR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 MOVE CTPR-SQLCODE             TO CTPR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *----------------------------------------------------------------*
      *                   2350-VALIDA-PLAZO                            *
      *----------------------------------------------------------------*
        2350-VALIDA-PLAZO.

           IF WS-PLAZO(1:1) NOT EQUAL CTN-DOS
              IF WS-PLAZO(1:1)= CTN-UNO
                 MOVE WS-PLAZO(2:3)        TO WS-PLAZO-MES
                 COMPUTE PLAZO-MES = WS-PLAZO-MES / 30
                 MOVE PLAZO-MES            TO WSV-RANGO-PLAZO
              END-IF

              IF WS-PLAZO(1:1)= CTN-TRES
                 MOVE WS-PLAZO(2:3)        TO WS-PLAZO-MES
                 COMPUTE PLAZO-MES = WS-PLAZO-MES * 12
                 MOVE PLAZO-MES            TO WSV-RANGO-PLAZO
              END-IF
           ELSE
              MOVE WS-PLAZO(2:3)           TO WSV-RANGO-PLAZO
           END-IF
           MOVE WSV-RANGO-PLAZO(2:3)       TO WSV-RANGO-PLAZO-I.
      *
      *----------------------------------------------------------------*
      *                   2360-BUSCA-VLRCOMPRA                         *
      *----------------------------------------------------------------*
        2360-BUSCA-VLRCOMPRA.

           MOVE '%'                     TO WS-OFICINA(1:1)
           MOVE CTPR-ENTIOFI(5:4)       TO WS-OFICINA(2:4)
           MOVE CTPR-CUENTA             TO RAR-CUENTA
           MOVE CTPR-NUMCLIEN           TO RAR-DESCRIPCION(8: )
           MOVE RAR-DESCRIPCION(8: )    TO AUX-RAR-DESCRIPCION(2:8)
           MOVE '%'                     TO AUX-RAR-DESCRIPCION(1:1)
           MOVE '%'                     TO AUX-RAR-DESCRIPCION(10:1)

           EXEC SQL
              SELECT  RAR_VLR_COMPRA,
                      RAR_ENTIOFI
                INTO :RAR-VLR-COMPRA,
                     :RAR-ENTIOFI
                FROM  UGDTRAR
               WHERE  RAR_CUENTA  =         :RAR-CUENTA
                 AND  RAR_DESCRIPCION  LIKE :AUX-RAR-DESCRIPCION
                 AND  RAR_ENTIOFI LIKE      :WS-OFICINA
COL03            ORDER BY RAR_TIMEST_UMO DESC
COL03            FETCH FIRST 1 ROWS ONLY
           END-EXEC.

           MOVE SQLCODE                        TO DB2-RETURN-CDE

           EVALUATE SQLCODE
              WHEN ZERO
                 SET SI-VALOR-COMPRA           TO TRUE
                 MOVE RAR-ENTIOFI(1:4)         TO WS-SECUENCIA
                 MOVE RAR-VLR-COMPRA           TO WSV-VLR-BIEN
                 IF WSV-TIPO-PRODUCTO = 'V'
                    PERFORM 2331-BUSCAR-SMLV
                    COMPUTE WSV-RANGO-GAMA    = WSV-VLR-BIEN  /
                                                WSV-SALARIO-MINIMO
                 ELSE
                    MOVE ZEROS                 TO WSV-RANGO-GAMA
                 END-IF
              WHEN +100
                 SET NO-VALOR-COMPRA           TO TRUE
      *          MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
      *          MOVE SQLERRM                  TO CTPR-SQLERRM
      *          MOVE 'SIN VLR. COMPRA'        TO CTPR-VAR1-ERROR
      *          MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
      *          PERFORM 3000-FINAL-PROGRAMA
              WHEN OTHER
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE 'UGDTRAR'                TO CTPR-VAR1-ERROR
                 MOVE 'SELECT RAR UR7CCTPR'    TO CTPR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 MOVE CTPR-SQLCODE             TO CTPR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.

      *----------------------------------------------------------------*
      *                   2370-BUSCA-DTS-VEHI                          *
      *----------------------------------------------------------------*
        2370-BUSCA-DTS-VEHI.

           MOVE WS-SECUENCIA                   TO RVE-ENTIOFI(1:4)
           MOVE CTPR-ENTIOFI(5:4)              TO RVE-ENTIOFI(5:4)
           MOVE CTPR-CUENTA                    TO RVE-CUENTA
           MOVE CTPR-NUMCLIEN                  TO RVE-PRGRM-UMO

           EXEC SQL
              SELECT  RVE_TIPO_VEH   ,
                      RVE_ESTADO_VEH
                INTO :RVE-TIPO-VEH   ,
                     :RVE-ESTADO-VEH
                FROM  UGDTRVE
               WHERE  RVE_CUENTA    =  :RVE-CUENTA
      *          AND  RVE_PRGRM_UMO =  :RVE-PRGRM-UMO
                 AND  RVE_ENTIOFI   =  :RVE-ENTIOFI
COL03            ORDER BY RVE_TIMEST_UMO DESC
COL03            FETCH FIRST 1 ROWS ONLY
           END-EXEC.

           MOVE SQLCODE                        TO DB2-RETURN-CDE

           EVALUATE SQLCODE
              WHEN ZERO
      *COL14-I
                 EVALUATE WSV-TIPO-PRODUCTO
                    WHEN 'V'
      *COL14-F
                       SET SI-DTS-VEH             TO TRUE
                       MOVE RVE-TIPO-VEH          TO WSV-RANGO-TIPVEH
                       MOVE RVE-ESTADO-VEH        TO WSV-RANGO-ESTADO
      *COL14-I
                    WHEN 'H'
                    WHEN 'L'
                       MOVE RVE-ESTADO-VEH        TO WSV-RANGO-ESTADO
                 END-EVALUATE
      *COL14-F
              WHEN +100
                 SET NO-DTS-VEH                TO TRUE
      *          MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
      *          MOVE SQLERRM                  TO CTPR-SQLERRM
      *          MOVE 'SIN DTS VEHICUL'        TO CTPR-VAR1-ERROR
      *          MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
      *          PERFORM 3000-FINAL-PROGRAMA
              WHEN OTHER
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE 'UGDTRVE'                TO CTPR-VAR1-ERROR
                 MOVE 'SELECT RVE UR7CCTPR'    TO CTPR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 MOVE CTPR-SQLCODE             TO CTPR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.

      *----------------------------------------------------------------*
      *                   2460-PARM-MONTO-SOLICI                       *
      *----------------------------------------------------------------*
        2460-PARM-MONTO-SOLICI.
      *
           INITIALIZE                           UGTCDTE
           MOVE WSV-TIPO-PRODUCTO        TO DTE-TIPO-PRODUCTO
           MOVE CTPR-FECHA-PROCESO       TO DTE-FECHA-INI
                                            DTE-FECHA-FIN
           MOVE '06'                     TO DTE-COD-TIPO-PUNTAJE
           MOVE WSV-RANGO-MONTO          TO DTE-PROB-RIESGO-INICIAL
                                            DTE-PROB-RIESGO-FINAL
           MOVE WSV-RANGO-MONTO          TO WS-SMLV-MONTO
           MOVE 0                        TO WS-DESC-MONTO
      *
           EXEC SQL
             SELECT DTE_TASA_DESCUENTO
               INTO :DTE-TASA-DESCUENTO
               FROM UGDTDTE
              WHERE DTE_COD_TIPO_PUNTAJE  =:DTE-COD-TIPO-PUNTAJE
                AND DTE_TIPO_PRODUCTO     =:DTE-TIPO-PRODUCTO
                AND DTE_FECHA_INI        <=:DTE-FECHA-INI
                AND DTE_FECHA_FIN        >=:DTE-FECHA-FIN
                AND DTE_PROB_RIESGO_INICIAL <=
                                         :DTE-PROB-RIESGO-INICIAL
                AND DTE_PROB_RIESGO_FINAL   >=
                                         :DTE-PROB-RIESGO-FINAL
           END-EXEC.
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE
      *
           EVALUATE SQLCODE
              WHEN ZERO
                 MOVE DTE-TASA-DESCUENTO       TO WS-DESC-MONTO
                 ADD DTE-TASA-DESCUENTO        TO WS-TOTAL-DESC
              WHEN +100
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE WS-SMLV-MONTO            TO CTPR-VAR1-ERROR
                 MOVE 'PARAM. RANGO MONTO '    TO CTPR-VAR2-ERROR
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
              WHEN OTHER
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE 'UGDTDTE'                TO CTPR-VAR1-ERROR
                 MOVE 'RANGO MONTO  '          TO CTPR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 MOVE CTPR-SQLCODE             TO CTPR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *----------------------------------------------------------------*
      *                     2470-PARM-PLAZO
      *----------------------------------------------------------------*
       2470-PARM-PLAZO.
      *
           INITIALIZE                           UGTCDTE
           MOVE 0                               TO WS-DESC-PLAZO
           MOVE WSV-TIPO-PRODUCTO               TO DTE-TIPO-PRODUCTO
           MOVE CTPR-FECHA-PROCESO              TO DTE-FECHA-INI
                                                   DTE-FECHA-FIN
           MOVE '07'                            TO DTE-COD-TIPO-PUNTAJE
           MOVE WSV-RANGO-PLAZO                 TO DTE-RANGO-INI
                                                   DTE-RANGO-FIN
      *
           EXEC SQL
             SELECT DTE_TASA_DESCUENTO
               INTO :DTE-TASA-DESCUENTO
               FROM UGDTDTE
              WHERE DTE_COD_TIPO_PUNTAJE  =:DTE-COD-TIPO-PUNTAJE
                AND DTE_TIPO_PRODUCTO     =:DTE-TIPO-PRODUCTO
                AND DTE_FECHA_INI        <=:DTE-FECHA-INI
                AND DTE_FECHA_FIN        >=:DTE-FECHA-FIN
                AND DTE_RANGO_INI        <=:DTE-RANGO-INI
                AND DTE_RANGO_FIN        >=:DTE-RANGO-FIN
           END-EXEC.
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE
      *
           EVALUATE SQLCODE
              WHEN ZERO
                 MOVE DTE-TASA-DESCUENTO       TO WS-DESC-PLAZO
                 ADD DTE-TASA-DESCUENTO        TO WS-TOTAL-DESC
              WHEN +100
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE WSV-RANGO-PLAZO          TO CTPR-VAR1-ERROR
                 MOVE 'PARAMETRIZAR PLAZO '    TO CTPR-VAR2-ERROR
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
              WHEN OTHER
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE 'UGDTDTE '               TO CTPR-VAR1-ERROR
                 MOVE 'RANGO PLAZO '           TO CTPR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 MOVE CTPR-SQLCODE             TO CTPR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *----------------------------------------------------------------*
      *                      2480-PARM-GAMA                            *
      *----------------------------------------------------------------*
        2480-PARM-GAMA.
      *
           INITIALIZE                           UGTCDTE
           MOVE WSV-TIPO-PRODUCTO        TO DTE-TIPO-PRODUCTO
           MOVE CTPR-FECHA-PROCESO       TO DTE-FECHA-INI
                                            DTE-FECHA-FIN
           MOVE '08'                     TO DTE-COD-TIPO-PUNTAJE
           MOVE WSV-RANGO-GAMA           TO DTE-PROB-RIESGO-INICIAL
                                            DTE-PROB-RIESGO-FINAL
           MOVE WSV-RANGO-GAMA           TO WS-SMLV-GAMA
           MOVE 0                        TO WS-DESC-GAMA
      *
           EXEC SQL
             SELECT DTE_TASA_DESCUENTO
               INTO :DTE-TASA-DESCUENTO
               FROM UGDTDTE
              WHERE DTE_COD_TIPO_PUNTAJE  =:DTE-COD-TIPO-PUNTAJE
                AND DTE_TIPO_PRODUCTO     =:DTE-TIPO-PRODUCTO
                AND DTE_FECHA_INI        <=:DTE-FECHA-INI
                AND DTE_FECHA_FIN        >=:DTE-FECHA-FIN
                AND DTE_PROB_RIESGO_INICIAL <=
                                         :DTE-PROB-RIESGO-INICIAL
                AND DTE_PROB_RIESGO_FINAL   >=
                                         :DTE-PROB-RIESGO-FINAL
           END-EXEC.
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE
      *
           EVALUATE SQLCODE
              WHEN ZERO
                 MOVE DTE-TASA-DESCUENTO       TO WS-DESC-GAMA
                 ADD DTE-TASA-DESCUENTO        TO WS-TOTAL-DESC
              WHEN +100
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE WS-SMLV-GAMA             TO CTPR-VAR1-ERROR
                 MOVE 'PARAM. RANGO GAMA '     TO CTPR-VAR2-ERROR
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
              WHEN OTHER
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE 'UGDTDTE'                TO CTPR-VAR1-ERROR
                 MOVE 'RANGO GAMA   '          TO CTPR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 MOVE CTPR-SQLCODE             TO CTPR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *----------------------------------------------------------------*
      *                    2490-PARM-TIPVEH                            *
      *----------------------------------------------------------------*
        2490-PARM-TIPVEH.
      *
           INITIALIZE                    UGTCDTE
           MOVE WSV-TIPO-PRODUCTO        TO DTE-TIPO-PRODUCTO
           MOVE CTPR-FECHA-PROCESO       TO DTE-FECHA-INI
                                            DTE-FECHA-FIN
           MOVE '09'                     TO DTE-COD-TIPO-PUNTAJE
           IF WSV-RANGO-TIPVEH = 'PA'
              MOVE 'P'                   TO DTE-IND-CLIENTE-VIP
           ELSE
              MOVE 'S'                   TO DTE-IND-CLIENTE-VIP
           END-IF

           MOVE 0                        TO WS-DESC-TIPVEH
      *
           EXEC SQL
             SELECT DTE_TASA_DESCUENTO
               INTO :DTE-TASA-DESCUENTO
               FROM UGDTDTE
              WHERE DTE_COD_TIPO_PUNTAJE  =:DTE-COD-TIPO-PUNTAJE
                AND DTE_TIPO_PRODUCTO     =:DTE-TIPO-PRODUCTO
                AND DTE_FECHA_INI        <=:DTE-FECHA-INI
                AND DTE_FECHA_FIN        >=:DTE-FECHA-FIN
                AND DTE_IND_CLIENTE_VIP   =:DTE-IND-CLIENTE-VIP
           END-EXEC.
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE
      *
           EVALUATE SQLCODE
              WHEN ZERO
                 MOVE DTE-TASA-DESCUENTO       TO WS-DESC-TIPVEH
                 ADD DTE-TASA-DESCUENTO        TO WS-TOTAL-DESC
              WHEN +100
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE 'PARAM. TIPO VEHICUL'    TO CTPR-VAR2-ERROR
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
                 CONTINUE
              WHEN OTHER
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE 'UGDTDTE'                TO CTPR-VAR1-ERROR
                 MOVE 'BUSCAR TIP VEHICULO'    TO CTPR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 MOVE CTPR-SQLCODE             TO CTPR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *----------------------------------------------------------------*
      *                    2500-PARM-ESTADO                            *
      *----------------------------------------------------------------*
        2500-PARM-ESTADO.
      *
           INITIALIZE                    UGTCDTE
           MOVE WSV-TIPO-PRODUCTO        TO DTE-TIPO-PRODUCTO
           MOVE CTPR-FECHA-PROCESO       TO DTE-FECHA-INI
                                            DTE-FECHA-FIN
           MOVE '10'                     TO DTE-COD-TIPO-PUNTAJE
           MOVE WSV-RANGO-ESTADO         TO DTE-IND-CLIENTE-VIP
           MOVE 0                        TO WS-DESC-ESTADO
      *
           EXEC SQL
             SELECT DTE_TASA_DESCUENTO
               INTO :DTE-TASA-DESCUENTO
               FROM UGDTDTE
              WHERE DTE_COD_TIPO_PUNTAJE  =:DTE-COD-TIPO-PUNTAJE
                AND DTE_TIPO_PRODUCTO     =:DTE-TIPO-PRODUCTO
                AND DTE_FECHA_INI        <=:DTE-FECHA-INI
                AND DTE_FECHA_FIN        >=:DTE-FECHA-FIN
                AND DTE_IND_CLIENTE_VIP   =:DTE-IND-CLIENTE-VIP
           END-EXEC.
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE
      *
           EVALUATE SQLCODE
              WHEN ZERO
                 MOVE DTE-TASA-DESCUENTO       TO WS-DESC-ESTADO
                 ADD DTE-TASA-DESCUENTO        TO WS-TOTAL-DESC
              WHEN +100
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE 'PARAM. ESTADO VEH  '    TO CTPR-VAR2-ERROR
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
                 CONTINUE
              WHEN OTHER
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE 'UGDTDTE'                TO CTPR-VAR1-ERROR
                 MOVE 'BUSCAR ESTADO VEH  '    TO CTPR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 MOVE CTPR-SQLCODE             TO CTPR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *----------------------------------------------------------------*
      *                   2510-PARM-PORCENTAJE                         *
      *----------------------------------------------------------------*
        2510-PARM-PORCENTAJE.
      *
           COMPUTE WSV-RANGO-PORCENTA  = WSV-MONTO-SOLICI /
                                         WSV-VLR-BIEN

           INITIALIZE                           UGTCDTE
           MOVE WSV-TIPO-PRODUCTO        TO DTE-TIPO-PRODUCTO
           MOVE CTPR-FECHA-PROCESO       TO DTE-FECHA-INI
                                            DTE-FECHA-FIN
           MOVE '11'                     TO DTE-COD-TIPO-PUNTAJE
           MOVE WSV-RANGO-PORCENTA       TO DTE-PROB-RIESGO-INICIAL
                                            DTE-PROB-RIESGO-FINAL
           MOVE WSV-RANGO-PORCENTA       TO WS-PORCENTAJE
                                            WS-PORCENTAJE-S
           MOVE 0                        TO WS-DESC-PORCENTA
      *
           EXEC SQL
             SELECT DTE_TASA_DESCUENTO
               INTO :DTE-TASA-DESCUENTO
               FROM UGDTDTE
              WHERE DTE_COD_TIPO_PUNTAJE  =:DTE-COD-TIPO-PUNTAJE
                AND DTE_TIPO_PRODUCTO     =:DTE-TIPO-PRODUCTO
                AND DTE_FECHA_INI        <=:DTE-FECHA-INI
                AND DTE_FECHA_FIN        >=:DTE-FECHA-FIN
                AND DTE_PROB_RIESGO_INICIAL <=
                                         :DTE-PROB-RIESGO-INICIAL
                AND DTE_PROB_RIESGO_FINAL   >=
                                         :DTE-PROB-RIESGO-FINAL
           END-EXEC.
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE
      *
           EVALUATE SQLCODE
              WHEN ZERO
                 MOVE DTE-TASA-DESCUENTO       TO WS-DESC-PORCENTA
                 ADD DTE-TASA-DESCUENTO        TO WS-TOTAL-DESC
              WHEN +100
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE WS-PORCENTAJE            TO CTPR-VAR1-ERROR
                 MOVE 'PARAM.% FINANCIACION'   TO CTPR-VAR2-ERROR
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
              WHEN OTHER
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE 'UGDTDTE'                TO CTPR-VAR1-ERROR
                 MOVE 'RANGO % FINAN'          TO CTPR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 MOVE CTPR-SQLCODE             TO CTPR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *----------------------------------------------------------------*
      *                       2520-PARM-SEGMENTO                       *
      *----------------------------------------------------------------*
        2520-PARM-SEGMENTO.
      *
           PERFORM 25201-VALIDA-SEGMENTO

           IF PMT01-S-CODRET = '00'
              INITIALIZE                        UGTCDTE
              MOVE WSV-TIPO-PRODUCTO     TO DTE-TIPO-PRODUCTO
              MOVE CTPR-FECHA-PROCESO    TO DTE-FECHA-INI
                                            DTE-FECHA-FIN
              MOVE '12'                  TO DTE-COD-TIPO-PUNTAJE
              MOVE WSV-RANGO-SEG         TO DTE-PROB-RIESGO-INICIAL
      *                                     DTE-PROB-RIESGO-FINAL
              MOVE WSV-RANGO-SEG         TO WS-SEGMENTO
              MOVE 0                     TO WS-DESC-SEG
      *
              EXEC SQL
                SELECT DTE_TASA_DESCUENTO
                INTO :DTE-TASA-DESCUENTO
                FROM UGDTDTE
                WHERE DTE_COD_TIPO_PUNTAJE  =:DTE-COD-TIPO-PUNTAJE
                  AND DTE_TIPO_PRODUCTO     =:DTE-TIPO-PRODUCTO
                  AND DTE_FECHA_INI        <=:DTE-FECHA-INI
                  AND DTE_FECHA_FIN        >=:DTE-FECHA-FIN
                  AND DTE_PROB_RIESGO_INICIAL =
                                             :DTE-PROB-RIESGO-INICIAL
      *           AND DTE_PROB_RIESGO_INICIAL <=
      *                                      :DTE-PROB-RIESGO-INICIAL
      *           AND DTE_PROB_RIESGO_FINAL   >=
      *                                      :DTE-PROB-RIESGO-FINAL
              END-EXEC
      *
              MOVE SQLCODE                     TO DB2-RETURN-CDE
      *
              EVALUATE SQLCODE
                 WHEN ZERO
                    MOVE DTE-TASA-DESCUENTO    TO WS-DESC-SEG
                    ADD DTE-TASA-DESCUENTO     TO WS-TOTAL-DESC
                 WHEN +100
                    MOVE WSC-ALF-99            TO CTPR-CODIGO-RETORNO
                    MOVE SQLERRM               TO CTPR-SQLERRM
                    MOVE WS-SEGMENTO           TO CTPR-VAR1-ERROR
                    MOVE 'PARAM. SEGMENTO '    TO CTPR-VAR2-ERROR
                    MOVE DB2-RETURN-CDE        TO CTPR-SQLCODE
                    PERFORM 3000-FINAL-PROGRAMA
                 WHEN OTHER
                    MOVE WSC-ALF-99            TO CTPR-CODIGO-RETORNO
                    MOVE SQLERRM               TO CTPR-SQLERRM
                    MOVE 'UGDTDTE'             TO CTPR-VAR1-ERROR
                    MOVE 'RANGO SEGMENTO'      TO CTPR-VAR2-ERROR(1:16)
                    MOVE DB2-RETURN-CDE        TO CTPR-SQLCODE
                    MOVE CTPR-SQLCODE          TO CTPR-VAR2-ERROR(17:4)
                    PERFORM 3000-FINAL-PROGRAMA
              END-EVALUATE
           ELSE
              CONTINUE
           END-IF.
      *
      *----------------------------------------------------------------*
      *                   25201-VALIDA-SEGMENTO
      *----------------------------------------------------------------*
      *  ACCESO A LA RUTINA QUE RETORNA EL CODIGO TCOM DEL CLIENTE     *
      *----------------------------------------------------------------*
       25201-VALIDA-SEGMENTO.

           MOVE CTPR-NUMCLIEN                TO PMT01-E-NUMCLIEN
           MOVE '1'                          TO PMT01-E-FUNCION
           CALL WSC-PM9CT011 USING AREA-PMECT011

           EVALUATE PMT01-S-CODRET
           WHEN '00'
      *COL15A-I
              IF PMT01-S-SEGMENTO EQUAL  SPACES OR LOW-VALUES
                 MOVE ZEROS                  TO WSV-RANGO-SEG
              ELSE
      *COL15A-F
                 MOVE PMT01-S-SEGMENTO          TO WSV-RANGO-SEG
              END-IF
           WHEN OTHER
              MOVE ZEROS                     TO WSV-RANGO-SEG
           END-EVALUATE.
      *
      *----------------------------------------------------------------*
      *                       2530-PARM-COLECTIVO                      *
      *----------------------------------------------------------------*
        2530-PARM-COLECTIVO.
      *
           PERFORM 25301-VALIDA-COLECTIVO

           IF WSCLC-RETORNO = '00'
              INITIALIZE                        UGTCDTE
              MOVE WSV-TIPO-PRODUCTO     TO DTE-TIPO-PRODUCTO
              MOVE CTPR-FECHA-PROCESO    TO DTE-FECHA-INI
                                            DTE-FECHA-FIN
              MOVE '13'                  TO DTE-COD-TIPO-PUNTAJE
              MOVE WSV-RANGO-COL         TO DTE-PROB-RIESGO-INICIAL
      *                                     DTE-PROB-RIESGO-FINAL
              MOVE WSV-RANGO-COL         TO WS-COLECTIVO
              MOVE 0                     TO WS-DESC-COL
      *
              EXEC SQL
                 SELECT DTE_TASA_DESCUENTO
                 INTO :DTE-TASA-DESCUENTO
                 FROM UGDTDTE
                 WHERE DTE_COD_TIPO_PUNTAJE  =:DTE-COD-TIPO-PUNTAJE
                   AND DTE_TIPO_PRODUCTO     =:DTE-TIPO-PRODUCTO
                   AND DTE_FECHA_INI        <=:DTE-FECHA-INI
                   AND DTE_FECHA_FIN        >=:DTE-FECHA-FIN
                   AND DTE_PROB_RIESGO_INICIAL =
                                              :DTE-PROB-RIESGO-INICIAL
      *            AND DTE_PROB_RIESGO_INICIAL <=
      *                                       :DTE-PROB-RIESGO-INICIAL
      *            AND DTE_PROB_RIESGO_FINAL   >=
      *                                       :DTE-PROB-RIESGO-FINAL
              END-EXEC
      *
              MOVE SQLCODE                     TO DB2-RETURN-CDE

              EVALUATE SQLCODE
                 WHEN ZERO
                    MOVE DTE-TASA-DESCUENTO    TO WS-DESC-COL
                    ADD DTE-TASA-DESCUENTO     TO WS-TOTAL-DESC
                 WHEN +100
                    MOVE WSC-ALF-99            TO CTPR-CODIGO-RETORNO
                    MOVE SQLERRM               TO CTPR-SQLERRM
                    MOVE WS-COLECTIVO          TO CTPR-VAR1-ERROR
                    MOVE 'PARAM. COLECTIVO'    TO CTPR-VAR2-ERROR
                    MOVE DB2-RETURN-CDE        TO CTPR-SQLCODE
                    PERFORM 3000-FINAL-PROGRAMA
                 WHEN OTHER
                    MOVE WSC-ALF-99           TO CTPR-CODIGO-RETORNO
                    MOVE SQLERRM              TO CTPR-SQLERRM
                    MOVE 'UGDTDTE'            TO CTPR-VAR1-ERROR
                    MOVE 'RANGO COLECTIVO'    TO CTPR-VAR2-ERROR(1:16)
                    MOVE DB2-RETURN-CDE       TO CTPR-SQLCODE
                    MOVE CTPR-SQLCODE         TO CTPR-VAR2-ERROR(17:4)
                    PERFORM 3000-FINAL-PROGRAMA
              END-EVALUATE
           ELSE
              CONTINUE
           END-IF.
      *COL04-I
      ******************************************************************
      *  SE ADICIONAN DOS NUEVOS PARRAFOS PARM-EDAD Y PARM-SITU-LABO   *
      *            PARA OBTENER SU RESPECTIVA TASA DE DESCUENTO        *
      ******************************************************************
      *----------------------------------------------------------------*
      *                     2540-PARM-EDAD
      *----------------------------------------------------------------*
       2540-PARM-EDAD.
      *
           INITIALIZE                           UGTCDTE
                                                WS-DESC-EDAD
           PERFORM 2360-OBTENER-FEC-NACIMI
      *
           MOVE WS-TIPO-PROD                    TO WSV-TIPO-PRODUCTO
           MOVE WSV-TIPO-PRODUCTO               TO DTE-TIPO-PRODUCTO
           MOVE CTPR-FECHA-PROCESO              TO DTE-FECHA-INI
                                                   DTE-FECHA-FIN
           MOVE WS-EDAD                         TO DTE-RANGO-INI
                                                   DTE-RANGO-FIN
           MOVE '14'                            TO DTE-COD-TIPO-PUNTAJE
      *
           EXEC SQL
             SELECT DTE_TASA_DESCUENTO
               INTO :DTE-TASA-DESCUENTO
               FROM UGDTDTE
              WHERE DTE_COD_TIPO_PUNTAJE  =:DTE-COD-TIPO-PUNTAJE
                AND DTE_TIPO_PRODUCTO     =:DTE-TIPO-PRODUCTO
                AND DTE_FECHA_INI        <=:DTE-FECHA-INI
                AND DTE_FECHA_FIN        >=:DTE-FECHA-FIN
                AND DTE_RANGO_INI        <=:DTE-RANGO-INI
                AND DTE_RANGO_FIN        >=:DTE-RANGO-FIN
           END-EXEC
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE
      *
           EVALUATE SQLCODE
              WHEN ZERO
      *
                 MOVE DTE-TASA-DESCUENTO       TO WS-DESC-EDAD
      *
                 ADD DTE-TASA-DESCUENTO        TO WS-TOTAL-DESC
              WHEN +100
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE WS-EDAD                  TO CTPR-VAR1-ERROR
                 MOVE 'PARAMETRIZAR EDAD'      TO CTPR-VAR2-ERROR
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
              WHEN OTHER
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE 'UGDTDTE'                TO CTPR-VAR1-ERROR
                 MOVE 'BUSCAR RANGO '          TO CTPR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 MOVE CTPR-SQLCODE             TO CTPR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *----------------------------------------------------------------*
      *                    2550-PARM-SITU-LABO                         *
      *----------------------------------------------------------------*
        2550-PARM-SITU-LABO.
      *
           PERFORM 2370-OBTENER-SITU-LABO
           INITIALIZE                    UGTCDTE
                                         WS-DESC-SITU
           MOVE WSV-TIPO-PRODUCTO        TO DTE-TIPO-PRODUCTO
           MOVE CTPR-FECHA-PROCESO       TO DTE-FECHA-INI
                                            DTE-FECHA-FIN
           MOVE '15'                     TO DTE-COD-TIPO-PUNTAJE
           MOVE WS-SITU-LABO             TO DTE-IND-CLIENTE-VIP
      *
           EXEC SQL
             SELECT DTE_TASA_DESCUENTO
               INTO :DTE-TASA-DESCUENTO
               FROM UGDTDTE
              WHERE DTE_COD_TIPO_PUNTAJE  =:DTE-COD-TIPO-PUNTAJE
                AND DTE_TIPO_PRODUCTO     =:DTE-TIPO-PRODUCTO
                AND DTE_FECHA_INI        <=:DTE-FECHA-INI
                AND DTE_FECHA_FIN        >=:DTE-FECHA-FIN
                AND DTE_IND_CLIENTE_VIP   =:DTE-IND-CLIENTE-VIP
           END-EXEC
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE
      *
           EVALUATE SQLCODE
              WHEN ZERO
                 MOVE DTE-TASA-DESCUENTO       TO WS-DESC-SITU
                 ADD DTE-TASA-DESCUENTO        TO WS-TOTAL-DESC
              WHEN +100
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE 'PARAM. SITUACION   '    TO CTPR-VAR1-ERROR
                 MOVE 'LABORAL '               TO CTPR-VAR2-ERROR(1:8)
                 MOVE DTE-IND-CLIENTE-VIP      TO CTPR-VAR2-ERROR(9: )
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 PERFORM 3000-FINAL-PROGRAMA
              WHEN OTHER
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE 'UGDTDTE'                TO CTPR-VAR1-ERROR
                 MOVE 'BUSCAR SITU. LABORA'    TO CTPR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 MOVE CTPR-SQLCODE             TO CTPR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *COL04-F
      *----------------------------------------------------------------*
      *                   25301-VALIDA-COLECTIVO
      *----------------------------------------------------------------*
      *  ACCESO A LA RUTINA QUE RETORNA EL CODIGO DE COLECTIVO DEL     *
      *  CLIENTE.
      *----------------------------------------------------------------*
       25301-VALIDA-COLECTIVO.

           MOVE 'S1'                         TO WECLC-OPCION
           MOVE CTPR-NUMCLIEN                TO WECLC-NUMCLIEN

           CALL WSC-PE9C0CLC USING AREA-PE9TCLC

           EVALUATE WSCLC-RETORNO
           WHEN '00'
              MOVE WSCLC-CODIGO-COL          TO WSV-RANGO-COL
           WHEN OTHER
              MOVE ZEROS                     TO WSV-RANGO-COL
           END-EVALUATE.
      *
      *COL05-I
      *----------------------------------------------------------------*
      *                   25302-VALIDA-SUBPRODUCTO
      *----------------------------------------------------------------*
      *  VALIDA EL SUBPRODUCTO PARA SABER SI ES DE COMPRA DE CARTERA   *
      *----------------------------------------------------------------*
       25302-VALIDA-SUBPRODUCTO.

           INITIALIZE UGTCT37
           MOVE '9931'                        TO T37-SECCION
           MOVE CTPR-SUBPRO                   TO T37-ELEMENTO(1:4)
      *
             EXEC SQL
                 SELECT RESTO
                   INTO :T37-RESTO
                   FROM UGDTT37
                  WHERE SECCION  = :T37-SECCION
                    AND ELEMENTO   = :T37-ELEMENTO
             END-EXEC
      *
           MOVE SQLCODE                        TO DB2-RETURN-CDE
      *
           IF DB2-OK AND SQLWARN0 = SPACES
              EVALUATE WSV-TIPO-PRODUCTO
                 WHEN 'N'
                       MOVE 'NC'               TO UGNRA-PRODUCTO
                       MOVE 'CKC CONSUMO'      TO WS-DESTINO
      *COL13-I
                       IF SW-SI-CON-TASAV
                          MOVE 'NK'            TO UGNRA-PRODUCTO
                          MOVE 'NCK CONSUMO TASA VAR' TO WS-DESTINO
                       END-IF
      *COL13-F
                 WHEN 'V'
                       MOVE 'VC'               TO UGNRA-PRODUCTO
                       MOVE 'CKC VEHICULO'     TO WS-DESTINO
      *COL13-I
                       IF SW-SI-VEH-TASAV
                          MOVE 'VK'            TO UGNRA-PRODUCTO
                          MOVE 'VEK VEHICULO TASA VA' TO WS-DESTINO
                       END-IF
      *COL13-F
      *COL14-I
      *           WHEN 'H'
      *                 IF SW-SI-HIPOT-UVR
      *                    MOVE 'HK'            TO UGNRA-PRODUCTO
      *                    MOVE 'CKC HIPOTECARIO UVR'
      *                                         TO WS-DESTINO
      *                 ELSE
      *                    MOVE 'HC'            TO UGNRA-PRODUCTO
      *                    MOVE 'CKC HIPOTECARIO'
      *                                         TO WS-DESTINO
      *                 END-IF
      *COL14-F
              END-EVALUATE
           ELSE
              IF DB2-NOTFND AND SQLWARN0 = SPACES
                 SET SW-SI-SUBPRO-X            TO TRUE
              ELSE
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE 'UGDTT37'                TO CTPR-VAR1-ERROR
                 MOVE 'VAL TIPO CARTERA'       TO CTPR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 MOVE CTPR-SQLCODE             TO CTPR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
              END-IF
           END-IF.
      *COL05-F
      *COL07-I
      *----------------------------------------------------------------*
      *                   25304-CONSULTA-HV-HS
      *----------------------------------------------------------------*
      *  DETERMINA SI HIPOTECARIO CORRESPONDE A VIS O SOSTENIBLE       *
      *----------------------------------------------------------------*
       25304-CONSULTA-HV-HS.

           SET SW-NO-HIPOT-SOS              TO TRUE
           SET SW-NO-HIPOT-VIS              TO TRUE
           MOVE WSC-ALF-5011                TO WS-SECCION
           MOVE CTPR-SUBPRO                 TO WS-ELEMENTO(1:4)
      *
           PERFORM 253041-CONSULTA-UR2CIT37
      *
           IF SW-SI-PARAM-T37
             SET SW-SI-HIPOT-SOS              TO TRUE
      *COL14-I
      *     ELSE
      *       MOVE WSC-ALF-1737                TO WS-SECCION
      *       MOVE WSC-PRODUC-96               TO WS-ELEMENTO(1:10)
      *       MOVE CTPR-SUBPRO                 TO WS-ELEMENTO(11:4)
      *       PERFORM 253041-CONSULTA-UR2CIT37
      *       IF SW-SI-PARAM-T37
      *         SET SW-SI-HIPOT-VIS              TO TRUE
      *       END-IF
      *COL14-F
           END-IF.
      *
      *COL14-I
      *----------------------------------------------------------------*
      *                  25303-ASIGNAR-PROD                            *
      *----------------------------------------------------------------*
      *  DETERMINA EL PRODUCTO SEGÚN EL TIPO DE PRODUCTO VIS/NOVIS,    *
      *  UVR/PESOS, SI ES SOSTENIBLE                                   *
      *----------------------------------------------------------------*
       25303-ASIGNAR-PROD.
      *
           PERFORM 25304-CONSULTA-HV-HS
           PERFORM 25305-CONSULTA-VIS
      *
           EVALUATE WSV-TIPO-PRODUCTO
              WHEN 'H'
                 EVALUATE TRUE
                    WHEN SW-SI-HIPOT-VIS AND SW-NO-HIPOT-UVR
                     AND SW-NO-HIPOT-SOS
                       MOVE 'HV'           TO UGNRA-PRODUCTO
                       MOVE 'HIPOT VIS PESOS'
                                           TO WS-DESTINO
                    WHEN SW-SI-HIPOT-VIS AND SW-SI-HIPOT-UVR
                     AND SW-NO-HIPOT-SOS
                       MOVE 'HA'           TO UGNRA-PRODUCTO
                       MOVE 'HIPOT VIS UVR'
                                           TO WS-DESTINO
                    WHEN SW-NO-HIPOT-VIS AND SW-NO-HIPOT-UVR
                     AND SW-NO-HIPOT-SOS
                       MOVE 'H '           TO UGNRA-PRODUCTO
                       MOVE 'HIPOT NO VIS PESOS'
                                           TO WS-DESTINO
                    WHEN SW-NO-HIPOT-VIS AND SW-SI-HIPOT-UVR
                     AND SW-NO-HIPOT-SOS
                       MOVE 'HU'           TO UGNRA-PRODUCTO
                       MOVE 'HIPOT NO VIS UVR'
                                           TO WS-DESTINO
                    WHEN SW-SI-HIPOT-VIS AND SW-NO-HIPOT-UVR
                     AND SW-SI-HIPOT-SOS
                       MOVE 'HB'           TO UGNRA-PRODUCTO
                       MOVE 'HIPOT VIS PESOS SOST'
                                           TO WS-DESTINO
                    WHEN SW-SI-HIPOT-VIS AND SW-SI-HIPOT-UVR
                     AND SW-SI-HIPOT-SOS
                       MOVE 'HC'           TO UGNRA-PRODUCTO
                       MOVE 'HIPOT VIS UVR SOST'
                                           TO WS-DESTINO
                    WHEN SW-NO-HIPOT-VIS AND SW-NO-HIPOT-UVR
                     AND SW-SI-HIPOT-SOS
                       MOVE 'HD'           TO UGNRA-PRODUCTO
                       MOVE 'HIPOT NOVIS PESOS SOS'
                                           TO WS-DESTINO
                    WHEN SW-NO-HIPOT-VIS AND SW-SI-HIPOT-UVR
                     AND SW-SI-HIPOT-SOS
                       MOVE 'HE'           TO UGNRA-PRODUCTO
                       MOVE 'HIPOT NOVIS UVR SOST'
                                           TO WS-DESTINO
                 END-EVALUATE
              WHEN 'L'
                 EVALUATE TRUE
                    WHEN SW-SI-HIPOT-VIS AND SW-NO-HIPOT-UVR
                     AND SW-NO-HIPOT-SOS
                       MOVE 'LV'           TO UGNRA-PRODUCTO
                       MOVE 'LEASING VIS PESOS'
                                           TO WS-DESTINO
                    WHEN SW-SI-HIPOT-VIS AND SW-SI-HIPOT-UVR
                     AND SW-NO-HIPOT-SOS
                       MOVE 'LA'           TO UGNRA-PRODUCTO
                       MOVE 'LEASING VIS UVR'
                                           TO WS-DESTINO
                    WHEN SW-NO-HIPOT-VIS AND SW-NO-HIPOT-UVR
                     AND SW-NO-HIPOT-SOS
                       MOVE 'L '           TO UGNRA-PRODUCTO
                       MOVE 'LEASING NO VIS PESOS'
                                           TO WS-DESTINO
                    WHEN SW-NO-HIPOT-VIS AND SW-SI-HIPOT-UVR
                     AND SW-NO-HIPOT-SOS
                       MOVE 'LB'           TO UGNRA-PRODUCTO
                       MOVE 'LEASING NO VIS UVR'
                                           TO WS-DESTINO
                    WHEN SW-SI-HIPOT-VIS AND SW-NO-HIPOT-UVR
                     AND SW-SI-HIPOT-SOS
                       MOVE 'LC'           TO UGNRA-PRODUCTO
                       MOVE 'LEASING VIS PESOS SOS'
                                           TO WS-DESTINO
                    WHEN SW-SI-HIPOT-VIS AND SW-SI-HIPOT-UVR
                     AND SW-SI-HIPOT-SOS
                       MOVE 'LD'           TO UGNRA-PRODUCTO
                       MOVE 'LEASING VIS UVR SOST'
                                           TO WS-DESTINO
                    WHEN SW-NO-HIPOT-VIS AND SW-NO-HIPOT-UVR
                     AND SW-SI-HIPOT-SOS
                       MOVE 'LE'           TO UGNRA-PRODUCTO
                       MOVE 'LEASING NOVIS PES SOS'
                                           TO WS-DESTINO
                    WHEN SW-NO-HIPOT-VIS AND SW-SI-HIPOT-UVR
                     AND SW-SI-HIPOT-SOS
                       MOVE 'LF'           TO UGNRA-PRODUCTO
                       MOVE 'LEASING NOVIS UVR SOS'
                                           TO WS-DESTINO
                 END-EVALUATE
           END-EVALUATE
           IF WS-SITU-LABO = '3'
              PERFORM 25306-CONSULTA-PROFESION-NICHO
           END-IF

           PERFORM 25307-CONSULTA-DESTINO-SUBPRO

           MOVE WS-DEST-SUBPRO         TO WSV-RANGO-COL

           EVALUATE TRUE
              WHEN SW-SI-PROY-FINAN
                 MOVE 1                TO WSV-RANGO-SEG
              WHEN SW-NO-PROY-FINAN
                 MOVE 2                TO WSV-RANGO-SEG
              WHEN SW-NA-PROY-FINAN
                 MOVE 0                TO WSV-RANGO-SEG
           END-EVALUATE.
      *----------------------------------------------------------------*
      *                   25305-CONSULTA-VIS
      *----------------------------------------------------------------*
      *  DETERMINA SI EL SUBPRODUCTO CORRESPONDE A VIS O NO VIS       *
      *  MEDIANTE LA CONSULTA A LA SECCION 1737 DE FORMA INDEPENDIENTE *
      *----------------------------------------------------------------*
       25305-CONSULTA-VIS.

           SET SW-NO-HIPOT-VIS              TO TRUE
           MOVE WSC-ALF-1737                TO WS-SECCION
           MOVE WSC-PRODUC-96               TO WS-ELEMENTO(1:10)
           MOVE CTPR-SUBPRO                 TO WS-ELEMENTO(11:4)
      *
           PERFORM 253041-CONSULTA-UR2CIT37
      *
           IF SW-SI-PARAM-T37
              SET SW-SI-HIPOT-VIS           TO TRUE
           ELSE
              SET SW-NO-HIPOT-VIS           TO TRUE
           END-IF.
      *
      *----------------------------------------------------------------*
      *                   25306-CONSULTA-PROFESION-NICHO
      *----------------------------------------------------------------*
      *  DETERMINA SI LA PROFESION DEL CLIENTE INDEPENDIENTE           *
      *  PERTENECE A UN NICHO HIPOTECARIO/LEASING MEDIANTE LA          *
      *  CONSULTA A LA SECCION 9639 DE LA UMTA                         *
      *----------------------------------------------------------------*
       25306-CONSULTA-PROFESION-NICHO.
      *
           MOVE SPACES                      TO WS-ELEMENTO
           MOVE WSC-ALF-9639                TO WS-SECCION
           MOVE 'N-HX-'                     TO WS-ELEMENTO(1:5)
      * SE VALIDA NICHO CON CIIU DE LA PEDT001 CAMPO ACTOGIRO
      * VALIDANDO SI EXISTE DENTRO DE LA PARAMETRIA 9639
           MOVE PE001-ACTOGIRO(8:4)         TO WS-ELEMENTO(6:4)
      *
           PERFORM 253041-CONSULTA-UR2CIT37
      *
           IF SW-SI-PARAM-T37
              MOVE '6'                      TO WS-SITU-LABO
           END-IF.
      *
      *----------------------------------------------------------------*
      *                   25307-CONSULTA-DESTINO-SUBPRO
      *----------------------------------------------------------------*
      *  DETERMINA EL DESTINO DEL SUBPRODUCTO Y SI PERTENECE A UN      *
      *  PROYECTO FINANCIADO/ALIADO MEDIANTE LA CONSULTA A LA          *
      *  SECCION 9639 DE LA UMTA CON PREFIJO S-                        *
      *----------------------------------------------------------------*
       25307-CONSULTA-DESTINO-SUBPRO.
      *
           MOVE SPACES                      TO WS-ELEMENTO
           MOVE ZEROS                       TO WS-DEST-SUBPRO
           MOVE SPACES                      TO WS-IND-PROY-FINAN
           SET  SW-NA-PROY-FINAN            TO TRUE
           MOVE WSC-ALF-9639                TO WS-SECCION
           MOVE 'S-'                        TO WS-ELEMENTO(1:2)
           MOVE CTPR-SUBPRO                 TO WS-ELEMENTO(3:4)
      *
           PERFORM 253041-CONSULTA-UR2CIT37
      *
           IF SW-SI-PARAM-T37
              UNSTRING IT37-RESTO
                 DELIMITED BY ';'
                 INTO WS-DEST-SUBPRO
                      WS-IND-PROY-FINAN
              END-UNSTRING
              EVALUATE WS-IND-PROY-FINAN
                 WHEN 'SI'
                    SET SW-SI-PROY-FINAN    TO TRUE
                 WHEN 'NO'
                    SET SW-NO-PROY-FINAN    TO TRUE
                 WHEN OTHER
                    SET SW-NA-PROY-FINAN    TO TRUE
              END-EVALUATE
           ELSE
              MOVE ZEROS                    TO WS-DEST-SUBPRO
              MOVE SPACES                   TO WS-IND-PROY-FINAN
              SET  SW-NA-PROY-FINAN         TO TRUE
           END-IF.
      *COL14-F
      *
      *----------------------------------------------------------------*
      *                  253041-CONSULTA-UR2CIT37
      *----------------------------------------------------------------*
      *  REALIZA LLAMADO A LA RUTINA DE PARAMETRIA UR2CIT37            *
      *----------------------------------------------------------------*
       253041-CONSULTA-UR2CIT37.
      *
           SET SW-NO-PARAM-T37              TO TRUE
           INITIALIZE UGWCIT37-REG
           MOVE WS-SECCION                  TO IT37-SECCION
           MOVE WS-ELEMENTO                 TO IT37-ELEMENTO
           MOVE WSC-ALF-D                   TO IT37-CICS
      *
           EXEC CICS
                LINK PROGRAM(WSC-UR2CIT37)
                COMMAREA(UGWCIT37-REG)
                NOHANDLE
           END-EXEC
      *
           EVALUATE IT37-CODRETORNO
             WHEN '00'
                 SET SW-SI-PARAM-T37     TO TRUE
              WHEN '10'
                 SET SW-NO-PARAM-T37     TO TRUE
              WHEN OTHER
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE 'UGDTT37'                TO CTPR-VAR1-ERROR
                 MOVE 'SECCION '               TO CTPR-VAR2-ERROR(1:08)
                 MOVE IT37-SECCION             TO CTPR-VAR2-ERROR(9:04)
                 MOVE IT37-SQLCODE             TO CTPR-SQLCODE
                 MOVE CTPR-SQLCODE             TO CTPR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *COL07-F
      *
      *----------------------------------------------------------------*
      *                        INSERTAR-UGDTRAR                        *
      *  INSERTA POR CONTRATO EL PUNTAJE DE LAS NUEVAS VARIABALES PARA *
      *  EL CALCULO DE LA TASA RAR
      *----------------------------------------------------------------*
        INSERTAR-UGDTRAR.

      *@COL12-JNS-INI                                                   00820000
      *    INITIALIZE DCLUGDTRAR
           INITIALIZE UGTCRAR
      *@COL12-JNS-INI                                                   00820000
           MOVE '%'                     TO WS-OFICINA(1:1)
           MOVE CTPR-ENTIOFI(5:4)       TO WS-OFICINA(2:4)              05080100
      *    MOVE CTPR-ENTIOFI            TO RAR-ENTIOFI                  05080100
           MOVE CTPR-CUENTA             TO RAR-CUENTA                   05080200
           MOVE CTPR-FECHA-PROCESO      TO RAR-FECMOV                   05080400
           MOVE WSV-RANGO-MONTO         TO RAR-MONTO-FINA               05080900
           MOVE WS-DESC-MONTO           TO RAR-DSC-MONTO                05081000
      *    MOVE WSV-RANGO-PLAZO         TO RAR-PLAZO-MES                05081100
           MOVE WSV-RANGO-PLAZO-I       TO RAR-PLAZO-MES                05081100
           MOVE WS-DESC-PLAZO           TO RAR-DSC-PLAZO-MES            05081200
      *    MOVE WSV-RANGO-PORCENTA      TO RAR-DESCRIPCION(1:7)
      *    MOVE WSV-RANGO-PORCENTA      TO WS-PORCENTA-A
      *    MOVE WS-PORCENTA             TO RAR-DESCRIPCION(1:7)
           MOVE WS-PORCENTAJE-S         TO RAR-DESCRIPCION(1:7)
           MOVE CTPR-NUMCLIEN           TO RAR-DESCRIPCION(8: )
           MOVE RAR-DESCRIPCION(8: )    TO AUX-RAR-DESCRIPCION(2:8)
           MOVE '%'                     TO AUX-RAR-DESCRIPCION(1:1)
           MOVE '%'                     TO AUX-RAR-DESCRIPCION(10:1)
           MOVE WS-DESC-PORCENTA        TO RAR-DSC-PORC-FINA            05082000
           MOVE WSV-RANGO-SEG           TO RAR-SEGMENTO                 05082100
           MOVE WS-DESC-SEG             TO RAR-DSC-SEGMENTO             05082200
           MOVE WSV-RANGO-COL           TO RAR-COLECTIVO                05082300
           MOVE WS-DESC-COL             TO RAR-DSC-COLECTIVO            05082400
      *COL04-I
           MOVE WS-EDAD                 TO RAR-EDAD
           MOVE WS-DESC-EDAD            TO RAR-DSC-EDAD
           MOVE WS-SITU-LABO            TO RAR-SITU-LABO
           MOVE WS-DESC-SITU            TO RAR-DSC-SITU-LABO
      *COL04-F
      *    MOVE SPACES                  TO RAR-DESCRIPCION              05082500
           MOVE CTPR-ENTIOFI            TO RAR-USERID-UMO               05082600
           MOVE 'U040'                  TO RAR-NETNAME-UMO              05082700
           MOVE 'UR7CCTPR'              TO RAR-PRGRM-UMO                05082800
           PERFORM UPDATE-UGDTRAR.
      *
      *----------------------------------------------------------------*
      *                       UPDATE-UGDTRAR                           *
      *  INSERTA POR CONTRATO EL PUNTAJE DE LAS NUEVAS VARIABALES PARA *
      *  EL CALCULO DE LA TASA RAR
      *----------------------------------------------------------------*
        UPDATE-UGDTRAR.

           EXEC SQL
              UPDATE UGDTRAR
              SET RAR_FECMOV             = :RAR-FECMOV            ,
                  RAR_MONTO_FINA         = :RAR-MONTO-FINA        ,
                  RAR_DSC_MONTO          = :RAR-DSC-MONTO         ,
                  RAR_PLAZO_MES          = :RAR-PLAZO-MES         ,
                  RAR_DSC_PLAZO_MES      = :RAR-DSC-PLAZO-MES     ,
                  RAR_DESCRIPCION        = :RAR-DESCRIPCION       ,
                  RAR_DSC_PORC_FINA      = :RAR-DSC-PORC-FINA     ,
                  RAR_SEGMENTO           = :RAR-SEGMENTO          ,
                  RAR_DSC_SEGMENTO       = :RAR-DSC-SEGMENTO      ,
                  RAR_COLECTIVO          = :RAR-COLECTIVO         ,
                  RAR_DSC_COLECTIVO      = :RAR-DSC-COLECTIVO     ,
      *COL04-I
                  RAR_EDAD               = :RAR-EDAD              ,
                  RAR_DSC_EDAD           = :RAR-DSC-EDAD          ,
                  RAR_SITU_LABO          = :RAR-SITU-LABO         ,
                  RAR_DSC_SITU_LABO      = :RAR-DSC-SITU-LABO     ,
      *COL04-F
                  RAR_USERID_UMO         = :RAR-USERID-UMO        ,
                  RAR_NETNAME_UMO        = :RAR-NETNAME-UMO       ,
                  RAR_PRGRM_UMO          = :RAR-PRGRM-UMO         ,
                  RAR_TIMEST_UMO         =  CURRENT TIMESTAMP
              WHERE  RAR_CUENTA          = :RAR-CUENTA
                AND  RAR_DESCRIPCION  LIKE :AUX-RAR-DESCRIPCION
                AND  RAR_ENTIOFI LIKE      :WS-OFICINA
           END-EXEC

           MOVE SQLCODE                        TO DB2-RETURN-CDE

           EVALUATE SQLCODE
              WHEN ZERO
                 PERFORM 888888-COMMIT
              WHEN OTHER
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE 'UGDTRAR'                TO CTPR-VAR1-ERROR
                 MOVE 'UPDATE RAR UR7CCTPR'    TO CTPR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 MOVE CTPR-SQLCODE             TO CTPR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      *
      *----------------------------------------------------------------*
      *                        INSERTAR-UGDTRVE                        *
      *  INSERTA POR CONTRATO EL PUNTAJE DE LAS NUEVAS VARIABALES PARA *
      *  EL CALCULO DE LA TASA RAR PARA VEHICULO
      *----------------------------------------------------------------*
        INSERTAR-UGDTRVE.

      *@COL12-JNS-INI                                                   00820000
      *    INITIALIZE DCLUGDTRVE
           INITIALIZE UGTCRVE
      *@COL12-JNS-INI                                                   00820000
           MOVE WS-SECUENCIA            TO RVE-ENTIOFI(1:4)
           MOVE CTPR-ENTIOFI(5:4)       TO RVE-ENTIOFI(5:4)             05080100
           MOVE CTPR-CUENTA             TO RVE-CUENTA                   05080200
           MOVE WSV-RANGO-GAMA          TO RVE-GAMA-VEH                 05081300
           MOVE WS-DESC-GAMA            TO RVE-DSC-GAMA-VEH             05081400
           MOVE WS-DESC-TIPVEH          TO RVE-DSC-TIPO-VEH             05081600
           MOVE WS-DESC-ESTADO          TO RVE-DSC-ESTD-VEH             05081800
           MOVE CTPR-ENTIOFI            TO RVE-USERID-UMO               05082600
           MOVE 'U040'                  TO RVE-NETNAME-UMO              05082700
      *    MOVE 'UR7CCTPR'              TO RVE-PRGRM-UMO                05082800
           MOVE CTPR-NUMCLIEN           TO RVE-PRGRM-UMO                05082800
           PERFORM UPDATE-UGDTRVE.
      *
      *----------------------------------------------------------------*
      *                       UPDATE-UGDTRVE                           *
      *  INSERTA POR CONTRATO EL PUNTAJE DE LAS NUEVAS VARIABALES PARA *
      *  EL CALCULO DE LA TASA RAR PARA VEHICULOS
      *----------------------------------------------------------------*
        UPDATE-UGDTRVE.

           EXEC SQL
              UPDATE UGDTRVE
              SET RVE_GAMA_VEH           = :RVE-GAMA-VEH          ,
                  RVE_DSC_GAMA_VEH       = :RVE-DSC-GAMA-VEH      ,
                  RVE_DSC_TIPO_VEH       = :RVE-DSC-TIPO-VEH      ,
                  RVE_DSC_ESTD_VEH       = :RVE-DSC-ESTD-VEH      ,
                  RVE_USERID_UMO         = :RVE-USERID-UMO        ,
                  RVE_NETNAME_UMO        = :RVE-NETNAME-UMO       ,
                  RVE_PRGRM_UMO          = :RVE-PRGRM-UMO         ,
                  RVE_TIMEST_UMO         =  CURRENT TIMESTAMP
              WHERE  RVE_CUENTA          = :RVE-CUENTA
      *         AND  RVE_PRGRM_UMO       = :RVE-PRGRM-UMO
                AND RVE_ENTIOFI          = :RVE-ENTIOFI
           END-EXEC

           MOVE SQLCODE                        TO DB2-RETURN-CDE

           EVALUATE SQLCODE
              WHEN ZERO
                 PERFORM 888888-COMMIT
              WHEN OTHER
                 MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                 MOVE SQLERRM                  TO CTPR-SQLERRM
                 MOVE 'UGDTRVE'                TO CTPR-VAR1-ERROR
                 MOVE 'UPDATE RVE UR7CCTPR'    TO CTPR-VAR2-ERROR(1:16)
                 MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                 MOVE CTPR-SQLCODE             TO CTPR-VAR2-ERROR(17:4)
                 PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *
      ******************************************************************
      *                       PARRAFO DE COMMIT
      ******************************************************************
       888888-COMMIT.

           EXEC SQL
             COMMIT
           END-EXEC
           MOVE SQLCODE                       TO DB2-RETURN-CDE
           IF DB2-OK
              CONTINUE
           ELSE
              IF DB2-NOTFND
                 MOVE 'UGE0939'               TO CTPR-VAR1-ERROR
                 MOVE 'ERROR EN COMMIT '      TO CTPR-VAR2-ERROR
                 PERFORM 3000-FINAL-PROGRAMA
              END-IF
           END-IF.
      *
      ******************************************************************
      *                       VALIDA-RELACION                          *
      ******************************************************************
       VALIDA-RELACION.

           INITIALIZE AUX-RELACION

           MOVE CTPR-ENTIOFI     TO REL-ENTIOFI
           MOVE CTPR-CUENTA      TO REL-CUENTA

           EXEC SQL
             SELECT ENTIOFI_REL,
                    CUENTA_REL
               INTO
                    :REL-ENTIOFI-REL,
                    :REL-CUENTA-REL
               FROM UGDTREL
               WHERE ENTIOFI = :REL-ENTIOFI AND
                     CUENTA  = :REL-CUENTA
               FETCH FIRST 1 ROWS ONLY
           END-EXEC

           MOVE SQLCODE TO DB2-RETURN-CDE

           EVALUATE SQLCODE
             WHEN ZEROES
                MOVE 'S' TO AUX-RELACION
             WHEN +100
                MOVE 'N' TO AUX-RELACION
             WHEN OTHER
                MOVE WSC-ALF-99               TO CTPR-CODIGO-RETORNO
                MOVE SQLERRM                  TO CTPR-SQLERRM
                MOVE 'UGDTREL'                TO CTPR-VAR1-ERROR
                MOVE 'BUSCAR RELAC'           TO CTPR-VAR2-ERROR(1:16)
                MOVE DB2-RETURN-CDE           TO CTPR-SQLCODE
                MOVE CTPR-SQLCODE             TO CTPR-VAR2-ERROR(17:4)
                PERFORM 3000-FINAL-PROGRAMA
           END-EVALUATE.
      *COL02-F
      *COL13-I
      ******************************************************************
      *                    2221-VALIDAR-TASA-VARIABLE                  *
      * SE VERIFICA SI EL SUBPRODUCTO CORRESPONDE A CONSUMO O VEHICULO *
      * CUOTA FIJA TASA VARIABLE                                       *
      ******************************************************************
       2221-VALIDAR-TASA-VARIABLE.
      *
           SET SW-NO-VEH-TASAV              TO TRUE
           SET SW-NO-CON-TASAV              TO TRUE
      *COL15-I
           SET SW-NO-LIB-TASAV              TO TRUE
      *COL15-F
           MOVE WSC-ALF-0028                TO WS-SECCION
           MOVE CTPR-SUBPRO                 TO WS-ELEMENTO(1:4)
      *
           PERFORM 253041-CONSULTA-UR2CIT37
      *
           MOVE SPACES TO WS-SECCION
                          WS-ELEMENTO
           IF SW-SI-PARAM-T37
              EVALUATE WSV-TIPO-PRODUCTO
                 WHEN 'N'
                   SET SW-SI-CON-TASAV      TO TRUE
                 WHEN 'V'
                   SET SW-SI-VEH-TASAV      TO TRUE
      *COL15-I
                 WHEN 'Z'
                   SET SW-SI-LIB-TASAV      TO TRUE
      *COL15-F
              END-EVALUATE
           END-IF.
      *COL13-F