      *_____________________ INICIO PROGRAMA __________________________*
       IDENTIFICATION DIVISION.
       PROGRAM-ID. UG9C0NRA.
       AUTHOR. BBVA(LUIS SANDON).
       DATE-WRITTEN. 06/11/2025.
      *________________________________________________________________*
      *                     DESCRIPCION DEL PROCESO                    *
      *                                                                *
      *   RUTINA DE ACCESO A LA TABLA UGDTNRA                          *
      *                                                                *
      * FEATURE....: COLONEPRE1-16282                                  *
      * ENABLER....: N/A                                               *
      * HUQA.......: COLONEPRE1-16737                                  *
      *                                                                *
      *________________________________________________________________*
      *   OPCION                                                       *
      *   S1           CONSULTA REGISTRO                               *
      *   I1           INSERTA REGISTRO                                *
      *   U1           ACTUALIZA REGISTRO                              *
      *   D1           ELIMINACION REGISTRO                            *
      *________________________________________________________________*
      *                    LOG DE MODIFICACIONES                       *
      *________________________________________________________________*
      *  AUTOR   FECHA  PETICION             DESCRIPCION               *
      * _______ _______ _________ ___________________________________  *
      *                                                                *
      *________________________________________________________________*
      *                     ENVIRONMENT DIVISION                       *
      *________________________________________________________________*
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. IBM-3090.
       OBJECT-COMPUTER. IBM-3090.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
      *________________________________________________________________*
      *                       DATA DIVISION                            *
      *________________________________________________________________*
       DATA DIVISION.
       FILE SECTION.
       WORKING-STORAGE SECTION.
      *________________________________________________________________*
      *                             DCL'S                              *
      *________________________________________________________________*

      * INCLUDE DEL SQLCA *
           EXEC SQL
                INCLUDE SQLCA
           END-EXEC.

      * AREA DE LA TABLA DB2 UGDTNRA *
           EXEC SQL
                INCLUDE UGTCNRA
           END-EXEC.

           EXEC SQL
                INCLUDE UGGTNRA
           END-EXEC.

      *________________________________________________________________*
      *                          SWITCHES                              *
      *________________________________________________________________*
       01 WSS-SWITCHES.

          05 WSS-RETURN-CDE                PIC S9(9) VALUE ZEROS.
             88 WSS-OK                               VALUE +0.
             88 WSS-NOTFND                           VALUE +100.
             88 WSS-DUPREC                           VALUES -803, -811.
             88 WSS-NOTOK                            VALUE +999.

      *________________________________________________________________*
      *                        WSV-VARIABLES                           *
      *________________________________________________________________*
      *01 WSV-VARIABLES.

      *________________________________________________________________*
      *                      WSC-CONSTANTES                            *
      *________________________________________________________________*
       01 WSC-CONSTANTES.
          05 WSC-OPCION-S1                 PIC X(02) VALUE 'S1'.
          05 WSC-OPCION-I1                 PIC X(02) VALUE 'I1'.
          05 WSC-OPCION-U1                 PIC X(02) VALUE 'U1'.
          05 WSC-OPCION-D1                 PIC X(02) VALUE 'D1'.
          05 WSC-UG9C0NRA                  PIC X(08) VALUE 'UG9C0NRA'.

      *________________________________________________________________*
      *                         MENSAJES                               *
      *________________________________________________________________*
       01 MENSAJES-ERROR.
          05 CON-ERR-NOTFOUND              PIC X(100) VALUE
                             'REGISTRO INEXISTENTE'.


      *________________________________________________________________*
      *                            COPYS                               *
      *________________________________________________________________*


      *________________________________________________________________*
      *                       LINKAGE SECTION                          *
      *________________________________________________________________*
       LINKAGE SECTION.
         COPY UGWC3NRA.

      *________________________________________________________________*
      *           P R O C E D U R E   D I V I S I O N                  *
      *________________________________________________________________*
       PROCEDURE DIVISION USING UGWC3NRA.

           PERFORM 100000-INICIO
           PERFORM 200000-PROCESO
           PERFORM 300000-FINAL.

      *________________________________________________________________*
      *                        100000-INICIO                           *
      *    REALIZA EL PROCESO DE INICIO DE LAS VARIBLES DE PROCESO     *
      *________________________________________________________________*
       100000-INICIO.

           INITIALIZE UGTCNRA.

      *________________________________________________________________*
      *              200000-PROCESO                                    *
      *________________________________________________________________*
       200000-PROCESO.

           EVALUATE 0NRA-OPCION
               WHEN WSC-OPCION-S1
                    PERFORM 2000S1-CONSULTA
               WHEN WSC-OPCION-I1
                    PERFORM 2000I1-INSERTA
               WHEN WSC-OPCION-U1
                    PERFORM 2000U1-ACTUALIZA
               WHEN WSC-OPCION-D1
                    PERFORM 2000D1-ELIMINA
               WHEN OTHER
                    MOVE '10'              TO 0NRA-RETORNO
                    MOVE 'OPCION INVALIDA' TO 0NRA-DESCERROR
                    MOVE 'UGDTNRA'         TO 0NRA-TABLA
                    MOVE ZEROS             TO 0NRA-SQL
           END-EVALUATE.

      *________________________________________________________________*
      *                    CONSULTA-UGDTNRA                            *
      *________________________________________________________________*
       2000S1-CONSULTA.

           INITIALIZE UGTCNRA

           MOVE 0NRA-UGTCNRA               TO UGTCNRA

           EXEC SQL
               SELECT
                      NRA_TIPO_PRODUCTO   ,
                      NRA_VARIABLE        ,
                      NRA_CONSECUTIVO     ,
                      NRA_FECHA_INI       ,
                      NRA_FECHA_FIN       ,
                      NRA_RANGO_INI       ,
                      NRA_RANGO_FIN       ,
                      NRA_IND_DOM_NOMINA  ,
                      NRA_SITUA_LABORAL   ,
                      NRA_MONTO_INICIAL   ,
                      NRA_MONTO_FINAL     ,
                      NRA_SEGMENTO        ,
                      NRA_IND_CLIENTE_VIP ,
                      NRA_RANGO_RIESGO_INI,
                      NRA_RANGO_RIESGO_FIN,
                      NRA_IND_ESTADO_VEH  ,
                      NRA_IND_TIPO_VEH    ,
                      NRA_CLAVE_ID        ,
                      NRA_CLUSTER         ,
                      NRA_ESTADO          ,
                      NRA_TASA            ,
                      NRA_CENTRO_UMO      ,
                      NRA_USERID_UMO      ,
                      NRA_NETNAME_UMO     ,
                      NRA_TIMESTAMP       ,
                      NRA_RATING          ,
                      NRA_RANGO_RATING    ,
                      NRA_GARANTIA        ,
                      NRA_PORCENTA
                 INTO
                      :NRA-TIPO-PRODUCTO   ,
                      :NRA-VARIABLE        ,
                      :NRA-CONSECUTIVO     ,
                      :NRA-FECHA-INI       ,
                      :NRA-FECHA-FIN       ,
                      :NRA-RANGO-INI       ,
                      :NRA-RANGO-FIN       ,
                      :NRA-IND-DOM-NOMINA  ,
                      :NRA-SITUA-LABORAL   ,
                      :NRA-MONTO-INICIAL   ,
                      :NRA-MONTO-FINAL     ,
                      :NRA-SEGMENTO        ,
                      :NRA-IND-CLIENTE-VIP ,
                      :NRA-RANGO-RIESGO-INI,
                      :NRA-RANGO-RIESGO-FIN,
                      :NRA-IND-ESTADO-VEH  ,
                      :NRA-IND-TIPO-VEH    ,
                      :NRA-CLAVE-ID        ,
                      :NRA-CLUSTER         ,
                      :NRA-ESTADO          ,
                      :NRA-TASA            ,
                      :NRA-CENTRO-UMO      ,
                      :NRA-USERID-UMO      ,
                      :NRA-NETNAME-UMO     ,
                      :NRA-TIMESTAMP       ,
                      :NRA-RATING          ,
                      :NRA-RANGO-RATING    ,
                      :NRA-GARANTIA        ,
                      :NRA-PORCENTA
                 FROM UGDTNRA
                WHERE NRA_CLAVE_ID      = :0NRA-CLAVE-ID
                AND   NRA_TIPO_PRODUCTO = :0NRA-TIPO-PRODUCTO
                AND   NRA_VARIABLE      = :0NRA-VARIABLE
                AND   NRA_ESTADO        = :0NRA-ESTADO
                FETCH FIRST 1 ROWS ONLY
           END-EXEC.

           MOVE SQLCODE                    TO WSS-RETURN-CDE

           EVALUATE TRUE
               WHEN WSS-OK
                    INITIALIZE 0NRA-SALIDA
                    MOVE UGTCNRA           TO 0NRA-UGTCNRA
               WHEN WSS-NOTFND
                    MOVE '10'              TO 0NRA-RETORNO
                    MOVE 'ERROR DB2      ' TO 0NRA-DESCERROR
                    MOVE 'UGDTNRA'         TO 0NRA-TABLA
                    MOVE SQLCODE           TO 0NRA-SQL
               WHEN WSS-DUPREC
                    MOVE '20'              TO 0NRA-RETORNO
                    MOVE 'ERROR DB2      ' TO 0NRA-DESCERROR
                    MOVE 'UGDTNRA'         TO 0NRA-TABLA
                    MOVE SQLCODE           TO 0NRA-SQL
               WHEN WSS-NOTOK
                    MOVE '30'              TO 0NRA-RETORNO
                    MOVE 'ERROR DB2      ' TO 0NRA-DESCERROR
                    MOVE 'UGDTNRA'         TO 0NRA-TABLA
                    MOVE SQLCODE           TO 0NRA-SQL
               WHEN OTHER
                    MOVE '90'              TO 0NRA-RETORNO
                    MOVE 'ERROR DB2      ' TO 0NRA-DESCERROR
                    MOVE 'UGDTNRA'         TO 0NRA-TABLA
                    MOVE SQLCODE           TO 0NRA-SQL
           END-EVALUATE.

      *________________________________________________________________*
      *                    INSERTA-UGDTNRA                            *
      *________________________________________________________________*
       2000I1-INSERTA.

           INITIALIZE UGTCNRA

           MOVE 0NRA-UGTCNRA               TO UGTCNRA

           EXEC SQL
               INSERT INTO UGDTNRA
                 ( NRA_TIPO_PRODUCTO   ,
                   NRA_VARIABLE        ,
                   NRA_CONSECUTIVO     ,
                   NRA_FECHA_INI       ,
                   NRA_FECHA_FIN       ,
                   NRA_RANGO_INI       ,
                   NRA_RANGO_FIN       ,
                   NRA_IND_DOM_NOMINA  ,
                   NRA_SITUA_LABORAL   ,
                   NRA_MONTO_INICIAL   ,
                   NRA_MONTO_FINAL     ,
                   NRA_SEGMENTO        ,
                   NRA_IND_CLIENTE_VIP ,
                   NRA_RANGO_RIESGO_INI,
                   NRA_RANGO_RIESGO_FIN,
                   NRA_IND_ESTADO_VEH  ,
                   NRA_IND_TIPO_VEH    ,
                   NRA_CLAVE_ID        ,
                   NRA_CLUSTER         ,
                   NRA_ESTADO          ,
                   NRA_TASA            ,
                   NRA_CENTRO_UMO      ,
                   NRA_USERID_UMO      ,
                   NRA_NETNAME_UMO     ,
                   NRA_TIMESTAMP       ,
                   NRA_RATING          ,
                   NRA_RANGO_RATING    ,
                   NRA_GARANTIA        ,
                   NRA_PORCENTA)
               VALUES
                 (:NRA-TIPO-PRODUCTO   ,
                  :NRA-VARIABLE        ,
                  :NRA-CONSECUTIVO     ,
                  :NRA-FECHA-INI       ,
                  :NRA-FECHA-FIN       ,
                  :NRA-RANGO-INI       ,
                  :NRA-RANGO-FIN       ,
                  :NRA-IND-DOM-NOMINA  ,
                  :NRA-SITUA-LABORAL   ,
                  :NRA-MONTO-INICIAL   ,
                  :NRA-MONTO-FINAL     ,
                  :NRA-SEGMENTO        ,
                  :NRA-IND-CLIENTE-VIP ,
                  :NRA-RANGO-RIESGO-INI,
                  :NRA-RANGO-RIESGO-FIN,
                  :NRA-IND-ESTADO-VEH  ,
                  :NRA-IND-TIPO-VEH    ,
                  :NRA-CLAVE-ID        ,
                  :NRA-CLUSTER         ,
                  :NRA-ESTADO          ,
                  :NRA-TASA            ,
                  :NRA-CENTRO-UMO      ,
                  :NRA-USERID-UMO      ,
                  :NRA-NETNAME-UMO     ,
                  CURRENT TIMESTAMP    ,
                  :NRA-RATING          ,
                  :NRA-RANGO-RATING    ,
                  :NRA-GARANTIA        ,
                  :NRA-PORCENTA)
           END-EXEC.

           MOVE SQLCODE                    TO WSS-RETURN-CDE

           EVALUATE TRUE
               WHEN WSS-OK
                    INITIALIZE 0NRA-SALIDA
               WHEN WSS-NOTFND
                    MOVE '10'              TO 0NRA-RETORNO
                    MOVE 'ERROR DB2      ' TO 0NRA-DESCERROR
                    MOVE 'UGDTNRA'         TO 0NRA-TABLA
                    MOVE SQLCODE           TO 0NRA-SQL
               WHEN WSS-DUPREC
                    MOVE '20'              TO 0NRA-RETORNO
                    MOVE 'ERROR DB2      ' TO 0NRA-DESCERROR
                    MOVE 'UGDTNRA'         TO 0NRA-TABLA
                    MOVE SQLCODE           TO 0NRA-SQL
               WHEN WSS-NOTOK
                    MOVE '30'              TO 0NRA-RETORNO
                    MOVE 'ERROR DB2      ' TO 0NRA-DESCERROR
                    MOVE 'UGDTNRA'         TO 0NRA-TABLA
                    MOVE SQLCODE           TO 0NRA-SQL
               WHEN OTHER
                    MOVE '90'              TO 0NRA-RETORNO
                    MOVE 'ERROR DB2      ' TO 0NRA-DESCERROR
                    MOVE 'UGDTNRA'         TO 0NRA-TABLA
                    MOVE SQLCODE           TO 0NRA-SQL
           END-EVALUATE.

      *________________________________________________________________*
      *                  ACTUALIZA-UGDTNRA                            *
      *________________________________________________________________*
       2000U1-ACTUALIZA.

           INITIALIZE UGTCNRA

           MOVE 0NRA-UGTCNRA               TO UGTCNRA

           EXEC SQL
               UPDATE UGDTNRA
                  SET NRA_TIPO_PRODUCTO    = :NRA-TIPO-PRODUCTO   ,
                      NRA_VARIABLE         = :NRA-VARIABLE        ,
                      NRA_CONSECUTIVO      = :NRA-CONSECUTIVO     ,
                      NRA_FECHA_INI        = :NRA-FECHA-INI       ,
                      NRA_FECHA_FIN        = :NRA-FECHA-FIN       ,
                      NRA_RANGO_INI        = :NRA-RANGO-INI       ,
                      NRA_RANGO_FIN        = :NRA-RANGO-FIN       ,
                      NRA_IND_DOM_NOMINA   = :NRA-IND-DOM-NOMINA  ,
                      NRA_SITUA_LABORAL    = :NRA-SITUA-LABORAL   ,
                      NRA_MONTO_INICIAL    = :NRA-MONTO-INICIAL   ,
                      NRA_MONTO_FINAL      = :NRA-MONTO-FINAL     ,
                      NRA_SEGMENTO         = :NRA-SEGMENTO        ,
                      NRA_IND_CLIENTE_VIP  = :NRA-IND-CLIENTE-VIP ,
                      NRA_RANGO_RIESGO_INI = :NRA-RANGO-RIESGO-INI,
                      NRA_RANGO_RIESGO_FIN = :NRA-RANGO-RIESGO-FIN,
                      NRA_IND_ESTADO_VEH   = :NRA-IND-ESTADO-VEH  ,
                      NRA_IND_TIPO_VEH     = :NRA-IND-TIPO-VEH    ,
                      NRA_CLAVE_ID         = :NRA-CLAVE-ID        ,
                      NRA_CLUSTER          = :NRA-CLUSTER         ,
                      NRA_ESTADO           = :NRA-ESTADO          ,
                      NRA_TASA             = :NRA-TASA            ,
                      NRA_CENTRO_UMO       = :NRA-CENTRO-UMO      ,
                      NRA_USERID_UMO       = :NRA-USERID-UMO      ,
                      NRA_NETNAME_UMO      = :NRA-NETNAME-UMO     ,
                      NRA_TIMESTAMP        = CURRENT TIMESTAMP    ,
                      NRA_RATING           = :NRA-RATING          ,
                      NRA_RANGO_RATING     = :NRA-RANGO-RATING    ,
                      NRA_GARANTIA         = :NRA-GARANTIA        ,
                      NRA_PORCENTA         = :NRA-PORCENTA
                WHERE NRA_CONSECUTIVO   = :NRA-CONSECUTIVO
                AND   NRA_FECHA_INI     = :NRA-FECHA-INI
                AND   NRA_TIPO_PRODUCTO = :NRA-TIPO-PRODUCTO
                AND   NRA_VARIABLE      = :NRA-VARIABLE
           END-EXEC.

           MOVE SQLCODE                    TO WSS-RETURN-CDE

           EVALUATE TRUE
               WHEN WSS-OK
                    INITIALIZE 0NRA-SALIDA
               WHEN WSS-NOTFND
                    MOVE '10'              TO 0NRA-RETORNO
                    MOVE 'ERROR DB2      ' TO 0NRA-DESCERROR
                    MOVE 'UGDTNRA'         TO 0NRA-TABLA
                    MOVE SQLCODE           TO 0NRA-SQL
               WHEN WSS-DUPREC
                    MOVE '20'              TO 0NRA-RETORNO
                    MOVE 'ERROR DB2      ' TO 0NRA-DESCERROR
                    MOVE 'UGDTNRA'         TO 0NRA-TABLA
                    MOVE SQLCODE           TO 0NRA-SQL
               WHEN WSS-NOTOK
                    MOVE '30'              TO 0NRA-RETORNO
                    MOVE 'ERROR DB2      ' TO 0NRA-DESCERROR
                    MOVE 'UGDTNRA'         TO 0NRA-TABLA
                    MOVE SQLCODE           TO 0NRA-SQL
               WHEN OTHER
                    MOVE '90'              TO 0NRA-RETORNO
                    MOVE 'ERROR DB2      ' TO 0NRA-DESCERROR
                    MOVE 'UGDTNRA'         TO 0NRA-TABLA
                    MOVE SQLCODE           TO 0NRA-SQL
           END-EVALUATE.

      *________________________________________________________________*
      *                    ELIMINA-UGDTNRA                            *
      *________________________________________________________________*
       2000D1-ELIMINA.

           INITIALIZE UGTCNRA

           MOVE 0NRA-UGTCNRA               TO UGTCNRA

           EXEC SQL
               DELETE FROM UGDTNRA
                WHERE NRA_CONSECUTIVO   = :NRA-CONSECUTIVO
                AND   NRA_FECHA_INI     = :NRA-FECHA-INI
                AND   NRA_TIPO_PRODUCTO = :NRA-TIPO-PRODUCTO
                AND   NRA_VARIABLE      = :NRA-VARIABLE
           END-EXEC.

           MOVE SQLCODE                    TO WSS-RETURN-CDE

           EVALUATE TRUE
               WHEN WSS-OK
                    INITIALIZE 0NRA-SALIDA
               WHEN WSS-NOTFND
                    MOVE '10'              TO 0NRA-RETORNO
                    MOVE 'ERROR DB2      ' TO 0NRA-DESCERROR
                    MOVE 'UGDTNRA'         TO 0NRA-TABLA
                    MOVE SQLCODE           TO 0NRA-SQL
               WHEN WSS-DUPREC
                    MOVE '20'              TO 0NRA-RETORNO
                    MOVE 'ERROR DB2      ' TO 0NRA-DESCERROR
                    MOVE 'UGDTNRA'         TO 0NRA-TABLA
                    MOVE SQLCODE           TO 0NRA-SQL
               WHEN WSS-NOTOK
                    MOVE '30'              TO 0NRA-RETORNO
                    MOVE 'ERROR DB2      ' TO 0NRA-DESCERROR
                    MOVE 'UGDTNRA'         TO 0NRA-TABLA
                    MOVE SQLCODE           TO 0NRA-SQL
               WHEN OTHER
                    MOVE '90'              TO 0NRA-RETORNO
                    MOVE 'ERROR DB2      ' TO 0NRA-DESCERROR
                    MOVE 'UGDTNRA'         TO 0NRA-TABLA
                    MOVE SQLCODE           TO 0NRA-SQL
           END-EVALUATE.

      *________________________________________________________________*
      *              300000-FINAL                                      *
      *    REALIZAR EL PROCESO DE TERMINACION DEL PROGRAMA             *
      *________________________________________________________________*
       300000-FINAL.

           GOBACK.

      *_____________________ FIN RUTINA ______________________________*